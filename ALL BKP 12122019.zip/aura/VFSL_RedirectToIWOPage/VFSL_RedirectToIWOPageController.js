({
    doInit : function(component, event, helper) {
        var getRecId = component.get("v.recordId");
        var PTFlag = component.get("v.isPTFlag");
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
        componentDef: "c:vfsl_CreateIWOPage",
        componentAttributes: {
            "recordId" : getRecId,
            "isPTFlag" : PTFlag
        }
    });
    evt.fire(); 
    }
})