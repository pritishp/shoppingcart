({ 
    doInit : function(component, event, helper) { 
        component.set("v.processing", true);
        helper.loadInitData (component, event, helper);       
    },
    
    filterCategory: function (cmp, event, helper) {
        cmp.set("v.processing", true);
        var tab = event.getSource();
        var tabname = tab.get('v.id');        
        cmp.set('v.selectedAppCat', tabname);
        cmp.set("v.index", 0);        
        cmp.set("v.startOffset", 1); 
        var catMapList = cmp.get('v.applicatorMapList');
        var allCatList = cmp.get("v.totalApplicatorList");
        console.log('catMapList>>>' +JSON.stringify(catMapList) + ' allCatList>>>' + JSON.stringify(allCatList));
        var totalRecs=0;
        var listofValues;
        if(allCatList && allCatList.length>0){
            if(tabname!= 'All Categories'){             
                if(typeof catMapList.get(tabname)!= "undefined" ){                
                    listofValues= catMapList.get(tabname);                
                    totalRecs = parseInt(listofValues.length);
                }
                else{               
                    cmp.set("v.applicatorList", null);                  
                    cmp.set("v.totalRecs",0);
                    cmp.set('v.index', 0);
                    cmp.set('v.startOffset', 0);
                    cmp.set('v.endOffset', 0);
                    cmp.set("v.noApplicatorsMsg",true);
                    cmp.set("v.processing", false);                
                    return;
                }            
            }
            else{             	
                listofValues = cmp.get("v.totalApplicatorList");                
                totalRecs = parseInt(allCatList.length);           
            } 
            var blockSize = parseInt(cmp.get('v.blockSize'));
            var index = parseInt(cmp.get('v.index'));        
            var startOffset = index + 1;
            var endOffset = index + blockSize;
            if( endOffset >  totalRecs){
                endOffset = totalRecs;
            }
            var totalPageCount = totalRecs / parseInt(cmp.get('v.blockSize'));
            var totalPageRemainder = totalRecs % parseInt(cmp.get('v.blockSize'));
            if( totalPageRemainder > 0 ){
                totalPageCount = totalPageCount + 1;
            }
            cmp.set('v.paginationTotalPageCount', parseInt(totalPageCount));  
            cmp.set('v.startOffset', startOffset);
            cmp.set('v.endOffset', endOffset);
            cmp.set("v.noApplicatorsMsg",false);
            cmp.set("v.totalRecs",totalRecs);
            
            var appListings=[];
            for(var i= index ; i< endOffset; i++) {
                appListings.push(listofValues[i]);
            }
            cmp.set("v.applicatorList",  appListings);
            window.scrollTo(0,0);
            
            for(var i=0; i < appListings.length; i++){                       
                var inventory = appListings[i].inventoryList;
                var inventoryInfo = ''; var totalQuantity = 0;
                var inventoryInfoFinalText = '';                        
                if( inventory.length > 0 ){
                    if( typeof inventory[0] !== 'undefined' ){
                        inventoryInfo += inventory[0].Unrestricted_Quantity__c + ' in ' + inventory[0].Plant_Description__c;
                        totalQuantity += parseInt(inventory[0].Unrestricted_Quantity__c); 
                    }
                    if( typeof inventory[1] !== 'undefined' ){
                        inventoryInfo += '<br />' + inventory[1].Unrestricted_Quantity__c + ' in ' + inventory[1].Plant_Description__c;
                        totalQuantity += parseInt(inventory[1].Unrestricted_Quantity__c); 
                    }
                    inventoryInfoFinalText += 'Total Quantity: ' + totalQuantity + '<br />' + inventoryInfo;                            
                }else{
                    inventoryInfoFinalText = 'No inventory data available.';
                }
                appListings[i]['inventoryInfo'] = inventoryInfoFinalText;                        
            }		
            
            cmp.set("v.processing", false);
            
        }
        else {            
            cmp.set("v.applicatorList", null);
            cmp.set("v.totalApplicatorList", null);
            cmp.set("v.totalRecs",0);
            cmp.set('v.index', 0);
            cmp.set('v.startOffset', 1);
            cmp.set('v.endOffset', 0);
            cmp.set("v.noApplicatorsMsg",true);
            cmp.set('v.paginationTotalPageCount',0);
            cmp.set("v.processing", false);             
        }  
    },    
    filterApps: function (cmp, event, helper) {
        var accountId = component.get('v.selectedAccountRecord.Id') === undefined ? "" : component.get('v.selectedAccountRecord.Id');
        helper.getFilteredProducts(cmp, event, accountId);
    },     
    appDetailMouseOver: function(component, event, helper) {        
        var items = component.find("hover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    appDetailMouseOut: function(component, event, helper) {        
        var items = component.find("hover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    disabledCartMouseOver: function(component, event, helper) {        
        var items = component.find("disabledCartPopover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },    
    disabledCartMouseOut: function(component, event, helper) {        
        var items = component.find("disabledCartPopover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    inventoryMouseOver: function(component, event, helper) {        
        var items = component.find("inventoryInfoPopover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');       
    },    
    inventoryMouseOut: function(component, event, helper) {        
        var items = component.find("inventoryInfoPopover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');        
    },
    nextPage:function(component, event, helper) {        
        var totalRecs = parseInt(component.get('v.totalRecs'))
        var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));       
        var nextIndex = index + blockSize;                
        if((index + blockSize) >= totalRecs){
            return false;
        }
        component.set("v.index", nextIndex);
        var list = document.getElementsByClassName('paginationPageInput');
        for (var n = 0; n < list.length; ++n) {
            list[n].value='';
        }        
        helper.nextPage(component, totalRecs, blockSize, nextIndex);
    },
    prevPage:function(component, event, helper) {        
        var totalRecs = parseInt(component.get('v.totalRecs'))
        var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));    
        var prevIndex = index - blockSize;
        if (prevIndex < 0){
            prevIndex = 0;
            return false;
        } 
        
        component.set("v.index", prevIndex);
        var list = document.getElementsByClassName('paginationPageInput');
        for (var n = 0; n < list.length; ++n) {
            list[n].value='';
        }        
        helper.nextPage(component, totalRecs, blockSize, prevIndex);
    },
    keyPressPaginationInput: function(component, event, helper){
        //console.log(event.target.value);        
        var inputVal = parseInt(event.target.value);
        var totalPageCount = parseInt(component.get('v.paginationTotalPageCount'));
        var blockSize = parseInt(component.get('v.blockSize'));
        if( inputVal > 0 && inputVal <= totalPageCount){
            var index = (inputVal - 1 ) * blockSize;
            component.set('v.index', index);
            var list = document.getElementsByClassName('paginationPageInput');
            for (var n = 0; n < list.length; ++n) {
                list[n].value=inputVal;
            } 
            var accountId = component.get('v.selectedAccountRecord.Id') === undefined ? "" : component.get('v.selectedAccountRecord.Id');
            helper.getFilteredProducts(component, event, accountId);
        }        
    },
    handleApplicationEvent : function(component, event, helper) {       
        var message = event.getParam("searchedName");        
        component.set("v.appNameFromEvent", message);        
        var accountId = component.get('v.selectedAccountRecord.Id') === undefined ? "" : component.get('v.selectedAccountRecord.Id');
        helper.getFilteredProducts(component, event, accountId);
    },
    
    AddToCart : function (component, event, helper) {
        helper.addToCart(component, event, helper);
    },
    openFilters: function (component, event, helper) {       
        document.getElementById("sidenavFilterList").style.width = "305px";
        document.getElementById("backgroundOverlay").style.display = "block";        
    },
    closeFilters: function (component, event, helper) {
        document.getElementById("sidenavFilterList").style.width = "0";  
        document.getElementById("backgroundOverlay").style.display = "none"; 
    },
    searchByAccount: function (component, event, helper) {
        helper.searchByAccount(component, event,helper);
    },
    searchByContact: function (component, event, helper) {
        helper.searchByContactInfo(component, event,helper);
    },
    onfocusAccountNameLookup : function(component,event,helper){
        $A.util.addClass(component.find("spinnerAccountNameLookup"), "slds-show");
        $A.util.removeClass(component.find("spinnerAccountNameLookup"), "slds-show");
        var forOpen = component.find("searchResultAccountNameLookup");
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');        
        var getInputkeyWord = '';
        helper.searchHelperAccountNameLookup(component,event,getInputkeyWord);
    },
    onblurAccountNameLookup : function(component,event,helper){       
        component.set("v.listOfSearchAccountRecords", null );
        var forclose = component.find("searchResultAccountNameLookup");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    keyPressAccountNameLookup : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchAccountKeyWord");          
        if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchResultAccountNameLookup");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelperAccountNameLookup(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchAccountRecords", null ); 
            var forclose = component.find("searchResultAccountNameLookup");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    },
    clearAccountNameLookup :function(component,event,heplper){
        var pillTarget = component.find("lookup-pill-accountName");
        var lookUpTarget = component.find("lookupFieldAccountName"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');      
        component.set("v.searchAccountKeyWord",null);
        component.set("v.listOfSearchAccountRecords", null );
        component.set("v.selectedAccountRecord", {} );   
    },
    selectRecordAccountNameLookup : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfSearchAccountRecords")[index]; // Use it retrieve the store record
        component.set("v.selectedAccountRecord" , selectedRecord);        
        
        var forclose = component.find("lookup-pill-accountName");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        var forclose = component.find("searchResultAccountNameLookup");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupFieldAccountName");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show'); 
        
    },
    onfocusContactNameLookup : function(component,event,helper){
        $A.util.addClass(component.find("spinnerContactNameLookup"), "slds-show");
        $A.util.removeClass(component.find("spinnerContactNameLookup"), "slds-show");
        var forOpen = component.find("searchResultContactNameLookup");
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');
        // Get Default 5 Records order by createdDate DESC  
        var getInputkeyWord = '';
        helper.searchHelperContactNameLookup(component,event,getInputkeyWord);
    },
    onblurContactNameLookup : function(component,event,helper){       
        component.set("v.listOfSearchContactRecords", null );
        var forclose = component.find("searchResultContactNameLookup");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    keyPressContactNameLookup : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchContactKeyWord");          
        if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchResultContactNameLookup");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelperContactNameLookup(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchContactRecords", null ); 
            var forclose = component.find("searchResultContactNameLookup");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    },
    clearContactNameLookup :function(component,event,heplper){
        var pillTarget = component.find("lookup-pill-contactName");
        var lookUpTarget = component.find("lookupFieldContactName"); 
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        component.set("v.searchContactKeyWord",null);
        component.set("v.listOfSearchContactRecords", null );
        component.set("v.selectedContactRecord", {} );   
    },
    selectRecordContactNameLookup : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfSearchContactRecords")[index]; // Use it retrieve the store record
        component.set("v.selectedContactRecord" , selectedRecord);
        var forclose = component.find("lookup-pill-contactName");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        var forclose = component.find("searchResultContactNameLookup");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupFieldContactName");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');      
    },
    openSearchAccountModal: function(component, event, helper) {
        component.set('v.indexAccountSearch',0);
        component.set("v.searchAccountInputValue","");
        component.set("v.accountAfterLoader","");
        helper.getAccounts(component, event, helper);
        component.set("v.accountSearchModalOpen", true);
    },
    closeSearchAccountModal: function(component, event, helper) { 
        component.set("v.accountSearchModalOpen", false);
    },
    openSearchContactModal: function(component, event, helper) { 
        component.set("v.searchContactInputValue","");
        helper.getContacts(component, event, helper);
        component.set("v.contactSearchModalOpen", true);
    },
    closeSearchContactModal: function(component, event, helper) { 
        component.set("v.contactSearchModalOpen", false);
    },
    keyPressAccountNameSearch : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchAccountInputValue");        
        component.set('v.indexAccountSearch',0);
        helper.getAccounts(component, event, helper);
    },
    keyPressContactNameSearch : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchContactInputValue");             
        helper.getContacts(component, event, helper);                
    },
    selectRecordAccountNameSearch : function(component, event, helper) {      
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfAccountRecords")[index]; // Use it retrieve the store record
        var currentSelectedAccount = component.get("v.selectedAccountRecord");
        component.set("v.newAccountRecord" , selectedRecord); 
        component.set("v.isSelectedAccount" , true);
        var cartCount = component.get("v.cartCount");        
        if( (currentSelectedAccount != null) && ( typeof currentSelectedAccount.Id !== 'undefined' ) && (currentSelectedAccount.Id !=  selectedRecord.Id) && (cartCount > 0) ){
            helper.closeSearchAccountModal(component, event,helper);
            component.set("v.cartDeleteModalOpen", true); 
        }    
        else{    
            component.set("v.selectedAccountRecord" , selectedRecord);
            component.set("v.isAccSelectedByInternalUser" , true);            
            component.set("v.objAccount" , selectedRecord);
            component.set("v.selectedContactRecord" , null);
            component.set("v.totalRecs",0);
            component.set('v.index', 0);
            component.set('v.startOffset', 0);
            component.set('v.endOffset', 0);
            component.set('v.paginationTotalPageCount',0);
            helper.addAccountToCart(component, event, helper);            
            if( typeof selectedRecord !== 'undefined' ){
                var accId = selectedRecord.Id;        		
                helper.getSupportedModelType(component,event,helper,accId);
                helper.searchByAccount(component, event,helper);
            }    
        }		         
    },
    nextAccountSearch:function(component, event, helper) {        
        var totalAccountsCount = parseInt(component.get('v.totalAccountsCount'))
        var blockSizeAccountSearch = parseInt(component.get('v.blockSizeAccountSearch'));
        var indexAccountSearch = parseInt(component.get('v.indexAccountSearch'));
        var nextIndex = indexAccountSearch + blockSizeAccountSearch; 
        if((indexAccountSearch + blockSizeAccountSearch) >= totalAccountsCount){
            return false;
        }        
        component.set("v.indexAccountSearch", nextIndex);             
        helper.getAccounts(component, event, helper);
    },
    prevAccountSearch:function(component, event, helper) { 
        var blockSizeAccountSearch = parseInt(component.get('v.blockSizeAccountSearch'));
        var indexAccountSearch = parseInt(component.get('v.indexAccountSearch'));    
        var prevIndex = indexAccountSearch - blockSizeAccountSearch;
        if (prevIndex < 0){
            prevIndex = 0;
            return false;
        }        
        component.set("v.indexAccountSearch", prevIndex);                
        helper.getAccounts(component, event, helper);
    },
    openSearchProductModal: function(component, event, helper) {         
        component.set("v.productSearchModalOpen", true);
    },
    closeSearchProductModal: function(component, event, helper) { 
        component.set("v.productSearchModalOpen", false);
    },
    selectRecordContactNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var accId= component.get("v.selectedAccountRecord.Id");       
        var selectedRecord = component.get("v.listOfContactRecords")[index]; // Use it retrieve the store record       
        component.set("v.selectedContactRecord" , selectedRecord); 
        component.set("v.selectedAccountRecord" , selectedRecord.Account);
        if(typeof accId === 'undefined'){
            helper.searchByContactInfo(component, event,helper);
            helper.addAccountToCart(component, event, helper);
        }
        else
            helper.closeSearchContactModal(component, event,helper);
    },
    onAfterLoaderChange: function(component, event, helper) {
        var selectedVal = component.find("afterLoaderSelect").get('v.value');  
    },
    afterLoaderSearch: function(component, event, helper) {
        var afterLoader ='';
        if(component.find("afterLoaderSelect"))
            var afterLoader = component.find("afterLoaderSelect").get('v.value');        
        if(afterLoader !== ''){               
            component.set('v.selectedAfterLoader',afterLoader);
            var accountId = component.get('v.selectedAccountRecord.Id') === undefined ? "" : component.get('v.selectedAccountRecord.Id');
            helper.getFilteredProducts(component, event, accountId);
            component.set("v.productSearchModalOpen", false);
            component.find("categoryTab").set("v.selectedTabId",'All Categories');
        }
    },
    
    resetAfterLoader: function(component, event, helper) {
        component.set('v.selectedAfterLoader','');
        var accountId = component.get('v.selectedAccountRecord.Id') === undefined ? "" : component.get('v.selectedAccountRecord.Id');
        helper.getFilteredProducts(component, event, accountId);
    },
    openCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", true);
    },
    closeCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", false);
    },
    removeCart: function(component, event, helper) {        
        var newSelectedRecord = component.get("v.newAccountRecord");
        component.set("v.selectedAccountRecord" , newSelectedRecord);
        component.set("v.objAccount" , newSelectedRecord);
        component.set("v.cartDeleteModalOpen", false);
        helper.deleteCartItem(component, event,helper);
    },
    resetAccount: function(component, event, helper) {        
        var cartCount = component.get("v.cartCount");
        if( cartCount > 0 ){
            component.set('v.accResetCartDeleteModalOpen', true);
        }else{
            var accResetRemoveCart = component.get('c.accResetRemoveCart');
            $A.enqueueAction(accResetRemoveCart);
        }
    },
    closeAccResetCartDeleteModal: function(component, event, helper) {
        component.set('v.accResetCartDeleteModalOpen', false);
    },
    accResetRemoveCart: function(component, event, helper) {
        component.set("v.selectedAccountRecord" , {});
        component.set("v.objAccount" , null);
        component.set("v.selectedContactRecord" , {});
        component.set("v.selectedAfterLoader" , '');
        component.set("v.accountAfterLoader" , '');
        component.set('v.accResetCartDeleteModalOpen', false);
        component.set('v.selectedAppCat', 'All Categories');
        helper.resetAccountInfo(component, event,helper);
        component.find("categoryTab").set("v.selectedTabId",'All Categories');
    },
    itemAddedToCart: function(component, event, helper) {
        component.set("v.cartCount", 1);
    },	
    getAccountVal: function (component, event){        
        var accInfo = event.getParam("recordId");       
        component.set("v.objAccount", accInfo);        
    },    
    getFilteredProducts :function(component, event, helper) {
        var params = event.getParam('arguments');
        if (params) {
            var accId = params.accId;
            helper.getFilteredProducts(component,event, accId);
        }
    },
    
    clearAfterLoaderforAccount : function(component, event, helper) {   
        var selectedRecord = component.get("v.selectedAccountRecord");
        if( typeof selectedRecord !== 'undefined' ){
            var clearAfterLoaderAccId = selectedRecord.Id;
            if( component.find("clearAfterLoaderCB").get("v.value") ){  
                component.set("v.clearAfterLoader" , true);               
                helper.getSupportedModelType(component,event,helper,clearAfterLoaderAccId);            
            }          
            else{            
                component.set("v.clearAfterLoader" , false);              
                helper.getSupportedModelType(component,event,helper,clearAfterLoaderAccId);            
            }	
        }
    },
})