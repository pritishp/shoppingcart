({
	doInit : function(component, event, helper) {
        console.log('inside training student doinit');
		helper.getUrlParameter(component, event);
        helper.getCustomLabels(component, event);
	},
    
    sumitSignUp : function(component, event, helper) {
        helper.doSignUp(component, event, helper);
    }
})