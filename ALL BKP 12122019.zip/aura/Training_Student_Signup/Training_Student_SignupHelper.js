({
	getUrlParameter : function(component, event) {
        var getUrlParameter = function getUrlParameter(sParam,fParam,woId) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i,
                data = {};
            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');
                if (sParameterName[0] === sParam) {
                    data.lang = sParameterName[1] === undefined ? true : sParameterName[1];
                }
                else if (sParameterName[0] === fParam){
                    data.ext = sParameterName[1] === 'true' ? true : false;
                }
                else if (sParameterName[0] === woId){
                    data.woId = sParameterName[1];
                }
            }
            return data;
        };
        var bdata =  getUrlParameter('lang','ext','woId');
        component.set("v.isExternalUserParam",bdata.ext);
        var data = component.get("v.signUpData");
        
        if( typeof bdata.woId !== 'undefined' ){
            if( bdata.woId.startsWith("0WO") ){            
                component.set('v.isStandradWorkOrder', true);
                data.WorkOrder__c = bdata.woId;
            }else{           
                component.set('v.isStandradWorkOrder', false);
                data.Work_Order__c = bdata.woId;
            }
            data.WO_ID__c = bdata.woId;
        }
        component.set("v.signUpData",data);
		component.set("v.language",bdata.lang);
    },

    /* Load custome labels */
    getCustomLabels : function(component, event) {
        var action = component.get("c.getCustomLabelMap");
        action.setParams({"languageObj":component.get("v.language")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set("v.customLabelMap",response.getReturnValue());
            }else if(response.getState() == "ERROR"){
                $A.log("callback error", response.getError());
            }      
        } );
        $A.enqueueAction(action);
    },

    /* Load custome labels */
    doSignUp : function(component, event,helper) {
        //debugger;
        var data = component.get("v.signUpData");
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var firstName = component.find("firstName").get("v.value");
        var lastName = component.find("lastName").get("v.value");
        var email = component.find("email").get("v.value");
        var phone = component.find("phone").get("v.value");
        var comments = component.find("comments").get("v.value");
        
        if(firstName == null || email == null || !email.match(regExpEmailformat) ||
          lastName == null || phone == null){
            component.set("v.valMessage",'Please fill all required fields with correct format.');
            return;
        }else{
            data.First_Name__c  = firstName;
            data.Last_Name__c  = lastName;
            data.Email__c  = email;
            data.Phone__c  = phone;
            data.Comments__c= comments;
           
            component.set("v.valMessage",'');
        }
        
        var isStandradWorkOrder = component.get('v.isStandradWorkOrder');
        
        var action = component.get("c.saveSignUp");
        action.setParams(
            {
                "tSignUp":data, 
                "isStandradWorkOrder": isStandradWorkOrder
            }
        );
        action.setCallback(this, function(response) {
            debugger;
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set("v.isSuccess",response.getReturnValue());
                component.set("v.message",'Success');
            }else if(response.getState() == "ERROR"){
                $A.log("callback error", response.getError());
                component.set("v.isSuccess",false);
                console.log('error==='+response.getError());
                component.set("v.message",response.getError()[0].message);
            }      
        } );
        $A.enqueueAction(action);
    },
})