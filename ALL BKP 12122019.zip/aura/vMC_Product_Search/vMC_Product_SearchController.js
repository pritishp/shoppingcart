({
	doInit : function(component, event, helper) {
		component.set("v.processing", true);
        helper.getURLParameters (component, event, helper);
        helper.setBreadCrumbs (component, event, helper);
        helper.getProducts (component, event, helper);        
	},
    fetchCurrencyValue : function (component, event) {        
        component.set("v.conversionRate", event.getParam("conversionRate")); 
        component.set("v.currencyISOCode", event.getParam("selectedCurrency"));
    },
    AddToCart : function (component, event, helper) {
        helper.addToCart(component, event, helper);
    },
    onKeypressProductQtyBox: function (component, event, helper) {       
        var inputValue = event.target.value;        
        var regExTest = /^[0-9]+$/.test(inputValue);        
        if( !regExTest || parseInt(inputValue) === 0 ){
            event.target.value = '';
        }        
    }
})