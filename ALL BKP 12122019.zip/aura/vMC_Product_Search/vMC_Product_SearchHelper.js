({
	getURLParameters : function (component, event, helper) {        
        // the function that reads the url parameters
        var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;
            
            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');
                
                if (sParameterName[0] === sParam) {
                    return sParameterName[1] === undefined ? true : sParameterName[1];
                }
            }
        };
        
        //set the src param value to my src attribute
        if(getUrlParameter('searchKeyword')) {
            component.set("v.searchKeyword", getUrlParameter('searchKeyword'));
        }
        if(getUrlParameter('productModel')) {
            var productModel = getUrlParameter('productModel');
            component.set("v.productModel", productModel);            
            if(productModel == 'all'){
            	component.set("v.productModelStr", 'All');    
            }else if(productModel == 'thirdPartyApps'){
            	component.set("v.productModelStr", 'Third Party');    
            }else{
                component.set("v.productModelStr", getUrlParameter('productModel'));
            }
        }
    },
    setBreadCrumbs : function (component, event, helper) {
        var breadcrumbCollection = [
            {label: 'Home', name: 'Brachy' },
            {label: 'Product Search', name: '' }
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },
    getProducts : function (component, event, helper) {
        const accountPromise = this.getAccountDetails(component, event, helper);
        accountPromise.then(function(response){
            //alert(JSON.stringify(response));            
            var searchKeyword = component.get('v.searchKeyword');
            var productModel = component.get('v.productModel');
            var accountId = component.get('v.objAccount.Id');
            var isInternalUser = component.get('v.isInternalUser'); 
            var userCountry = component.get('v.objAccount.ISO_Country__c');
            console.log('get Products ISO_Country__c',component.get('v.objAccount.ISO_Country__c'));
            if( typeof accountId === 'undefined' ){
                accountId = '';
            }
            if(searchKeyword.length > 0 && productModel.length > 0){
                var action = component.get("c.fetchProducts"); 
                action.setParams({
                    'searchKeyword': searchKeyword.trim(),
                    'productModel': productModel.trim(),
                    'accountId': accountId,
                    'isInternalUser': isInternalUser,
                    'userCountry': userCountry
                });      
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    console.log('state',state);
                    if (state === "SUCCESS") {
                        var result = response.getReturnValue();   
                        console.log('result',result);
                        var vmipCatalog = JSON.parse(result.vmipCatalog);                        
                        var vmtpApp = JSON.parse(result.vmtpApp);
                        component.set('v.productsListThirdParty', vmtpApp);
                        console.log('vmipCatalog',vmipCatalog);                        
                        console.log('vmtpApp',vmtpApp);
                        
                        var productsMap = {};
                        for( var i=0; i<vmipCatalog.length; i++ ){                        
                            if( vmipCatalog[i].isMCM != 'false' ){
                                var productModel = vmipCatalog[i].vmipCatalogObj.Product_Model__c;
                                if( !productsMap.hasOwnProperty(productModel) ){
                                    productsMap[productModel] = [];
                                }                        
                                productsMap[productModel].push(vmipCatalog[i]);
                            }
                        }
                        console.log(productsMap);
                        
                        var productsList = [];
                        for ( var key in productsMap ) {
                            productsList.push({productModel:key, products:productsMap[key]});
                        }
                        console.log('productsList', productsList);
                        component.set('v.productsList', productsList);
                        
                        var internaluser = component.get('v.isInternalUser');
                        if( ( productsList.length == 0 && vmtpApp.length == 0 )  || ( internaluser && vmipCatalog.length == 0 ) ){
                            document.querySelector(".noProductsMsg").style.display = 'block';
                        }
                        component.set("v.processing", false);                    
                    }
                });
                $A.enqueueAction(action);	
            }          
        }, function(error){
            //alert(error);
        });        
        return false;             
    },
    getAccountDetails : function(component,event,helper) {
        return new Promise(function(resolve, reject) {
            var action = component.get("c.getAccountDetails"); 
            action.setCallback(this, function(a) {
                var state = a.getState(); 
                //alert('getAccountDetails state'+state);
                if (state === "SUCCESS") {                  
                    var result = a.getReturnValue();            
                    var sizeObj = Object.keys(result).length;                    
                    if(sizeObj > 0) {
                        component.set("v.isInternalUser",false);
                        component.set("v.objAccount", result); 
                        resolve(result);
                    } else {
                        component.set("v.isInternalUser",true);
                        //check if Cart has account
                        //helper.getAccountFromCart(component,event,helper);                        
                        var actionGetAccountFromCart = component.get("c.getAccountFromCart"); 
                        actionGetAccountFromCart.setCallback(this, function(a) {
                            var state2 = a.getState();
                            if (state2 === "SUCCESS") {
                               var result2 = a.getReturnValue();                            
                            	var accObj = JSON.parse(result2[0]);                       
                            	var sizeObj = Object.keys(accObj).length;                         
                                component.set("v.objAccount", accObj);                                    
                                resolve(accObj);                                                          	                                 
                            }                            
                        }); 
                        $A.enqueueAction(actionGetAccountFromCart);                         
                    }                                    
                } else {
                    reject(new Error(a.getError()));
                }         
            });
            $A.enqueueAction(action);
        });    
    },
    getAccountFromCart: function(component,event,helper) {
        var action = component.get("c.getAccountFromCart"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            console.log(JSON.stringify(result));
            var accObj = JSON.parse(result[0]);                       
            var sizeObj = Object.keys(accObj).length;
            if(sizeObj > 0) {
                component.set("v.objAccount", accObj);                
            }  
            console.log('Account obj from cart', JSON.stringify(component.get("v.objAccount"))); 
        }); 
        $A.enqueueAction(action);        
    },
    addToCart : function (component, event, helper) {                
        var ctarget = event.currentTarget;
        var productType = ctarget.dataset.prodtype;
        var accountId = component.get('v.objAccount.Id');
        
        if(typeof accountId === 'undefined' || accountId == null){
            helper.handleShowToast(component, event, helper, 'Account not selected. Please select Account from filter panel!','Error', 'Error');
            return false;
        }
        
        if( productType == 'varianProduct' ){   
       
            var productmodel = ctarget.dataset.productmodel;
            var productId = ctarget.dataset.productid;
            var unitPrice = ctarget.dataset.unitprice;
            var productDiscount = ctarget.dataset.productdiscount;            
            var index = parseInt(ctarget.dataset.index);        
            var quantityInputClass = '.' + productmodel + '-productQtyBox';        
            var quantity = parseInt(document.querySelectorAll(quantityInputClass)[index].value);
        
            console.log('productmodel',productmodel);
            console.log('productId',productId);
            console.log('unitPrice',unitPrice);
            console.log('productDiscount',productDiscount);
            console.log('accountId',accountId);
            console.log('quantity',quantity);
        
            var action = component.get("c.addCartItem");
            action.setParams ({
                productId: productId,
                quantity: quantity,
                prodDiscount : productDiscount,
                unitPrice : unitPrice,
                accountId: accountId,
                contactId: '',
                productModel : productmodel          
            }); 
            
        }else if( productType == 'thirdPartyApp' ){
            var appId = ctarget.dataset.appid;
			var unitPrice = ctarget.dataset.unitprice;            
            console.log('appId',appId);
            console.log('accountId',accountId);
            var action = component.get("c.addCartItemThirdPaty");
            action.setParams ({
                appId: appId,
                quantity: 1,
                accountId: accountId,
                contactId: '',
                unitPrice:unitPrice
        	});
        }
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var msg = response.getReturnValue();
                var variant;
                if(msg.includes('Success')) {
                    variant = 'Success';                    
                } else if(msg.includes('Exception')){
                    variant = 'Error';   
                } else {
                    variant = 'Info';
                    
                }
                helper.handleShowToast(component, event, helper, msg,variant,variant);
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();                
            }
            else {
                helper.handleShowToast(component, event, helper, 'Exception Occurred !','Error', 'Error');
            }
        });
        $A.enqueueAction(action);        
    },
    handleShowToast : function(component, event, helper, msg, variant,title) {
        component.find('notifLib').showToast({
            "title": title,
            "message": msg,
            "variant" : variant
        });
    },
})