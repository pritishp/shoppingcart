({
    /*method to get content of page when FAQ is clicked on screen */
	getPageContent : function(component, event, helper) {
        helper.getPageContent (component, event, helper);
	}
})