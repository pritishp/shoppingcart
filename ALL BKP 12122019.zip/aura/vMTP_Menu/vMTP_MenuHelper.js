({
    /*method to get content of page when FAQ is clicked on screen */
	getPageContent : function(component, event, helper) {
        var action = component.get("c.getvMarketFAQContent");
		action.setParams({ 
            type : component.get("v.pageTitle") 
        });
		action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.pageContent", response.getReturnValue());
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        
                    }
                } else {
                    
                }
            }
        });
        
        $A.enqueueAction(action);
	},
})