({
	helperMethod : function() {
	},

    validateEmail : function(component, event) {
    	var emailInput = component.find("userNameId").get("v.value");
    	//alert('emailInput = ' + emailInput);
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        /*
        if(emailInput == null || !emailInput.match(regExpEmailformat) 
        	|| $A.util.isEmpty(emailInput) ){ */

        if(!emailInput.match(regExpEmailformat)){ 
            return false;
        }else{
            return true;
        }    
    }, 	

    loginCall : function(component, event) {
        component.set("v.errorFound", false);
        component.set("v.errorMessage", '');
        component.set("v.divHeight", 490);

        var username = component.find("userNameId").get("v.value");
        var pwd = component.find("passwordId").get("v.value");

        if($A.util.isEmpty(username) && $A.util.isEmpty(pwd)) {
            component.set("v.errorFound", true);
            component.set("v.errorMessage", "Username and Password is required.");
            component.set("v.divHeight", 500);
            return;
        }

        if($A.util.isEmpty(username)) {
            component.set("v.errorFound", true);
            component.set("v.errorMessage", "Username is required.");
            component.set("v.divHeight", 500);
            return;
        }

        var validEmailRtrn = this.validateEmail(component, event, username);

        if(validEmailRtrn == false) {
            component.set("v.errorFound", true);
            component.set("v.errorMessage", "Email address is not valid");
            component.set("v.divHeight", 500);
            return;
        }       

        if($A.util.isEmpty(pwd)) {
            component.set("v.errorFound", true);
            component.set("v.errorMessage", "Password is required.");
            component.set("v.divHeight", 500);
            return;
        }

        
        //var b = component.get("c.validateform");
        //$A.enqueueAction(b);
        var username = component.find("userNameId").get("v.value");
        var password = component.find("passwordId").get("v.value");

        var action = component.get("c.loginCommunity");
        var startUrl = component.get("v.startUrl");        
        // startUrl = decodeURIComponent(startUrl);
        action.setParams({username:username, password:password, startURL:startUrl});
        action.setCallback(this, function(a){
            var rtnUrl = a.getReturnValue();
        //    alert('rtnValue = ' + rtnUrl);
            if(rtnUrl == 'Authentication failed') {
                var authErrorLabel = $A.get("$Label.c.vMarket_Authentication_Error");
                component.set("v.errorMessage",authErrorLabel);
                component.set("v.showError",true);
                component.set("v.errorFound", true);
            } else {
                var urlEvent = $A.get("e.force:navigateToURL");
                var urlLabel = $A.get("$Label.c.Varian_Marketplace_Url");
                //var url = urlLabel + 'vmtp-landing';
                var url =rtnUrl;
                //alert('urlLabel = ' + urlLabel);                
                //alert('urlEvent = ' + urlEvent);
                urlEvent.setParams({
                    //https://sfdev1-varian.cs62.force.com/varianMarketPlace/s
                   // "url": rtnUrl + '?ifAuthenticated='+component.get("v.isAuthenticated"),
                    "url" : url,
                });
              //  urlEvent.fire();
              
                var appEvent = $A.get("e.c:vMTP_UserDetailsEvent");
                appEvent.setParams({
                    "isAuthenticated" : component.get("v.isAuthenticated"),
                });
                appEvent.fire();
                window.open(rtnUrl, '_self');
                /* window.open(rtnUrl, '_self');
                if (rtnValue !== null) {
                    component.set("v.errorMessage",rtnValue);
                    component.set("v.showError",true);
                    component.set("v.errorFound", true);
                }*/
            }
        });
        $A.enqueueAction(action);  
    },
    
    ifValidUser : function (component, event, helper) {
        var action = component.get("c.getLoggedInUserDetails");
         action.setCallback(this, function(a){
            var rtnUrl = a.getReturnValue();
             component.set("v.isAuthenticated", rtnUrl.ifAuthenticated);
         });
        $A.enqueueAction(action);
    },
    
    getUrlParameter : function() {
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
       console.log('sPageURL ->' +sPageURL);
        var sURLVariables = sPageURL.split('&');
        console.log('sPageURL split ->' +sURLVariables);
        var sParameterName = [];
        var i;
        if(sURLVariables.length > 0){
            console.log('sURLVariables 0 ->' +sURLVariables[0]);
             sParameterName = sURLVariables[0].split(/=(.+)/)[1];
             return sParameterName === undefined ? '' : sParameterName;
          
        }
        
        return '';
    },
})