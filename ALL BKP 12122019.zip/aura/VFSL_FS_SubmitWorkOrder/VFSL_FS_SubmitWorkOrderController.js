({
    doInit: function(component, event, helper) {
        helper.populateWOFieldValues(component);
        helper.setUserTimezone(component);
    },
    searchActivity: function(component, event, helper) {
        var data = component.get("v.activityList"),
            term = component.get("v.activityFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.LineItemNumber) || regex.test(row.Asset_Name__c) || regex.test(row.Activity_Type__c) || regex.test(row.Billing_Type__c));
        } catch (e) {}
        component.set("v.filteredActivityList", results);
    },
    searchPart: function(component, event, helper) {
        var data = component.get("v.partList"),
            term = component.get("v.partFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.lineNumber) || regex.test(row.lineType) || regex.test(row.installedPart) || regex.test(row.asset));
        } catch (e) {}
        component.set("v.filteredPartList", results);
    },
    searchtools: function(component, event, helper) {
        var data = component.get("v.toolsList"),
            term = component.get("v.toolsFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.lineNumber) || regex.test(row.toolName) || regex.test(row.toolType) || regex.test(row.serialNumber));
        } catch (e) {}
        component.set("v.filteredtoolsList", results);
    },
    searchRemainingPart: function(component, event, helper) {
        var data = component.get("v.remPartsList"),
            term = component.get("v.remainingPartFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.partName) || regex.test(row.partNumber) || regex.test(row.installedQty) || regex.test(row.remainingQty));
        } catch (e) {}
        component.set("v.filteredRemPartsList", results);
    },
    searchRemovedPart: function(component, event, helper) {
        var data = component.get("v.removedPartsList"),
            term = component.get("v.removedPartFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.lineNumber) || regex.test(row.productName) || regex.test(row.productCode) || regex.test(row.lineQuantity));
        } catch (e) {}
        component.set("v.filteredRemovedPartsList", results);
    },
    searchRemovedPartReq: function(component, event, helper) {
        var data = component.get("v.removedPartsReqList"),
            term = component.get("v.removedPartReqFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.lineNumber) || regex.test(row.productName) || regex.test(row.productCode) || regex.test(row.lineQuantity));
        } catch (e) {}
        component.set("v.filteredRemovedPartsReqList", results);
    },
    searchPartsRemoved: function(component, event, helper) {
        var data = component.get("v.partsRemovedList"),
            term = component.get("v.partRemovedFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.lineItem) || regex.test(row.lineProdName) || regex.test(row.lineProdCode) || regex.test(row.lineSN));
        } catch (e) {}
        component.set("v.filteredpartsRemovedList", results);
    },
    submitWorkOrder: function(component, event, helper) {
        var isValid = helper.validate(component);
        if (isValid) {
            // Submit Inst WO Logic
            helper.submitWO(component);
        }
    },
    submitWorkOrderFromWarning: function(component, event, helper) {
        helper.submitWO(component);
        component.set("v.toolWarning", false);

    },
    closeModal: function(component, event, helper) {
      // Set isModalOpen attribute to false  
      component.set("v.toolWarning", false);
   },
    cancelWorkOrder: function(component, event, helper) {
        // Cancel Submit Inst WO Logic
        helper.redirectWOPage(component);
    },
    // common reusable function for toggle sections
    toggleSection: function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open');

        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if (sectionState == -1) {
            sectionDiv.setAttribute('class', 'slds-section slds-is-open');
        } else {
            sectionDiv.setAttribute('class', 'slds-section slds-is-close');
        }
    },
    dateChange: function(component, event, helper) {
        component.set("v.workOrderObj.Machine_Release__c", event.getParam("value"));
    }
    
})