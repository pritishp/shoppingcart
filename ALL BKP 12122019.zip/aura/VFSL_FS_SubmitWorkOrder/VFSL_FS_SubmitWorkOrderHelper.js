({
    setUserTimezone:  function(component) {
        var action = component.get("c.getCurrentTimezoneKey");

        var self = this;
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            component.set("v.timeZoneKey", result);
            console.log("Timezone Key==============" + result);
        });
        $A.enqueueAction(action);
    },
    populateWOFieldValues: function(component) {
        var action = component.get("c.getWORecord");
        console.log("case record id: " + component.get("v.recordId"));
        action.setParams({
            recordId: component.get("v.recordId")
        });
        var self = this;
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            if (result.isMessage === false) {
                console.log('result.ServiceCount: ' + result.workOrder.Test_Required__c);
                component.set("v.workOrderObj", result.workOrder);
                component.set("v.activeLineItems", result.activeLineItems);
                // Activity Tab
                component.set("v.activityList", result.activityLineItems);
                component.set("v.filteredActivityList", result.activityLineItems);
                
                if(result.latestWoliEndDate) 
                    component.set("v.machineRelease", result.latestWoliEndDate);
                
                if(result.workOrder.Machine_Release__c) {
                    component.set("v.machineRelease", result.workOrder.Machine_Release__c);
                }
                
                component.set("v.partList", result.partsInstalledLineItems);
                component.set("v.filteredPartList", result.partsInstalledLineItems);
                
                component.set("v.toolsList", result.toolsLineItems);
                component.set("v.filteredtoolsList", result.toolsLineItems);
                
                component.set("v.remPartsList", result.remainingParts);
                component.set("v.filteredRemPartsList", result.remainingParts);
                
                component.set("v.partsRemovedList", result.removedPartsLineItems);
                component.set("v.filteredpartsRemovedList", result.removedPartsLineItems);
                
                component.set("v.removedPartsList", result.remainingPartsRemoval);
                component.set("v.filteredRemovedPartsList", result.remainingPartsRemoval);
                
                component.set("v.removedPartsReqList", result.partsReqLineItems);
                component.set("v.filteredRemovedPartsReqList", result.partsReqLineItems);
                
                component.set("v.ecfList", result.ecfRecord);
                
                console.log('result.latestWoliEndDate: ' + result.latestWoliEndDate);
                component.set("v.latestWoliEndDate", result.latestWoliEndDate);
                component.set("v.workOrderObj.Machine_Release__c", null);
                
                component.set("v.remainingPartsCount", result.remainingParts.length);

                // Submit WO should not allow if ECF Required set to 'Yes from Work Order' and ECF Form Count is 0
                if (
                    (result.workOrder.Status === "Assigned" &&
                      result.workOrder.ECF_Required__c !== "Yes from Work Order" &&
                      !result.workOrder.Count_of_FSR__c) || 
                    (result.workOrder.Status === "Assigned" && 
                     result.workOrder.ECF_Required__c === "Yes from Work Order" &&
                     (!result.workOrder.ECF_Form_Count__c  ||
                     !result.workOrder.Count_of_FSR__c))
                ) {
                    component.find("SubmitButton").set("v.disabled", true);
                    component.set("v.toolWarning", true);
                    self.setToastErrorMsg(
                        "FSR is not yet created, OR Work Order is Escalated Complaint Required from Work Order, but there is no ECF created for this Case/Work Order. Create FSR, and/or submit ECF prior to WO Submission"
                    );
                    setTimeout(function() {
                        self.redirectWOPage(component);
                    }, 7000);
                }
            } else {
                component.find("SubmitButton").set("v.disabled", true);
                self.setToastErrorMsg(result.message);

                setTimeout(function() {
                    self.redirectWOPage(component);
                }, 7000);
                $A.get("e.force:closeQuickAction").fire();
            }
        });
        $A.enqueueAction(action);
    },
    setToastErrorMsg: function(errorMsg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: 'Error!',
            type: 'error',
            message: errorMsg,
            mode: 'sticky'
        });
        toastEvent.fire();
    },
    redirectWOPage: function(component) {
        var sObectEvent = $A.get("e.force:navigateToSObject");
        sObectEvent.setParams({
            recordId: component.get("v.recordId"),
            slideDevName: "detail"
        });
        sObectEvent.fire();
    },
    validate: function(component) {
        var errorMsg = '';
        var isValid = true;
        var woRecord = component.get("v.workOrderObj");
        var activityList = component.get("v.activityList");
        var partList = component.get("v.partList");
        var remPartList = component.get("v.remPartsList");
        var removedPartsList = component.get("v.removedPartsList");
        var toolsList = component.get("v.toolsList");
        var removedPartsReqList = component.get("v.filteredRemovedPartsReqList");
        
        console.log(JSON.stringify(removedPartsList));
        var ecfList = component.get("v.ecfList");
        
        var machine_release_time = component.get(
            "v.workOrderObj.Machine_Release__c"
        );
        
        if (machine_release_time === null || machine_release_time === undefined) {
            var latestEndDate = component.get("v.latestWoliEndDate");
            component.set("v.workOrderObj.Machine_Release__c", latestEndDate);
        }
            
        console.log('machine_release_time:' + component.get("v.workOrderObj").Machine_Release__c);
        var work_performed = component.get(
            "v.workOrderObj.Closure_Summary__c"
        );
        
        if (woRecord.Complaint__c === 'Yes' && !woRecord.Injured__c)
            errorMsg += ' Field \"Injured\" cannot be blank. Please change to correct entry. \n';
        
        if (work_performed === null || work_performed === undefined)
            errorMsg += ' Please fill in Closure Summary.';

        // WO's Service Resource's Work Center required, if Service resource is assigned on WO
        if (woRecord.Service_Resource__c !== undefined && woRecord.Service_Resource__c !== null) {
            if(
                (woRecord.Service_Resource__r.Work_Center__c === null ||
                    woRecord.Service_Resource__r.Work_Center__c === undefined)
            )
                errorMsg += ' Technician & Badge ID cannot be Null.';
    	}
        
        console.log('woRecord.Open_Line_Count__c: ' + woRecord.Open_Line_Count__c);
        if (woRecord.Open_Line_Count__c < 1)
            errorMsg +=
            ' There are no activities on this Work Order. Please add prior to Submission';

        if(remPartList.length > 0 || removedPartsList.length > 0 || removedPartsReqList.length > 0)
            errorMsg +=
                ' Work Order cannot be Submitted while there are Parts with Remaining Qty or Returnable parts not yet returned. See Remaining Parts, Parts Requiring Removal Entries, and  Removed Parts Requiring Return tabs for detailed information.';
        
        var submittedLineCount = component.get("v.workOrderObj.Line_Count__c");
        if (submittedLineCount !== null && submittedLineCount !== undefined)
            submittedLineCount = parseInt(submittedLineCount);
        // Submitted Line Count is 0
        if (parseInt(submittedLineCount) === 0 || submittedLineCount === undefined)
            errorMsg +=
            ' Submission is not allowed unless at least 1 labor or part is included.  Please return to Products Serviced SFM to add labor or parts as required.';

        if(component.get("v.workOrderObj").Machine_Release__c < woRecord.Malfunction_Start__c)
            errorMsg += ' \"Machine Release Time\" must be greater than or equal to \"Malfunction Start\".';
        
        
        if(woRecord.Test_Required__c && !woRecord.Test_Specifications_Met__c)
            errorMsg += ' Test Specifications Met is required';
        
        if(woRecord.Complaint__c === 'Yes' && !woRecord.ECF_Required__c)
            errorMsg += ' If Complaint is Yes, then Escalated Complaint Required must not be blank. Correct before proceeding.';
        
        if(ecfList.length > 0) {
            if(ecfList[0].isSubmitted === 'false')
                errorMsg += ' The Escalated Complaint Form(ECF) form on this Work Order has not been submitted. Please login online and submit the Escalated Complaint Form(ECF) before submission';
        }
        
        
        // Check whether entries on WOLI are overlapping
        var newConcatList = activityList.concat(partList);
        var daterangeArray = [];
        for (var i = 0; i < newConcatList.length; i++) {
            var row = newConcatList[i];
            daterangeArray.push(new Date(row.StartDate));
            daterangeArray.push(new Date(row.EndDate));
        }
        var isOverlap = this.multipleDateRangeOverlaps(daterangeArray);
        if (isOverlap) {
            errorMsg += " Work Order Line Item Entries are overlapping. Please, correct startdate and enddate on work order line item to avoid overlapping.";
        }
        
        if(toolsList.length === 0 && !errorMsg) {
            component.set("v.toolWarning", true);
            isValid = false;
        }
            

        if (errorMsg !== "" && errorMsg !== null) {
            isValid = false;
            this.setToastErrorMsg(errorMsg);
        }
        return isValid;
    },
    submitWO: function(component) {
        console.log('wo before submit: ' + JSON.stringify(component.get("v.workOrderObj")));
        var action = component.get("c.saveWorkOrder");

        // Convert to customer local time and set to 'customer malfunction end' field
		var machine_release_time = new Date(component.get("v.workOrderObj.Machine_Release__c"));
		var timeZoneKey = component.get("v.timeZoneKey");
		var customer_end_time = new Date(machine_release_time);
		customer_end_time = new Date(customer_end_time.toLocaleString("en-US", { timeZone: timeZoneKey }));
		customer_end_time.setTime(customer_end_time.getTime() - customer_end_time.getTimezoneOffset() * 60000);
        var woObj = component.get("v.workOrderObj");

        action.setParams({
            woObj: JSON.stringify(woObj),
            woliList: JSON.stringify(component.get("v.activeLineItems"))
        });
        component.find("SubmitButton").set("v.disabled", true);
        var self = this;
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            var state = response.getState();
            console.log("Result==============" + result);
            if (!result) {
                // Redirect to WO record
                window.location.href = '/'+component.get("v.recordId");
                //self.redirectWOPage(component);
            } else {
                console.log("result.message: " + result);
                //self.setToastErrorMsg(result.message)
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error!',
                    type: 'error',
                    message: result,
                    mode: 'sticky'
                });
                toastEvent.fire();
                //$A.get("e.force:closeQuickAction").fire();
            }
            component.find("SubmitButton").set("v.disabled", false);
        });
        $A.enqueueAction(action);
    },
    checkDateRangeOverlap: function(a_start, a_end, b_start, b_end) {
    	if(a_start <= b_start && b_start < a_end) return true;
    	if(a_start < b_end   && b_end <= a_end) return true;
    	if(b_start < a_start && a_end < b_end) return true;
    	return false;
	},
    multipleDateRangeOverlaps: function(dateRangeList) {
    	var i, j;
    	if (dateRangeList.length % 2 !== 0)
        	return false;

    	for(i = 0; i < dateRangeList.length - 2; i += 2) {
        	for(j = i + 2; j < dateRangeList.length; j += 2) {
            	if(this.checkDateRangeOverlap(dateRangeList[i], dateRangeList[i+1],dateRangeList[j], dateRangeList[j+1])) return true;
        	}
    	}
    	return false;
	}
});