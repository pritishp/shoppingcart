({
	doInit : function(component, event, helper) {
        var brachyTax = component.get("v.brachyTax");
        var thirdPartyTax = component.get("v.thirdPartyTax");
        var appTotalPrice = component.get("v.appTotalPrice");
        var brachyTotalPrice = component.get("v.brachyTotalPrice");
        var brachyShippingPrice = component.get("v.brachyShippingPrice");
        var total = Number(brachyTax) + Number(thirdPartyTax) + Number(appTotalPrice) + Number(brachyTotalPrice) + Number(brachyShippingPrice);
        component.set("v.totalPayableAmt", total);
       window.scrollTo(0,0);
        
	},
    
})