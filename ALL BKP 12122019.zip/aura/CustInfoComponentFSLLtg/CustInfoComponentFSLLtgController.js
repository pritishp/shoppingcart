({   
    doInit: function(component, event, helper){
        var action = component.get("c.getCase");
        action.setParams({ caseId : component.get('v.recordId')});
        action.setCallback(this, function(response) {
       		debugger;
            var state = response.getState();
            var caseObj = response.getReturnValue()
            console.log(' ### ' + JSON.stringify(response.getReturnValue()));
            var accountObj;
            if (caseObj.Account != undefined)
            {    
            	accountObj = caseObj.Account;
            }
            if(caseObj.Account != undefined) {
            	component.set('v.accountObj',accountObj);
            }
            component.set('v.caseObj',caseObj);
            var conObj = component.get("v.conObj");
            conObj.Id = caseObj.ContactId;
            if(caseObj.Contact != undefined){
				conObj.Name = caseObj.Contact.Name;
                conObj.Phone = caseObj.Contact.Phone;
            }
            console.log(' Point 2' + accountObj + JSON.stringify(accountObj));
            if(caseObj.Account != undefined) {
            	conObj.AccountId = accountObj.Id;
            }
            component.set('v.conObj',conObj);
            var assetObj = component.get("v.assetObj");
            console.log(' Point 3');
            if(caseObj.AssetId != undefined)
            assetObj.Name= caseObj.Asset.Name;
            assetObj.Id = caseObj.AssetId;
            component.set('v.assetObj',assetObj);
            console.log(response.getReturnValue());
        });
        $A.enqueueAction(action);
        
    },
	editCase: function(component, event, helper) {      
		component.set('v.editMode', true);
        debugger;
        var editReset = component.find("custInfoEditComponent");
        var action = component.get("c.getCase");
        action.setParams({ caseId : component.get('v.recordId')});
        action.setCallback(this, function(response) {
       		var state = response.getState();
            var caseObj = response.getReturnValue()
            var accountObj;
            if (caseObj.Account != undefined)
            {
            	accountObj = caseObj.Account;
                component.set('v.accountObj',accountObj);
            }
            
            component.set('v.caseObj',caseObj);
            var conObj = component.get("v.conObj");
            conObj.Id = caseObj.ContactId;
            if(caseObj.Contact != undefined)
            {
            	conObj.Name = caseObj.Contact.Name;
            	conObj.AccountId = accountObj.Id;
            }
            component.set('v.conObj',conObj);
            var assetObj = component.get("v.assetObj");
            if(caseObj.AssetId != undefined)
            {
            	assetObj.Name= caseObj.Asset.Name;
            	assetObj.Id = caseObj.AssetId;
            }
            component.set('v.assetObj',assetObj);
            console.log(response.getReturnValue());
            editReset.initializeBack(component.get('v.accountObj'),
                                     component.get('v.caseObj'),
                                     component.get('v.conObj'),
                                     component.get('v.assetObj'));
        });
        $A.enqueueAction(action);
        
	},     
	
    handleCustInfoEvent: function(cmp, event, helper) {  
   		cmp.set('v.editMode', false);
       
        //var a = cmp.get('c.doInit');
        //$A.enqueueAction(a);
        
       // $A.get('e.force:refreshView').fire();
        setTimeout(function(){   $A.get('e.force:refreshView').fire(); }, 2000);   
       //window.location.href = '/'+component.get("v.recordId"); 
       
     
       
    },
    
	submitCase: function(cmp, event, helper) {     
   		cmp.set('v.editMode', false);
    }, 
})