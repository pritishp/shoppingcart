({
    getAccountDetails : function(component,event,helper) {        
		 var action = component.get("c.getAccountDetails"); 
         action.setCallback(this, function(a) {             
             var result = a.getReturnValue();             
             console.log('objAccount=='+JSON.stringify(result));
             var sizeObj = Object.keys(result).length;
             if(sizeObj > 0) {
                 component.set("v.isInternalUser",false);
             } else {
                component.set("v.isInternalUser",true);
             }
             component.set("v.objAccount", result);      
         });
      	$A.enqueueAction(action);
	},
    getContactInfo : function(component) {        
		 var action = component.get("c.getContactDetails"); 
         action.setCallback(this, function(a) {
         var result = a.getReturnValue();
         console.log('objContact=='+JSON.stringify(result));    
             if(result!== '' && result!==null){
                 component.set("v.objContact" , result);
             }
      });
      $A.enqueueAction(action);
	},
    getCategoryValues : function(component,event) {
        
        var action = component.get("c.getAppCategories");
        action.setCallback(this, function(result){
			var response = result.getReturnValue();
			component.set("v.appCatValues", response);
        });
        $A.enqueueAction(action);
        
    },
    getISOCurrCode : function(component,event) {
        var action = component.get("c.getAppCurrencyCode");
        action.setCallback(this, function(result){
			var response = result.getReturnValue();
            var valList = [];
			for(var key in response){
				valList.push({value:response[key], key:key});
			}
			component.set("v.appCurrCodeValues", valList);
        });
        $A.enqueueAction(action);        
    },
    getFilterValues : function(component,event) {
        var action = component.get("c.getFilterMapValues");
        
        action.setCallback(this, function(result){
        	//$A.util.removeClass(component.find("mySpinner"), "slds-show");
			var response = result.getReturnValue();
            
            var filterList = [];
			for(var key in response){
				filterList.push({value:response[key], key:key});
			}
			component.set("v.filteredValues", filterList);
            console.log(this);
            //this.getFilteredApps(component,event);
        });
        $A.enqueueAction(action);
    },
    getFilteredApps : function(component,event, helper) {
        var self = component;
        var selectedFilterValue = component.find("selectedFilterValue").get("v.value");
        if(selectedFilterValue === undefined) {
            selectedFilterValue = '';
        } 

        var tabname = component.get('v.selectedAppCat');
        if(tabname === undefined) {
            tabname = '';
        }

        var totalRecs = parseInt(component.get('v.totalRecs'));
        var index = parseInt(component.get('v.index'));
        var blockSize = parseInt(component.get('v.blockSize'));
        
        /*var sPageURL = decodeURIComponent(window.location.search.substring(1));
        var splitArgs = sPageURL.split('&'); //Split by & so that you get the key value pairs separately in a list
        var argumentParams;
        var searchKey = '';
        for (var i = 0; i < splitArgs.length; i++) {
            argumentParams = splitArgs[i].split('=');
            if (argumentParams[0] === 'keyword') {
                searchKey = argumentParams[1];
                break;
            }
        }*/

        var action = component.get("c.getPublishedApps");
        action.setParams({
            filterVal: String(selectedFilterValue),
            catName: tabname,
            searchKeyword: component.get('v.appNameFromEvent'),
            totalRecs: totalRecs,
            index: index,
            blockSize: blockSize
        });
        
        action.setCallback(this, function(result){
			var response = result.getReturnValue();         
            var currencyMapValues = self.get("v.appCurrCodeValues");
            var currencyMap = {};
            for(var i=0; i<currencyMapValues.length;i++) { 
                currencyMap[String(currencyMapValues[i].key)] = String(currencyMapValues[i].value); 
            }

            var appListings = JSON.parse(response[0]);
            var appAttachments = JSON.parse(response[1]);
            var totalRecs = parseInt(response[2]);
            var index = parseInt(response[3]);
            component.set('v.totalRecs', totalRecs);
            component.set('v.index', index);
            
            var startOffset = index + 1;
            var endOffset = index + blockSize;
            if( endOffset >  totalRecs){
        	    endOffset = totalRecs;
            }
            component.set('v.startOffset', startOffset);
            component.set('v.endOffset', endOffset);
            
            var totalPageCount = totalRecs / parseInt(component.get('v.blockSize'));
            var totalPageRemainder = totalRecs % parseInt(component.get('v.blockSize'));
            if( totalPageRemainder > 0 ){
                totalPageCount = totalPageCount + 1;
            }
            component.set('v.paginationTotalPageCount', parseInt(totalPageCount));

            var total_comment_size = 0;
            var star5 = 0;
            var star4 = 0;
            var star3 = 0;
            var star2 = 0;
            var star1 = 0;
            var rating = 0;
            var avgRating = 0;

			for(var key in appListings){
                var code = appListings[key].CurrencyIsoCode;
                if(currencyMap[code] !== null && currencyMap[code] !== undefined) {
                    appListings[key].CurrencyIsoCode = currencyMap[code];
                }
                if(appAttachments[appListings[key].Id] !==null && appAttachments[appListings[key].Id] !== undefined) {
                    appListings[key]['imageUrl'] = appAttachments[appListings[key].Id];
                }

                
                if(appListings[key].vMTP_Comments__r !== undefined) {
                    total_comment_size = parseInt(appListings[key].vMTP_Comments__r.totalSize);
                    star5 = 0;star4 = 0;star3 = 0;star2 = 0;star1 = 0;avgRating = 0;rating = 0;
                    if(total_comment_size !== 0) {
                        for(var i in appListings[key].vMTP_Comments__r.records) {
                            var rating = parseInt(appListings[key].vMTP_Comments__r.records[i].Rating__c);
                            if(rating === 1) {
                                star1 += 1;
                            } else if(rating === 2) {
                                star2 += 1;
                            } else if(rating === 3) {
                                star3 += 1;
                            } else if(rating === 4) {
                                star4 += 1;
                            } else if(rating === 5) {
                                star5 += 1;
                            }
                        }
                        avgRating = ((5*star5) + (4*star4) + (3*star3) + (2*star2) + (1*star1)) / total_comment_size;
                        avgRating = String(avgRating.toFixed(1));
                        avgRating = avgRating.replace(".", "-");
                    }
                    appListings[key]['avgRating'] = avgRating;
                }else{
                    appListings[key]['avgRating'] = 0;
                }               
                
                
			}
			console.log(appListings);
			component.set("v.filterAppsList", appListings);
            window.scrollTo(0,0);
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
	updateQueryStringParameter: function(uri, key, value) {
		var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
		var separator = uri.indexOf('?') !== -1 ? "&" : "?";
		return uri.match(re) ? uri.replace(re, '$1' + key + "=" + value + '$2') : (uri + separator + key + "=" + value);
	},
    addToCart : function (component, event, helper) {
        var rectarget = event.currentTarget;
        var appId = rectarget.getAttribute("data-appId"); 
        var quantity= component.get('v.quantity');
        var accountId = '';
        var contactId = '';
        if(component.get('v.objAccount')){
            accountId = component.get('v.objAccount').Id;
        }
        if(component.get('v.objContact')){
            contactId = component.get('v.objContact').Id;
        }        
        var action = component.get("c.addCartItem");
        action.setParams ({
            appId: appId,
            quantity:quantity,
            accountId: accountId,
            contactId: contactId            
        });
        action.setCallback(this, function(response) {            
            var state = response.getState();
            if (state === "SUCCESS") {
                var msg = response.getReturnValue();
                var variant;
                if(msg.includes('Success')) {
                   variant = 'Success';
                } else if(msg.includes('Exception')){
                 	variant = 'Error';   
                } else {
                    variant = 'Info';

                }
                helper.handleShowToast(component, event, helper, msg,variant,variant);
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
            }
            else {
                helper.handleShowToast(component, event, helper, 'Exception Occurred !','Error', 'Error');
            }
        });
        $A.enqueueAction(action);
    },
    handleShowToast : function(component, event, helper, msg, variant,title) {
        component.find('notifLib').showToast({
            "title": title,
            "message": msg,
            "variant" : variant
        });
    },
})