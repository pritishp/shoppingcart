({
	getWrapperData : function(component, event, helper) {
        //helper.getURLParameters (component, event, helper);
        var action = component.get("c.fetchWrapperData");
        var applicationId = component.get("v.appId");
        action.setParams ({
            appId: applicationId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp = response.getReturnValue();
                console.log('App Data=='+JSON.stringify(resp));
                component.set("v.appWrapper", resp);
                helper.setBreadCrumbs (component, event, helper);
                
                if( resp.appDocuments ){
                    for( var i=0; i < resp.appDocuments.length ; i++ ){
                        if(resp.appDocuments[i].ContentDocument.FileExtension !='application/pdf' && resp.appDocuments[i].ContentDocument.Title.startsWith('AppLogo')) {
                            component.set("v.logoURL" ,resp.baseUrl+ '/sfc/servlet.shepherd/version/download/'+resp.appDocuments[i].ContentDocument.LatestPublishedVersionId);
                            break;
                        } else {
                            component.set("v.logoURL", null);
                        }
                    }
                }
                
                /*attached Images */
                /*if(resp.attachObjList)
                    for(var app=0 ; app < resp.attachObjList.length; app++) {
                        if(resp.attachObjList[app].ContentType !='application/pdf' && resp.attachObjList[app].Name.startsWith('Logo_')) {
                            component.set("v.logoURL" ,resp.baseUrl+ '/servlet/servlet.FileDownload?file='+resp.attachObjList[app].Id);
                            break;
                        } else {
                            component.set("v.logoURL", null);
                        }
                    }*/
                
                /*subscribed Plans*/
                /*var subsciptionPlan = resp.subscriptionPlans;
                var employees = {
                    accounting: []
                };
                for(var i in subsciptionPlan) {    
                    
                    var item = subsciptionPlan[i];   
                    if(item.VMarket_Price__c > 0) {
                        employees.accounting.push({ 
                            "label" : item.VMarket_Duration_Type__c.toUpperCase() + ' : ' +resp.App__r.CurrencyIsoCode + '  '+ item.VMarket_Price__c,
                            "value" : item.Id 
                        });
                    }
                }
                component.set("v.options", employees.accounting);*/
                
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        
                    }
                } else {
                    
                }
            }
            component.set("v.loaded", false);
        });
        
        $A.enqueueAction(action);
    },
    setBreadCrumbs : function (component, event, helper) {
        var breadcrumbCollection = [
            {label: 'Home', name: 'all products' },
            {label: component.get("v.appWrapper.vMTPApp.Name"), name: 'Product Name'}
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },
    getURLParameters : function (component, event, helper) {        
        // the function that reads the url parameters
        var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;
            
            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');
                
                if (sParameterName[0] === sParam) {
                    return sParameterName[1] === undefined ? true : sParameterName[1];
                }
            }
        };
        
        //set the src param value to my src attribute
        if(getUrlParameter('appId')) {
            component.set("v.appId", getUrlParameter('appId'));
        }
    }
})