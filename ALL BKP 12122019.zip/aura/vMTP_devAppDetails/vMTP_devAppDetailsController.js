({
	getWrapperData : function(component, event, helper) {
        helper.getURLParameters (component, event, helper);
        helper.getWrapperData (component, event, helper);
	},
    carouselClick: function(component, event, helper) {
    	component.set("v.appVideoModalOpen", true);
	},
    openAppVideoModal: function(component, event, helper) {
        component.set("v.appVideoModalOpen", true);
    },
	closeAppVideoModal: function(component, event, helper) {
        component.set("v.appVideoModalOpen", false);
    }
})