({
	setBreadCrumbs : function (component, event, helper) {
        var breadcrumbCollection = [
            {label: 'Home', name: 'all products' },
            {label: 'All Orders', name: '' }
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },
    getOrders : function(component, event, helper) {
		var self = this;
        var action = component.get("c.fetchAllOrders");
		var selectOrderTypeVal = component.find("orderTypeSelect").get("v.value"); 
        var orderSearchInputVal = component.find("orderSearchInput").get("v.value");
        var brachySalesManager = component.find("salesManagerId").get("v.value"); //added  by Sanika
        var selectStatusTypeVal = component.find("orderStatusSelect").get("v.value");
        var selectpaymentTypeVal = component.find("paymentTypeSelect").get("v.value");
        console.log('selectOrderTypeVal=='+selectOrderTypeVal);
        if( orderSearchInputVal != '' ){
            selectOrderTypeVal = '';
        }
        action.setParams({
            recordType: selectOrderTypeVal,
            orderSearchName: orderSearchInputVal,
            orderStatus: selectStatusTypeVal,
            paymentType: selectpaymentTypeVal,
            salesManager: brachySalesManager
        });
        action.setCallback(this, function(response) {
            var state = response.getState();              
            if(state == "SUCCESS"){               
                var responseWrap = response.getReturnValue(); 
                component.set("v.ordersList",responseWrap); 
                console.log(responseWrap);
                if(responseWrap.length ===0){
                    component.set("v.noOrdersMsg",true);
                }else{
                    component.set("v.noOrdersMsg",false);
                	                   
                }    
            }
            component.set("v.processing", false);
        });
        $A.enqueueAction(action); 
	},
    getAccountInfo : function(component, event, helper) {
        var self = this;
        var action = component.get("c.getAccountDetails");
        action.setCallback(this, function(response) {
            var state = response.getState();              
            if(state == "SUCCESS"){               
                var responseWrap = response.getReturnValue();                 
                console.log('Account Info=='+JSON.stringify(responseWrap));                
            }
        });
        $A.enqueueAction(action);
    },
    getManager : function(component, event, helper) {
        debugger;
        var self = this;
        var options = [];
        options.push({
            label : '--Any--',
            value : ''
        });
        
        var action = component.get("c.getSalesManagers");
        //action.setParams();
        action.setCallback(this, function(response) {
            debugger;
            var state = response.getState();
            if(state == "SUCCESS")
            {
                var picklistresult = response.getReturnValue();
                console.log(picklistresult);
                
                for(var i =0;i<picklistresult.length;i++)
                {
                    options.push({
                        label : picklistresult[i].label,
                        value : picklistresult[i].pvalue
                    });
                }                
            }
            component.find("salesManagerId").set("v.options",options);          
           
        }); 
        $A.enqueueAction(action);
    }
})