({
	doInit : function(component, event, helper) { 
        component.set("v.processing", true);
        helper.setBreadCrumbs (component, event, helper);
		helper.getOrders(component, event, helper);
        helper.getAccountInfo(component, event, helper);
        helper.getManager(component,event,helper);
	},
    selectedManager: function(component, event, helper) {
       component.find("orderSearchInput").set("v.value","");
        helper.getOrders(component, event, helper);
       console.log('+++am'+component.get("v.sManager"));
        
    },
    onOrderTypeSelectChange: function(component, event, helper) {
        component.find("orderSearchInput").set("v.value","");
		helper.getOrders(component, event, helper);
	},
    onOrderSearchSubmit: function(component, event, helper) {        
        helper.getOrders(component, event, helper);
    },
    onKeyupOrderSearchInput: function(component, event, helper) { 
    	var orderSearchInputVal = component.find("orderSearchInput").get("v.value");
        console.log(orderSearchInputVal);
        if(orderSearchInputVal == ''){
            helper.getOrders(component, event, helper);
        }
    }
})