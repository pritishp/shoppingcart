({
    
    doInit : function(component, event, helper) {
        var userEmail =  $A.get("$SObjectType.CurrentUser.Email");
        component.set('v.email',userEmail);
    },
 
    sendMail: function(component, event, helper) {
        
        var getEmail = component.get("v.email");
        var getSubject = component.get("v.subject");
        var getbody = component.get("v.body");
        var getFirstname = component.get("v.Firstname");
        var getlastname = component.get("v.lastname");
        
        var errorField = '';
        var Fname = component.find('FirstName');
        var FnameValue = Fname.get('v.value');
        if(FnameValue == undefined || FnameValue == ''){
            Fname.set("v.errors", [{message:"Please Enter First Name...!!"}]);
            errorField = errorField +', firstname';
        }else{
           Fname.set("v.errors", [{message:""}]);
		   errorField = errorField.replace('firstname','');
        }
        
        var lname = component.find('LastName');
        var LnameValue = lname.get('v.value');
        /*if(LnameValue == undefined || LnameValue == ''){
            lname.set("v.errors", [{message:"Please Enter Last Name...!!"}]);
            errorField = errorField +', lastname';
        }else {
           lname.set("v.errors", [{message:""}]);
		   errorField = errorField.replace('lastname','');
        }*/
        
        var email = component.find('Email');
        var emailValue = email.get('v.value');
        if(emailValue == undefined || emailValue == ''){
            email.set("v.errors", [{message:"Please Enter Your Mail Id...!!"}]);
            errorField = errorField +', email';
        }else{
           email.set("v.errors", [{message:""}]);
		   errorField = errorField.replace('email','');
        }
        
        var subject = component.find('Subject');
        var subjectValue = subject.get('v.value');
        if(subjectValue == undefined ||subjectValue == ''){
            subject.set("v.errors", [{message:"Please Enter Subject...!!"}]);
            errorField = errorField +', subject';
        }else{
           subject.set("v.errors", [{message:""}]);
		   errorField = errorField.replace('subject','');
        }
        var body = component.find('Body');
        var bodyValue = body.get('v.value');
        if(bodyValue == undefined || bodyValue == ''){
            body.set("v.errors", [{message:"Please Enter Description...!!"}]);
            errorField = errorField +', body';
        }else{
            body.set("v.errors", [{message:""}]);
            errorField = errorField.replace('body','');
        }
        
        console.log('value' + errorField);
        console.log('length' + errorField.length);
        
		errorField = errorField.replace("[,]*","");
        
        console.log('value' + errorField);
        console.log('length' + errorField.length);
        
        if ( errorField == '') {
        helper.showSpinner(component);
        helper.contactUsHelper(component, getEmail, getSubject, getbody, getlastname, getFirstname,event, helper);
       } 
        
    },
    handleCloseModal: function(component, event, helper){
        component.set('v.isEmailSentPopUp',false);
        location.reload();
    }
    
})