({
    contactUsHelper: function(component, getEmail, getSubject, getbody, getFirstname, getlastname,event, helper) {
        var action = component.get("c.contactUsMethod");
        action.setParams({
            'mMail': getEmail,
            'mSubject': getSubject,
            'mbody': getbody,
            'mFirstname': getFirstname,
            'mlastname': getlastname,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set("v.mailStatus", true);
                /*var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Success',
                    message: 'Thank You, Your mail is sent successfully!!!',
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'pester'
                });
                toastEvent.fire();*/
               component.set('v.isEmailSentPopUp',true);
               this.hideSpinner(component); 
                
            }
        });
        $A.enqueueAction(action);
    },
     showSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
     
    hideSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    }
})