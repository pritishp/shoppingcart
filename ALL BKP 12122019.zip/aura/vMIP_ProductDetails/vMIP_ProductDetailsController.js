({
	doInit : function(component, event, helper) {
        helper.getAccountDetails(component,event,helper);
        helper.getContactInfo(component, event, helper);
		helper.getParentProductDetails(component);
        
  	},
    
    clearErrorMessage : function (component, evnt, helper) {
        component.set('v.ifQtyAllowed',true);
    },
    
    AddToCart : function(component, event, helper) {
        var quantity=component.find('qty').get('v.value');
        var maxQuantity=component.get('v.objHeaderProduct.maxQty');
        var proCode=component.get('v.objHeaderProduct.objProduct.Product_Number__c');
        console.log('quantity--'+quantity+'---max---'+maxQuantity+'--proCode--'+proCode);
        if(quantity==0){
           helper.handleShowToast(component, event, helper, 'Please add quantity of product','Error', 'Error'); 
        }
        else{
            if((maxQuantity && quantity>maxQuantity)){
                component.set('v.ifQtyAllowed',false);
            }
            else{
                 helper.getAllowedProdQty(component, event, helper,proCode,quantity,maxQuantity);
            }
        }
  	},
    // for Account filter
    openFilters: function (component, event, helper) {
        document.getElementById("sidenavFilterList").style.width = "305px";
		document.getElementById("backgroundOverlay").style.display = "block";        
    },
    closeFilters: function (component, event, helper) {
        document.getElementById("sidenavFilterList").style.width = "0";  
        document.getElementById("backgroundOverlay").style.display = "none"; 
    },
    openSearchAccountModal: function(component, event, helper) {
        component.set('v.indexAccountSearch',0);
        helper.getAccounts(component, event, helper);
    	component.set("v.accountSearchModalOpen", true);
    },
    closeSearchAccountModal: function(component, event, helper) { 
    	component.set("v.accountSearchModalOpen", false);
    },
   searchByAccount: function (component, event, helper) {
      helper.searchByAccount(component, event,helper);
      //helper.getFilteredProducts(component,event);  
    },
   keyPressAccountNameSearch : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchAccountInputValue");
        console.log('keyPressAccountNameSearch===='+getInputkeyWord);
        component.set('v.indexAccountSearch',0);
        helper.getAccounts(component, event, helper);
    },
    selectRecordAccountNameSearch : function(component, event, helper) {     
        var selectedItem = event.currentTarget; // Get the target object
		var index = selectedItem.dataset.record; // Get its value i.e. the index
		var selectedRecord = component.get("v.listOfAccountRecords")[index]; // Use it retrieve the store record
       	var currentSelectedAccount = component.get("v.selectedAccountRecord");
        component.set("v.newAccountRecord" , selectedRecord);
        var cartCount = component.get("v.cartCount");
        console.log('currentSelectedAccount=='+currentSelectedAccount.Id+'=='+currentSelectedAccount.Name);
        console.log('newSelectedAccount=='+selectedRecord.Id+'=='+selectedRecord.Name);
        console.log('cartCount=='+cartCount);
        helper.closeSearchAccountModal(component, event,helper);  
        if( ( typeof currentSelectedAccount.Id !== 'undefined' ) && (currentSelectedAccount.Id !=  selectedRecord.Id) && (cartCount > 0) ){
            component.set("v.cartDeleteModalOpen", true); 
            
        }     
        //}else if( typeof currentSelectedAccount.Id === 'undefined' || ( (currentSelectedAccount.Id !=  selectedRecord.Id) && (cartCount == 0) ) ){
        else{    
            component.set("v.selectedAccountRecord" , selectedRecord);
        	if( typeof selectedRecord !== 'undefined' ){
            	var accId = selectedRecord.Id;
        		helper.getAccountAfterloader(component,event,helper,accId);
                helper.addAccountToCart(component, event, helper,accId);
            }
        }
		
    },
    nextAccountSearch:function(component, event, helper) {        
        var totalAccountsCount = parseInt(component.get('v.totalAccountsCount'))
        var blockSizeAccountSearch = parseInt(component.get('v.blockSizeAccountSearch'));
        var indexAccountSearch = parseInt(component.get('v.indexAccountSearch'));
        var nextIndex = indexAccountSearch + blockSizeAccountSearch;        
        
        if((indexAccountSearch + blockSizeAccountSearch) >= totalAccountsCount){
            return false;
        }
        
        component.set("v.indexAccountSearch", nextIndex);             
        helper.getAccounts(component, event, helper);
    },
    prevAccountSearch:function(component, event, helper) { 
    	var blockSizeAccountSearch = parseInt(component.get('v.blockSizeAccountSearch'));
        var indexAccountSearch = parseInt(component.get('v.indexAccountSearch'));    
        var prevIndex = indexAccountSearch - blockSizeAccountSearch;
        if (prevIndex < 0){
            prevIndex = 0;
            return false;
    	}
        
    	component.set("v.indexAccountSearch", prevIndex);                
        helper.getAccounts(component, event, helper);
    },
    openCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", true);
    },
	closeCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", false);
    },
    removeCart: function(component, event, helper) {
        helper.deleteCartItem(component, event,helper);
        var newSelectedRecord = component.get("v.newAccountRecord");
        component.set("v.selectedAccountRecord" , newSelectedRecord);
        component.set("v.cartDeleteModalOpen", false);
    },
    imageClick : function (component, event, helper){
        component.set("v.appImageModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
      component.set("v.appImageModalOpen", false);
   }
})