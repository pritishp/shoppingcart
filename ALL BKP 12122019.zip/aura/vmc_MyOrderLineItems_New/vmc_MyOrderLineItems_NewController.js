({
	downloadAppSource : function(component, event, helper) {
		var docId = event.getSource().get("v.value");
        console.log(docId);
        window.open(window.location.protocol+'//'+window.location.hostname+'/sfc/servlet.shepherd/version/download/'+docId);
	}
})