({
	doInit : function(component, event, helper) {
		helper.callInit(component, event);
	}
})