({
    callInit : function(component, event) {
        var recordId = component.get('v.recordId');
        
        var action = component.get("c.updateIsSubmit");
        action.setParams({
            "recordId": recordId
        });

        action.setCallback(this, function(response) {
            var state = response.getState();
            var result = response.getReturnValue();
            component.set('v.isSuccess', false);
            if(state === "SUCCESS" && result[0] === 'true') {
                location.reload();
                component.set('v.msgString', result[1]);
                component.set('v.isSuccess', true);
            } else if(state === "SUCCESS" && result[0] === 'false') {
                component.set('v.msgString', result[1]);
            } else if(response.getState() == "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set('v.msgString', "Error message: " + errors[0].message);
                    }
                }
            } else {
                component.set('v.msgString', 'Unknown Error');
            }
            $A.util.addClass(component.find('busyIndicator'), 'slds-hide');
			$A.get('e.force:refreshView').fire();
        });
        $A.enqueueAction(action);
    }
})