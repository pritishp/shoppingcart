({
    refreshView: function(component, event) {
        // refresh the view
        $A.get('e.force:refreshView').fire();
    }
})