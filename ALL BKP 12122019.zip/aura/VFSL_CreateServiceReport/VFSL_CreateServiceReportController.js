({
    doInit : function(component, event, helper) {
        var myRecord = component.get("v.recordId");
        console.log('myRecord check:'+myRecord);
        component.set('v.isOpen', true);
        var inputVariables = [{
            name: "recordId",
            type:"String",
            value:myRecord
        }];
        var flow = component.find('flow');
        flow.startFlow('VFSL_Create_ServiceReport_Online',inputVariables);
    },
    
    closeFlowModal : function(component, event, helper) {
        component.set("v.isOpen", false);
        component.find("overlayLib").notifyClose();
    },
    
    closeModalOnFinish : function(component, event, helper) {
        if(event.getParam('status') === "FINISHED") {
            component.set("v.isOpen", false);
            component.find("overlayLib").notifyClose();
        		var refreshPage = $A.get("e.force:refreshView");
        		refreshPage.fire();
        }
    }
})