({
    initializeAppAssets : function(component, event, helper) {
        var applicationId = helper.getUrlParameter('appId');
        var applicationCategoryId = helper.getUrlParameter('appCategoryId');
        var appAssertId = helper.getUrlParameter('appAssertId');
        
        component.set("v.vMTPAppId", applicationId);
         component.set("v.vMTPAppAssertId", appAssertId);
        helper.getContentDocId(component);
        component.set("v.vMTPAppCategoryId", applicationCategoryId);
        console.log('---initializeAppAssets--'+applicationId);
        if(applicationId == '' && applicationCategoryId == ''){
            helper.getNewRecordInstance(component, "vMTP_App_Asset__c","newVMAppAsset", "newVMAppAssetError", "vMAppAssetCreator", "vMAppAsset");
        }else{
            helper.getAppSources(component);
        }
        helper.getNewRecordInstance(component, "vMTP_App_Source__c","newVMAppSource", "newVMAppSourceError", "vMAppSourceCreator", "vMAppSource");
    },
    
    uploadAssets : function(component, event, helper){
        component.set("v.loading", true);
        if(helper.validateAssets(component)){
            console.log('----uploadAssets--validated-');
           // helper.saveRecordAndCreateAssets(component, helper, "vMAppAssetCreator", "vMTP_App_Asset__c");
             helper.updateAppStatus(component);
        }else{
            component.set("v.loading", false);
        }
    },
    
    onCategoryVersionChange : function (component, event, helper) {
        console.log('version id' +component.find("appCategoryVersion").get("v.value"));
        var appCategoryVersion = component.find("appCategoryVersion").get("v.value");
        if(appCategoryVersion!=''){
            component.find('vMAppSourceCreator').saveRecord($A.getCallback(function(saveResult) {
                console.log('----saveResult---'+saveResult.state);
                if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
                    console.log("--saveAppSource-1-"+saveResult.recordId);
                    component.set("v.vmcAppSourceId", saveResult.recordId);
                } else if (saveResult.state === "INCOMPLETE") {
                    console.log("User is offline, device doesn't support drafts.");
                } else if (saveResult.state === "ERROR") {
                    console.log('Problem saving record, error: ' + JSON.stringify(saveResult.error));
                } else {
                    console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
                }
            }));
        }
    },
    
    fileSelected : function(component, event, helper){
        var fileElement = event.getSource();
        var files = fileElement.get("v.files");
        fileElement.showHelpMessageIfInvalid();
        var componentId = fileElement.getLocalId();
        var fileElements = component.find(componentId);
        if(files && files[0]){
            for(var index in fileElements) {
                if(fileElements[index].get("v.name") == event.getSource().get('v.name')) {
                    if(event.getSource().get('v.name')=='UserGuide') {
                        if(files[0].type != 'application/pdf') {
                            fileElements[index].setCustomValidity('Please upload a PDF File');
                            fileElements[index].reportValidity();
                            component.find(fileElement.get("v.name")).getElement().innerHTML = '';
                        } else {
                            component.find(fileElement.get("v.name")).getElement().innerHTML = files[0].name;
                            fileElements[index].setCustomValidity('');
                            fileElements[index].reportValidity();
                        }
                    } else if(event.getSource().get('v.name')=='AppSource') {
                        component.find(fileElement.get("v.name")).getElement().innerHTML = files[0].name;
                    } else {
                        if(files[0].size>500000 || (files[0].type != 'image/jpeg' && files[0].type != 'image/png')) {
                            fileElements[index].setCustomValidity('Please upload a JPEG or JPG File of size less than 0.5 MB');
                            fileElements[index].reportValidity();
                            component.find(fileElement.get("v.name")).getElement().innerHTML = '';
                        } else {
                            component.find(fileElement.get("v.name")).getElement().innerHTML = files[0].name;
                            fileElements[index].setCustomValidity('');
                            fileElements[index].reportValidity();
                        }
                    }
                    
                    
                }
            }
            
        }
    },
    
    appLogoSelected : function(component, event, helper){
        var fileElement = event.getSource();        
        console.log('--fileElement--'+fileElement.get("v.name"));
        var files = fileElement.get("v.files");
        component.find("logoFile").set("v.HTMLAttributes.src","");    
        
        if(files && files[0]){
            console.log('--files--'+files[0].name);
            component.find(fileElement.get("v.name")).getElement().innerHTML = files[0].name;
            var reader = new FileReader();
            reader.onload = function(e) {
                var imagePreviewComponent = component.find("logoFile");
                imagePreviewComponent.set("v.HTMLAttributes.src", e.target.result);
                console.log("----CREATE COMPONENT--");
                helper.showHideComponent(component, "logoFilePlaceholder", false);
                helper.showHideComponent(component, "logoFile", true);
            }
            reader.readAsDataURL(files[0]);
        }
    },
    
    handleRowAction: function (cmp, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        console.log('Showing Details: ' + JSON.stringify(row));
        switch (action.name) {
            case 'download':
                helper.downloadFile(row.contentVersionId);
                break;
            case 'delete':
                helper.deleteFiles(cmp, row.contentVersionId, 'AppSource' ,row.parentRecordId, helper);
                break;
        }
    }, 
    
    onFileUpload : function (component, event, helper) {
        component.set("v.loading", true);
        var uploadedFiles = event.getParam("files"); 
        var source = event.getSource().get("v.name");
        var sourceId = event.getSource().get("v.recordId");
        var documentId = uploadedFiles[0].documentId;  
        var fileName = uploadedFiles[0].name;  
        console.log('source ' +source +' documentId ' +documentId +' fileName ' +fileName);
        if(source == 'AppBanner'){
            console.log('component.get("v.appbannerId") ' +component.get("v.appbannerId"));
            if(component.get("v.appbannerId")!=null){
                console.log('delete existing appbanner');
                 helper.deleteFiles(component, component.get("v.appbannerId"), source ,component.get("v.vMTPAppAssertId"), helper);
				component.set("v.appbannerId",documentId);
            }else
				component.set("v.appbannerId",documentId);
        }else if(source == 'AppLogo'){
            if(component.get("v.appLogoId")!=null){
                console.log('delete existing appLogoId');
 				helper.deleteFiles(component, component.get("v.appLogoId"), source ,component.get("v.vMTPAppId"), helper);
				component.set("v.appLogoId",documentId);
                
            }else
				component.set("v.appLogoId",documentId);
        }else if(source == 'Screenshot1'){
            if(component.get("v.Screenshot1Id")!=null){
                console.log('delete existing Screenshot1Id');
 				helper.deleteFiles(component, component.get("v.Screenshot1Id"), source ,component.get("v.vMTPAppAssertId"), helper);
				component.set("v.Screenshot1Id",documentId);
                
            }else
				component.set("v.Screenshot1Id",documentId);
        }else if(source == 'Screenshot2'){
            if(component.get("v.Screenshot2Id")!=null){
                console.log('delete existing Screenshot2Id');
 				helper.deleteFiles(component, component.get("v.Screenshot2Id"), source ,component.get("v.vMTPAppAssertId"), helper);
				component.set("v.Screenshot2Id",documentId);
                
            }else
				component.set("v.Screenshot2Id",documentId);
        }else if(source == 'Screenshot3'){
            if(component.get("v.Screenshot3Id")!=null){
                console.log('delete existing Screenshot3Id');
 				helper.deleteFiles(component, component.get("v.Screenshot3Id"), source ,component.get("v.vMTPAppAssertId"), helper);
				component.set("v.Screenshot3Id",documentId);
                
            }else
				component.set("v.Screenshot3Id",documentId);
        }else if(source == 'Screenshot4'){
            if(component.get("v.Screenshot4Id")!=null){
                console.log('delete existing Screenshot4Id');
 				helper.deleteFiles(component, component.get("v.Screenshot4Id"), source ,component.get("v.vMTPAppAssertId"), helper);
				component.set("v.Screenshot4Id",documentId);
                
            }else
				component.set("v.Screenshot4Id",documentId);
        }else if (source == 'UserGuide'){
            if(component.get("v.attachmentInfo.AppGuide.contentVersionId")!=null){
                console.log('delete existing UserGuide');
 				helper.deleteFiles(component, component.get("v.attachmentInfo.AppGuide.contentVersionId"), source ,component.get("v.vMTPAppId"), helper);
				//component.set("v.Screenshot4Id",documentId);)
            }
        }else if (source == 'EULA'){
            if(component.get("v.attachmentInfo.EULA.contentVersionId")!=null){
                console.log('delete existing EULA Guide');
 				helper.deleteFiles(component, component.get("v.attachmentInfo.EULA.contentVersionId"), source ,component.get("v.vMTPAppId"), helper);
				//component.set("v.Screenshot4Id",documentId);)
            }
        }else if (source == 'appEngInstructions'){
            if(component.get("v.attachmentInfo.appEngInstructions.contentVersionId")!=null){
                console.log('delete existing appEngInstructions');
 				helper.deleteFiles(component, component.get("v.attachmentInfo.appEngInstructions.contentVersionId"), source ,component.get("v.vMTPAppId"), helper);
				//component.set("v.Screenshot4Id",documentId);)
            }
        }
		        
        helper.UpdateDocument (component, event, helper, documentId, fileName, source, sourceId);
    },
    
    download: function(component, event, helper){
        console.log("---download-1-");
        var attachId = event.target.name;
        window.open(window.location.protocol+'//'+window.location.hostname+'/sfc/servlet.shepherd/version/download/'+attachId);
    },
    
    navigateToAppUpload : function (component, event, helper) {
        var applicationId = helper.getUrlParameter('appId');
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": '/vmtp-appupload?appId='+applicationId,
        });
        urlEvent.fire();
    },
    openReviewModal: function (component, event, helper) {
        component.set("v.reviewApp", true);
    },
    
    closeReviewModal: function (component, event, helper) {
        component.set("v.reviewApp", false);
    }
    
    
    
})