({
	getNewRecordInstance : function(component, objectName, targetRecord, targetError, recordDataAuraId, targetFieldsObject){
        console.log('---newVMarketRecord--');
        var applicationId = this.getUrlParameter('appId');
        component.find(recordDataAuraId).getNewRecord(
            objectName, // sObject type (entityAPIName)
            null,      // recordTypeId
            false,     // skip cache?
            $A.getCallback(function() {
                console.log('---newVMarketRecord-callBack--');
                var rec = component.get("v."+targetRecord);
                var error = component.get("v."+targetError);
                component.set("v."+targetFieldsObject+".vMTP_App__c", applicationId);
                if(error || (rec === null)) {
                    console.log("Error initializing record template: " + error);
                }
                else {
                    console.log("Record template initialized: " + rec.apiName);
                }
            })
        );
    },
    
    loadAppCategoryVersions : function(component) {
        console.log('---loadAppCategoryVersions--');
		var loadVersions = component.get("c.getAppCategoryVersions");
        loadVersions.setParams ({
            "appId": component.get("v.vMTPAppId"),
            "appCategoryId": component.get("v.vMTPAppCategoryId")
        });
        component.set("v.loading", true);
        loadVersions.setCallback(this, function(response){
            var state = response.getState();
            console.log("---state--"+state);
            if (state === "SUCCESS") {                
            	var versionOptions = response.getReturnValue();
                console.log('---versions--'+JSON.stringify(versionOptions));
                component.set("v.appCategoryVersionOptions", versionOptions);
                if(versionOptions.length == 1){
                    component.set("v.showAppCategoryAndPackages", false);
                }else{
                    component.set("v.showAppCategoryAndPackages", true);
                }
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });
        $A.enqueueAction(loadVersions);
	},
    
    saveRecordAndCreateAssets : function(component, helper, dataServiceAuraId, objectName){
        var self = this;
        console.log('----saveRecordAndCreateAssets----'+dataServiceAuraId +'object ' +objectName );
        component.find(dataServiceAuraId).saveRecord($A.getCallback(function(saveResult) {
            console.log('----saveResult---'+saveResult.state);
            if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
                console.log("--saveRecordAndCreateAssets--"+objectName);
                if(objectName == "vMTP_App_Asset__c"){
                    console.log("--saveAppAssets--"+saveResult.recordId);
                     helper.updateAppStatus(component);
                     self.saveAppAssets(component, saveResult.recordId);
                }else if(objectName == "vMTP_App_Source__c"){
                    console.log("--saveAppSource-1-"+saveResult.recordId);
               //     self.saveAppSourcePackage(component, saveResult.recordId);
                    component.set("v.vmcAppSourceId", saveResult.recordId);
                }	
            } else if (saveResult.state === "INCOMPLETE") {
                console.log("User is offline, device doesn't support drafts.");
            } else if (saveResult.state === "ERROR") {
                console.log('Problem saving record, error: ' + JSON.stringify(saveResult.error) + ' -> ' +component.get("v.error"));
            } else {
                console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
            }
        }));
    },
 /*   
    saveAppAssets : function(component, sfRecordId){
        console.log("--saveAppAssets--"+sfRecordId);
         var attachmentObject = component.get('v.attachmentInfo');
         var filesUploaded = component.get('v.filesUploaded');
        console.log('saveAppAssets attobject ' +JSON.stringify(attachmentObject));
        console.log('saveAppAssets filesUploaded ' +JSON.stringify(filesUploaded));
        console.log('filesUploaded lenght ->' +filesUploaded.length);
        var appScreenshotComponents = component.find("screenshots");
        appScreenshotComponents = appScreenshotComponents.concat(component.find("assets"));
        console.log("----saveAppAssets--1--"+JSON.stringify(appScreenshotComponents));
        var sfObjectId = '';
        var newFilesSelected = false;               
        
        for(var appScreenshotCounter in appScreenshotComponents){
            console.log("----saveAppAssets--3--");
            var fileElement = appScreenshotComponents[appScreenshotCounter];
            var fileName = fileElement.get("v.name");
            console.log("----saveAppAssets--4--"+fileName);
            if(fileName != "AppSource"){
                var uploadedFiles = fileElement.get("v.files");
                console.log("----saveAppAssets--5--");
                if(fileName.startsWith("Screenshot")){
                    sfObjectId = sfRecordId;
                }else{
                    sfObjectId = component.get("v.vMTPAppId");
                }  
                if(!uploadedFiles){
                    console.log('--saveAppAssets--NO FILES--');
                }else{
                    newFilesSelected = true;
                    console.log("----saveAppAssets--6--");
                    for (var i = 0; i < uploadedFiles.length; i++) {
                        this.setupReader(component, uploadedFiles[i], sfObjectId, fileName+'_'+uploadedFiles[i].name);
                    }
                    console.log("----saveAppAssets--7--");
                }
            }
        }
        if(!newFilesSelected){
            component.set("v.loading", false);
            this.navigateToAppDetailPage(component);
        }
    },*/
   /*     
    saveAppSourcePackage : function(component, sfRecordId){
        var appSourceComponents = component.find("assets");
        console.log("--saveAppSource-2-"+sfRecordId);           
        for(var appSourceCounter in appSourceComponents){
            var fileElement = appSourceComponents[appSourceCounter];
            var fileName = fileElement.get("v.name");
            if(fileName == "AppSource"){
                var uploadedFiles = fileElement.get("v.files");                        
                if(!uploadedFiles){
                    console.log('--saveAppAssets--NO FILES--');
                }else{
                    for (var i = 0; i < uploadedFiles.length; i++) {
                        this.setupReader(component, uploadedFiles[i], sfRecordId, fileName+'_'+uploadedFiles[i].name);
                    }
                }
            }
        }
    },*/
    
    getAppSources : function(component){
        console.log("--getAppSources");
        component.set("v.loading", true);
        var getUploadedPackages = component.get("c.getAppSources");
        getUploadedPackages.setParams({
            "appId" : component.get("v.vMTPAppId")
        });
        getUploadedPackages.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {      
                var tableData = response.getReturnValue()
            	console.log('--getAppSources-SUCCESS--'+JSON.stringify(tableData));
                this.extractAttachments(component, tableData);
				this.loadAppCategoryVersions(component);              
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });
        $A.enqueueAction(getUploadedPackages);
    },
    
    UpdateDocument : function(component,event,helper, documentId, fileName, source, sourceId) {  
        var action = component.get("c.UpdateFiles");  
        action.setParams({"documentId":documentId,  
                          "title": source+fileName,  
                          "recordId": sourceId
                         });  
        action.setCallback(this,function(response){  
            var state = response.getState();  
            if(state=='SUCCESS'){  
                 var result = response.getReturnValue();  
                 console.log('Result Returned: ' +JSON.stringify(result));  
                 component.set("v.filesUploaded",result);  
                helper.getNewRecordInstance(component, "vMTP_App_Source__c","newVMAppSource", "newVMAppSourceError", "vMAppSourceCreator", "vMAppSource");
                this.getAppSources(component);     
            }  
            component.set("v.loading", false);
        });  
        $A.enqueueAction(action);  
    },  
    
    deleteFiles : function (component,documentId, source, sourceId, helper) {
        component.set("v.loading", true);
        console.log('delete source file ' +source);
        var action = component.get("c.deleteFiles");  
        action.setParams({"documentId":documentId,  
                          "source": source,  
                          "recordId": sourceId 
                         });  
        action.setCallback(this,function(response){  
            var state = response.getState();
            console.log('---state-deleteContentVersion-'+state);
            if(state === "SUCCESS"){
                if(source='AppSource'){
                    component.set("v.vmcAppSourceId", '');
                    component.set("v.data", response.getReturnValue());
                    this.getNewRecordInstance(component, "vMTP_App_Source__c","newVMAppSource", "newVMAppSourceError", "vMAppSourceCreator", "vMAppSource");
                    this.loadAppCategoryVersions(component);
                }
                else{
                    console.log('old ' +soucrce + 'Image successfully deleted');
                }
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });  
        $A.enqueueAction(action);  
    },
    
    extractAttachments : function(component, attachments){
        console.log('--extractAttachments--1-'+attachments);
        var appPackages = [];
        var attachmentObject = component.get('v.attachmentInfo');
        var screenShotName = '';
        for(var attachmentCounter in attachments){
            var attachmentJSONObject = attachments[attachmentCounter];
            if(attachmentJSONObject && attachmentJSONObject.docName){
                if(attachmentJSONObject.docName.startsWith('AppSource')){
                	appPackages.push(attachmentJSONObject);
                }else if(attachmentJSONObject.docName.startsWith('AppBanner')){
                    attachmentObject["AppBanner"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('UserGuide')){
                    attachmentObject["AppGuide"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('AppLogo')){
                    attachmentObject["AppLogo"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('Screenshot1')){
                    attachmentObject['Screenshot1'] = attachmentJSONObject;
                    screenShotName = 'Screenshot1';
                }else if(attachmentJSONObject.docName.startsWith('Screenshot2')){
                    attachmentObject['Screenshot2'] = attachmentJSONObject;
                    screenShotName = 'Screenshot2';
                }else if(attachmentJSONObject.docName.startsWith('Screenshot3')){
                    attachmentObject['Screenshot3'] = attachmentJSONObject;
                    screenShotName = 'Screenshot3';
                }else if(attachmentJSONObject.docName.startsWith('Screenshot4')){
                    attachmentObject['Screenshot4'] = attachmentJSONObject;
                    screenShotName = 'Screenshot4';
                }else if(attachmentJSONObject.docName.startsWith('EULA')){
                    attachmentObject['EULA'] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('appEngInstructions')){
                    attachmentObject['AppEngInstructions'] = attachmentJSONObject;                   
                }
            }    
        }
        if(attachmentObject[screenShotName]){
            console.log('----attachmentObject[screenShotName]--'+JSON.stringify(attachmentObject[screenShotName]));
            component.set("v.vmcAppAssetId", attachmentObject[screenShotName].parentRecordId);
            //component.find("vMAppAssetCreator").reloadRecord();
        }else{
			this.getNewRecordInstance(component, "vMTP_App_Asset__c","newVMAppAsset", "newVMAppAssetError", "vMAppAssetCreator", "vMAppAsset");            
        }
        component.set("v.data", appPackages);
        component.set("v.attachmentInfo", attachmentObject);
        console.log('---attachmentObject--'+JSON.stringify(attachmentObject));
        return appPackages;
    },
    
    getUrlParameter : function(sParam) {
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
        var sURLVariables = sPageURL.split('&');
        var sParameterName = [];
        var i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? '' : sParameterName[1];
            }
        }
        return '';
    },
    
   /* setupReader : function(component, file, parentRecordId, fileName) {
        console.log("----setupReader-");
        var fr = new FileReader();
        var self = this;
        var fileObj = new Object();
        fr.onload = function() {
            var fileContents = fr.result;
            var base64Mark = 'base64,';
            var dataStart = fileContents.indexOf(base64Mark) + base64Mark.length;
            
            fileContents = fileContents.substring(dataStart);
            fileObj = {
                parentId: parentRecordId,
                fileName: fileName,
                attachmentBody: '', 
                fileContentType: file.type
        	};
            console.log('----onload--'+fileObj.fileName);
            var versionId = self.getExistingVersionId(component, fileObj.fileName);
            $A.getCallback(function() {
                if (component.isValid()) {
                    self.sendFile(component, fileObj, fileContents, versionId);
                }
            })();
        };
        fr.readAsDataURL(file);
    },
    */
    getExistingVersionId : function(component, fName){
        var attachmentObject = component.get("v.attachmentInfo");
        console.log('---getExistingVersionId--'+JSON.stringify(attachmentObject));
        if(fName.startsWith('AppGuide') && attachmentObject['AppGuide']){
       		return attachmentObject['AppGuide'].contentVersionId;
        }else if(fName.startsWith('AppLogo') && attachmentObject['AppLogo']){
            return attachmentObject['AppLogo'].contentVersionId;
        }else if(fName.startsWith('Screenshot1') && attachmentObject['Screenshot1']){
            return attachmentObject['Screenshot1'].contentVersionId;
        }else if(fName.startsWith('Screenshot2') && attachmentObject['Screenshot2']){
            return attachmentObject['Screenshot2'].contentVersionId;
        }else if(fName.startsWith('Screenshot3') && attachmentObject['Screenshot3']){
            return attachmentObject['Screenshot3'].contentVersionId;
        }else if(fName.startsWith('Screenshot4') && attachmentObject['Screenshot4']){
            return attachmentObject['Screenshot4'].contentVersionId;
        }
        return '';
    },
    
    /*sendFile : function(component, obj, fileContents, existingVersionId){
        component.set("v.loading", true);
        console.log('--sendFile--');
        var action = component.get("c.saveFile"); 
        action.setParams({
            fileUploadJSONString : JSON.stringify(obj),
            fileBody : fileContents,
            contentVersionId : existingVersionId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log("----status-sendFile-"+state);
            if (state === "SUCCESS") {                
            	console.log('--SUCCESS--');
                this.getAppSources(component);     
                this.getNewRecordInstance(component, "vMTP_App_Source__c","newVMAppSource", "newVMAppSourceError", "vMAppSourceCreator", "vMAppSource");
                var totalFilesSent = component.get("v.totalFileSentToSF");
                var totalFiles = component.get("v.totalFiles");
                totalFilesSent = totalFilesSent + 1;
                console.log('--totalFilesSent--'+totalFilesSent+'--totalFiles-'+totalFiles);
                if(totalFilesSent == totalFiles){
                    console.log('-----thisthis----'+JSON.stringify(this));
                    this.updateAppStatus(component);
                }else{
                    component.set("v.totalFileSentToSF", totalFilesSent);
                }
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });
        $A.enqueueAction(action);
    },*/
    
    showHideComponent : function(component, auraId, showComponent){
        var lightningElement = component.find(auraId);
        if(showComponent){
    		$A.util.addClass(lightningElement, 'slds-show');
            $A.util.removeClass(lightningElement, 'slds-hide');
        }else{
            $A.util.addClass(lightningElement, 'slds-hide');
            $A.util.removeClass(lightningElement, 'slds-show');
        }
	},
    
    validateAssets : function(component){
        var totalFileCount = 0;
        var fileArray = component.find("screenshots");
        var noScreenshotSelected = [];
        var filesValidated = true;
        for(var fileCounter in fileArray){
            var fileComponent = fileArray[fileCounter];
            var uploadedFiles = fileComponent.get("v.files");
            console.log('---files--'+JSON.stringify(uploadedFiles));
            if(!uploadedFiles){
                noScreenshotSelected.push("true");
            }else{
                noScreenshotSelected.push("false");
                totalFileCount = totalFileCount + 1;
            }
        }
        if(noScreenshotSelected.indexOf("false") == -1){
            for(var fileCounter in fileArray){
                var fileComponent = fileArray[fileCounter];
                var isRequired = fileComponent.get("v.required");
                console.log('--isRequired--'+isRequired);
                var uploadedFiles = fileComponent.get("v.files");
                if(!uploadedFiles && isRequired){
                    filesValidated = false;
                    fileComponent.showHelpMessageIfInvalid();
                    console.log('---isValid'+fileComponent.showHelpMessageIfInvalid());
                }else if(isRequired || uploadedFiles){
                	totalFileCount = totalFileCount + 1;
            	}
            }
        }
        var assetArray = component.find("assets");
        for(var fileCounter in assetArray){
            var fileComponent = assetArray[fileCounter];
            var isRequired = fileComponent.get("v.required");
            var uploadedFiles = fileComponent.get("v.files");
            console.log('---files--'+JSON.stringify(uploadedFiles))
            if(!uploadedFiles && isRequired){
            	filesValidated = false;
               	fileComponent.showHelpMessageIfInvalid();
            }else if(isRequired || uploadedFiles){
                totalFileCount = totalFileCount + 1;
            }
        }
        console.log('--totalFiles-'+totalFileCount);
        component.set("v.totalFiles", totalFileCount);
        return filesValidated;
    },
    
    downloadFile : function(contentVersionId){
        console.log('---downloadFile---'+contentVersionId);
        console.log('---downloadFile-1-'+window.location.protocol+'//'+window.location.hostname);
        window.open(window.location.protocol+'//'+window.location.hostname+'/sfc/servlet.shepherd/version/download/'+contentVersionId);
    },
    
    updateAppStatus : function(component){
        console.log('--updateAppStatus-1-');
        component.set("v.loading", true);
        var appObject = new Object();
        appObject.Id = component.get("v.vMTPAppId");
        appObject.ApprovalStatus__c = 'Submitted';
        appObject.IsActive__c = true;
        var saveAppAction = component.get("c.updateApp");
        saveAppAction.setParams({
            "vMarketApp" : JSON.stringify(appObject),
        });
        saveAppAction.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {             
                var appRecordId = response.getReturnValue();
                this.navigateToAppDetailPage(component);
                console.log('---updateAppStatus--'+appRecordId);
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });
        $A.enqueueAction(saveAppAction);
    },
    
    getContentDocId : function(component, event, helper) {
        var action = component.get("c.getAttachedFiles");
        var applicationId = component.get("v.vMTPAppId");
        var sourceIds = [applicationId,component.get("v.vMTPAppAssertId") ];
        console.log('sourceIds ' +sourceIds);
        action.setParams ({
            appId: sourceIds
			//appAssertId: component.get("v.vMTPAppAssertId")
        });
        action.setCallback(this, function(response){
            console.log('--'+response.getReturnValue());
            var state = response.getState();
            if(state == "SUCCESS"){
                var dataList = response.getReturnValue();
                var attachemnts = [];
                for(var dataIndex in dataList) {
                    if(dataList[dataIndex].Title.includes('AppLogo') || dataList[dataIndex].Title.includes('Applogo')) {
                        //console.log('v.appLogoId ' +dataList[dataIndex].Id);
                        component.set("v.appLogoId", dataList[dataIndex].Id );
                    }
                    if(dataList[dataIndex].Title.includes('AppBanner') || dataList[dataIndex].Title.includes('Appbanner')) {
                        //console.log('v.appbannerId ' +dataList[dataIndex].Id);
                        component.set("v.appbannerId", dataList[dataIndex].Id );
                    } 
                    
                    if(dataList[dataIndex].Title.includes('Screenshot1') || dataList[dataIndex].Title.includes('screenshot1')) {
                      //  console.log('v.Screenshot1Id ' +dataList[dataIndex].Id);
                        component.set("v.Screenshot1Id", dataList[dataIndex].Id );
                    }else if(dataList[dataIndex].Title.includes('Screenshot2') || dataList[dataIndex].Title.includes('screenshot2')) {                      
                        component.set("v.Screenshot2Id", dataList[dataIndex].Id );
                    }else if(dataList[dataIndex].Title.includes('Screenshot3') || dataList[dataIndex].Title.includes('screenshot3')) {                      
                        component.set("v.Screenshot3Id", dataList[dataIndex].Id );
                    }else if(dataList[dataIndex].Title.includes('Screenshot4') || dataList[dataIndex].Title.includes('screenshot4')) {                      
                        component.set("v.Screenshot4Id", dataList[dataIndex].Id );
                    }                     
                }
            }
            else{
                alert("Error in get Data getVMTAppImages");
            }
        });
        $A.enqueueAction(action);
    },
    
    navigateToAppDetailPage : function(component){
        console.log('-----navigateToAppAssetPage----');
        var appId = component.get('v.vMTPAppId');
		console.log('---appId--'+appId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": '/vmtp-devappdetails?appId='+appId
        });
        urlEvent.fire();
    }
})