({
    fetchProductDoc : function(component, event) {
        
        var prodVal = component.get("v.prodValue");
     console.log('ProdVal = ' + prodVal);
        var selectedVersion;
        if(component.find("selectVer") != undefined) {
            selectedVersion = component.find("selectVer").get("v.value");
        }
        if(selectedVersion === undefined) {
            selectedVersion = '';
        }
        component.set("v.selectedVersion", selectedVersion);
        var action = component.get("c.getProductDoc");
        action.setParams({
            productvalue: prodVal, VersionInfo : component.get("v.selectedVersion")
        });
        console.log('ProdVal 2= ' + prodVal);
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            //alert('state = ' + state);
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('response = ' + JSON.stringify(response));
                component.set("v.prods", response);          
            }
        });
        $A.enqueueAction(action);	
    },
    
    fetchVersions : function(component, event) {
        //var prodVal = component.get("v.prodValue");
        var selectedAppCategory;
        if(component.find("selectAppCat") != undefined) {
            selectedAppCategory = component.find("selectAppCat").get("v.value");
        }
        if(selectedAppCategory === undefined) {
            selectedAppCategory = '';
        }
        component.set("v.prodValue", selectedAppCategory);
        console.log('selectedAppCategory ' +selectedAppCategory);
        console.log('selectedAppCategory Version ' +component.get("v.selectedVersion"));
        
        var action = component.get("c.getVersions");
        action.setParams({
            productvalue: selectedAppCategory
	
        });        
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            //alert('state = ' + state);
            if (state === "SUCCESS") {
                var versions = response.getReturnValue();
                //alert('response = ' + versions);
                component.set("v.versions", versions);          
            }
        });
        $A.enqueueAction(action);	
    },
    
})