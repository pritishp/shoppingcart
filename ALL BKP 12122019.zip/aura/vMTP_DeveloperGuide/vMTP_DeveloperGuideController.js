({
    onAppCatChange : function(component, event, helper) {       
        component.set("v.prodValue", '');
        component.set("v.prods",[]);
        component.set("v.selectedVersion", '');
		helper.fetchVersions(component, event);
    },
    
    handleActiveTab : function(component, event, helper) {
        component.set("v.prodValue", '');
        component.set("v.prods",[]);
        component.set("v.selectedVersion", '');
        component.set("v.selectedTermResponse", '');
        component.find("selectTerm").set("v.value",'');
    },
    
    callProductDocs : function(component, event, helper) {
        //component.set("v.prodValue", "Eclipse"); 
	var prodVal = component.get("v.prodValue");
        var selectedVersion;
        if(component.find("selectVer") != undefined) {
            selectedVersion = component.find("selectVer").get("v.value");
        }
        if(selectedVersion === undefined) {
            selectedVersion = '';
        }
        component.set("v.selectedVersion", selectedVersion);
        console.log('selectedVersion ' +selectedVersion);
        console.log('prodVal from controller ' +prodVal);
        if(selectedVersion != '') {
            helper.fetchProductDoc(component, event);
        }
        else
            component.set("v.prods",[]);
        
    },  
    onTermSelect : function(component, event, helper) {        
        component.set("v.selectedTermResponse", null);
        component.set("v.regTermStRes", null);
        component.set("v.techTermStRes", null);		
        component.set("v.prodValue", null);
        component.set("v.prods",[]);
        var selectedTerms;
        if(component.find("selectTerm") != undefined) {
            selectedTerms = component.find("selectTerm").get("v.value");
        }
        if(selectedTerms === undefined) {
            selectedTerms = '';
        }
        
        //component.set("v.selectedTermResponse", selectedTerms);
        var path;
        if(selectedTerms == 'ProgramTerms'){
            path = $A.get("$Resource.vMarketplace_ProgramTerms");
        }else if(selectedTerms == 'RegulatoryTerms'){
            path = $A.get("$Resource.vMTP_RegulatoryTerms");
        }else if(selectedTerms == 'TechnicalTerms')  { 
            path = $A.get("$Resource.vMTP_TechnicalTerms");
        }    
        var req = new XMLHttpRequest();
        req.open("GET", path);
        req.addEventListener("load", $A.getCallback(function() {
            component.set("v.selectedTermResponse", req.response);
            console.log('Response -> '+req.response);
        }));
        req.send(null);
    },    
})