({
	doInit : function(component, event, helper) {        
		helper.isAuthenticated(component,event);
        helper.isTermsHeaderVisible(component,event);
        helper.isDeveloper(component,event);
        helper.isDeveloperPending(component,event);
        helper.cartItemCount(component,event);
        helper.getUserInfo(component,event,helper);
        helper.authorizeDeveloperAccount(component);
        helper.getStripeConnectURL(component, event, helper);
        component.set("v.pageName", helper.getPageName());
        console.log('--PAGE NAME---'+component.get("v.pageName"));
	},
   /*
    addCartItem : function(component, event, helper) {
        helper.addCartItem(component,event);
    },
    removeCartItem : function(component, event, helper) {
        helper.removeCartItem(component,event);
    },
    */
    openCartMessageModel: function(component, event, helper) {
      // for Display Model,set the "isOpen" attribute to "true"
      component.set("v.cartMessageModalOpen", true);
   }, 
   closeCartMessageModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
      component.set("v.cartMessageModalOpen", false);
   },
    reloadCartCount : function(component, event, helper) {
        helper.cartItemCount(component,event);
    },
    handleSelectedMenu : function (component, event, helper) {
        var selectedMenuItemValue = event.getParam("value");
        if(selectedMenuItemValue == 'myOrders') {
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-all-orders"
            });
            urlEvent.fire();
        }
        if(selectedMenuItemValue == 'mySubscriptions') {
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-all-subscriptions"
            });
            urlEvent.fire();
        }
        if(selectedMenuItemValue == 'myDashboard') {
            /*var myDashboardEvent = $A.get("e.force:navigateToURL");
            myDashboardEvent.setParams({
                "url": "/varianMarketPlace/s/vmtp-landing-dev",
               
            });
            myDashboardEvent.fire();*/
            window.location.href = '/varianMarketPlace/s/vmtp-landing-dev';
        }
        if(selectedMenuItemValue == 'connectWithStripe') {    
            var stripeURL = component.get('v.stripeConnectURL');                        
            window.open(
            	stripeURL,
            	'_blank' 
            );            
        }
        if(selectedMenuItemValue == 'myProfile') {
            var myProfileUrlEvent = $A.get("e.force:navigateToURL");
            myProfileUrlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-myprofile"
            });
            myProfileUrlEvent.fire();
        }
        if(selectedMenuItemValue == 'logout') {
           // window.location.replace("https://sfdev1-varian.cs62.force.com/secur/logout.jsp?retUrl=https://sfdev1-varian.cs62.force.com/varianMarketPlace/s/login");
            helper.handleLogout(component,event,helper);
        }
    },
    openACHModal : function (component, event, helper) {
        component.set("v.isACHModalOpen", true);
    },
    openAppUploadPopup : function(component, event, helper){
        var popupComponent = component.find("uploadAppPopup");
        $A.util.addClass(popupComponent, 'slds-show');
        $A.util.removeClass(popupComponent, 'slds-hide');
    },
    
    executeAppUploadActions : function(component, event, helper){
        var clickedActionName = event.getSource().getLocalId();
        console.log("--clickedActionName--"+clickedActionName);
        if(clickedActionName == 'openAppUploadPopup'){
            var popupComponent = component.find("uploadAppPopup");
            $A.util.addClass(popupComponent, 'slds-show');
            $A.util.removeClass(popupComponent, 'slds-hide');
        }else if(clickedActionName == 'newAppUpload'){
            helper.navigateToCommunityPage(component, "vmtp-appupload");
        }else if(clickedActionName == 'bugFix'){
            helper.navigateToCommunityPage(component, "vmtp-appbugfix");
        }else if(clickedActionName == "closeAppUploadPopup"){
            var popupComponent = component.find("uploadAppPopup");
            $A.util.addClass(popupComponent, 'slds-hide');
            $A.util.removeClass(popupComponent, 'slds-show');
        }
    }
})