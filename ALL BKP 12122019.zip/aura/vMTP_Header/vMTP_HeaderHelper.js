({
    isAuthenticated: function(component,event) {
        var action = component.get("c.isAuthenticatedUser");
      	console.log('---isAuthenticated---');   
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            console.log('---state'+state);
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('authenticated==>'+response);
                // set searchResult list with return value from server.
                component.set("v.authenticated", response);
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
                component.set("v.authenticated", false);
            }
 
        });
      	// enqueue the Action  
        $A.enqueueAction(action);
    },
    isTermsHeaderVisible: function(component,event) {
        var action = component.get("c.isTermsOfUseHeader");
        var pathname = window. location. pathname; 
        action.setParams({
            "pageURL": pathname
        });
      	// set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('termsOfUseHeader==>'+response);
                // set searchResult list with return value from server.
                component.set("v.termsOfUseHeader", response);
            } else {
                component.set("v.termsOfUseHeader", false);
            }
 
        });
      	// enqueue the Action  
        $A.enqueueAction(action);
    },
    isDeveloper: function(component,event) {
        var action = component.get("c.isDev");
      	// set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('isDeveloper==>'+response);
                // set searchResult list with return value from server.
                component.set("v.developer", response);
            } else {
                component.set("v.developer", false);
            }
 
        });
      	// enqueue the Action  
        $A.enqueueAction(action);
    },
    isDeveloperPending: function(component,event) {        
        var action = component.get("c.isDevRequestPending");        
      	// set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();            
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('isDeveloperPending==>'+response);
                // set searchResult list with return value from server.
                component.set("v.developerPending", response);
            } else {
                component.set("v.developerPending", false);
            }
 
        });
      	// enqueue the Action  
        $A.enqueueAction(action);
    },
    cartItemCount: function(component,event) {        
        var action = component.get("c.getCartItemCount");        
      	// set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();            
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('cartItemCount==>'+response);
                // set searchResult list with return value from server.
                component.set("v.cartItemCount", response);
            } 
        });
      	// enqueue the Action  
        $A.enqueueAction(action);
    },
    getUserInfo: function(component,event,helper){
       	var action = component.get("c.fetchUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
               // set current user information on userInfo attribute
               if(storeResponse.ContactId != null) {
                    component.set("v.isInternalUser", false);
                } else {
                    component.set("v.isInternalUser", true);
                    helper.getUserProfileName(component,event,helper);
                }
                component.set("v.userInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
   /* addCartItem: function(component,event){        
        var action = component.get("c.addAppToCart");
        var appId = 'a5S5C0000004v9tUAA';       	
        action.setParams({
            "appId": appId
        });
        component.set("v.vMarketSpinner", true);
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
               	console.log('addcartItem==>'+storeResponse);
                if(storeResponse[0] === 'false' || storeResponse[0] === 'False') {
                    // TODO - Print the error
                    component.set("v.cartMessage", storeResponse[1]);
                    component.set("v.cartMessageModalOpen", true);
                } else {
                    this.cartItemCount(component,event);
                }
                component.set("v.vMarketSpinner", false);
            }
        });
        $A.enqueueAction(action);
    },
    removeCartItem: function(component,event){        
        var action = component.get("c.removeAppFromCart");
        var appId = 'a5S5C0000004v9tUAA';       	
        action.setParams({
            "appId": appId
        });
        component.set("v.vMarketSpinner", true);
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
               	console.log('removeCartItem==>'+storeResponse);
                this.cartItemCount(component,event);
                component.set("v.vMarketSpinner", false);
            }
        });
        $A.enqueueAction(action);
    },
    */
    showSpinner: function(component, event) {
        alert(111);
      // make Spinner attribute true for display loading spinner 
      component.set("v.Spinner", true); 
   },
   hideSpinner : function(component,event){
       alert(222);
     // make Spinner attribute to false for hide loading spinner    
     component.set("v.Spinner", false);
   },
   
   authorizeDeveloperAccount : function(component){
	   var stripeKey = this.getUrlParameter('code');
	   var scopeValue = this.getUrlParameter('scope');
	   console.log('---stripeKey--'+stripeKey);
	   console.log('---scopeValue--'+scopeValue);
	   if(stripeKey != '' && scopeValue != ''){
		   console.log('---in authorize--');
		   var action = component.get("c.authorizeCustomerAccount");
		   action.setParams({
			   "customerStripeAccId": stripeKey,
			   "scope": scopeValue
		   });
		   component.set("v.vMarketSpinner", true);
		   action.setCallback(this, function(response) {
		   var state = response.getState();
		   		console.log('---AUTHORIZE STRIPE--'+state);
	            if (state === "SUCCESS") {
	                component.set("v.vMarketSpinner", false);
	            }else{
	            	console.log('----ERROR--authorize--'+response.getError());
	            }
	        });
	        $A.enqueueAction(action);
        }
   },
    
    getUrlParameter : function(sParam) {
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
        var sURLVariables = sPageURL.split('&');
        var sParameterName = [];
        var i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? '' : sParameterName[1];
            }
        }
        return '';
    },
    
    getPageName : function(){
        var pageName = decodeURIComponent(window.location);
        var pageNameArray = pageName.split('/');
        var pageNameArrayLength = pageNameArray.length;
        return pageNameArray[pageNameArrayLength-1];
    },
    getUserProfileName : function(component,event,helper) {
		 var action = component.get("c.getUserProfile"); 
         action.setCallback(this, function(a) {
         	var result = a.getReturnValue();         
            console.log('getUserProfile=='+result); 
             if( !(result === 'VMS VMarket Admin' || result === 'VMS System Admin' || result === 'System Administrator') ){
                 component.set("v.showThirdParty", false);
             }
      	});
      $A.enqueueAction(action);
	},
    
    navigateToCommunityPage : function(component, pageName){
        console.log('-----navigateToAppAssetPage----');
        var appId = component.get('v.vMTPAppId');
		console.log('---appId--'+appId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": '/'+pageName
        });
        urlEvent.fire();
    },
     handleLogout : function(component,event,helper) {
          console.log('-----HandleLogout----');
		  var logoutUser = component.get("c.logoutUser");
          logoutUser.setCallback(this, function(response) {              
              var state = response.getState();
	            if (state === "SUCCESS") {
	               var logoutUrl = response.getReturnValue();
                     //window.location.replace('/varianMarketPlace/s/login/');
                    window.location.replace('/apex/vMarketPlaceLogoutPage');
	            }else{
	            	console.log('----ERROR--authorize--'+response.getError());
	            }
        });
        $A.enqueueAction(logoutUser);
	},
    getStripeConnectURL: function(component,event,helper) {
        var action = component.get("c.isDevStripeNotConnected");
        action.setCallback(this, function(response) {              
            var state = response.getState();
            console.log('getStripeConnectURL state',state);
            if (state === "SUCCESS") {
	        	var stripeUrl =  response.getReturnValue();  
                component.set("v.stripeConnectURL", stripeUrl);
                console.log('getStripeConnectURL returnValue',stripeUrl);
            }else{
	            component.set("v.stripeConnectURL", '');	
            }
        });
        $A.enqueueAction(action);
    }
    
})