({
    navigateTo: function (cmp, event, helper) {
        var name = event.getSource().get('v.name');
        var orderId = event.getSource().get('v.class');
        
        /* For Dashboard Navigation, url navigation doesn't work as Chart.js library is included on Dashboard page */
        if(name=='dashboard') {
            window.location.href = '/varianMarketPlace/s/vmtp-landing-dev';
        } else {
            var urlEvent = $A.get("e.force:navigateToURL");         
            
            if( name == 'all products' ){
                urlEvent.setParams({ "url": '/'});
            }else if( name == 'All Orders' ){
                urlEvent.setParams({ "url": '/vmc-all-orders'});
            }else if( name == 'thirdParty products' ){
                urlEvent.setParams({ "url": '/?activeTab=vMarket'});
            }else if( name == 'All Subscriptions' ){
                urlEvent.setParams({ "url": '/vmc-all-subscriptions'});
            }else if( name != null && name != undefined ){
                urlEvent.setParams({ "url": '/?activeTab=' + name });
            }            
            
            urlEvent.fire();
        }
        
    }
})