({
	doInit : function(component, event, helper) {
		helper.fetchEntries(component, event);
		helper.fetchAppsTable(component, event);	
	},

	callAppTable : function(component, event, helper) {
		helper.fetchAppsTable(component, event);
	},

    nextPage:function(component, event, helper) {
        var totalRecs = parseInt(component.get('v.totalRecs'))
        var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));
        console.log(totalRecs+'==='+blockSize+'=='+index);
        var nextIndex = index + blockSize;        
        
        if((index + blockSize) >= totalRecs){
            return false;
        }
        
        component.set("v.index", nextIndex);       
        helper.fetchAppsTable(component, event);
    },
    prevPage:function(component, event, helper) {
        var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));    
        var prevIndex = index - blockSize;
        if (prevIndex < 0){
            prevIndex = 0;
            return false;
    	}
        
    	component.set("v.index", prevIndex);    
        helper.fetchAppsTable(component, event);
	},	
})