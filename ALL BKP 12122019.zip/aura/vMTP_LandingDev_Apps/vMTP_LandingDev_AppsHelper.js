({
	fetchEntries : function(component, event) {
        var action = component.get("c.getEntriesValues");
      	// set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            //alert('state 2 = ' + state);
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                //alert('response 2 = ' + response);
                //component.set("v.earnings", response);
                //alert('response = ' + JSON.stringify(response));

	            var entryList = [];
				for(var key in response){
					entryList.push({value:response[key], key:key});
				}
				//alert('entryList = ' + entryList);
				component.set("v.entries", entryList);                
            }
        });
        $A.enqueueAction(action);		
	},

	fetchAppsTable : function(component, event) {
		//alert('in fetchAppsTable');
        //var self = component;
        var selectedFilterValue;
        if(component.find("selectedFilterValue") != undefined) {
        	selectedFilterValue = component.find("selectedFilterValue").get("v.value");
        }

        //alert('***selectedFilterValue**'+selectedFilterValue);
        if(selectedFilterValue === undefined) {
            selectedFilterValue = '';
        }

		var totalRecs = parseInt(component.get('v.totalRecs'));
        var index = parseInt(component.get('v.index'));
        var blockSize = parseInt(component.get('v.blockSize'));

         // alert('totalRecs passed = ' + totalRecs);
         // alert('index passed = ' + index);
         // alert('blockSize passed = ' + blockSize);

        var action = component.get("c.getAppsByDeveloper");
        action.setParams({
            selectedValue: String(selectedFilterValue),
            //searchKeyword: component.get('v.appNameFromEvent'),
            totalRecs: totalRecs,
            index: index,
            blockSize: blockSize
        });

      	// set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            //alert('state for app table = ' + state);
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                // alert('response for app table total = ' + response.totalRecs);
                // alert('response for app table list = ' + response.appDetList.length);
                component.set("v.apps", result.appDetList);
                //alert('response = ' + JSON.stringify(response));               

	              var totalRecs = result.totalRecs;
	              //alert('totalRecs = ' + totalRecs);
	              var index = result.recIndex;
	              //alert('recIndex = ' + index);

	              component.set("v.totalRecs",totalRecs);
	              component.set('v.index', index);
	              var startOffset = index + 1;
	              var endOffset = index + blockSize;
	              if( endOffset >  totalRecs){
	                    endOffset = totalRecs;
	              }
	              component.set('v.startOffset', startOffset);
	              component.set('v.endOffset', endOffset);

            }
        });
        $A.enqueueAction(action);		
	},
})