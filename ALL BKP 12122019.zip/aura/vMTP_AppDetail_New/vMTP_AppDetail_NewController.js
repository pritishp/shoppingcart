({
	getWrapperData : function(component, event, helper) {
        component.set("v.loaded", true);
        helper.getAccountDetails(component, event, helper);
        helper.getContactInfo(component, event, helper);
        helper.getURLParameters (component, event, helper);
        var action = component.get("c.incrementReadOnlyCount");
        var applicationId = component.get("v.appId");
        action.setParams ({
            appId: applicationId
        });
       action.setCallback(this, function(a) { 
       var result = a.getReturnValue();
       	if(result!== '' && result!==null){
            helper.getWrapperData (component, event, helper);
       	} 
      });
      $A.enqueueAction(action); 
	},
    carouselClick: function(component, event, helper) {
    	component.set("v.appVideoModalOpen", true);
	},
    openAppVideoModal: function(component, event, helper) {
        component.set("v.appVideoModalOpen", true);
    },
	closeAppVideoModal: function(component, event, helper) {
        component.set("v.appVideoModalOpen", false);
    },
    fetchCurrencyValue : function (component, event) {
        console.log("currency existing " +component.get("v.currencyISOCode"));
        component.set("v.conversionRate", event.getParam("conversionRate")); 
        component.set("v.currencyISOCode", event.getParam("selectedCurrency"));
        var resp = component.get("v.subscriptionPlans");
        if(resp && resp.subscriptionPlans) {
            var subFrequency = [];
            var appPrice;
            for(var key in resp.subscriptionPlans){
                appPrice = (resp.subscriptionPlans[key].vMTP_Price__c * component.get("v.conversionRate")).toFixed(2);
                if(resp.subscriptionPlans[key].vMTP_Duration_Type__c == 'Monthly')
                    subFrequency.push({label:'Monthly : '+component.get("v.currencyISOCode") +' '+appPrice,value:resp.subscriptionPlans[key].vMTP_Duration_Type__c});
                if(resp.subscriptionPlans[key].vMTP_Duration_Type__c == 'Quarterly')
                    subFrequency.push({label:'Quarterly : '+component.get("v.currencyISOCode") +' '+appPrice,value:resp.subscriptionPlans[key].vMTP_Duration_Type__c});
                if(resp.subscriptionPlans[key].vMTP_Duration_Type__c == 'Half Yearly')
                    subFrequency.push({label:'Half Yearly : '+component.get("v.currencyISOCode") +' '+appPrice,value:resp.subscriptionPlans[key].vMTP_Duration_Type__c});
                if(resp.subscriptionPlans[key].vMTP_Duration_Type__c == 'Yearly')
                    subFrequency.push({label:'Yearly : '+component.get("v.currencyISOCode") +' '+appPrice,value:resp.subscriptionPlans[key].vMTP_Duration_Type__c});
            }
            component.set("v.options",subFrequency);
        }
    }
})