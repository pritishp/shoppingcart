({
    init : function(component, event, helper) {
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
        console.log('payment type ' + component.get("v.selectedPaymentType"));
        console.log('appTotalQty ' + component.get("v.appTotalQty"));
        console.log('brachyTotalQty ' + component.get("v.brachyTotalQty"));
        var brachyTotalQty = component.get("v.brachyTotalQty");
        component.set('v.today', today);
        component.set("v.selectedBillToRecord", component.get("v.billToErp"));
        component.set("v.selectedShipToRecord", component.get("v.shipToErp"));
        component.set("v.selectedContactRecord",component.get("v.orderContact"));
        if(!component.get("v.cart.Shipping_Contact_Attn__c"))
        	component.set("v.cart.Shipping_Contact_Attn__c", component.get("v.contactInfo.Name"));
        if(!component.get("v.cart.Shipping_Contact_Phone__c"))
        	component.set("v.cart.Shipping_Contact_Phone__c", component.get("v.contactInfo.Phone"));
        if(!component.get("v.cart.Shipping_Contact_Email__c"))
        component.set("v.cart.Shipping_Contact_Email__c", component.get("v.contactInfo.Email"));
        if(brachyTotalQty > 0) // Added By Phani 04242019
        	helper.getShippingMethodPicklist(component, event, helper); 
       
        if(!component.get("v.cart.vMC_Shipping_Method__c"))
            	 component.set('v.cart.vMC_Shipping_Method__c','Customer Carrier');
        var shippingMethod = component.get("v.cart.vMC_Shipping_Method__c");
        console.log('shippingMethod ->' +component.get('v.selectedShippingMethod'));
        console.log('shippingMethod ' +shippingMethod);
        if(brachyTotalQty > 0 && shippingMethod) // Updated By Phani 04242019
        	helper.showShippingTypes(component, event, helper,shippingMethod);
        if(!component.get("v.contactInfo.Name"))
        {
         
         component.find('shipToName').set('v.value',component.get("v.cart.Order_Contact__r.Name"));
		 component.find('shipToPhone').set('v.value',component.get("v.cart.Order_Contact__r.Phone"));
         component.find('shipToEmail').set('v.value',component.get("v.cart.Order_Contact__r.Email"));
            
        }
    },
    onRender: function(component, event, helper) {
       /* console.log('appTotalQty==='+component.get('v.appTotalQty'));
        console.log('brachyTotalQty==='+component.get('v.brachyTotalQty'));
        var thirdPartyToatlQty = parseInt(component.get('v.appTotalQty'));
        var brachyTotalQty = parseInt(component.get('v.brachyTotalQty'));
        if( thirdPartyToatlQty != 0 && brachyTotalQty == 0 ){
            component.set('v.disabledInput', true);
            component.find('customerCarrierType').set("v.value", '');
            component.find('shippingNote').set("v.value", '');
            component.find('fob').set("v.value", '');
            //component.find('shippingMethod').set("v.value", '');
            component.find('customerCarrierNo').set("v.value", '');
            component.find('orderContact').set("v.value", '');
            component.find('shipToName').set("v.value", '');
            component.find('shipToPhone').set("v.value", '');
            component.find('shipToEmail').set("v.value", '');
        }*/
        
      /*  if( (typeof component.get("v.contactInfo.Id") !== 'undefined') && (component.get("v.contactInfo.Id") !== '') ){
            component.find('orderContact').set('v.value',component.get("v.contactInfo.Name"));
            if(component.find('shipToName') && component.find('shipToName').get("v.value")!='') {
                component.find('shipToName').set("v.value", component.get("v.contactInfo.Name"));
            }  
            if(component.find('shipToPhone') && component.find('shipToPhone').get("v.value") !='') {
                component.find('shipToPhone').set("v.value", component.get("v.contactInfo.Phone"));
            } 
            if(component.find('shipToEmail') && component.find('shipToEmail').get("v.value")!='') {
                component.find('shipToEmail').set("v.value", component.get("v.contactInfo.Email"));
            } 
        }*
        /*if(component.find('shippingMethod')) {
            component.find('shippingMethod').set("v.value", 'Freight Ground');
        } */
        
        
    },
    getFields : function (component, event, helper) {
        component.set("v.Spinner",true);
        helper.getFields(component,event,helper);
         component.set("v.Spinner",false);
    },
    openSearchBillToModal: function(component, event, helper) {        
        component.set("v.billToSearchModalOpen", true);
        helper.getBillTo(component,event,helper);
    },
    closeSearchBillToModal: function(component, event, helper) { 
        component.set("v.billToSearchModalOpen", false);
    },
    selectRecordBillToNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfBillToRecords")[index]; // Use it retrieve the store record
        component.set("v.selectedBillToRecord" , selectedRecord);        
        console.log(selectedRecord); 
        component.set("v.billToSearchModalOpen", false);
        var billToVal = selectedRecord.ERP_Partner__r.Name + ' - ' + selectedRecord.ERP_Partner__r.City__c;        
        component.find('billToInput').set('v.value',billToVal);
        component.find('billToInput').set('v.readonly',true);
		component.find('billToInput').reportValidity();
    },
    keyPressBillToNameSearch : function(component, event, helper) {                
        helper.getBillTo(component, event, helper);
    },
    openSearchContactModal: function(component, event, helper) {        
        helper.getContacts(component, event, helper);
        component.set("v.contactSearchModalOpen", true);
    },
    closeSearchContactModal: function(component, event, helper) { 
        component.set("v.contactSearchModalOpen", false);
    },
    openSearchShipToModal: function(component, event, helper) {        
    	component.set("v.shipToSearchModalOpen", true);
        helper.getShipTo(component, event, helper);
    },
    closeSearchShipToModal: function(component, event, helper) { 
    	component.set("v.shipToSearchModalOpen", false);
    },
    selectRecordContactNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfContactRecords")[index]; // Use it retrieve the store record
        console.log(selectedRecord);
        component.set("v.selectedContactRecord" , selectedRecord);                
        component.find('orderContact').set('v.value',selectedRecord.Name);
		component.find('orderContact').reportValidity();        
        component.set("v.contactSearchModalOpen", false);      
        component.find('shipToName').set('v.value',selectedRecord.Name);
		 component.find('shipToPhone').set('v.value',selectedRecord.Phone); 
         component.find('shipToEmail').set('v.value',selectedRecord.Email);
    },
    keyPressContactNameSearch : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchContactInputValue");
        console.log('keyPressContactNameSearch===='+getInputkeyWord);
        helper.getContacts(component, event, helper);
    },
    onCheckNetTerm : function(component, event, helper) { 
        var changeElement = component.find("ifPreDefinedNetTerm");
        console.log('---changeElement---'+changeElement.get("v.value"));
        component.set("v.preDefinedNetTerm", changeElement.get("v.value"));
    },
    validateOrderInfo: function(component, event, helper) {    
		var formValidated=[];
        if(component.find('shippingMethod') && component.find('shippingMethod').get('v.value')!='Customer Carrier'){
            formValidated = [component.find('fob'), component.find('shippingMethod'), component.find('orderContact'),component.find('shipToInput'),
                            component.find('shipToName'),component.find('billToInput'),component.find('shipToPhone')].reduce(function (validSoFar, inputCmp) {
                            // Displays error messages for invalid fields            
                            inputCmp.showHelpMessageIfInvalid();
                            return validSoFar && inputCmp.get('v.validity').valid;
                        }, true);
        }
        else if(component.get("v.appTotalQty")!=0 && component.get("v.brachyTotalQty")==0) {
            formValidated = [component.find('orderContact'),component.find('shipToInput'),
                            component.find('billToInput')].reduce(function (validSoFar, inputCmp) {
                            // Displays error messages for invalid fields            
                            inputCmp.showHelpMessageIfInvalid();
                            return validSoFar && inputCmp.get('v.validity').valid;
                        }, true);
        }
        else{
            formValidated =[component.find('fob'), component.find('shippingMethod'), component.find('orderContact'),component.find('shipToInput'),
                            component.find('shipToName'),component.find('shipToPhone'),component.find('customerCarrierType'),component.find('customerCarrierNo'),
                            component.find('customerShippingMethod'),component.find('billToInput')].reduce(function (validSoFar, inputCmp) {
                            // Displays error messages for invalid fields            
                            inputCmp.showHelpMessageIfInvalid();
                            return validSoFar && inputCmp.get('v.validity').valid;
                        }, true);
        }
		var ifEmailValid = false;
        if(component.get("v.brachyTotalQty")!=0){
        var emailField = component.find('shipToEmail');
        var emailFieldValue = emailField.get('v.value');
        var emailValid = component.find('shipToEmailValidError');
        if(emailField && !$A.util.isEmpty(emailFieldValue)) {
		var regExpEmailformat =/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/ ;  
		 if(!$A.util.isEmpty(emailFieldValue)){   
                if(emailFieldValue.match(regExpEmailformat)){
                    ifEmailValid = true;
                    console.log('Email valid***');
                }else{
                    component.set("v.shipToEmailValidError", true);
                    $A.util.removeClass(emailValid, 'slds-hide');
                    //emailField.set("v.errors", [{message: "Please Enter a Valid Email Address"}]);
                    console.log('Email invalid***');
                }
            }
        }else
        {
            ifEmailValid = true;
        } 
        
        }else
        {
            ifEmailValid = true;
        }
        
        
		var isStepThreeValid = false;
        if(ifEmailValid && formValidated) {
          	isStepThreeValid = true;  
        } else {
            isStepThreeValid = false;
        }

        component.set('v.stepThreeValid', isStepThreeValid);
    },
    onChangeShippingMethod: function(component, event, helper) {
        var shippingMethod = component.find('shippingMethod').get('v.value');
        helper.showShippingTypes(component, event, helper,shippingMethod);
    },
    onCustomerShippingMethodChange : function(component, event, helper) {
        console.log('Customer Carrier Change');
        var shippingMethod = component.find('customerShippingMethod').get('v.value');
         console.log('Customer Carrier Change' +shippingMethod);
        if(shippingMethod)
        	helper.getEstimatedDeliveryDate(component, event, helper,shippingMethod);
         /*var customerCarrierShipping=component.get("v.cart.Customer_Carrier_Shipping_Method__c");
            if(customerCarrierShipping){
                if(customerCarrierShipping=='Overnight'){
                    helper.getEstimatedDeliveryDate(component, event, helper,'Freight Next Day Early AM');
                }
                else if(customerCarrierShipping=='2nd Day'){
                    helper.getEstimatedDeliveryDate(component, event, helper,'Freight 2 Day');
                }
                else if(customerCarrierShipping=='Ground'){
                    helper.getEstimatedDeliveryDate(component, event, helper,'Freight Ground');
                }
            } */
        
    },
    phoneChange: function(component, event, helper) {        
        var str = event.getSource().get('v.value');  		
        var patt = new RegExp('^[0-9]+$');
        var res = patt.test(str);        
        if(!res){
            event.getSource().set('v.value', '');
        }        
    },
    keyChecksBillToInput: function(component, event, helper) {        
        var isReadOnly = component.find('billToInput').get('v.readonly');
        if(!isReadOnly){
            component.find('billToInput').set('v.value','');
        }
    },
    
     keyChecksShipToInput: function(component, event, helper) { 	
        var isReadOnly = component.find('shipToInput').get('v.readonly');
        if(!isReadOnly){
            component.find('shipToInput').set('v.value','');
        } 
    },
    
    keyChecksOrderContact: function(component, event, helper) {        
        var isReadOnly = component.find('orderContact').get('v.readonly');
        if(!isReadOnly){
            component.find('orderContact').set('v.value','');
        }
        
    },
    
    keyPressShipToNameSearch : function(component, event, helper) { 
        helper.getShipTo(component, event, helper);
    },
    
    selectRecordShipToNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
		var index = selectedItem.dataset.record; // Get its value i.e. the index
		var selectedRecord = component.get("v.listOfShipToRecords")[index]; // Use it retrieve the store record
        
         console.log('selectedItem ->' +selectedItem +'  ' +index);
        
       	component.set("v.selectedShipToRecord" , selectedRecord); 
        console.log('selectedRecord ->' +selectedRecord);        
        component.set("v.shipToSearchModalOpen", false);
        var shipToVal = selectedRecord.ERP_Partner__r.Name + ' - ' + selectedRecord.ERP_Partner__r.City__c;      
        
        console.log('shipToVal ->' +shipToVal +' ->' +selectedRecord.ERP_Partner_Number__c);
        component.find('shipToInput').set('v.value',shipToVal);
        component.find('shipToInput').set('v.readonly',true);
		component.find('shipToInput').reportValidity();        
    },
    
    getShipTo : function (component, event, helper) {
        component.set("v.selectedShipToRecord", event.getParam("recordName"));
        component.set("v.userAccount", event.getParam("recordId"));
        var accModalBackdrop = component.find('accModalBackdrop');
        var accModal = component.find('accModal');
        $A.util.addClass(accModalBackdrop, 'slds-hide');
        $A.util.addClass(accModal, 'slds-hide');
        helper.getShipTo(component, event, helper);
    },
})