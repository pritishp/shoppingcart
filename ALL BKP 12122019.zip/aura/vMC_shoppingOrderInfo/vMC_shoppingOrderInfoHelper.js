({    
    getRelatedContacts : function(component,event,helper) {        
        var action = component.get("c.fetchRelatedContacts");
        action.setParams({
            'accountId' : component.get("v.userAccount")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp = response.getReturnValue();
                component.set("v.ContactOptions", resp);
                console.log('contactOptions='+response);
            }
        });
        $A.enqueueAction(action);
    },
    
    getFields : function (component, event, helper) {   
       // debugger;
        var fields = [];
        if(component.get("v.appTotalQty")!=0 && component.get("v.brachyTotalQty")==0) {
            fields.push({
                'destination' : component.get("v.selectedShipToRecord"),
                'orderContact' : component.find('orderContact').get("v.value"),
                'orderContactId' : component.get("v.orderContact.Id"), // Added By Phani 04242019
                'billingAddress' : component.get("v.selectedBillToRecord"),
                'shipToName' : component.get("v.contactInfo.Name"),
                'shipToPhone' : component.get("v.contactInfo.Phone"),
                'shipToEmail' : component.get("v.contactInfo.Email"),
                'erpPartnerNo' : component.get("v.shippingERP"),
                
            })
        } else {
            fields.push ({
                'destination' : component.get("v.selectedShipToRecord"),
                'fob' : component.find('fob').get("v.value"),
                'shippingNote' : component.find('shippingNote').get("v.value"),
                'shippingMethod' : component.find('shippingMethod').get("v.value"),
                'customerShippingMethod' : component.find('customerShippingMethod').get("v.value"),
                'orderContact' : component.find('orderContact').get("v.value"),
                'billingAddress' : component.get("v.selectedBillToRecord"),
                'netTerm' : (component.get("v.selectedPaymentType") == 'PO') ? component.find("netTerm").get("v.value") : 'N/A', 
                'shipToName' : component.find('shipToName').get("v.value"),
                'shipToPhone' : component.find('shipToPhone').get("v.value"),
                'shipToEmail' : component.find('shipToEmail').get("v.value"),
                'preDefinedNetTerm' : (component.get("v.selectedPaymentType") == 'PO') ?component.get("v.preDefinedNetTerm"): false,
                'stepThreeValid': component.get("v.stepThreeValid"),
                'customerCarrierDeliveryDate' : component.find('deliveryDate').get("v.value"),
                'orderContactId':component.get("v.selectedContactRecord.Id"),  
            });
        }
        
        if(component.find('shippingMethod') && component.find('shippingMethod').get("v.value")=='Customer Carrier') {
            fields[0].customerCarrierNo = component.find('customerCarrierNo').get("v.value");
            fields[0].customerCarrierType =component.find('customerCarrierType').get("v.value");
            fields[0].customerShippingMethod =component.find('customerShippingMethod').get("v.value");
            //As per Catherine comments, these fields are optional for customer irrespective of the Shipping Method selection- Phani
           // fields[0].customerCarrierDeliveryDate = component.find('deliveryDate').get("v.value");
           // fields[0].customerCarrierPreference = component.find('deliveryPreference').get("v.value");            
        }
        component.set("v.fieldValues", fields);
        console.log('----'+JSON.stringify(component.get("v.fieldValues")));        
    },
    getBillTo: function(component, event, helper) {
        var accountId='';
        if( (typeof component.get("v.accountInfo.Id") !== 'undefined') && (component.get("v.accountInfo.Id") !== '') ){
            accountId = component.get("v.accountInfo.Id");
        }
        /*if(component.get("v.userAccount")){
            accountId=component.get("v.userAccount");
             console.log('account---'+accountId);
        }
        else{
            accountId='0015C00000LNIKmQAP';
             console.log('account--dummy-'+accountId);
        }*/
        
    	var action = component.get("c.fetchShipToBillToAccounts");
        var index = parseInt(component.get('v.indexBillToSearch'));
        var blockSize = parseInt(component.get('v.blockSizeBillToSearch'));
        action.setParams({
            'searchKeyWord': component.get('v.searchBillToInputValue'),
            'partnerFunction' : component.get("v.partnerFunction"),
            'accountId' : accountId,
            'index': index,
            'blockSize': blockSize 
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log(storeResponse);
                component.set('v.listOfBillToRecords',storeResponse);                
            }
        });
        $A.enqueueAction(action);
    },
    getContacts: function(component, event, helper) {
		var accountId='';
        if( (typeof component.get("v.accountInfo.Id") !== 'undefined') && (component.get("v.accountInfo.Id") !== '') ){
            accountId = component.get("v.accountInfo.Id");
        }
        /*if(component.get("v.userAccount")){
            accountId=component.get("v.userAccount");
        }
        else{
            accountId='0015C00000LNIKmQAP';            
        }*/        
    	var action = component.get("c.fetchContacts");
        action.setParams({
            'searchKeyWord': component.get('v.searchContactInputValue'), 
            'accountId' : accountId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log('Contacts=='+JSON.stringify(storeResponse));
                console.log(component.get('v.contactInfo'));
                component.set('v.listOfContactRecords',storeResponse);
                if( (typeof component.get("v.contactInfo.Id") !== 'undefined') && (component.get("v.contactInfo.Id") !== '') ){
            		accountId = component.get("v.accountInfo.Id");
                    component.set('v.listOfContactRecords',component.get("v.contactInfo"));                    
        		}
                
            }
        });
        $A.enqueueAction(action);
    },
    
    getShipTo: function(component, event, helper) {
        var accountId='';
        if( (typeof component.get("v.accountInfo.Id") !== 'undefined') && (component.get("v.accountInfo.Id") !== '') ){
            accountId = component.get("v.accountInfo.Id");
        }
    	var action = component.get("c.fetchShipToBillToAccounts");
        var index = parseInt(component.get('v.indexShipToSearch'));
        var blockSize = parseInt(component.get('v.blockSizeShipToSearch'));
        action.setParams({
            'searchKeyWord': component.get('v.searchShipToInputValue'),
            'partnerFunction' : 'SH=Ship-to party',
            'accountId' : accountId,
            'index': index,
            'blockSize': blockSize 
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log(storeResponse);
                component.set('v.listOfShipToRecords',storeResponse);
                component.set("v.processing", false);
            }
        });
        $A.enqueueAction(action);
    },
    
    getShippingMethodPicklist: function(component, event, helper){
        var action = component.get("c.fetchShippingMethod");
        var opts=[];
        action.setCallback(this, function(response) {
            var resp=response.getReturnValue();
    		console.log('--rsp--'+JSON.stringify(resp));
            //opts.push({"class": "optionClass", label: 'None', value:''});
            	component.set('v.selectedShippingMethod','Customer Carrier');
             opts.push({"class": "optionClass", label: 'Customer Carrier', value:'Customer Carrier'});
    		for(var i=0;i< resp.length;i++){
                opts.push({"class": "optionClass", label:resp[i].Shipping_Material_Label__c+' - $ '+resp[i].Shipping_Cost__c, value: resp[i].Shipping_Material_Label__c});
			}
           
            component.set('v.shippingTypeLst',opts);
         var customerOpts=[];   
            for(var i=0;i< resp.length;i++){
                customerOpts.push({"class": "optionClass", label:resp[i].Shipping_Material_Label__c, value: resp[i].Shipping_Material_Label__c});
			}
             component.set('v.customShippingTypeLst',customerOpts);
            console.log('customShippingTypeLst ' +JSON.stringify(component.get('v.customShippingTypeLst')));
            console.log('shippingTypeLst ' +JSON.stringify(component.get('v.shippingTypeLst')));
        });
        	
            $A.enqueueAction(action);
        
	},
    
    showShippingTypes: function(component, event, helper,shippingMethod){
    	var cmpTarget = component.find('customerCarrierInfo');
        var cmpTargetDate = component.find('customerCarrierDeliveryDate');
        var cmpTargetPreference = component.find('customerCarrierPreference');
        if( typeof shippingMethod !== 'undefined' ){
			component.set('v.selectedShippingMethod',shippingMethod);            
            if( shippingMethod == "Customer Carrier" ){
                console.log(shippingMethod);
                
                // $A.util.addClass(cmpTarget, "slds-show");
                $A.util.removeClass(cmpTarget, "slds-hide");
               // $A.util.removeClass(cmpTargetDate, "slds-hide");
               // $A.util.removeClass(cmpTargetPreference, "slds-hide");
                component.find('customerCarrierType').set('v.disabled',false);
                component.find('customerCarrierType').set('v.required',true);
                //component.find('customerCarrierType').set('v.value', ''); 
                //component.find('customerCarrierType').showHelpMessageIfInvalid();
                
                component.find('customerCarrierNo').set('v.disabled',false);
                component.find('customerCarrierNo').set('v.required',true);
                //component.find('customerCarrierNo').set('v.value', '');
                
                component.find('customerShippingMethod').set('v.disabled',false);
                component.find('customerShippingMethod').set('v.required',true);
                //component.find('customerShippingMethod').set('v.value', '');
                
                component.set('v.customerCarrier', true);
                console.log('shippingMethod' +component.get('v.customerCarrier'));
                
            }else{             
                console.log(shippingMethod);
                if(component.find('customerCarrierType')) {
                    component.find('customerCarrierType').set('v.disabled',true);
                    component.find('customerCarrierType').set('v.required',false);
                    component.find('customerCarrierType').set('v.value', '');
                }
                                
                if(component.find('customerCarrierNo')) {
                    component.find('customerCarrierNo').set('v.disabled',true);
                    component.find('customerCarrierNo').set('v.required',false);
                    component.find('customerCarrierNo').set('v.value', '');
                }
                
                if(component.find('customerShippingMethod')) {
                    component.find('customerShippingMethod').set('v.disabled',true);
                    component.find('customerShippingMethod').set('v.required',false);
                    component.find('customerShippingMethod').set('v.value', '');

                }
                                
                $A.util.addClass(cmpTarget, "slds-hide");
                component.set('v.customerCarrier', false);
            }
            if(component.find('customerCarrierNo')){
                component.find('customerCarrierNo').reportValidity();
            }
            if(shippingMethod!=='Customer Carrier'){
            	this.getEstimatedDeliveryDate(component, event, helper,shippingMethod);    
            }
            console.log('carr--'+component.get("v.cart.Customer_Carrier_Shipping_Method__c"));
          /*  var customerCarrierShipping=component.get("v.cart.Customer_Carrier_Shipping_Method__c");
            if(customerCarrierShipping){
                if(customerCarrierShipping=='Overnight'){
                    this.getEstimatedDeliveryDate(component, event, helper,'Freight Next Day Early AM');
                }
                else if(customerCarrierShipping=='2nd Day'){
                    this.getEstimatedDeliveryDate(component, event, helper,'Freight Airborne 2 Day');
                }
                else if(customerCarrierShipping=='Ground'){
                    this.getEstimatedDeliveryDate(component, event, helper,'Freight Ground');
                }
            }*/
            
        }        
	},
    
    getEstimatedDeliveryDate: function(component, event, helper,shippingMethod){
        var action = component.get("c.fetchEstimatedDate");
        action.setParams({
            'shipMethod': shippingMethod
        });
        action.setCallback(this, function(response) {
            var resp=response.getReturnValue();
            component.set("v.ExpectedDeliveryDate",resp);
        });
       $A.enqueueAction(action);
        
	},
})