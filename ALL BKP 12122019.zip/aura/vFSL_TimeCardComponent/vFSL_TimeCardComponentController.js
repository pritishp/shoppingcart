({
    doInit : function(component, event, helper) {
        var timesheetId = component.get("v.recordId");
        var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
            componentDef: "c:vFSL_TimeCardPage",
            componentAttributes: {
                "recordId" : timesheetId
            }
        });
        evt.fire(); 
    }
})