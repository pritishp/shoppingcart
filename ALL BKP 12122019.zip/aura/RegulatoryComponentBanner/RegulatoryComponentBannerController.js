({
    doInit : function(component, event, helper) {
        var action = component.get("c.getWorkOrderWithECF");
        action.setParams({
            "recordId" : component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            console.log(result);
            var sObj = JSON.parse(result);
            var woObj = sObj.workOrder;
            var ecfCount = sObj.ecfCount;
            component.set('v.WorkOrder', woObj);
            component.set('v.ecfCount', ecfCount);
        });
        $A.enqueueAction(action);
    },
    
    navigateToECF : function(component, event, helper) {
        var woObject = component.get("v.WorkOrder");
        var woEcfCount = component.get("v.ecfCount");
        var urlEvent = $A.get("e.force:navigateToComponent");
        
        if(woObject.ECF_Required__c == 'Yes from Work Order' && woEcfCount < 1) {
            urlEvent.setParams({
                componentDef  : "c:VFSL_ECF_Form",
                componentAttributes : {
                    recordId : woObject.Id
                }
            });
            urlEvent.fire();
        } else {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error Message',
                message:'You cannot create ECF form because Escalated Complaint Required is not set to Yes from Work Order, or where active ECF is already created.',
                duration:' 5000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
        }
    }, 
    
    navigateToPHI : function(component, event, helper) {
        var woObject = component.get("v.WorkOrder");
        var woEcfCount = component.get("v.ecfCount");
        var urlEvent = $A.get("e.force:navigateToComponent");
        
        urlEvent.setParams({
            componentDef  : "c:vfsl_createPhiLog",
            componentAttributes : {
                recordId : woObject.Id
            }
        });
        urlEvent.fire(); 
    }, 
    
    navigateToToR: function (component, event, helper) {
        var recordId = component.get("v.recordId");
        var url = '/apex/VFSL_TransferResponsibilityLaunch?id=' + recordId;
        window.open(url, '_blank');
    }
})