({
	getLoggedInUser : function(component, event) {
        var action = component.get("c.getLoggedInUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                console.log('loggedInUser'+JSON.stringify(response.getReturnValue()));
                component.set("v.loggedInUser", response.getReturnValue());                               
            } else if (response.getState() == "ERROR") {
                $A.log("callback error", response.getError());
            }
        });
        $A.enqueueAction(action);
    },
    setBreadCrumbs : function (component, event, helper) {
        var breadcrumbCollection = [
            {label: 'Home', name: 'all products' },
            {label: 'My Profile', name: '' }
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    }
})