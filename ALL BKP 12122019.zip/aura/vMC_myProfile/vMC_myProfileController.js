({
	doInit : function(component, event, helper) {
        helper.setBreadCrumbs (component, event, helper);
		helper.getLoggedInUser(component, event);
	}
})