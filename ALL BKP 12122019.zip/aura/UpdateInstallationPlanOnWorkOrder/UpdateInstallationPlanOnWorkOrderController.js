({
    doInit : function(component, event, helper) {
        var getRecId = component.get("v.recordId");
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
        componentDef: "c:updateinstallationplan",
        componentAttributes: {
            "recordId" : getRecId
        }
    });
    evt.fire(); 
    }
})