({
	doInit : function(component, event, helper) {
      //  $A.enqueueAction(component.get('c.openFilters'));
		helper.getCategoryValues(component,event);
        helper.getFilterValues(component,event);
        helper.getContactInfo(component);
        helper.getAccountDetails(component, event, helper);
        
    },
     filterCategory: function (cmp, event, helper) {
        cmp.set("v.processing", true);
        var tab = event.getSource();
        var tabname = tab.get('v.id');
        console.log('tabname=='+tabname);
        cmp.set('v.selectedAppCat', tabname);
        cmp.set("v.index", 0);        
		cmp.set("v.startOffset", 1); 
        var catMapList = cmp.get('v.applicatorMapList');
        var allCatList = cmp.get("v.totalApplicatorList");
         console.log('catMapList ' +catMapList + ' allCatList ' +allCatList)
        var totalRecs=0;
         var listofValues;
         if(allCatList!= null){
        if(tabname!= 'All Categories'){
           // console.log('catMapList size' +catMapList.size);
             console.log('catMapList2 ' +catMapList.get(tabname));
            console.log(typeof catMapList.get(tabname) === "undefined");
            if(typeof catMapList.get(tabname)!= "undefined" ){
                console.log('catMapList.get(tabname)')
                listofValues= catMapList.get(tabname);
                console.log('listofValues ' +listofValues.length);
              //  cmp.set("v.applicatorList", catMapList.get(tabname));
                totalRecs = parseInt(listofValues.length);
            }
            else{
                console.log('No Records');
                    cmp.set("v.applicatorList", null);
                  //  cmp.set("v.totalApplicatorList", null);
                    cmp.set("v.totalRecs",0);
                    cmp.set('v.index', 0);
                    cmp.set('v.startOffset', 0);
                    cmp.set('v.endOffset', 0);
                    cmp.set("v.noApplicatorsMsg",true);
                cmp.set("v.processing", false);
                
                return;
            }
            
        }
        else{             	
            	listofValues = cmp.get("v.totalApplicatorList");
                // cmp.set("v.applicatorList",  allCatList);
                 totalRecs = parseInt(allCatList.length);           
        } 
        var blockSize = parseInt(cmp.get('v.blockSize'));
        var index = parseInt(cmp.get('v.index'));
        console.log(totalRecs+'==='+blockSize+'=='+index);
         var startOffset = index + 1;
                    var endOffset = index + blockSize;
                    if( endOffset >  totalRecs){
                        endOffset = totalRecs;
                    }
                    var totalPageCount = totalRecs / parseInt(cmp.get('v.blockSize'));
             var totalPageRemainder = totalRecs % parseInt(cmp.get('v.blockSize'));
                    if( totalPageRemainder > 0 ){
                        totalPageCount = totalPageCount + 1;
                    }
                    cmp.set('v.paginationTotalPageCount', parseInt(totalPageCount));  
                    cmp.set('v.startOffset', startOffset);
                    cmp.set('v.endOffset', endOffset);
                    cmp.set("v.noApplicatorsMsg",false);
            		cmp.set("v.totalRecs",totalRecs);
             
            var appListings=[];
                    for(var i= index ; i< endOffset; i++) {
                        appListings.push(listofValues[i]);
                    }
             cmp.set("v.applicatorList",  appListings);
             window.scrollTo(0,0);
             
             for(var i=0; i < appListings.length; i++){
                       console.log('inventoryList' +i);
                        var inventory = appListings[i].inventoryList;
                        var inventoryInfo = ''; var totalQuantity = 0;
                        var inventoryInfoFinalText = '';
                        
                        if( inventory.length > 0 ){
                            if( typeof inventory[0] !== 'undefined' ){
                                inventoryInfo += inventory[0].Unrestricted_Quantity__c + ' in ' + inventory[0].Plant_Description__c;
                                totalQuantity += parseInt(inventory[0].Unrestricted_Quantity__c); 
                            }
                            if( typeof inventory[1] !== 'undefined' ){
                                inventoryInfo += '<br />' + inventory[1].Unrestricted_Quantity__c + ' in ' + inventory[1].Plant_Description__c;
                                totalQuantity += parseInt(inventory[1].Unrestricted_Quantity__c); 
                            }
                            inventoryInfoFinalText += 'Total Quantity: ' + totalQuantity + '<br />' + inventoryInfo;
                            console.log('inventoryInfoFinalText--' + i + '--' + inventoryInfoFinalText);
                        }else{
                			inventoryInfoFinalText = 'No inventory data available.';
            			}
                        appListings[i]['inventoryInfo'] = inventoryInfoFinalText;                        
                    }		
             	
        cmp.set("v.processing", false);
       
         }
         else {
             console.log('No Records');
                    cmp.set("v.applicatorList", null);
                    cmp.set("v.totalApplicatorList", null);
                    cmp.set("v.totalRecs",0);
                    cmp.set('v.index', 0);
                    cmp.set('v.startOffset', 0);
                    cmp.set('v.endOffset', 0);
                    cmp.set("v.noApplicatorsMsg",true);
            		cmp.set('v.paginationTotalPageCount',0);
                    cmp.set("v.processing", false);
             
         }
        
       /* if(tabname!= 'All Categories'){
            console.log('tabname!= All Categories');
        	helper.getFilteredProducts(cmp, event);
        }*/
    },
    /*
    filterCategory: function (cmp, event, helper) {
        cmp.set("v.processing", true);
        var tab = event.getSource();
        var tabname = tab.get('v.id');
        console.log('tabname=='+tabname);
        cmp.set('v.selectedAppCat', tabname);
        cmp.set("v.index", 0);        
		cmp.set("v.startOffset", 1);  
        helper.getFilteredProducts(cmp, event);
    }, */
    filterApps: function (cmp, event, helper) {
        helper.getFilteredProducts(cmp, event);
    },
     
	appDetailMouseOver: function(component, event, helper) {
        console.log('test=='+component.find("hover"));
        var items = component.find("hover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    appDetailMouseOut: function(component, event, helper) {
        console.log('test out=='+component.find("hover"));
        var items = component.find("hover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    disabledCartMouseOver: function(component, event, helper) {        
        var items = component.find("disabledCartPopover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },    
    disabledCartMouseOut: function(component, event, helper) {        
        var items = component.find("disabledCartPopover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    inventoryMouseOver: function(component, event, helper) {        
        var items = component.find("inventoryInfoPopover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');       
    },    
    inventoryMouseOut: function(component, event, helper) {        
        var items = component.find("inventoryInfoPopover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');        
    },
    nextPage:function(component, event, helper) {        
        var totalRecs = parseInt(component.get('v.totalRecs'))
        var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));
        console.log(totalRecs+'==='+blockSize+'=='+index);
        var nextIndex = index + blockSize;        
        
        if((index + blockSize) >= totalRecs){
            return false;
        }
		component.set("v.index", nextIndex);
        var list = document.getElementsByClassName('paginationPageInput');
        for (var n = 0; n < list.length; ++n) {
            list[n].value='';
        }        
        helper.nextPage(component, totalRecs, blockSize, nextIndex);
    },
    prevPage:function(component, event, helper) {        
        var totalRecs = parseInt(component.get('v.totalRecs'))
        var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));    
        var prevIndex = index - blockSize;
        if (prevIndex < 0){
            prevIndex = 0;
            return false;
    	} 
        
    	component.set("v.index", prevIndex);
        var list = document.getElementsByClassName('paginationPageInput');
        for (var n = 0; n < list.length; ++n) {
            list[n].value='';
        }        
        helper.nextPage(component, totalRecs, blockSize, prevIndex);
	},
    keyPressPaginationInput: function(component, event, helper){
        console.log(event.target.value);        
        var inputVal = parseInt(event.target.value);
        var totalPageCount = parseInt(component.get('v.paginationTotalPageCount'));
        var blockSize = parseInt(component.get('v.blockSize'));
        if( inputVal > 0 && inputVal <= totalPageCount){
            var index = (inputVal - 1 ) * blockSize;
            component.set('v.index', index);
            var list = document.getElementsByClassName('paginationPageInput');
            for (var n = 0; n < list.length; ++n) {
                list[n].value=inputVal;
            } 
            helper.getFilteredProducts(component, event);
        }        
    },
    handleApplicationEvent : function(component, event, helper) {
        var message = event.getParam("searchedName");
        //var category = event.getParam("recordCategory");
        component.set("v.appNameFromEvent", message);
        //component.find('categoryTab').set("v.selectedTabId", category);
		helper.getFilteredProducts(component, event);
    },
    
    AddToCart : function (component, event, helper) {
        helper.addToCart(component, event, helper);
    },
    openFilters: function (component, event, helper) {
        console.log('Open Filter');
        document.getElementById("sidenavFilterList").style.width = "305px";
		document.getElementById("backgroundOverlay").style.display = "block";        
    },
    closeFilters: function (component, event, helper) {
        document.getElementById("sidenavFilterList").style.width = "0";  
        document.getElementById("backgroundOverlay").style.display = "none"; 
    },
    searchByAccount: function (component, event, helper) {
      helper.searchByAccount(component, event,helper);
      //helper.getFilteredProducts(component,event);  
    },
    searchByContact: function (component, event, helper) {
      helper.searchByContactInfo(component, event,helper);
      //var conname=component.find('conname').get('v.value');
      /*var conname = component.get("v.selectedContactRecord.Name");
       var conemail=component.find('conemail').get('v.value');
       console.log(conname+'--'+conemail);
      
       var action = component.get("c.internalUserSearch"); 
       
        action.setParams ({
            strName: conname,
            strReference:conemail,
            searchType:'Contact'
        });
        action.setCallback(this, function(a) {         
         var result = a.getReturnValue();
         console.log('result ---->' + JSON.stringify(result));
         component.set("v.objAccount", result);
         console.log('acc ---->' + component.get("v.objAccount"));
      });
      $A.enqueueAction(action); */  
    },
    onfocusAccountNameLookup : function(component,event,helper){
        $A.util.addClass(component.find("spinnerAccountNameLookup"), "slds-show");
        $A.util.removeClass(component.find("spinnerAccountNameLookup"), "slds-show");
        var forOpen = component.find("searchResultAccountNameLookup");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
        // Get Default 5 Records order by createdDate DESC  
         var getInputkeyWord = '';
         helper.searchHelperAccountNameLookup(component,event,getInputkeyWord);
    },
    onblurAccountNameLookup : function(component,event,helper){       
        component.set("v.listOfSearchAccountRecords", null );
        var forclose = component.find("searchResultAccountNameLookup");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    keyPressAccountNameLookup : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchAccountKeyWord");          
        if( getInputkeyWord.length > 0 ){
             var forOpen = component.find("searchResultAccountNameLookup");
               $A.util.addClass(forOpen, 'slds-is-open');
               $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelperAccountNameLookup(component,event,getInputkeyWord);
        }
        else{  
             component.set("v.listOfSearchAccountRecords", null ); 
             var forclose = component.find("searchResultAccountNameLookup");
               $A.util.addClass(forclose, 'slds-is-close');
               $A.util.removeClass(forclose, 'slds-is-open');
          }
	},
    clearAccountNameLookup :function(component,event,heplper){
         var pillTarget = component.find("lookup-pill-accountName");
         var lookUpTarget = component.find("lookupFieldAccountName"); 
        
         $A.util.addClass(pillTarget, 'slds-hide');
         $A.util.removeClass(pillTarget, 'slds-show');
        
         $A.util.addClass(lookUpTarget, 'slds-show');
         $A.util.removeClass(lookUpTarget, 'slds-hide');
      
         component.set("v.searchAccountKeyWord",null);
         component.set("v.listOfSearchAccountRecords", null );
         component.set("v.selectedAccountRecord", {} );   
    },
    selectRecordAccountNameLookup : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
		var index = selectedItem.dataset.record; // Get its value i.e. the index
		var selectedRecord = component.get("v.listOfSearchAccountRecords")[index]; // Use it retrieve the store record
       	component.set("v.selectedAccountRecord" , selectedRecord);        
        
        var forclose = component.find("lookup-pill-accountName");
           $A.util.addClass(forclose, 'slds-show');
           $A.util.removeClass(forclose, 'slds-hide');
  
        var forclose = component.find("searchResultAccountNameLookup");
           $A.util.addClass(forclose, 'slds-is-close');
           $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupFieldAccountName");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show'); 
      
	},
    onfocusContactNameLookup : function(component,event,helper){
        $A.util.addClass(component.find("spinnerContactNameLookup"), "slds-show");
        $A.util.removeClass(component.find("spinnerContactNameLookup"), "slds-show");
        var forOpen = component.find("searchResultContactNameLookup");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
        // Get Default 5 Records order by createdDate DESC  
         var getInputkeyWord = '';
         helper.searchHelperContactNameLookup(component,event,getInputkeyWord);
    },
    onblurContactNameLookup : function(component,event,helper){       
        component.set("v.listOfSearchContactRecords", null );
        var forclose = component.find("searchResultContactNameLookup");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    keyPressContactNameLookup : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchContactKeyWord");          
        if( getInputkeyWord.length > 0 ){
             var forOpen = component.find("searchResultContactNameLookup");
               $A.util.addClass(forOpen, 'slds-is-open');
               $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelperContactNameLookup(component,event,getInputkeyWord);
        }
        else{  
             component.set("v.listOfSearchContactRecords", null ); 
             var forclose = component.find("searchResultContactNameLookup");
               $A.util.addClass(forclose, 'slds-is-close');
               $A.util.removeClass(forclose, 'slds-is-open');
          }
	},
    clearContactNameLookup :function(component,event,heplper){
         var pillTarget = component.find("lookup-pill-contactName");
         var lookUpTarget = component.find("lookupFieldContactName"); 
        
         $A.util.addClass(pillTarget, 'slds-hide');
         $A.util.removeClass(pillTarget, 'slds-show');
        
         $A.util.addClass(lookUpTarget, 'slds-show');
         $A.util.removeClass(lookUpTarget, 'slds-hide');
      
         component.set("v.searchContactKeyWord",null);
         component.set("v.listOfSearchContactRecords", null );
         component.set("v.selectedContactRecord", {} );   
    },
    selectRecordContactNameLookup : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
		var index = selectedItem.dataset.record; // Get its value i.e. the index
		var selectedRecord = component.get("v.listOfSearchContactRecords")[index]; // Use it retrieve the store record
       	component.set("v.selectedContactRecord" , selectedRecord);
        console.log(selectedRecord);
        
        var forclose = component.find("lookup-pill-contactName");
           $A.util.addClass(forclose, 'slds-show');
           $A.util.removeClass(forclose, 'slds-hide');
  
        var forclose = component.find("searchResultContactNameLookup");
           $A.util.addClass(forclose, 'slds-is-close');
           $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupFieldContactName");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show');      
	},
    openSearchAccountModal: function(component, event, helper) {
        component.set('v.indexAccountSearch',0);
        component.set("v.searchAccountInputValue","");
        helper.getAccounts(component, event, helper);
    	component.set("v.accountSearchModalOpen", true);
    },
    closeSearchAccountModal: function(component, event, helper) { 
    	component.set("v.accountSearchModalOpen", false);
    },
    openSearchContactModal: function(component, event, helper) { 
        component.set("v.searchContactInputValue","");
        helper.getContacts(component, event, helper);
    	component.set("v.contactSearchModalOpen", true);
    },
    closeSearchContactModal: function(component, event, helper) { 
    	component.set("v.contactSearchModalOpen", false);
    },
    keyPressAccountNameSearch : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchAccountInputValue");
        console.log('keyPressAccountNameSearch===='+getInputkeyWord);
        component.set('v.indexAccountSearch',0);
        helper.getAccounts(component, event, helper);
    },
    keyPressContactNameSearch : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchContactInputValue");
        console.log('keyPressContactNameSearch===='+getInputkeyWord);        
        helper.getContacts(component, event, helper);                
    },
    selectRecordAccountNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
		var index = selectedItem.dataset.record; // Get its value i.e. the index
		var selectedRecord = component.get("v.listOfAccountRecords")[index]; // Use it retrieve the store record
       	var currentSelectedAccount = component.get("v.selectedAccountRecord");
        component.set("v.newAccountRecord" , selectedRecord);
        var cartCount = component.get("v.cartCount");
        
        if( (currentSelectedAccount != null) && ( typeof currentSelectedAccount.Id !== 'undefined' ) && (currentSelectedAccount.Id !=  selectedRecord.Id) && (cartCount > 0) ){
            helper.closeSearchAccountModal(component, event,helper);
            component.set("v.cartDeleteModalOpen", true); 
        }    
        //}else if( typeof currentSelectedAccount.Id === 'undefined' || ( (currentSelectedAccount.Id !=  selectedRecord.Id) && (cartCount == 0) ) ){
        else{    
            component.set("v.selectedAccountRecord" , selectedRecord);
            component.set("v.objAccount" , selectedRecord);
        	component.set("v.selectedContactRecord" , null);
            component.set("v.totalRecs",0);
            component.set('v.index', 0);
            component.set('v.startOffset', 0);
            component.set('v.endOffset', 0);
            component.set('v.paginationTotalPageCount',0);
            helper.addAccountToCart(component, event, helper);
            if( typeof selectedRecord !== 'undefined' ){
            	var accId = selectedRecord.Id;
        		helper.getAccountAfterloader(component,event,helper,accId);
                helper.searchByAccount(component, event,helper);
            }    
        }		         
    },
    nextAccountSearch:function(component, event, helper) {        
        var totalAccountsCount = parseInt(component.get('v.totalAccountsCount'))
        var blockSizeAccountSearch = parseInt(component.get('v.blockSizeAccountSearch'));
        var indexAccountSearch = parseInt(component.get('v.indexAccountSearch'));
        var nextIndex = indexAccountSearch + blockSizeAccountSearch;        
        
        if((indexAccountSearch + blockSizeAccountSearch) >= totalAccountsCount){
            return false;
        }
        
        component.set("v.indexAccountSearch", nextIndex);             
        helper.getAccounts(component, event, helper);
    },
    prevAccountSearch:function(component, event, helper) { 
    	var blockSizeAccountSearch = parseInt(component.get('v.blockSizeAccountSearch'));
        var indexAccountSearch = parseInt(component.get('v.indexAccountSearch'));    
        var prevIndex = indexAccountSearch - blockSizeAccountSearch;
        if (prevIndex < 0){
            prevIndex = 0;
            return false;
    	}
        
    	component.set("v.indexAccountSearch", prevIndex);                
        helper.getAccounts(component, event, helper);
    },
    openSearchProductModal: function(component, event, helper) {         
    	component.set("v.productSearchModalOpen", true);
    },
    closeSearchProductModal: function(component, event, helper) { 
    	component.set("v.productSearchModalOpen", false);
    },
    selectRecordContactNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
		var index = selectedItem.dataset.record; // Get its value i.e. the index
        var accId= component.get("v.selectedAccountRecord.Id");
        console.log('Account exists in contact ' + accId);
		var selectedRecord = component.get("v.listOfContactRecords")[index]; // Use it retrieve the store record
       	console.log(selectedRecord);
		component.set("v.selectedContactRecord" , selectedRecord); 
        component.set("v.selectedAccountRecord" , selectedRecord.Account);
        if(typeof accId === 'undefined'){
        	helper.searchByContactInfo(component, event,helper);
       		helper.addAccountToCart(component, event, helper);
        }
        else
            helper.closeSearchContactModal(component, event,helper);
    },
    onAfterLoaderChange: function(component, event, helper) {
        var selectedVal = component.find("afterLoaderSelect").get('v.value');
        console.log('afterLoaderSelect==='+selectedVal);
        //component.set('v.selectedAfterLoader',selectedVal);        
    },
    afterLoaderSearch: function(component, event, helper) {
        var afterLoader = component.find("afterLoaderSelect").get('v.value');
        if(afterLoader !== ''){                 
        	component.set('v.selectedAfterLoader',afterLoader);   
            helper.getFilteredProducts(component, event);
            component.set("v.productSearchModalOpen", false);
            component.find("categoryTab").set("v.selectedTabId",'All Categories');
        }
    },
    resetAfterLoader: function(component, event, helper) {
        component.set('v.selectedAfterLoader','');
        helper.getFilteredProducts(component, event);
    },
    openCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", true);
    },
	closeCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", false);
    },
    removeCart: function(component, event, helper) {        
        var newSelectedRecord = component.get("v.newAccountRecord");
        component.set("v.selectedAccountRecord" , newSelectedRecord);
        component.set("v.objAccount" , newSelectedRecord);
        component.set("v.cartDeleteModalOpen", false);
        helper.deleteCartItem(component, event,helper);
    },
    resetAccount: function(component, event, helper) {        
        var cartCount = component.get("v.cartCount");
        if( cartCount > 0 ){
            component.set('v.accResetCartDeleteModalOpen', true);
        }else{
            var accResetRemoveCart = component.get('c.accResetRemoveCart');
        	$A.enqueueAction(accResetRemoveCart);
        }
    },
    closeAccResetCartDeleteModal: function(component, event, helper) {
        component.set('v.accResetCartDeleteModalOpen', false);
    },
    accResetRemoveCart: function(component, event, helper) {
        component.set("v.selectedAccountRecord" , {});
        component.set("v.objAccount" , null);
        component.set("v.selectedContactRecord" , {});
        component.set("v.selectedAfterLoader" , '');
        component.set("v.accountAfterLoader" , '');
        component.set('v.accResetCartDeleteModalOpen', false);
        component.set('v.selectedAppCat', 'All Categories');
        helper.resetAccountInfo(component, event,helper);
        component.find("categoryTab").set("v.selectedTabId",'All Categories');
    },
    itemAddedToCart: function(component, event, helper) {
        component.set("v.cartCount", 1);
    }
})