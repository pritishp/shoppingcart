({
    getAccountDetails : function(component,event,helper) {
        var action = component.get("c.getAccountDetails"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();            
            var sizeObj = Object.keys(result).length;
            if(sizeObj > 0) {
                component.set("v.isInternalUser",false);
                component.set("v.objAccount", result);
                component.set("v.selectedAccountRecord", result);                
                if( typeof result.Id != 'undefined' ){
                    var accId = result.Id;
                    console.log('accId ' +result.Id);
                    helper.getAccountAfterloader(component,event,helper,accId);
                } //Added by Phani fix for these calls that were made parallel. So due to that changes were not refelecting based on the 
                else {
				helper.getFilteredProducts(component,event);                
                }    
            } else {
                component.set("v.isInternalUser",true);
                //check if Cart has account
                helper.getAccountFromCart(component,event,helper);
            }         
            console.log('isInternalUser ---->' + component.get("v.isInternalUser"));
            //helper.getFilteredProducts(component,event);
        });
        $A.enqueueAction(action);
    },
    getAccountFromCart: function(component,event,helper) {
        var action = component.get("c.getAccountFromCart"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            console.log(JSON.stringify(result));
            var accObj = JSON.parse(result[0]);
            var cartCount = parseInt(result[1]);
            console.log('accObj=='+JSON.stringify(accObj));
            console.log('cartCount=='+cartCount);            
            var sizeObj = Object.keys(accObj).length;
            if(sizeObj > 0) {
                component.set("v.objAccount", accObj);
                component.set("v.selectedAccountRecord", accObj); 
                var accId = accObj.Id;
                helper.getAccountAfterloader(component,event,helper,accId);
            }
            else{
                helper.getFilteredProducts(component,event);  
            }
            component.set("v.cartCount", cartCount);
             
        }); 
        $A.enqueueAction(action);        
    },
    getAccountAfterloader: function(component,event,helper,accId) {    
        var action = component.get("c.fetchAccountAfterloader"); 
        action.setParams({
            'accountId': accId,                      
        });
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();			        
            var afterLoaderStr = '';
            if (result.indexOf("H64") > -1) {
    			afterLoaderStr += ' / ' + 'GammaMed';
			}
			if (result.indexOf("H60") > -1) {
    			afterLoaderStr += ' / ' + 'VariSource';
			}
			if (result.indexOf("H65") > -1) {
    			afterLoaderStr += ' / ' + 'Bravos';
			}
            afterLoaderStr = afterLoaderStr.slice(3);			
            component.set('v.accountAfterLoader', afterLoaderStr);	
            //Added By Phani 
            helper.getFilteredProducts(component,event);   
        }); 
        $A.enqueueAction(action); 
    },
    deleteCartItem: function(component,event,helper) {
        var accountId = component.get('v.newAccountRecord.Id');
        console.log('deleteCartItem----'+accountId);        
        var action = component.get("c.deleteCart");
        action.setParams({
            'accountId': accountId,                      
        });
        action.setCallback(this, function(response) {            
            var state = response.getState();
            if (state === "SUCCESS") {
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
				component.set("v.cartCount", 0);
                helper.getFilteredProducts(component,event);
            }    
        }); 
        $A.enqueueAction(action);        
    },
    getContactInfo : function(component) {
        var action = component.get("c.getContactDetails"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            if(result!== '' && result!==null){
                component.set("v.selectedContactRecord" , result);
            }
        });
        $A.enqueueAction(action);
    },
    getCategoryValues : function(component,event) {
        var action = component.get("c.getCategories");
        action.setCallback(this, function(result){
            var response = result.getReturnValue();
            console.log('result cat---->' + JSON.stringify(response));
            component.set("v.appCatValues", response);
        });
        $A.enqueueAction(action);
    },
    
    getFilterValues : function(component,event) {
        var action = component.get("c.getFilterMapValues");
        action.setCallback(this, function(result){
            var response = result.getReturnValue();
            console.log(response);
            var filterList = [];
            for(var key in response){
                filterList.push({value:response[key], key:key});
            }
            component.set("v.filteredValues", filterList);
        });
        $A.enqueueAction(action);
    },
    
    getFilteredProducts : function(component,event) {
        component.set("v.processing", true);
        var self = component;       
        var selectedFilterValue = component.find("selectedFilterValue").get("v.value");
        console.log('***selectedFilterValue**'+selectedFilterValue);
        if(selectedFilterValue === undefined) {
            selectedFilterValue = '';
        }
        
        var tabname = component.get('v.selectedAppCat');
        console.log('***tabname**'+tabname);
        if(tabname === undefined) {
            tabname = '';
        }
        var totalRecs = parseInt(component.get('v.totalRecs'));
        var index = parseInt(component.get('v.index'));
        var blockSize = parseInt(component.get('v.blockSize'));		
        //var accountId=component.get('v.objAccount.Id')===undefined ? "" : component.get('v.objAccount.Id');
        var accountId = component.get('v.selectedAccountRecord.Id') === undefined ? "" : component.get('v.selectedAccountRecord.Id');
        console.log('***account**'+accountId);
        /*
        if( accountId === '' ){
            accountId = component.get("v.selectedAccountRecord.Id");
        }*/       
        console.log('***account Id**'+accountId);
        var action = component.get("c.getBAProducts");
        var paramObj = {
            tempAccId:accountId,
            filterVal: String(selectedFilterValue),
            catName: 'All Categories',
            searchKeyword: component.get('v.appNameFromEvent'),
            totalRecs: totalRecs,
            index: index,
            blockSize: blockSize,
            afterLoaderVal: component.get('v.selectedAfterLoader')
        };
        console.log('paramObj=='+JSON.stringify(paramObj));
        action.setParams({
            tempAccId:accountId,
            filterVal: String(selectedFilterValue),
            catName: 'All Categories',
            searchKeyword: component.get('v.appNameFromEvent'),
            totalRecs: totalRecs,
            index: index,
            blockSize: blockSize,
            afterLoaderVal: component.get('v.selectedAfterLoader')
        });
        action.setCallback(this, function(a) {
            var state = a.getState();            
            if(state=="SUCCESS"){               
                var result = a.getReturnValue();
                console.log('result--01--'+result);
                if(result.length===0){
                    console.log('No Records');
                    component.set("v.applicatorList", null);
                    component.set("v.totalApplicatorList", null);
                    component.set("v.totalRecs",0);
                    component.set('v.index', 0);
                    component.set('v.startOffset', 0);
                    component.set('v.endOffset', 0);
                    component.set("v.noApplicatorsMsg",true);
                }
                else{
                    var totalApplicatorList = JSON.parse(result[0]);                       
                    var totalRecs = parseInt(result[1]);
                    var index = parseInt(result[2]);
                    
                   // var mapofApplicatorList = new Map();
                    var mapofApplicatorList = JSON.parse(result[3]);
                    console.log(typeof JSON.parse(result[3]));
                    console.log('**mapofApplicatorList** ' + result.length +'**' +Object.keys(mapofApplicatorList));
                    
                    var mapofApplicators = new Map();
                    Object.keys(mapofApplicatorList).forEach(key => {
                        console.log('key ' +key + ' *valur**' +JSON.stringify(mapofApplicatorList[key]));
                        mapofApplicators.set(key, mapofApplicatorList[key]);
                    });
                        console.log('mapofApplicators ->' + JSON.stringify(mapofApplicators.get(tabname)));
                    component.set("v.applicatorMapList",  mapofApplicators);   
                    console.log('applicatorMapList ->' + JSON.stringify(component.get("v.applicatorMapList")));
                        
                    component.set("v.totalApplicatorList", totalApplicatorList);
                    component.set("v.totalRecs",totalRecs);
                    component.set('v.index', index);
                    var startOffset = index + 1;
                    var endOffset = index + blockSize;
                    if( endOffset >  totalRecs){
                        endOffset = totalRecs;
                    }
                    var totalPageCount = totalRecs / parseInt(component.get('v.blockSize'));
                    var totalPageRemainder = totalRecs % parseInt(component.get('v.blockSize'));
                    if( totalPageRemainder > 0 ){
                        totalPageCount = totalPageCount + 1;
                    }
                    component.set('v.paginationTotalPageCount', parseInt(totalPageCount));  
                    component.set('v.startOffset', startOffset);
                    component.set('v.endOffset', endOffset);
                    component.set("v.noApplicatorsMsg",false);
                    
                    var appListings=[];
                    for(var i= index ; i< endOffset; i++) {
                        appListings.push(totalApplicatorList[i]);
                    }
                    
                    component.set("v.applicatorList", appListings);
                    window.scrollTo(0,0);
                    
                    for(var i=0; i < appListings.length; i++){
                      //  console.log('inventoryList'+appListings[i].inventoryList);
                        var inventory = appListings[i].inventoryList;
                        var inventoryInfo = ''; var totalQuantity = 0;
                        var inventoryInfoFinalText = '';
                        
                        if( inventory.length > 0 ){
                            if( typeof inventory[0] !== 'undefined' ){
                                inventoryInfo += inventory[0].Unrestricted_Quantity__c + ' in ' + inventory[0].Plant_Description__c;
                                totalQuantity += parseInt(inventory[0].Unrestricted_Quantity__c); 
                            }
                            if( typeof inventory[1] !== 'undefined' ){
                                inventoryInfo += '<br />' + inventory[1].Unrestricted_Quantity__c + ' in ' + inventory[1].Plant_Description__c;
                                totalQuantity += parseInt(inventory[1].Unrestricted_Quantity__c); 
                            }
                            inventoryInfoFinalText += 'Total Quantity: ' + totalQuantity + '<br />' + inventoryInfo;
                            console.log('inventoryInfoFinalText--' + i + '--' + inventoryInfoFinalText);
                        }else{
                			inventoryInfoFinalText = 'No inventory data available.';
            			}
                        appListings[i]['inventoryInfo'] = inventoryInfoFinalText;                        
                    }
                    console.log('appListings'+JSON.stringify(appListings));
                    
                }
                
            } 
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    nextPage : function (component, totalRecs, blockSize, index) { 
        var selectedTab = component.get("v.selectedAppCat");
        var totalApplicatorList = component.get("v.totalApplicatorList");
        var applicatorList = [];
        
        for(var i in totalApplicatorList) {
            if(selectedTab != 'All Categories') {
                if(totalApplicatorList[i].objProduct.category__c == selectedTab) {
                    applicatorList.push(totalApplicatorList[i]);
                }
            } else {
                applicatorList.push(totalApplicatorList[i]);
            }
        }
        
        var startOffset = index + 1;
        var endOffset = index + blockSize;
        if( endOffset >  totalRecs){
            endOffset = totalRecs;
        }
        var totalPageCount = totalRecs / parseInt(component.get('v.blockSize'));
        var totalPageRemainder = totalRecs % parseInt(component.get('v.blockSize'));
        if( totalPageRemainder > 0 ){
            totalPageCount = totalPageCount + 1;
        }
        component.set('v.paginationTotalPageCount', parseInt(totalPageCount));  
        component.set('v.startOffset', startOffset);
        component.set('v.endOffset', endOffset);
        component.set("v.noApplicatorsMsg",false);
        
        var appListings=[];
        for(var i= index ; i< endOffset; i++) {
            appListings.push(totalApplicatorList[i]);
        }
        
        component.set("v.applicatorList", appListings);
        window.scrollTo(0,0);
        component.set("v.processing", false);
        
        for(var i=0; i < appListings.length; i++){
            console.log('inventoryList'+appListings[i].inventoryList);
            var inventory = appListings[i].inventoryList;
            var inventoryInfo = ''; var totalQuantity = 0;
            var inventoryInfoFinalText = '';
            
            if( inventory.length > 0 ){
                if( typeof inventory[0] !== 'undefined' ){
                    inventoryInfo += inventory[0].Unrestricted_Quantity__c + ' in ' + inventory[0].Plant_Description__c;
                    totalQuantity += parseInt(inventory[0].Unrestricted_Quantity__c); 
                }
                if( typeof inventory[1] !== 'undefined' ){
                    inventoryInfo += '<br />' + inventory[1].Unrestricted_Quantity__c + ' in ' + inventory[1].Plant_Description__c;
                    totalQuantity += parseInt(inventory[1].Unrestricted_Quantity__c); 
                }
                inventoryInfoFinalText += 'Total Quanity: ' + totalQuantity + '<br />' + inventoryInfo;
                console.log('inventoryInfoFinalText--' + i + '--' + inventoryInfoFinalText);
            }else{
                inventoryInfoFinalText = 'No inventory data available.';
            }
            appListings[i]['inventoryInfo'] = inventoryInfoFinalText;                        
        }
        console.log('appListings'+JSON.stringify(appListings));        
    },
    
    addToCart : function (component, event, helper) {
        
        var ctarget = event.currentTarget;
        var id_str = ctarget.dataset.productid;
        console.log('==prod=='+id_str);
        var quantity=component.get('v.quantity');
        
        if(component.get('v.selectedAccountRecord')){
            var accountId = component.get('v.selectedAccountRecord').Id;
        }         
        
        if(component.get('v.selectedContactRecord')){
            var contactId = component.get('v.selectedContactRecord').Id;              
        }  
        
        var action = component.get("c.addCartItem");
        
        if(typeof accountId === 'undefined'){
            helper.handleShowToast(component, event, helper, 'Account not selected. Please select Account from filter panel!','Error', 'Error');
            return false;
        }
        
        action.setParams ({
            productId: id_str,
            quantity:quantity,
            accountId: accountId,
            contactId: contactId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var msg = response.getReturnValue();
                var variant;
                if(msg.includes('Success')) {
                    variant = 'Success';
                    component.set("v.cartCount", 1); 
                } else if(msg.includes('Exception')){
                    variant = 'Error';   
                } else {
                    variant = 'Info';
                    
                }
                helper.handleShowToast(component, event, helper, msg,variant,variant);
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
                
            }
            else {
                helper.handleShowToast(component, event, helper, 'Exception Occurred !','Error', 'Error');
            }
        });
        $A.enqueueAction(action);
    },
    handleShowToast : function(component, event, helper, msg, variant,title) {
        component.find('notifLib').showToast({
            "title": title,
            "message": msg,
            "variant" : variant
        });
    },
    searchByAccount :function (component, event,helper) {        
        var accName = component.get('v.selectedAccountRecord.Name');
        var accId  = component.get('v.selectedAccountRecord.Id');
        
        var action = component.get("c.internalUserSearch"); 
        action.setParams ({
            strName: accName,
            strReference:'',
            searchType:'Account',
            strAccId : accId
        });
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            component.set("v.objAccount", result);
            console.log('result ---->' + JSON.stringify(component.get("v.objAccount")));
            //commented by Phani 04172019 as the below call is unnecessary as we are making teh same call from getAfterloader function
            //helper.getFilteredProducts(component,event);
            //helper.closeFilters(); 
            helper.closeSearchAccountModal(component, event,helper);   
        });
        $A.enqueueAction(action); 
        
    },
    searchByContactInfo :function (component, event,helper) {
        var conname = component.get("v.selectedContactRecord.Name");
        var conemail=component.get("v.selectedContactRecord.Email");
        console.log(conname+'--'+conemail);
        
        var action = component.get("c.internalUserSearch"); 
        
        action.setParams ({
            strName: conname,
            strReference:conemail,
            searchType:'Contact'
        });
        action.setCallback(this, function(a) {         
            var result = a.getReturnValue();
            console.log('result ---->' + JSON.stringify(result));
            component.set("v.objAccount", result);
            console.log('acc ---->' + component.get("v.objAccount"));
            helper.getFilteredProducts(component,event);
            //helper.closeFilters(); 
            helper.closeSearchContactModal(component, event,helper);
        });
        $A.enqueueAction(action);
    },    
    searchHelperAccountNameLookup : function(component,event,getInputkeyWord) {       	
        component.set("v.accountSearchModalSpinner", true);
        // call the apex class method 
        var action = component.get("c.fetchAccountNameLookupValues");
        // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'ObjectName' : 'Account',            
        });
        // set a callBack    
        action.setCallback(this, function(response) {            
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log(storeResponse);
                // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
                if (storeResponse.length == 0) {
                    component.set("v.messageAccountNameLookup", 'No Result Found...');
                } else {
                    component.set("v.messageAccountNameLookup", '');
                }
                // set searchResult list with return value from server.
                component.set("v.listOfSearchAccountRecords", storeResponse);
                component.set("v.accountSearchModalSpinner", false);
            }            
        });
        // enqueue the Action  
        $A.enqueueAction(action);        
    },
    searchHelperContactNameLookup : function(component,event,getInputkeyWord) {
        $A.util.removeClass(component.find("spinnerContactNameLookup"), "slds-hide");
        $A.util.addClass(component.find("spinnerContactNameLookup"), "slds-show");
        // call the apex class method 
        var action = component.get("c.fetchContactNameLookupValues");
        // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'ObjectName' : 'Contact',            
        });
        // set a callBack    
        action.setCallback(this, function(response) {
            $A.util.removeClass(component.find("spinnerContactNameLookup"), "slds-show");
            $A.util.addClass(component.find("spinnerContactNameLookup"), "slds-hide");
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log(storeResponse);
                // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
                if (storeResponse.length == 0) {
                    component.set("v.messageContactNameLookup", 'No Result Found...');
                } else {
                    component.set("v.messageContactNameLookup", '');
                }
                // set searchResult list with return value from server.
                component.set("v.listOfSearchContactRecords", storeResponse);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
        
    },
    openFilters: function (component, event, helper) {
        document.getElementById("sidenavFilterList").style.width = "305px";
        document.getElementById("backgroundOverlay").style.display = "block";        
    },
    closeFilters: function (component, event, helper) {
        document.getElementById("sidenavFilterList").style.width = "0";  
        document.getElementById("backgroundOverlay").style.display = "none"; 
    },
    openSearchAccountModal: function(component, event, helper) { 
        component.set("v.accountSearchModalOpen", true);        
    },
    closeSearchAccountModal: function(component, event, helper) { 
        component.set("v.accountSearchModalOpen", false);
    },
    getAccounts: function(component, event, helper) { 
        var action = component.get("c.fetchAccounts");
        var index = parseInt(component.get('v.indexAccountSearch'));
        var blockSize = parseInt(component.get('v.blockSizeAccountSearch'));
        action.setParams({
            'searchKeyWord': component.get('v.searchAccountInputValue'),
            'index': index,
            'blockSize': blockSize 
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log(storeResponse);
                component.set('v.listOfAccountRecords',storeResponse);
            }
        });
        $A.enqueueAction(action);
        
        //Get Total Accounts Count
        var actionAccountCount = component.get("c.fetchTotalAccountCount");
        actionAccountCount.setParams({
            'searchKeyWord': component.get('v.searchAccountInputValue'),                      
        });
        actionAccountCount.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set('v.totalAccountsCount', storeResponse);
                console.log(storeResponse);
                var totalAccountsCount = parseInt(storeResponse);
                var index = parseInt(component.get('v.indexAccountSearch'));
                var blockSize = parseInt(component.get('v.blockSizeAccountSearch'));
                if((index + blockSize) >= totalAccountsCount){            		
                    document.getElementById("nextAccountSearchBtn").disabled = true;
                }else{
                    document.getElementById("nextAccountSearchBtn").disabled = false;
                }
                
                var prevIndex = index - blockSize;
                if (prevIndex < 0){                    
                    document.getElementById("prevAccountSearchBtn").disabled = true;
                }else{
                    document.getElementById("prevAccountSearchBtn").disabled = false;
                }			
                
            }
        });
        $A.enqueueAction(actionAccountCount);
        
    },
    openSearchContactModal: function(component, event, helper) {        
        component.set("v.contactSearchModalOpen", true);
    },
    closeSearchContactModal: function(component, event, helper) { 
        component.set("v.contactSearchModalOpen", false);
    },
    getContacts: function(component, event, helper) {        
        var action = component.get("c.fetchContacts");
        var accountId = '';
        if( typeof component.get("v.selectedAccountRecord.Id") !== 'undefined' && component.get("v.selectedAccountRecord.Id") !== ''){
            accountId = component.get("v.selectedAccountRecord.Id");
        }
        action.setParams({
            'searchKeyWord': component.get('v.searchContactInputValue'),
            'accountId': accountId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                console.log(storeResponse);
                component.set('v.listOfContactRecords',storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    openSearchProductModal: function(component, event, helper) {         
        component.set("v.productSearchModalOpen", true);
    },
    closeSearchProductModal: function(component, event, helper) { 
        component.set("v.productSearchModalOpen", false);
    },
    addAccountToCart: function(component, event, helper) {  
        var accountId = component.get("v.selectedAccountRecord.Id");
        console.log('addAccountToCart----'+accountId);
        if( typeof accountId !== 'undefined' && accountId !== ''){
            var action = component.get("c.addAccountToCart");
            action.setParams({
                'accountId': accountId,                      
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log('addAccountToCart success'); 
                    var accountSelectedFromLeftPanelEvent = $A.get("e.c:vMC_accountSelectedFromLeftPanel");
                    accountSelectedFromLeftPanelEvent.fire();
                }
            });
            $A.enqueueAction(action);
        }
    },
	resetAccountInfo: function(component,event,helper) {             
        var action = component.get("c.deleteCart");
        action.setParams({
            'accountId': '',                      
        });
        action.setCallback(this, function(response) {            
            var state = response.getState();
            if (state === "SUCCESS") {
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
				component.set("v.cartCount", 0);
                helper.getFilteredProducts(component,event);
                var accountSelectedFromLeftPanelEvent = $A.get("e.c:vMC_accountSelectedFromLeftPanel");
                accountSelectedFromLeftPanelEvent.fire();
            }    
        }); 
        $A.enqueueAction(action);        
    }    
})