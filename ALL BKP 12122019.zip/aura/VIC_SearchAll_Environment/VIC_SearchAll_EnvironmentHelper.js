({
    getEnvironment : function(component, environment, helper){
        var action = component.get("c.getEnvironmentDetails"); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.VICEnv', res);
                console.log(res);
            } 
        });
        $A.enqueueAction(action);
    },   
})