({
	doInit : function(component, event, helper) {
        helper.getEnvironment(component, event, helper);
	},
})