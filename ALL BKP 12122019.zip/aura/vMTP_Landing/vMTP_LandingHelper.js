({

	 increment : function(component, event) {
	  
	 },
     createCart : function(component, event) {
	  	var action = component.get("c.getUserAccount");
        action.setCallback(this, function(result){
			var state = action.getState();            
            if(state=="SUCCESS"){
                var result = action.getReturnValue();
                console.log('--cart acc--'+result);
                if(result){
                    component.set("v.landingCartAccount",result);
                }
            }
            else{
                console.log('error');
            }
        });
        $A.enqueueAction(action);
	 },
  	getAccountDetails : function(component,event,helper) {
		 var action = component.get("c.getAccountDetails"); 
         action.setCallback(this, function(a) {
         var result = a.getReturnValue();         
         var sizeObj = Object.keys(result).length;
         if(sizeObj > 0) {
             component.set("v.isInternalUser",false);             
             component.set("v.objAccount", result);         	     
         } else {
            component.set("v.isInternalUser",true);
			component.set("v.selectedAppType",'Brachy');             
            //helper.getUserProfileName(component,event,helper);
         }         
         console.log('isInternalUser ---->' + component.get("v.isInternalUser"));         
      });
      $A.enqueueAction(action);
	},
    getUserProfileName : function(component,event,helper) {
		 var action = component.get("c.getUserProfile"); 
         action.setCallback(this, function(a) {
         	var result = a.getReturnValue();         
            console.log('getUserProfile=='+result); 
             if( !(result === 'VMS VMarket Admin' || result === 'VMS System Admin' || result === 'System Administrator') ){
                 component.set("v.showThirdPartyTab",false); 
                 component.set("v.selectedAppType",'Brachy');
             }
      	});
      $A.enqueueAction(action);
	},
    getURLParameters : function (component) {			
        // the function that reads the url parameters
        var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;
            
            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');
                
                if (sParameterName[0] === sParam) {
                    return sParameterName[1] === undefined ? true : sParameterName[1];
                }
            }
        };
         	
        // set active catalogue tab
        component.set("v.selectedAppType", getUrlParameter('activeTab'));         	
    },
    
    getUserTermAndCondition : function(component,event,helper) {
		 var action = component.get("c.getUserTandC"); 
         action.setCallback(this, function(a) {             
         	var result = a.getReturnValue();  
             console.log('getUserTermAndCondition before if=='+result); 
             if(result == false){
                 component.set("v.isTermsOfUseChecked",false); 
                 console.log('getUserTermAndCondition=='+result);
                  component.set("v.ShowTerms",true);
				//document.querySelector(".headerWrapper").style.display = 'none';	                 
             }
             else{
                 component.set("v.isTermsOfUseChecked",true);                
                 console.log('getUserTermAndCondition=='+result);
                 component.set("v.ShowTerms",false);
                 //document.querySelector(".headerWrapper").style.display = 'block';	                 
             }
             var isInternalUser = component.get("v.isInternalUser");
             console.log('isInternalUserrrrrr=='+isInternalUser);
             if(isInternalUser)
             {
                 document.querySelector(".headerWrapper").style.display = 'block';
             }
             if(!isInternalUser && result === false)
             {
                 document.querySelector(".headerWrapper").style.display = 'none';
             }   
      	});
      $A.enqueueAction(action);
	},
       
})