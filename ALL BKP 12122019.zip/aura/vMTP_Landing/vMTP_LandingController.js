({
	doInit : function(component, event, helper) {
        helper.createCart(component, event, helper);
        helper.getAccountDetails(component, event, helper);
        helper.getURLParameters(component, event, helper);     
        helper.getUserTermAndCondition(component, event, helper);        
	},
    handleApplicationEvent: function(component, event, helper) {
        var message = event.getParam("isAuthenticated");
        component.set("v.isAuthenticated", message);
	},
    handleAppSearchEvent: function(component, event, helper) {
        var message = event.getParam("recordCategory");
        component.set("v.selectedAppType", message);
	}
})