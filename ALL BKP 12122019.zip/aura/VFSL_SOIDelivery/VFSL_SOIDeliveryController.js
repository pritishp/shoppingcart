({
    doInit : function(component, event, helper)
    {
        helper.getSoiDeliviries(component);
    },
    openSalesOrder: function(component, event, helper) {
    	var id_str = event.currentTarget.getAttribute("data-soId");
    	//sforce.one.navigateToSObject(id_str);

		if( (typeof sforce != 'undefined') && sforce && (!!sforce.one) ) {
		    // Salesforce app navigation
		    sforce.one.navigateToSObject(id_str);
		}
		else {
		    // Set the window's URL using a Visualforce expression

            window.open("/"+id_str, "_blank");
		}
    },   
    openDelVer: function(component, event, helper) {
    	var id_str = event.currentTarget.getAttribute("data-DelId");
    	//sforce.one.navigateToSObject(id_str);

		if( (typeof sforce != 'undefined') && sforce && (!!sforce.one) ) {
		    // Salesforce app navigation
		    sforce.one.navigateToSObject(id_str);
		}
		else {
		    // Set the window's URL using a Visualforce expression
            window.open("/"+id_str, "_blank");
		}
    }, 
})