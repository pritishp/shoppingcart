({
    getSoiDeliviries : function(component) 
    {
        var action = component.get('c.getSoiDeliveries'); 
        var recId = component.get("v.recordId");  
        action.setParams({"recId":recId});    
        action.setCallback(this, function(actionResult) 
           {
               var Results=actionResult.getReturnValue();
               component.set("v.soiDeliveries",Results);
               
           });
        $A.enqueueAction(action);
        
    }  
})