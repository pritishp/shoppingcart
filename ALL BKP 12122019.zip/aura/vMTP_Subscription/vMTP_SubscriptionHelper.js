({
	setBreadCrumbs : function (component, event, helper) {
        var breadcrumbCollection = [
            {label: 'All Products', name: 'all products' },
            {label: 'Subscribe', name: 'Subscribe'}
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },

})