({
	doInit : function(component, event, helper) {
        //Get Work Order defaults
        var WorkOrderInfo = component.get("c.getWorkOrderReassign");

        WorkOrderInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response){
            var woCheck = response.getReturnValue();
            component.set("v.WorkOrder",response.getReturnValue());   
            if((woCheck.Status != 'Submitted' && woCheck.Status != 'Error') 
               || (woCheck.Interface_Status__c != 'Processed' && woCheck.Interface_Status__c != 'Do Not Process' && woCheck.Interface_Status__c != 'Error')){
            		component.set("v.Qualify",false);
        			}
        });
        
        $A.enqueueAction(WorkOrderInfo);
        
	}, 
    
    YesClick : function(component, event, helper) {
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var saveWO = component.get("c.saveReassignWO");
        saveWO.setParams({
            "WorkOrder": component.get("v.WorkOrder"),
        });
        $A.enqueueAction(saveWO);
        
        saveWO.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                /*var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
				dismissActionPanel.fire(); 
        
                var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
            		"slideDevName": "detail"
        		});
        		backtoRecord.fire();*/
                
                component.find("overlayLib").notifyClose();
        		var refreshPage = $A.get("e.force:refreshView");
        		refreshPage.fire();
            }else{
                $A.util.addClass(
      			component.find('spinner'), 
      			"slds-hide"
				);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "message":  "There was problem reassigning Work Order.  Please log a ticket",
                    "type": "ERROR"
                });
                toastEvent.fire();
            }
        })
        }, 
    
    /*NoClick : function(component, event, helper) {
		var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
		dismissActionPanel.fire();
        
        var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
            		"slideDevName": "detail"
        		});
        backtoRecord.fire();
	}, */
    
    NoClick : function(component, event, helper) {
        component.find("overlayLib").notifyClose();
	}
})