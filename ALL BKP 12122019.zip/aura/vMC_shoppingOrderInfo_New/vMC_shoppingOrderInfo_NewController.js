({
    init : function(component, event, helper) {        
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
        component.set('v.today', today);
        component.set("v.selectedBillToRecord", component.get("v.billToErp"));
        component.set("v.selectedShipToRecord", component.get("v.shipToErp"));
        component.set("v.selectedContactRecord",component.get("v.orderContact"));
        if(!component.get("v.cart.Shipping_Contact_Attn__c"))             
            component.set("v.cart.Shipping_Contact_Attn__c", component.get("v.contactInfo.Name"));        
        if(!component.get("v.cart.Shipping_Contact_Phone__c"))
            component.set("v.cart.Shipping_Contact_Phone__c", component.get("v.contactInfo.Phone"));
        if(!component.get("v.cart.Shipping_Contact_Email__c"))
            component.set("v.cart.Shipping_Contact_Email__c", component.get("v.contactInfo.Email"));
        if(!(component.get("v.setOfModels").length ==1 && component.get("v.setOfModels")[0]=='Third Party')) {
            helper.getShippingMethodPicklist(component, event, helper);
        }
        // check for contact Role Assosiaction Records
        if(typeof component.get("v.contactInfo.Id") !== 'undefined'){
        helper.getAccfromContRoleAsso(component, event, helper);
        }
        helper.getUserCutOffDateTime(component, event, helper);
    },
    
    getFields : function (component, event, helper) {
        component.set("v.Spinner",true);
        helper.getFields(component,event,helper);
        component.set("v.Spinner",false);
    },
    openSearchBillToModal: function(component, event, helper) {        
        component.set("v.billToSearchModalOpen", true);
        helper.getBillTo(component,event,helper);
    },
    closeSearchBillToModal: function(component, event, helper) { 
        component.set("v.billToSearchModalOpen", false);
    },
    selectRecordBillToNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfBillToRecords")[index]; // Use it retrieve the store record
        component.set("v.selectedBillToRecord" , selectedRecord);        
        console.log(selectedRecord); 
        component.set("v.billToSearchModalOpen", false);
        var billToVal = selectedRecord.ERP_Partner__r.Name + ' - ' + selectedRecord.ERP_Partner__r.City__c;        
        component.find('billToInput').set('v.value',billToVal);
        component.find('billToInput').set('v.readonly',true);
        component.find('billToInput').reportValidity();
    },
    keyPressBillToNameSearch : function(component, event, helper) {                
        helper.getBillTo(component, event, helper);
    },
    openSearchContactModal: function(component, event, helper) {         
        component.set("v.contactSearchModalOpen", true);
        helper.getContacts(component, event, helper);        
    },
    closeSearchContactModal: function(component, event, helper) { 
        component.set("v.contactSearchModalOpen", false);
    },
    openSearchShipToModal: function(component, event, helper) {        
        component.set("v.shipToSearchModalOpen", true);
        helper.getShipTo(component, event, helper);
    },
    closeSearchShipToModal: function(component, event, helper) { 
        component.set("v.shipToSearchModalOpen", false);
    },
    selectRecordContactNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfContactRecords")[index]; // Use it retrieve the store record
        console.log(selectedRecord);
        component.set("v.selectedContactRecord" , selectedRecord);                
        component.find('orderContact').set('v.value',selectedRecord.Name);
        component.find('orderContact').reportValidity();        
        component.set("v.contactSearchModalOpen", false);      
        component.find('shipToName').set('v.value',selectedRecord.Name);
        component.find('shipToPhone').set('v.value',selectedRecord.Phone); 
        component.find('shipToEmail').set('v.value',selectedRecord.Email);
    },
    keyPressContactNameSearch : function(component, event, helper) {        
        var getInputkeyWord = component.get("v.searchContactInputValue");
        console.log('keyPressContactNameSearch===='+getInputkeyWord);
        helper.getContacts(component, event, helper);
    },
    onCheckNetTerm : function(component, event, helper) {   
        var changeElement = component.find("ifPreDefinedNetTerm");
        console.log('---changeElement---'+changeElement.get("v.value"));
        component.set("v.preDefinedNetTerm", changeElement.get("v.value"));
    },
    validateOrderInfo: function(component, event, helper) { 
        var formValidated=true;
        
        if(!component.get("v.cart.Ship_To_Site__r.ERP_Partner__r.Name")) {
            formValidated = [component.find('shipToInput')].reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
        }
        if(!component.get("v.cart.Bill_To_Site__r.ERP_Partner__r.Name")) {
            formValidated = [component.find('billToInput')].reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
        }
        if(!component.get("v.cart.Order_Contact__r.Name")) {
            formValidated = [component.find('orderContact')].reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
        }
        
        if(!(component.get("v.setOfModels").length ==1 && component.get("v.setOfModels")[0]=='Third Party')) {
            if(component.get("v.cart.Customer_Carrier__c")){
                formValidated = [component.find('fob'), component.find('shipToName'),component.find('shipToPhone'), component.find('customerCarrierType'),
                                 component.find('customerCarrierNo')].reduce(function (validSoFar, inputCmp) {
                                     // Displays error messages for invalid fields            
                                     inputCmp.showHelpMessageIfInvalid();
                                     return validSoFar && inputCmp.get('v.validity').valid;
                                 }, true);
            } else {
                formValidated = [component.find('shipToName'),component.find('shipToPhone')].reduce(function (validSoFar, inputCmp) {
                    // Displays error messages for invalid fields            
                    inputCmp.showHelpMessageIfInvalid();
                    return validSoFar && inputCmp.get('v.validity').valid;
                }, true);                
            }
        }
        
        if(component.find('fob')) {
            formValidated = [component.find('fob')].reduce(function (validSoFar, inputCmp) {
                // Displays error messages for invalid fields            
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && inputCmp.get('v.validity').valid;
            }, true);
        }
        if(component.find('shippingMethod')) {
            var shippingMethod = component.find('shippingMethod');
            if(shippingMethod.length >1) {
                for(var index in shippingMethod) {
                    formValidated = [shippingMethod[index]].reduce(function (validSoFar, inputCmp) {
                    // Displays error messages for invalid fields            
                    inputCmp.showHelpMessageIfInvalid();
                    return validSoFar && inputCmp.get('v.validity').valid;
                }, true);
                }
            } else {
                formValidated = [component.find('shippingMethod')].reduce(function (validSoFar, inputCmp) {
                    // Displays error messages for invalid fields            
                    inputCmp.showHelpMessageIfInvalid();
                    return validSoFar && inputCmp.get('v.validity').valid;
                }, true);
            }
            
        }
        if(component.find('customerShippingMethod')) {
            var customerShippingMethod = component.find('customerShippingMethod');
            if(customerShippingMethod.length >1) {
                for(var index in customerShippingMethod) {
                    formValidated = [customerShippingMethod[index]].reduce(function (validSoFar, inputCmp) {
                        // Displays error messages for invalid fields            
                        inputCmp.showHelpMessageIfInvalid();
                        return validSoFar && inputCmp.get('v.validity').valid;
                    }, true);
                }
            } else {
                formValidated = [component.find('customerShippingMethod')].reduce(function (validSoFar, inputCmp) {
                    // Displays error messages for invalid fields            
                    inputCmp.showHelpMessageIfInvalid();
                    return validSoFar && inputCmp.get('v.validity').valid;
                }, true);
            }
        }
        
        var ifEmailValid = false;
        if(!(component.get("v.setOfModels").length ==1 && component.get("v.setOfModels")[0]=='Third Party')){
            
            var emailField = component.find('shipToEmail');
            var emailFieldValue = emailField.get('v.value');
            var emailValid = component.find('shipToEmailValidError');
            if(emailField && !$A.util.isEmpty(emailFieldValue)) {
                
                var regExpEmailformat =/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/ ;  
                
                if(!$A.util.isEmpty(emailFieldValue)){   
                    if(emailFieldValue.match(regExpEmailformat)){
                        ifEmailValid = true;
                        console.log('Email valid***');
                    }else{
                        component.set("v.shipToEmailValidError", true);
                        $A.util.removeClass(emailValid, 'slds-hide');
                        console.log('Email invalid***');
                    }
                }
            } else {
                ifEmailValid = true;
            }
        }else
        {
            ifEmailValid = true;
        }
        
        var isStepThreeValid = false;
        if(ifEmailValid && formValidated) {
            isStepThreeValid = true;  
        } else {
            isStepThreeValid = false;
        }
        
        component.set('v.stepThreeValid', isStepThreeValid);
    },
    onChangeShippingMethod: function(component, event, helper) {
        var shippingMethod = event.getSource().get('v.value');
        var model = event.getSource().get('v.name'); 
        var shippingTypeLst = component.get("v.shippingTypeLst");
        for(var i in shippingTypeLst) {
            if(model == shippingTypeLst[i].class && shippingMethod == shippingTypeLst[i].value)
            	helper.setShippingMethod(component, event, helper,shippingTypeLst[i].shippingCost,model);
        }
        
        helper.getEstimatedDeliveryDate(component, event, helper,shippingMethod,model);
    }, 
    onCustomerShippingMethodChange : function(component, event, helper) {
        var shippingMethod = event.getSource().get('v.value');
        var model = event.getSource().get('v.name'); 
        var customShippingTypeLst = component.get("v.customShippingTypeLst");
        for(var i in customShippingTypeLst) {
            if(model == customShippingTypeLst[i].class && shippingMethod == customShippingTypeLst[i].value)
            	helper.setShippingMethod(component, event, helper,0,model);
        }
        if(shippingMethod)
            helper.getEstimatedDeliveryDate(component, event, helper,shippingMethod,model);
    },
    phoneChange: function(component, event, helper) {        
        var str = event.getSource().get('v.value');  		
        var patt = new RegExp('^[0-9]+$');
        var res = patt.test(str);        
        if(!res){
            event.getSource().set('v.value', '');
        }        
    },
    keyChecksBillToInput: function(component, event, helper) {        
        var isReadOnly = component.find('billToInput').get('v.readonly');
        if(!isReadOnly){
            component.find('billToInput').set('v.value','');
        }
    },
    
    keyChecksShipToInput: function(component, event, helper) { 	
        var isReadOnly = component.find('shipToInput').get('v.readonly');
        if(!isReadOnly){
            component.find('shipToInput').set('v.value','');
        } 
    },
    
    keyChecksOrderContact: function(component, event, helper) {        
        var isReadOnly = component.find('orderContact').get('v.readonly');
        if(!isReadOnly){
            component.find('orderContact').set('v.value','');
        }
        
    },
    
    keyPressShipToNameSearch : function(component, event, helper) { 
        helper.getShipTo(component, event, helper);
    },
    
    selectRecordShipToNameSearch : function(component, event, helper) {        
        var selectedItem = event.currentTarget; // Get the target object
        var index = selectedItem.dataset.record; // Get its value i.e. the index
        var selectedRecord = component.get("v.listOfShipToRecords")[index]; // Use it retrieve the store record
        
        console.log('selectedItem ->' +selectedItem +'  ' +index);
        
        component.set("v.selectedShipToRecord" , selectedRecord);
        component.set("v.selectedShipToERP" , selectedRecord.ERP_Partner_Number__c);        
        console.log('selectedRecord ->' +selectedRecord);        
        component.set("v.shipToSearchModalOpen", false);
        var shipToVal = selectedRecord.ERP_Partner__r.Name + ' - ' + selectedRecord.ERP_Partner__r.City__c;      
        
        console.log('shipToVal ->' +shipToVal +' ->' +selectedRecord.ERP_Partner_Number__c);
        component.find('shipToInput').set('v.value',shipToVal);
        component.find('shipToInput').set('v.readonly',true);
        component.find('shipToInput').reportValidity();        
    },
    
    getShipTo : function (component, event, helper) {
        component.set("v.selectedShipToRecord", event.getParam("recordName"));
        component.set("v.userAccount", event.getParam("recordId"));
        var accModalBackdrop = component.find('accModalBackdrop');
        var accModal = component.find('accModal');
        $A.util.addClass(accModalBackdrop, 'slds-hide');
        $A.util.addClass(accModal, 'slds-hide');
        helper.getShipTo(component, event, helper);
    },
    CheckLengthshipToPhone : function(component, event, helper) {
        var val = component.find("shipToPhone").get('v.value');
        if(val.length > 14){
            var comp = component.find("shipToPhone");
            comp.set('v.value',val.substring(0,14));
        }
    },
    handleRemove : function (component) {
        component.set("v.cart.Bill_To_Site__r.ERP_Partner__r.Name", '');
    },
    
    handleShipToRemove : function (component) {
        component.set("v.cart.Ship_To_Site__r.ERP_Partner__r.Name", '');
    },
    
    handleContactRemove : function (component) {
        if(!(component.get("v.setOfModels").length ==1 && component.get("v.setOfModels")[0] == 'Third Party')) 
            component.set("v.cart.Order_Contact__r.Name", '');
    },
    
    changeShippingFields: function (component, event, helper) {
        helper.changeShippingFields (component, event, helper);
    }
    
    
});