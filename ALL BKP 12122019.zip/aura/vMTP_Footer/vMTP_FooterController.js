({
    doInit : function(component,event,helper){
    console.log("doInit is called.-----");
      var envURL =  $A.get('$Label.c.vMarketplaceLightning_FooterPageUrl');
      console.log("FooterCommPageUrl-----"+envURL);
      component.set("v.environmentUrl", envURL);      
      component.set("v.TandC", envURL + 'vmc-terms-and-condition');
      component.set("v.FAQ", envURL + 'vmc-faq');
      component.set("v.contactUs", envURL + 'vmc-contactus');
        
  },
    
	handleTermsOfUseClick : function(component, event, helper) {
	var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef: "c:vMTP_marketPlace_Policy"
        });
       console.log("in handleTermsOfUseClick--");
    evt.fire();
    },
    
    handleClick: function(cmp, event, helper) {
        var navService = cmp.find("navService");
        // Uses the pageReference definition in the init handler
        var pageReference = cmp.get("v.pageReference");
        event.preventDefault();
        navService.navigate(pageReference);
    }
    
})