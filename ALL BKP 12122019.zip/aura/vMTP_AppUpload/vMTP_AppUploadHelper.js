({
    
	initializeAppPage : function(component, appMetadata){
        console.log('---appMetadata.isFreeDeveloper--'+appMetadata.isFreeDeveloper);
        /*if(appMetadata.isFreeDeveloper){
        	component.set('v.vMApp.Payment_Type__c', 'Free');
        }*/
    },
    
    showHideComponent : function(component, auraId, showComponent){
        var lightningElement = component.find(auraId);
        if(showComponent){
    		$A.util.addClass(lightningElement, 'slds-show');
            $A.util.removeClass(lightningElement, 'slds-hide');
        }else{
            $A.util.addClass(lightningElement, 'slds-hide');
            $A.util.removeClass(lightningElement, 'slds-show');
        }
	},
    
     validateAppUploadForm : function(component){
         console.log('---validateAppUploadForm--');
          var formValidated;
        var totalFileCount = 0;		         
         formValidated = component.find('appUploadFormInput').reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        var appId = component.get("v.vmcAppId");
        var isEcliplse = component.get("v.isEclipseCat");
        console.log('isEcliplse validate form ' +isEcliplse);
        if(isEcliplse){
            var encryptionTech = component.get("v.simpleApp.vMTP_Primary_Purpose_Encr__c");
            if(encryptionTech == 'false'){
                var fileArray = component.find("techFile");
                console.log('---techFile--'+fileArray.length);
                // console.log('---techFile len--'+component.find("techFile").get("v.files").length );
                for(var fileCounter in fileArray){
                    var fileComponent = fileArray[fileCounter];
                    var uploadedFiles = fileComponent.get("v.files");
                    console.log('---files--'+JSON.stringify(uploadedFiles));
                    console.log('---files--'+component.find('techFileUploaded'));
                    if(!uploadedFiles){
                       formValidated = false;
                       fileComponent.showHelpMessageIfInvalid();
                    }/*else{
                        totalFileCount = totalFileCount + 1;
                    }*/
                }
             }
             var medicalDevicecheckbox = component.get("v.medicalDevicecheckbox");
              if(medicalDevicecheckbox == false){
                var expertOpinionFileComponent = component.find("expertOpinionFile");
                console.log('---expertOpinionFile--'+expertOpinionFileComponent);
                // console.log('---techFile len--'+component.find("techFile").get("v.files").length );
				var uploadedFiles = expertOpinionFileComponent.get("v.files");
                    //if(!component.find('legalFileUploaded') &&!uploadedFiles){
                    if(!uploadedFiles){
                        formValidated = false;
                        expertOpinionFileComponent.showHelpMessageIfInvalid();
                    }
             }
        
             var legalFileComponents = component.find("legalFile");
             // console.log('---legalFileComponents--'+legalFileComponents.length);
             if(legalFileComponents){
                 if($A.util.isArray(legalFileComponents)){
                     for(var legaFileCounter in legalFileComponents){
                         var fileComponent = legalFileComponents[legaFileCounter];
                         var uploadedFiles = fileComponent.get("v.files");
                         console.log('---files--'+JSON.stringify(uploadedFiles))
                         // if(!component.find('legalFileUploaded') && !uploadedFiles){
                         if(!uploadedFiles){
                             formValidated = false;
                             fileComponent.showHelpMessageIfInvalid();
                         }/*else{
                        totalFileCount = totalFileCount + 1;
                    } */
               		}
            	}else{
                    var uploadedFiles = legalFileComponents.get("v.files");
                    //if(!component.find('legalFileUploaded') &&!uploadedFiles){
                    if(!uploadedFiles){
                        formValidated = false;
                        legalFileComponents.showHelpMessageIfInvalid();
                    }/*else{
                        totalFileCount = totalFileCount + 1;
                    }*/
                }
        }
         }     
         console.log('--1-'+formValidated+'---');
         if($A.util.isEmpty(component.get("v.simpleApp.vMTP_App_Category__c"))){
             component.find('appCategory').set("v.valid", false);	
             formValidated = false;
             console.log('--1 appCategory'+formValidated);
         }
         
         if($A.util.isEmpty(component.get("v.simpleApp.Publisher_Developer_Support__c"))){
             component.find('publisherAppSupport').set("v.valid", false);
             formValidated = false;
             
             console.log('--2 publisherAppSupport-'+formValidated);
         }
         
         
         if($A.util.isEmpty(component.get("v.simpleApp.Key_features__c"))){
             component.find('keyFeatures').set("v.valid", false);
             formValidated = false;
             console.log('--2 keyFeatures-'+formValidated);
         } 
         console.log('--3-'+formValidated);
         //   console.log('--3-totalFiles-'+totalFileCount);
         //  component.set("v.totalFiles", totalFileCount);
         return formValidated;
     },
    
    saveAppCountryRecords : function(component, appRecordId){
        console.log('----saveAppCountryRecords-1-'+appRecordId);
   		var countryDocumentsArray = component.get("v.legalDocuments");
        console.log('----saveAppCountryRecords-2-'+JSON.stringify(countryDocumentsArray));
        var totalFilesToSave = component.get("v.totalFiles");
        if(countryDocumentsArray){
            var saveAppCountries = component.get("c.saveAppDetails");             
            saveAppCountries.setParams({
                appId : appRecordId,
                countryDocuments : JSON.stringify(countryDocumentsArray)
            });
            console.log('----saveAppCountryRecords-3-');
            saveAppCountries.setCallback(this, function(response) {
                var state = response.getState();
                console.log("----state-saveAppCountryRecords-"+state);
                if (state === "SUCCESS") {                
                    var attachments = response.getReturnValue();
                    console.log('----legalDocuments-1-'+JSON.stringify(attachments));
                    
                    if(totalFilesToSave > 0){
                        this.saveAppCountryFiles(component, attachments);
                        this.uploadFiles(component, appRecordId);
                        console.log('component.get(v.medicalDevicecheckbox) ' +component.get("v.medicalDevicecheckbox") +' and ' + component.get("v.simpleApp.Is_Medical_Device__c"));
                        if(!component.get("v.medicalDevicecheckbox")){
                            console.log('medicalDevicecheckbox');
                                                     this.uploadOpinionFiles(component, appRecordId);	
                        }
                    }else
                        this.navigateToAppAssetPage(component);
                }else if (state === "INCOMPLETE") {
                    console.log("--STATE--INCOMPLETE--");
                }else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("APP-UPLOAD-Error message: " + errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
            });
            $A.enqueueAction(saveAppCountries); 
        }else{
            console.log('No Legal files');
             if(totalFilesToSave > 0){
                      this.uploadFiles(component, appRecordId);
                        console.log('component.get(v.medicalDevicecheckbox) ' +component.get("v.medicalDevicecheckbox") +' and ' + component.get("v.simpleApp.Is_Medical_Device__c"));
                        if(!component.get("v.medicalDevicecheckbox")){
                            console.log('medicalDevicecheckbox');
                          	this.uploadOpinionFiles(component, appRecordId);	
                        }
             }else
				 this.navigateToAppAssetPage(component);
        }
            
            
    },
    
    saveRapidPlanModelAppDetails : function(component, appRecordId){
        console.log('----saveRapidPlanModelAppCountryRecords-1-'+appRecordId);
         var totalFilesToSave = component.get("v.totalFiles");
        var saveRapidPlanModelAppCountries = component.get("c.saveRapidPlanModelAppDetails"); 
      	saveRapidPlanModelAppCountries.setParams({
            appId : appRecordId            
        });
        console.log('----saveAppCountryRecords-3-');
        saveRapidPlanModelAppCountries.setCallback(this, function(response) {
            var state = response.getState();
            console.log("----state-saveAppCountryRecords-"+state);
            if (state === "SUCCESS") {   
                console.log('Success');
             	if(totalFilesToSave > 0){
                      this.uploadFiles(component, appRecordId);
                }else
              	  this.navigateToAppAssetPage(component);
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(saveRapidPlanModelAppCountries); 
    },
    
    saveAppCountryFiles : function(component, legalCountryAttachments){
        
        var legalFileComponents = component.find("legalFile");  
        if(legalFileComponents) {
            console.log('----legalFileComponents--'+JSON.stringify(legalFileComponents));
            var countryCodes = {}; var europeanIndexCounter = 0;
            for(var countryCounter in legalCountryAttachments){
                var countryDocumentsObject = legalCountryAttachments[countryCounter];
                var vMCountry = countryDocumentsObject.vMarketCountry;
                var countryApp = countryDocumentsObject.appCountry;
                for(var fileCounter in countryDocumentsObject.files){
                  /*  if(vMCountry.European_Country__c == true) {
                        countryCodes[countryDocumentsObject.files[fileCounter]+''+vMCountry.Code__c.split(',')[europeanIndexCounter]] = countryApp.Id;
                    }
                    else {*/
                        countryCodes[countryDocumentsObject.files[fileCounter]+''+vMCountry.Code__c] = countryApp.Id;
                   // }
                }
                /*if(vMCountry.European_Country__c == true) {
                    europeanIndexCounter++;
                }*/
            }
            console.log('---countryCodes--'+JSON.stringify(countryCodes));
            if($A.util.isArray(legalFileComponents)){
                for(var legaFileCounter in legalFileComponents){
                    console.log("----saveAppCountryFiles--1--");
                    var legalFileElement = legalFileComponents[legaFileCounter];
                    if(legalFileElement.get("v.name").includes(',')) {
                        var temp = legalFileElement.get("v.name");
                        var documentName = legalFileElement.get("v.name").split(',')[0].substring(0 , legalFileElement.get("v.name").split(',')[0].length- 2);
                        var countries = legalFileElement.get("v.name").substring(documentName.length, temp.length).split(',');
                        for(var counter in countries) {
                            var fileName = documentName + countries[counter];
                            this.uploadLegalFiles(component, legalFileElement, countryCodes, fileName);
                        }
                        
                    } else {
                        var fileName = legalFileElement.get("v.name");
                        this.uploadLegalFiles(component, legalFileElement, countryCodes, fileName);
                    }
                    
                    
                }
            }else{
                this.uploadLegalFiles(component, legalFileComponents, countryCodes, legalFileComponents.get("v.name"));
            }
        }
        
    },
    
    uploadLegalFiles : function(component, fileComponent, countryCodes, fileName){
        console.log('---uploadLegalFiles--');
        
        
        if(countryCodes[fileName] && fileComponent){
            var uploadedFiles = fileComponent.get("v.files");
            if(!uploadedFiles && component.get("v.vmcAppId") !=''){
                console.log('--Legal File already uploaded--' + component.get("v.totalFiles"));
                if(component.get("v.totalFiles") == 1) {
                    this.navigateToAppAssetPage(component);
                } else {
                    component.set("v.totalFiles", component.get("v.totalFiles") - 1);
                }
            }      
            else if(!uploadedFiles && component.get("v.vmcAppId") ==''){
                console.log('----NO FILES--');
            } 
            else{
                console.log('----Legal Files to Upload--' + uploadedFiles[0]);
                for (var i = 0; i < uploadedFiles.length; i++) {
                    this.setupReader(component, uploadedFiles[i], countryCodes[fileName], fileName);
                }
            }            
        }
    },
    
    uploadFiles : function(component, parentRecordId) {
        console.log("----uploadFiles--");
        
        var technicalFileComponents = component.find("techFile");
        if(technicalFileComponents) {
            console.log("----uploadFiles--1--");
            for(var techFileCounter in technicalFileComponents){
                console.log("----uploadFiles--3--");
                var fileElement = technicalFileComponents[techFileCounter];
                console.log("----uploadFiles--4--"+fileElement.get("v.name"));
                var uploadedFiles = fileElement.get("v.files");
                console.log("----uploadFiles--5--");
                
                if(!uploadedFiles && component.get("v.vmcAppId") !=''){
                    console.log('--tech File already uploaded--' + component.get("v.totalFiles"));
                    if(component.get("v.totalFiles") == 1) {
                        this.navigateToAppAssetPage(component);
                    } else {
                        component.set("v.totalFiles", component.get("v.totalFiles") - 1);
                    }
                }else if(!uploadedFiles && component.get("v.vmcAppId") ==''){
                    console.log('----NO FILES--');
                }else{
                        console.log("----uploadFiles--6--");
                        for (var i = 0; i < uploadedFiles.length; i++) {
                            this.setupReader(component, uploadedFiles[i], parentRecordId, fileElement.get("v.name"));
                        }
                    }
                
                console.log("----uploadFiles--7--");
            }
        }        
    },
    uploadOpinionFiles : function(component, parentRecordId) {
         var expertOpinionFileComponents = component.find("expertOpinionFile");
        if(expertOpinionFileComponents) {
            console.log("----uploadOpinionFiles--1--");
            for(var fileCounter in expertOpinionFileComponents){
                var fileElement = expertOpinionFileComponents[fileCounter];
                console.log("----uploadFiles--4--"+fileElement.get("v.name"));
                var uploadedFiles = fileElement.get("v.files");
                console.log("----uploadFiles--5--");
                
                if(!uploadedFiles && component.get("v.vmcAppId") !=''){
                    console.log('--opinion File already uploaded--' + component.get("v.totalFiles"));
                    if(component.get("v.totalFiles") == 1) {
                        this.navigateToAppAssetPage(component);
                    } else {
                        component.set("v.totalFiles", component.get("v.totalFiles") - 1);
                    }
                }else if(!uploadedFiles && component.get("v.vmcAppId") ==''){
                    console.log('----NO FILES--');
                }else{
                        console.log("----uploading OpinionFiles--6--");
                        for (var i = 0; i < uploadedFiles.length; i++) {
                            this.setupReader(component, uploadedFiles[i], parentRecordId, fileElement.get("v.name"));
                        }
                }
            }
        }
        
    },
    
    setupReader : function(component, file, parentRecordId, fileName, fileArray) {
        console.log("----setupReader-");
        var fr = new FileReader();
        var self = this;
        var fileObj = new Object();
        fr.onload = function() {
            var fileContents = fr.result;
            var base64Mark = 'base64,';
            var dataStart = fileContents.indexOf(base64Mark) + base64Mark.length;
            
            fileContents = fileContents.substring(dataStart);
            fileObj = {
                parentId: parentRecordId,
                fileName: fileName,
                attachmentBody: '', 
                fileContentType: file.type
        	};
            console.log('----onload--'+fileObj.fileName);
            $A.getCallback(function() {
                if (component.isValid()) {
                    self.sendFile(component, fileObj, fileContents);
                }
            })();
        };
        fr.readAsDataURL(file);
    },
    
    sendFile : function(component, obj, fileContents){
        component.set("v.loading", true);
        console.log('--sendFile--');
        var action = component.get("c.saveFile"); 
        action.setParams({
            fileUploadJSONString : JSON.stringify(obj),
            fileBody : fileContents
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log("----status-sendFile-"+state);
            if (state === "SUCCESS") {                
            	console.log('--SUCCESS--');
                var totalFilesSent = component.get("v.totalFileSentToSF");
                var totalFiles = component.get("v.totalFiles");
                totalFilesSent = totalFilesSent + 1;
                console.log('--totalFilesSent--'+totalFilesSent+'--totalFiles-'+totalFiles);
                if(totalFilesSent == totalFiles){
                    console.log('-----thisthis----'+JSON.stringify(this));
                    this.navigateToAppAssetPage(component);
                }else{
                    component.set("v.totalFileSentToSF", totalFilesSent);
                }
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });
        $A.enqueueAction(action);
    },
    
    navigateToAppAssetPage : function(component){
        console.log('-----navigateToAppAssetPage----');
        var appId = component.get('v.vmcAppId');
        var categoryId = component.get('v.simpleApp.vMTP_App_Category__c');
        var appAssertId = component.get("v.vmcAppAssertId");
        console.log('---appId--'+appId);
        console.log('---categoryId--'+categoryId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": '/vmtp-appassetupload?appId='+appId+'&appCategoryId='+categoryId+'&appAssertId='+appAssertId
        });
        urlEvent.fire();
    },
    
     getUrlParameter : function(sParam) {
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
        var sURLVariables = sPageURL.split('&');
        var sParameterName = [];
        var i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? '' : sParameterName[1];
            }
        }
        return '';
    },
    
    
    getDocuments : function(component, event, helper, ifAppIdDefined){
        component.set("v.loading", true);
        var selectedCountryValues;
        if(ifAppIdDefined) {
            selectedCountryValues= component.get("v.values");
            var getLegalDocuments = component.get("c.getExistingCountryDocumentList");
            getLegalDocuments.setParams({
                "appId": component.get("v.vmcAppId")
            });
        }
        else {
            // selectedCountryValues = event.getParam("value");
            selectedCountryValues= component.get("v.values");
            if(component.get("v.isEclipseCat") ){
                var getLegalDocuments = component.get("c.getCountryDocumentList");
                getLegalDocuments.setParams({
                    "selectedCountries":JSON.stringify(selectedCountryValues),
                    "appId": component.get("v.vmcAppId")                    
                });
            }            
        }
        
        console.log('----selectedOptionValue--'+selectedCountryValues);
        if(component.get("v.isEclipseCat") || (component.get("v.isEclipseCat") && ifAppIdDefined)){
            getLegalDocuments.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {                
                    var legalDocs = response.getReturnValue();
                    console.log('legalDocs ' +legalDocs.length);
                    console.log('legalDocs ' +JSON.stringify(legalDocs));
                    
                    /*  for(var legalDocCounter in legalDocs) {
                    if(legalDocs[legalDocCounter].vMarketCountry && legalDocs[legalDocCounter].vMarketCountry.Address_Required__c) {
                        legalDocs[legalDocCounter].vMarketCountry.Address_Required__c = true;
                    } else {
                        legalDocs[legalDocCounter].vMarketCountry.Address_Required__c = false;
                        legalDocs[legalDocCounter].appCountry.vMTP_Legal_Name__c = '';
                        legalDocs[legalDocCounter].appCountry.vMTP_Legal_Address__c = '';
                    }
                        
                }*/
                component.set("v.legalDocuments", legalDocs);
                
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });
          $A.enqueueAction(getLegalDocuments);
          
      }else{
          component.set("v.loading", false);
      }    
        
    },
    
    getAttachedFiles : function (component, attachments) {
        var appPackages = [];
        var attachmentObject = component.get('v.attachmentInfo');
        var screenShotName = '';
        for(var attachmentCounter in attachments){
            var attachmentJSONObject = attachments[attachmentCounter];
            if(attachmentJSONObject && attachmentJSONObject.docName){
                if(attachmentJSONObject.docName.startsWith('AppSource')){
                	appPackages.push(attachmentJSONObject);
                }else if(attachmentJSONObject.docName.startsWith('tech')){
                    attachmentObject["techFile"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('CCAT')){
                    attachmentObject["CCATFile"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('510kForm')){
                    attachmentObject["510kForm"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('EnglishInstruction')){
                    attachmentObject['EnglishInstruction'] = attachmentJSONObject;
                    screenShotName = 'EnglishInstruction';
                }
            }    
        }
        if(attachmentObject[screenShotName]){
            console.log('----attachmentObject[screenShotName]--'+JSON.stringify(attachmentObject[screenShotName]));
            component.set("v.vmcAppAssetId", attachmentObject[screenShotName].parentRecordId);
            component.find("vMAppAssetCreator").reloadRecord();
        }else{
			this.getNewRecordInstance(component, "vMTP_App_Asset__c","newVMAppAsset", "newVMAppAssetError", "vMAppAssetCreator", "vMAppAsset");            
        }
        component.set("v.data", appPackages);
        component.set("v.attachmentInfo", attachmentObject);
        console.log('---attachmentObject--'+JSON.stringify(attachmentObject));
        return appPackages;
    },
    
    deleteAppSources :  function(component,event,appId){
        console.log('App Id' + appId)
        var deleteAppSourceAction = component.get("c.deleteAppSources");
        deleteAppSourceAction.setParams({
            "appId" : appId
        });
        deleteAppSourceAction.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {   
                var result = response.getReturnValue();
                if(result)
                    console.log('AppSoure and Content Document deleted');
            }
        });
        
        $A.enqueueAction(deleteAppSourceAction);
    },
    
    createAppAssert :  function(component, appRecordId){
        console.log('createAppAssert for App Id' + appRecordId)
        var createAppAssertAction = component.get("c.createAppAsert");
        createAppAssertAction.setParams({
            "appId" : appRecordId
        });
        
        createAppAssertAction.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {   
                var result = response.getReturnValue();
                  console.log('AppAsert Id  ' + result);
                	component.set("v.vmcAppAssertId", result);
            }
        });
        
        $A.enqueueAction(createAppAssertAction);
    }
})