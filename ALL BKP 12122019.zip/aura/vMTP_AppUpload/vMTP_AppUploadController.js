({
	startAppUpload : function(component, event, helper) {
        if(window.location.href.indexOf("appId") > -1) {
            var applicationId = helper.getUrlParameter('appId');
            component.set("v.vmcAppId", applicationId);
        }
        
		var loadAppMetadata = component.get("c.initializeAppUpload");
        component.set("v.loading", true);
        loadAppMetadata.setParams({
            appId: component.get("v.vmcAppId"),
        })
        loadAppMetadata.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {                
            	var appUploadObj = response.getReturnValue();
                console.log('----appUploadObj--'+JSON.stringify(appUploadObj));
                component.set('v.appUpload',appUploadObj);
                component.set("v.countryOptions", appUploadObj.vMarketCountries);
                component.set("v.encryptionOptions", appUploadObj.encryptionTypes);
                if(appUploadObj.vMC_AppData) {
                    component.set("v.simpleApp", appUploadObj.vMC_AppData);
                    console.log('selAppCategory from Step2 '+ appUploadObj.vMC_AppData.vMTP_App_Category__c );
                    component.set("v.insertedAppCategory",appUploadObj.vMC_AppData.vMTP_App_Category__c );
                    var items = [];
                    var countries = appUploadObj.vMC_AppData.Countries__c.split(";");
                    for(var item in countries) {
                        items.push(countries[item]);
                    }
                    
                	component.set("v.values",items);
                    helper.getDocuments(component, event, helper, true);
                   // helper.getAttachedFiles(component, appUploadObj.getAppFiles);
                } else {
                     component.set("v.simpleApp",{'sobjectType': 'vMTP_App__c', 
                                                  'vMTP_App_Category__c' : '', 
                                                  'Payment_Type__c' : ''});
                }
                    
                helper.initializeAppPage(component,appUploadObj);
            }else if (state === "INCOMPLETE") {
                console.log("--STATE--INCOMPLETE--");
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("APP-UPLOAD-Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            component.set("v.loading", false);
        });
        $A.enqueueAction(loadAppMetadata);
        console.log('---startAppUpload--');
	},
    
    getDocuments : function(component, event, helper){
        if($A.util.isEmpty(component.get("v.simpleApp.vMTP_App_Category__c"))){
        	component.find('appCategory').set("v.valid", false);
			component.find('appCategory').showHelpMessageIfInvalid();
            console.log('countries' +component.get("v.values"));
        }else{
			if(component.get("v.simpleApp.Is_Medical_Device__c"))
        		helper.getDocuments(component, event, helper, false);
        }
    },
    
    encryptionOptionChange : function(component, event){
        var selectedEncryptionTypes = event.getParam("value");
        console.log('----selectedOptionValue--'+selectedEncryptionTypes);
    },
    
    showHidePricing : function(component, event, helper){
        console.log('---showHidePricing---');
        var paymentTypeValue = component.get("v.simpleApp.Payment_Type__c");
        console.log('---paymentTypeValue---'+paymentTypeValue);
        if(paymentTypeValue == 'Subscription'){
            helper.showHideComponent(component, "subscriptionPrices", true);
            helper.showHideComponent(component, "oneTimePriceSection", false);
        }else if(paymentTypeValue == 'One Time'){
            helper.showHideComponent(component, "subscriptionPrices", false);
            helper.showHideComponent(component, "oneTimePriceSection", true);
        }else{
            helper.showHideComponent(component, "subscriptionPrices", false);
            helper.showHideComponent(component, "oneTimePriceSection", false);
        }
    },
    
    saveVMCApp : function(component, event, helper){
        component.set("v.loading", true);
        component.set("v.activeSections", ['securityDetails','appDetails','publisherDetails']);
        console.log('---saveVMCApp--1-'+JSON.stringify(component.get('v.simpleApp')));
        if(helper.validateAppUploadForm(component)){
            console.log("--saveAppRecord--");
            var vmcAppRecord = component.get('v.simpleApp');
            if(vmcAppRecord && vmcAppRecord.vMTP_Is_Designed_For_Medical__c == true){
                vmcAppRecord.vMTP_Is_Designed_For_Medical__c = true;
            }
            else if(vmcAppRecord && vmcAppRecord.vMTP_Is_Designed_For_Medical__c == false){
                vmcAppRecord.vMTP_Is_Designed_For_Medical__c = false;
            }
            if(vmcAppRecord && vmcAppRecord.vMTP_Primary_Purpose_Encr__c == true){
                vmcAppRecord.vMTP_Primary_Purpose_Encr__c = true;
            }
            else if(vmcAppRecord && vmcAppRecord.vMTP_Primary_Purpose_Encr__c == false){
                vmcAppRecord.vMTP_Primary_Purpose_Encr__c = false;
            }
            if(vmcAppRecord && vmcAppRecord.vMTP_Protected_Health_Info__c == true) {
                vmcAppRecord.vMTP_Protected_Health_Info__c = true;
            } 
            else if(vmcAppRecord && vmcAppRecord.vMTP_Protected_Health_Info__c == false){
                vmcAppRecord.vMTP_Protected_Health_Info__c = false;
            }
            if(vmcAppRecord && vmcAppRecord.vMTP_Personal_Info__c == true) {
                vmcAppRecord.vMTP_Personal_Info__c = true;
            } 
            else if(vmcAppRecord && vmcAppRecord.vMTP_Personal_Info__c == false){
                vmcAppRecord.vMTP_Personal_Info__c = false;
            }
            var vmAppId = component.get("v.vmcAppId");
            if(vmAppId){
                vmcAppRecord.Id = vmAppId;
                if(component.get("v.simpleApp.vMTP_App_Category__c") != component.get("v.insertedAppCategory"))
                	helper.deleteAppSources(component,event,vmAppId);
            }
            vmcAppRecord.ApprovalStatus__c = 'Draft';
            var saveAppAction = component.get("c.saveApp");
            saveAppAction.setParams({
                "selectedCountries" : JSON.stringify(component.get("v.values")),
                "vMarketApp" : JSON.stringify(vmcAppRecord)
            });
            saveAppAction.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {                
                    var appRecordId = response.getReturnValue();
                    component.set("v.vmcAppId", appRecordId);
                    helper.createAppAssert(component, appRecordId);
                    console.log('appRecordId ' +appRecordId +' is eclipse ' +component.get("v.isEclipseCat"));
                    if( component.get("v.isEclipseCat")){
                        console.log('appRecordId 2 ' +appRecordId +' is eclipse ' +component.get("v.isEclipseCat"));
						helper.saveAppCountryRecords(component, appRecordId);                        
                    }else{
                        helper.saveRapidPlanModelAppDetails(component, appRecordId);
                    }
                }else if (state === "INCOMPLETE") {
                    console.log("--STATE--INCOMPLETE--");
                }else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("APP-UPLOAD-Error message: " + errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
                component.set("v.loading", false);
            });
            $A.enqueueAction(saveAppAction);
        }else{
            component.set("v.loading", false);
        }
        console.log('---saveVMCApp--2-');
    },
    
    appAccessingPersonalProtectedData : function(component, event, helper){
        var changeValue = event.getParam("value");
        console.log('----appAccessingPersonalProtectedData?--'+changeValue);
    },
    
    fileSelected : function(component, event, helper){
        var fileElement = event.getSource();
        var files = fileElement.get("v.files");
        fileElement.showHelpMessageIfInvalid();
        var componentId = fileElement.getLocalId();
        var uploadedFile = component.find(componentId + 'Uploaded');
        var totalFiles = component.get("v.totalFiles");
        if(files && files[0]){
            var fileElements = component.find(componentId+"Name");
            if($A.util.isArray(fileElements)){
                for(var index in fileElements) {
                    if(component.find(componentId)[index].get("v.name") == event.getSource().get('v.name')) {
                        if(files[0].size>500000 || files[0].type != 'application/pdf') {
                            component.find(componentId)[index].setCustomValidity('Please upload a PDF File of size less than 0.5 MB');
                            component.find(componentId)[index].reportValidity();
                            fileElements[index].getElement().innerHTML = '';
                        } else {
                            fileElements[index].getElement().innerHTML = files[0].name;
                            component.find(componentId)[index].setCustomValidity('');
                            component.find(componentId)[index].reportValidity();
                            $A.util.addClass(uploadedFile[index], 'slds-hide');
                            totalFiles = totalFiles + 1;
                        }
                        
                    }
                }
            }
            else {
                if(files[0].size>500000 || files[0].type != 'application/pdf') {
                    component.find(componentId).setCustomValidity('Please upload a PDF File of size less than 0.5 MB');
                    component.find(componentId).reportValidity();
                    fileElements.getElement().innerHTML  = '';
                }
                
                else {
                    fileElements.getElement().innerHTML = files[0].name;
                    component.find(componentId).setCustomValidity('');
                    component.find(componentId).reportValidity();
                    $A.util.addClass(uploadedFile, 'slds-hide');
					totalFiles = totalFiles + 1;
                }
            }
           component.set("v.totalFiles", totalFiles);
           console.log('totalFiles' + component.get("v.totalFiles"));
        }
    },
    
    openInfoModal : function (component, event, helper) {
        var iconName = event.getSource().get('v.iconVariant');
        component.set("v.infoTitle", iconName);
        component.set("v.infoModal", true);
    },
    
    closeModal : function (component, event, helper) {
        component.set("v.infoModal", false);
		component.set("v.isMedicalDevice", false);
		component.set("v.isopinionModalOpen", false);        
    },
    
    getMedicalDeviceValue : function (component, event, helper) {
		var isMedical = component.find('isMedicalDeviceInput').get("v.checked");
        console.log('v.simpleApp.Is_Medical_Device__c' + component.get("v.simpleApp.Is_Medical_Device__c"));
       // if(isMedical)
       	 component.set("v.medicalDevicecheckbox", isMedical);
        if(component.get("v.isEclipseCat") && component.get("v.values").length>0 && component.get("v.simpleApp.Is_Medical_Device__c"))
               helper.getDocuments(component, event, helper, false);
        else{
            var legalDocs;
            component.set("v.legalDocuments", legalDocs);
        }    
    },
    
    openMedicalDeviceModal : function (component, event, helper) {
		component.set("v.isMedicalDevice", true);        
    },
    
     closeMedicalDeviceModal : function (component, event, helper) {
        component.set("v.isMedicalDevice", false);
    },
    openOpinionModal : function (component, event, helper) {
		component.set("v.isopinionModalOpen", true);        
    },
    validateRichText : function (component, event, helper) {
        if($A.util.isEmpty(component.get("v.simpleApp.Publisher_Developer_Support__c"))){
        	component.find('publisherAppSupport').set("v.valid", false);
        } else {
            component.find('publisherAppSupport').set("v.valid", true);
        }
        if($A.util.isEmpty(component.get("v.simpleApp.Key_features__c"))){
        	component.find('keyFeatures').set("v.valid", false);
        } else {
            component.find('keyFeatures').set("v.valid", true);
        }
    },
    
    checkAppCategory : function(component,event, helper){
        console.log('selectedCategory ' + component.get("v.simpleApp.vMTP_App_Category__c"));
        console.log('Inserted Category ' +  component.get("v.insertedAppCategory"));
        if(component.get("v.simpleApp.vMTP_App_Category__c")){
            var isEclipseCatgeory = component.get("c.isEclipseCatgeory");
            console.log('length Country ' +component.get("v.values").length);
            
            isEclipseCatgeory.setParams({
                appCategoryId : component.get("v.simpleApp.vMTP_App_Category__c")
            });
            isEclipseCatgeory.setCallback(this, function(response){
                var state = response.getState();          
                if (state === "SUCCESS") {                
                    var isEclipse = response.getReturnValue();
                    console.log('isEclipse ' +isEclipse);
                    if(isEclipse){
                        component.set("v.isEclipseCat",true);
                        if(component.get("v.values").length>0 && component.get("v.simpleApp.vMTP_App_Category__c") != null && component.get("v.medicalDevicecheckbox"))
                        {
                            console.log('getDocuments');
                            helper.getDocuments(component, event, helper, false);
                        }
                    }else{
                        component.set("v.isEclipseCat",false);
                        var legalDocs;
                        component.set("v.legalDocuments", legalDocs);
                    }
                    
                }
            });
            $A.enqueueAction(isEclipseCatgeory); 
        }else{
            component.set("v.isEclipseCat",false);
        }
    },
    
    setEncryptionDetails : function (component, event, helper) {
      var encryptionTech = component.get("v.simpleApp.vMTP_Primary_Purpose_Encr__c");
       console.log('Encryption Radio ' + component.get("v.simpleApp.vMTP_Primary_Purpose_Encr__c"));
      // encryptionDetails
       console.log(typeof encryptionTech);
       if(encryptionTech == 'false'){
            console.log('Encryption Radio ');
            $A.util.addClass(component.find('encryptionDetails'), 'slds-show');
            $A.util.removeClass(component.find('encryptionDetails'), 'slds-hide');
        }else{
             console.log('Encryption Radio else');
            $A.util.addClass(component.find('encryptionDetails'), 'slds-hide');
            $A.util.removeClass(component.find('encryptionDetails'), 'slds-show');
        }
    },
    
})