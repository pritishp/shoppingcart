({
    doInit : function (component, event, helper) {
        console.log('Init---');
        var caseObject = component.get("v.caseRecord");
    },
    closeModel: function(component, event, helper) {
        component.set("v.showPopup", false);
    },
    createArticle : function(component, event, helper) {
        helper.showSpinner(component, event, helper);
        
        console.log('Test');
        var action = component.get("c.getRecordTypeId");
        action.setParams({ 
            "recTypeName" : component.find("levels").get("v.value") 
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var recid = response.getReturnValue();
                var articleRecTypeName = component.find("levels").get("v.value");
                var subject = component.get("v.caseRecord").Subject;
                var urlName =  subject.replace(/[^a-zA-Z0-9 -]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/,'');                
                
                if (articleRecTypeName === 'Q&A') {
                    var createRecordEvent = $A.get("e.force:createRecord");
                    createRecordEvent.setParams({
                        "entityApiName": "Service_Article__kav",
                        "recordTypeId" : recid,
                        "defaultFieldValues": {
                            'Answer__c' : component.get("v.caseRecord").Local_Case_Activity__c,
                            'Title' : component.get("v.caseRecord").Subject,
                            'Manager_Name__c' : component.get("v.caseRecord").Applies_To__c,
                            'UrlName' : urlName,
                            'Properties__c' : component.get("v.caseRecord").ECF_Investigation_Notes__c,
                            'Solution__c' : component.get("v.caseRecord").Local_Case_Activity__c,
                            'Symptoms__c' : component.get("v.caseRecord").Symptoms__c,
                            'SourceId': component.get("v.caseRecord").Id
                        }
                    });
                    helper.hideSpinner(component, event, helper);
                    component.set("v.showPopup", false);
                    createRecordEvent.fire();
                } else if (articleRecTypeName === 'How To') {
                    var createRecordEvent = $A.get("e.force:createRecord");
                    createRecordEvent.setParams({
                        "entityApiName": "Service_Article__kav",
                        "recordTypeId" : recid,
                        "defaultFieldValues": {
                            'Process__c' : component.get("v.caseRecord").Local_Case_Activity__c,
                            'Title' : component.get("v.caseRecord").Subject,
                            'Manager_Name__c' : component.get("v.caseRecord").Applies_To__c,
                            'UrlName' : urlName,
                            'Properties__c' : component.get("v.caseRecord").ECF_Investigation_Notes__c,
                            'Solution__c' : component.get("v.caseRecord").Local_Case_Activity__c,
                            'Symptoms__c' : component.get("v.caseRecord").Symptoms__c,
                            'SourceId': component.get("v.caseRecord").Id
                        }
                    });
                    helper.hideSpinner(component, event, helper);
                    component.set("v.showPopup", false);
                    createRecordEvent.fire();
                } else {
                    var createRecordEvent = $A.get("e.force:createRecord");
                    createRecordEvent.setParams({
                        "entityApiName": "Service_Article__kav",
                        "recordTypeId" : recid,
                        "defaultFieldValues": {
                            'Title' : component.get("v.caseRecord").Subject,
                            'Manager_Name__c' : component.get("v.caseRecord").Applies_To__c,
                            'UrlName' : urlName,
                            'Properties__c' : component.get("v.caseRecord").ECF_Investigation_Notes__c,
                            'Solution__c' : component.get("v.caseRecord").Local_Case_Activity__c,
                            'Symptoms__c' : component.get("v.caseRecord").Symptoms__c,
                            'SourceId': component.get("v.caseRecord").Id
                        }
                    });
                    helper.hideSpinner(component, event, helper);
                    component.set("v.showPopup", false);
                    createRecordEvent.fire();
                }
            }
        });
        $A.enqueueAction(action);
    }
})