({
	closeModal : function(component, event, helper) {
        var modalWindow = component.find('modalWindow');
        $A.util.addClass(modalWindow, 'slds-hide');
        var backdrop = component.find('backdrop');
        $A.util.removeClass(modalWindow, 'slds-fade-in-open');
        $A.util.removeClass(backdrop, 'slds-backdrop slds-backdrop_open');
	},
    
    addToCart : function (component, event, helper) {
        var quantity= component.get('v.quantity');
        var selectedSubPlan='';
       
        if(component.find('selectedPlan')) {
         	selectedSubPlan = component.find('selectedPlan').get('v.value');
        //console.log('selectedSubPlan ' +selectedSubPlan);
        }
        var accountId = '';
        var contactId = '';
        var unitP = component.get("v.AppDetail.vMTPApp.Price__c");
         var conversionRate= component.get("v.conversionRate");
        //alert('unitP--'+unitP);
        if(component.get('v.objAccount')){
            accountId = component.get('v.objAccount').Id;
        }
        if(component.get('v.objContact')){
            contactId = component.get('v.objContact').Id;
        } 
        var action = component.get("c.addCartItem");
        action.setParams ({
            appId: component.get("v.appId"),
            quantity:quantity,
            accountId: accountId,
            contactId: contactId,
            subDurationType :selectedSubPlan,
            unitPrice:unitP*conversionRate        
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var msg = response.getReturnValue();
                console.log('msg ' +msg);
                var variant;
                if(msg.includes('Success')) {
                   variant = 'Success';
                }else if(msg.includes('Subscription')){
                    console.log('Warning');
                 	variant = 'Warning';   
                }
                else if(msg.includes('Exception')){
                 	variant = 'Error';   
                } else {
                    variant = 'Info';

                }
                helper.handleShowToast(component, event, helper, msg,variant,variant);
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
            }
            else {
                helper.handleShowToast(component, event, helper, 'Exception Occurred !','Error', 'Error');
            }
        });
        $A.enqueueAction(action);
    },
    
    handleShowToast : function(component, event, helper, msg, variant,title) {
        component.find('notifLib').showToast({
            "title": title,
            "message": msg,
            "variant" : variant
        });
    }
})