({
    init: function(cmp) {
       console.log(">>>>>>>>>" + cmp.get("v.currencyISOCode"));
      //  var listRichText = cmp.find("listRichText");
       // listRichText.set("v.value", cmp.get("v.AppDetail.listingObj.App__r.Key_features__c"));

         },
	
    AddToCart : function (component, event, helper) {       
        helper.addToCart(component, event, helper);
    },
    
    closeModal : function (component, event, helper) {
        helper.closeModal (component, event, helper);
    },
    
    openSubscriptionPlans : function (component, event, helper) {
        var modalWindow = component.find('modalWindow');
        $A.util.removeClass(modalWindow, 'slds-hide');
        var backdrop = component.find('backdrop');
        $A.util.addClass(modalWindow, 'slds-fade-in-open');
        $A.util.addClass(backdrop, 'slds-backdrop slds-backdrop_open');
    },
    
    confirmSubscription : function (component, event, helper) {
        if(component.find('selectedPlan').get('v.value')=='') {
            alert('Please select a plan or press cancel');
        } else {
             var selectedPlan = component.find('selectedPlan').get('v.value');
            helper.closeModal (component, event, helper);
			helper.addToCart(component, event, helper);
        }
      
    },
    
    imageClick : function (component, event, helper){
        component.set("v.appImageModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
      component.set("v.appImageModalOpen", false);
   }
})