({
	 doInit : function (component, event, helper) {
      //helper.getURLParameters (component, event, helper);
     // helper.setAdminFlag(component, event);
      helper.getAppReviewDetails(component, event);
        //var pageRef = component.get("v.pageReference");
         //console.log(component.get("v.pageReference"));
		var appId = component.get("v.appId");
        var appCountry =component.get("v.country");
         console.log('appid ' +appId +' and Coutry ' +appCountry);
    },
    
    openAppDetails: function(component, event, helper) {
    	var appId = component.get("v.appId");
        
         console.log('navigateToRecord ');
       // var recordId = event.getParam("recordId");
       //window.location.href = '/one/one.app#/sObject/'+recordId+'/view';
       // varianMarketPlace/s/detail/
        window.open('/varianMarketPlace/s/detail/'+appId); 
       //  
     //  window.location.href = '/varianMarketPlace/s/detail/'+appId;
        /*
		var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                      "recordId": appId,
                	  "slideDevName" :"detail"
                    }); 
            navEvt.fire();*/
    },
    validateComments : function(component, event, helper) {
       var formValidated = [component.find('comments')].reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields            
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        console.log('---formValidated--'+formValidated);
        if(!formValidated){             
           component.set("v.isModalOpen", false);
        }else{            
            component.set("v.isModalOpen", true);
        }
      
    },
    handleAdminSubmit: function(component, event, helper) {
       //var validComments = component.validateComments(component, event, helper);
      var validComments= [component.find('comments')].reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields            
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        	}, true); 
        
       // console.log('isValid ' +validComments)
        if(validComments){
         	var clickedBtn = event.getSource().getLocalId();
        	console.log(clickedBtn);
          //  debugger;
            if(clickedBtn == "publish") {
                console.log(clickedBtn );
                // $A.util.removeClass(component.find("appPubLishText"), "slds-hide");
                component.set("v.isPublish", true);              
                component.set("v.isReject", false);     
                component.set("v.isInfoNeeded", false); 
                component.set("v.isModalOpen", true);
            }
            else if(clickedBtn == "reject") {
                console.log(clickedBtn);
               component.set("v.isPublish", false);              
                component.set("v.isReject", true);     
                component.set("v.isInfoNeeded", false);
                component.set("v.isModalOpen", true);
            }
            else if(clickedBtn == "moreInfo") {
                 //$A.util.removeClass(component.find('appInfoReqText'), "slds-hide");
               component.set("v.isPublish", false);              
                component.set("v.isReject", false);                 
                helper.getInfoRequestedFields(component, event, helper);
            }  
            
     }
    },
     closeModal: function(component, event, helper) { 
        component.set("v.isModalOpen", false);
    },
    
     handleReviewSubmission: function(component, event, helper) { 
         console.log('in handleReviewSubmission Approval ');
         helper.finishApproval(component, event, helper);
        component.set("v.isModalOpen", false);
    },
})