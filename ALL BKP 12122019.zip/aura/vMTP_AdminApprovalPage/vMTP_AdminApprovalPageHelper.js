({
    getURLParameters : function(component, event) {      
        var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),               
                sURLVariables = sPageURL.split('&'),               
                sParameterName,                
                i;  
            console.log('paramater len ' +sURLVariables.length);
            if(sURLVariables.length > 1){
            for (i = 0; i < sURLVariables.length; i++) {               
                sParameterName = sURLVariables[i].split('=');               
                if (sParameterName[0] === sParam) {                    
                    return sParameterName[1] === undefined ? true : sParameterName[1];                    
                } 
            }
            }
        }; 
        //  var AEMMode = getUrlParameter('mode');
  // console.log("getparameters " +getUrlParameter());
      
           
        component.set("v.appId", getUrlParameter('appId'));
        component.set("v.country", getUrlParameter('con'));
        console.log("getparameters 1" +component.get("v.appId"));
        
        //Calling Server Side controller for fetching the App Review Details   
       
         
        
    },
     getAppReviewDetails : function(component, event) {
         console.log('getAppReviewDetails ');
        var action = component.get("c.getAppReviewDetails");
        action.setParams({
            appId: String(component.get("v.appId")),
            countryCode : String(component.get("v.country"))
        });  
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('getAppReviewDetails() -> ' +state);
                component.set("v.objClassController", response.getReturnValue());
            }
        });
        $A.enqueueAction(action); 	
    },
    
    setAdminFlag : function(component, event) {
        var action = component.get("c.getUserAdminInfo");
        // set a callBack    
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.userAdminInfo", response.getReturnValue());
                console.log()
            }
        });
        $A.enqueueAction(action);		
    },
    
    getInfoRequestedFields : function(component, event,helper) {
        console.log('v.infoRequestedOptions ' +component.get("v.appId") +' country '+ component.get("v.country"));
		var action = component.get("c.getInfoRequestedFields");
        action.setParams({
            appId: component.get("v.appId"),
            countryCode : component.get("v.country")
        });
        var opts = [];
         action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                 var allValues = response.getReturnValue();
                for (var i = 0; i < allValues.length; i++) {
                    opts.push({
                        class: "optionClass",
                        label: allValues[i],
                        value: allValues[i]
                    });
                }
                component.set("v.isInfoNeeded", true);
                component.set("v.infoRequestedOptions", opts);
              //  console.log('v.infoRequestedOptions ->' +v.infoRequestedOptions);
                component.set("v.isModalOpen", true);
            }
             else{
                 console.log('State ->' +state);
             }
        });
        $A.enqueueAction(action);        
	},
    
    finishApproval : function(component, event, helper) { 
        
        var comments = component.find("comments").get('v.value');
        var appId = component.get("v.appId");
        var countryCode = component.get("v.country");
        var status;
        console.log('selectedinfoRequestedOptions ->' +component.get("v.selectedinfoRequestedOptions"));
        if(component.get("v.isPublish") )
            status = 'Published';
        else if(component.get("v.isReject") )
        	status ='Rejected';
        else if(component.get("v.isInfoNeeded") )
            status ='Info Requested';
        
        console.log('status finishApproval ' +status);
        
        var action = component.get("c.FinishApproval");
        action.setParams({
            appId : component.get("v.appId"),
            countryCode : component.get("v.country"),
            status: String(status),
            comment : String(comments),
            selRequestedFields : component.get("v.selectedinfoRequestedOptions")
        });
        
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();               
               console.log('result ->' +result);
                if(result == true){
                     $A.get('e.force:refreshView').fire();
                }
            }
        });
        $A.enqueueAction(action);        
    }
})