({
	onCurrencyChange : function(component, event, helper) {
        component.set("v.reloadStripePaymentScreen", false);
        window.setTimeout(
            $A.getCallback(function() {
                component.set("v.reloadStripePaymentScreen", true);
            }), 3000
        );
        window.scrollTo(0,0);
        
	},
    
    
})