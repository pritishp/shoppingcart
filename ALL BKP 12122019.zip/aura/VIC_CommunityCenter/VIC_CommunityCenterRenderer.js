({
    // Your renderer method overrides go here
    afterRender: function (component, helper) {
        if(document.querySelector(".communitySection") !== null && document.querySelector(".communitySection") !== undefined) {
            if(document.querySelector(".communitySection").offsetHeight < window.innerHeight) {
                var remainingHeight = (window.innerHeight - document.querySelector(".cVIC_FM_Footer").offsetHeight);
                var setHeight = (remainingHeight - 102)+10;
                document.querySelector(".communitySection").style.minHeight = setHeight + "px";
                document.querySelector(".communitySection").style.backgroundColor = "#fff";
            }
        }
        
        window.setInterval(function() {            
            if(this.frameElement !== null  && this.frameElement !== undefined) 
                this.frameElement.height = this.frameElement.contentWindow.document.body.scrollHeight + "px";            
        }, 3000); 
    }
})