({    
    handleCreate : function (component, event, helper) {                
        var saCountnumber = component.get("v.SAcount");
        console.log("saCountnumber: " + saCountnumber);
        if(saCountnumber == '' || saCountnumber == undefined || saCountnumber <= 0){
            component.find('tenotifLib').showNotice({
                "variant": "error",
                "header": "Valid Count is required to create Service Appointments."
            });
        }else if(saCountnumber >= 5){
            var saCountMsg = "Are you sure you want to create "+saCountnumber+" SA's??";            
            $A.util.addClass(component.find("createSAs"), "slds-hide");
            $A.util.removeClass(component.find("moreThanFiveSAs"), "slds-hide");
            $A.util.addClass(component.find("moreThanFiveSAs"), "slds-show");
        }
            else{
                console.log('Calling createServiceApp ');                
                var saCreation = component.get('c.createServiceApp');
                $A.enqueueAction(saCreation);
            }                
    },
    
    createServiceApp : function(component, event, helper){        
        /*show spinner on button press*/
        $A.util.removeClass(
            component.find('spinner'), 
            "slds-hide"
        );
                
        console.log("selectedRecordId: " + component.get("v.recordId"));
        console.log("selectedCount: " + component.get("v.SAcount"));
        
        
        var save = component.get("c.createServiceApps");
        save.setParams({
            "selectedRecordId": component.get("v.recordId"),
            "selectedCount": component.get("v.SAcount")
        });
        $A.enqueueAction(save);        
        save.setCallback(this, function(response){
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {           
                $A.util.addClass(
            component.find('spinner'), 
            "slds-hide"
        );
                component.find("teoverlayLib").notifyClose();
                var refreshPage = $A.get("e.force:refreshView");
                refreshPage.fire();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success",
                    "message":  "Service appointment created successfully.",
                    "type": "Success"
                });
                toastEvent.fire();
            }else{
                $A.util.addClass(
                    component.find('spinner'), 
                    "slds-hide"
                );
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "message":  "There was problem while creating service appointments. Please log a ticket",
                    "type": "ERROR"
                });
                toastEvent.fire();
            }
        })        
    },
    NoClick : function(component, event, helper) {
        component.find("teoverlayLib").notifyClose();        
    },
    
    yesClick : function(component, event, helper) {   
        $A.util.removeClass(
            component.find('spinnermore'), 
            "slds-hide"
        );        
        var saCreation = component.get('c.createServiceApp');
        $A.enqueueAction(saCreation);
    },
    
    backToSA : function(component, event, helper) {
        $A.util.addClass(component.find("moreThanFiveSAs"), "slds-hide");
        $A.util.removeClass(component.find("createSAs"), "slds-hide");
        $A.util.addClass(component.find("createSAs"), "slds-show");
    }
})