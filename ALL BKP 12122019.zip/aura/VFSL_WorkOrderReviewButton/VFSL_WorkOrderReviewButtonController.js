({
	doInit : function(component, event, helper) {
        //Get Work Order defaults
        var WorkOrderInfo = component.get("c.getWorkOrderReview");

        WorkOrderInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response){
            var woCheck = response.getReturnValue();
            component.set("v.WorkOrder",response.getReturnValue()); 
            if(woCheck.Status != 'Submitted' || (woCheck.Interface_Status__c != 'Do Not Process' && woCheck.SAP_Status__c != 'Success') ||
               	(woCheck.Interface_Status__c != 'Do Not Process' && woCheck.Interface_Status__c != 'Processed')){
            		component.set("v.Qualify",false);
        			}
            if((woCheck.Case_ECF_Count__c == 0 || woCheck.Case_ECF_Count__c == null) && woCheck.ECF_Required__c == 'Yes from Work Order'){
            	component.set("v.Qualify",false);
        	}
            if((woCheck.Remaining_Parts_Count__c > 0 && woCheck.RecordType__c == 'Field_Service') || (woCheck.Remaining_Parts_Count__c > 0 && woCheck.Close__c == true)){
                component.set("v.Qualify",false);
            }
        });
        
        $A.enqueueAction(WorkOrderInfo);
        
	}, 
    
    YesClick : function(component, event, helper) {
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var save = component.get("c.saveReviewWO");
        save.setParams({
            "WorkOrder": component.get("v.WorkOrder")
        });
        $A.enqueueAction(save);
        
        save.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                /*var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
				dismissActionPanel.fire(); 
        
                var backtoRecord = $A.get("e.force:navigateToSObject");
                backtoRecord.setParams({
                    "recordId": component.get("v.recordId"),
                    "slideDevName": "detail"
                });
                backtoRecord.fire();*/
                var refreshPage = $A.get("e.force:refreshView");
        		refreshPage.fire();
                component.find("overlayLib").notifyClose();
            }else{
                $A.util.addClass(
      			component.find('spinner'), 
      			"slds-hide"
				);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "message":  "There was problem reviewing Work Order.  Please log a ticket",
                    "type": "ERROR"
                });
                toastEvent.fire();
            }
        })
        }, 
    
    //navigate to tab
    /*NoClick : function(component, event, helper) {
		var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
		dismissActionPanel.fire(); 
        
        var backtoRecord = $A.get("e.force:navigateToSObject");
        backtoRecord.setParams({
            "recordId": component.get("v.recordId"),
            "slideDevName": "detail"
        });
        backtoRecord.fire();
	}*/
    
    //handle in overlay library
    NoClick : function(component, event, helper) {
        component.find("overlayLib").notifyClose();
	}
})