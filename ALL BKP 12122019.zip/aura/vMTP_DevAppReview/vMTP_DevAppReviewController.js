({
	getVMTAppData : function(component, event, helper) {
       // helper.getURLParameters (component, event, helper);
        helper.getVMTAppDetails (component, event, helper);
        helper.getVMTAppImages (component, event, helper);
        //helper.getVMTAppImagesAndAttachments (component, event, helper);
        component.set("v.temp", '&versionId=');
        
	}
})