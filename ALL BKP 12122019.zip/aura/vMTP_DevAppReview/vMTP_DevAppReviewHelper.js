({
	getVMTAppDetails : function(component, event, helper) {
		var action = component.get("c.getAppDetails");
         var applicationId = component.get("v.appId");
         action.setParams ({
            appId: applicationId
        });
        action.setCallback(this, function(response){
            component.set("v.appDetails", response.getReturnValue()[0]);
            console.log(response.getReturnValue());
            var state = response.getState();
        if(state == "SUCCESS"){
            var dataList = response.getReturnValue();   
        }
        else{
            alert("Error in get Data getVMTAppDetails");
            }
       });
        $A.enqueueAction(action);
	},
    
    getVMTAppImages : function(component, event, helper) {
        var action = component.get("c.getAttachedFiles");
        var applicationId = component.get("v.appId");
        action.setParams ({
            appId: applicationId
        });
        action.setCallback(this, function(response){
            console.log('--'+response.getReturnValue());
            var state = response.getState();
            if(state == "SUCCESS"){
                var dataList = response.getReturnValue();
                var attachemnts = [];
                for(var dataIndex in dataList) {
                    if(dataList[dataIndex].Title.includes('Logo') || dataList[dataIndex].Title.includes('logo')) {
                        component.set("v.appImgDetails", dataList[dataIndex].Id );
                    } else if(dataList[dataIndex].Title.includes('Screenshot') || dataList[dataIndex].Title.includes('Banner')){
                        attachemnts.push(dataList[dataIndex]);
                    }
                }
                component.set("v.appImgnAttachDetails", attachemnts);
            }
            else{
                alert("Error in get Data getVMTAppImages");
            }
        });
        $A.enqueueAction(action);
    },
    
    getVMTAppImagesAndAttachments : function(component, event, helper){
		var action = component.get("c.getAppImagesAndAttachments");
        var applicationId = component.get("v.appId");
         action.setParams ({
            appId: applicationId
        });
        action.setCallback(this, function(response){
            component.set("v.appImgnAttachDetails", response.getReturnValue());
            //component.set("v.appImgnAttachDetails", "/servlet/servlet.FileDownload?file=" + 'aD35C0000004F3X');
            console.log(response.getReturnValue());
            var state = response.getState();
        if(state == "SUCCESS"){
            var dataList = response.getReturnValue(); 
        }
        else{
             alert("Error in get Data getVMTAppImagesAndAttachments");
            }
       });
        $A.enqueueAction(action);
	},
     getURLParameters : function (component, event, helper) {
        console.log('Inside');
        // the function that reads the url parameters
        var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;
            
            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');
                
                if (sParameterName[0] === sParam) {
                    return sParameterName[1] === undefined ? true : sParameterName[1];
                }
            }
        };
        
        //set the src param value to my src attribute
        if(getUrlParameter('appId')) {
            component.set("v.appId", getUrlParameter('appId'));
        }
    },
})