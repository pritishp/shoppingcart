({
	doInit : function(component, event, helper) {
       console.log('----'+component.get("v.ifPermitted"));
       helper.getBAChildProducts(component);  
	},
     renderPage: function(component, event, helper) {
        helper.renderPage(component);
    },
     addtoCartApplicator: function(component, event, helper) {
        
        helper.addtoCartApplicator(component, event, helper);
        
    }
})