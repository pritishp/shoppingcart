({
    getBAChildProducts : function(component) {
        var catalogId = component.get("v.catlogId");
        var applicatorType=component.get("v.applicatorType");
        var accountId='';
        var afterLoader = '';
        if(component.get('v.selectedAccountRecord')){
            accountId = component.get('v.selectedAccountRecord').Id;
        }
        console.log(accountId+'----'+accountId);
        
        if( typeof component.get('v.selectedAfterLoader') !== 'undefined' ){
            console.log('selectedAfterLoader'+component.get('v.selectedAfterLoader'));
            afterLoader = component.get('v.selectedAfterLoader');
        }
        
        var action = component.get("c.getBAProductDetail"); 
        action.setParams ({
            catalogId: catalogId,
            applicatorType:applicatorType,
            accId:accountId,
            afterLoaderVal: afterLoader
        });
        action.setCallback(this, function(a) {
            var state = a.getState();            
            if(state=="SUCCESS"){
                var result = a.getReturnValue();
                console.log('rs ---->' + JSON.stringify(result)); 
                component.set("v.applicatorList", result);
                component.set("v.maxPage", Math.floor((result.length+9)/10));
                console.log('max ---->' +component.get("v.maxPage") ); 
                this.renderPage(component);
            } 
        });
        $A.enqueueAction(action);
    },
    
    renderPage: function(component) {
        var records = component.get("v.applicatorList"),
            pageNumber = component.get("v.pageNumber"),
            pageRecords = records.slice((pageNumber-1)*10, pageNumber*10);
        //component.set("v.applicatorCurrentList", pageRecords);
        component.set("v.applicatorCurrentList", records); 
        this.srollToProduct(component);
    },
    srollToProduct: function(component) {
        var productNumber = component.get('v.productNumber');        
        setTimeout(function(){ 
            var elementRow = document.getElementById(productNumber); 
            elementRow.style.background = '#ffa';
            var elementRowTop = elementRow.offsetTop;
            document.getElementById('productTable').scrollTop = elementRowTop;    
        }, 1000);
    },
    addtoCartApplicator: function(component, event, helper) {
        //var selectedItem = event.currentTarget;
        //var maximumQuantity = selectedItem.dataset.record;
        //console.log('maximumQuantity---->>'+maximumQuantity);
        if(component.get('v.selectedAccountRecord')){
            var accountId = component.get('v.selectedAccountRecord').Id;
        }
        if(typeof accountId === 'undefined'){
            helper.handleShowToast(component, event, helper, 'Account not selected. Please select Account from filter panel!','Info', 'Info');
            return false;
        }
        
        var wrappers=new Array();
        var checkvalue = component.find("qty");
        var totalQty = 0;
        if(checkvalue.length) {
            for (var i = 0; i < checkvalue.length; i++) {
                if (checkvalue[i].get("v.value") ==0) {
                }
                else{
                    var wrapper = {'productId' : checkvalue[i].get("v.id"),
                                   'qty' : checkvalue[i].get("v.value")
                                  };
                    wrappers.push(wrapper);
                }
                totalQty= totalQty + parseInt(checkvalue[i].get("v.value"));
            }
        } else {
            totalQty= totalQty + checkvalue.get("v.value");
            var wrapper = {'productId' : checkvalue.get("v.id"),
                           'qty' : checkvalue.get("v.value")
                          };
            wrappers.push(wrapper);
        }

        if(totalQty == 0) {
            helper.handleShowToast(component, event, helper, 'Please add quantity of products','Error', 'Error');
        }
        if(wrappers.length==0){
            helper.handleShowToast(component, event, helper, 'Please add quantity of products','Error', 'Error');
            return false; 
        }
        console.log('wrappers--'+ JSON.stringify(wrappers));
        var action = component.get("c.addApplicatorCartItem"); 
        action.setParams ({
            productQty:JSON.stringify(wrappers),
            accountId: accountId,
        });
        action.setCallback(this, function(a) {
            var state = a.getState();            
            if(state=="SUCCESS"){
                var msg = a.getReturnValue();
                var variant;
                if(msg.includes('Success')) {
                    variant = 'Success';
                    //var parentComp = component.find("vMIP_ProductDetails");
                    //var cartCount = parentComp.get("cartCount");
                    //debugger;
                } else if(msg.includes('Exception')){
                    variant = 'Error';   
                } else {
                    variant = 'Info';
                    //var parentComp = component.find("vMIP_ProductDetails");
                    //var cartCount = parentComp.get("cartCount");
                    //debugger;
                }
                helper.handleShowToast(component, event, helper, msg,variant,variant);
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire(); 
            } 
            else {
                helper.handleShowToast(component, event, helper, 'Exception Occurred !','Error', 'Error');
            }
        });
        if(totalQty != 0) 
            $A.enqueueAction(action);
    },
    handleShowToast : function(component, event, helper, msg, variant,title) {
        component.find('notifLib').showToast({
            "title": title,
            "message": msg,
            "variant" : variant
        });
    }
})