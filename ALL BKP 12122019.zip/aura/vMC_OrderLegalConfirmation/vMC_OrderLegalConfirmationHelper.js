({
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isModalOpen", false);
        component.set("v.agreementValue", false);
    },
    
    showToast : function(component, event, helper, errorMsg, title, type) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": title,
            "message": errorMsg,
            "type": type
        });
        toastEvent.fire();
    },
	
    fetchTermsConds : function (component, event, helper) {
        console.log('fetchTerms and conditions');
        var action = component.get("c.fetchTermsConds");
        
         action.setCallback(this, function(response) {
            var state = response.getState();
            if (response.getState() === "SUCCESS") {
                 var resp = response.getReturnValue();
                console.log('Terms -> ' +resp);
               component.set("v.TermsConds", resp);
               // component.set("v.TermsCondsName", resp.vMCTermsConds.MasterLabel);
            }
        });
        $A.enqueueAction(action);
    },
    
    redirectToOrderConfirmation : function (component, event, helper, resp) {
        if(resp.thirdParty) {
            var appOrder = resp.thirdParty;
        }
        if(resp.brachy) {
            var brachyOrder = resp.brachy;
        }
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": '/varianMarketPlace/s/vmc-order-confirmation?appOrderId='+  appOrder + '&baOrderId='+brachyOrder,
        });
        urlEvent.fire();
    },
    
    deleteCartItems : function (component, event, helper,resp) {
        var action = component.get("c.deleteCart");
        action.setParams( {
            paymentType : component.get("v.selectedPaymentType"),
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (response.getState() === "SUCCESS") {
                
            }
        });
        $A.enqueueAction(action);
    },
    
    validateTotal : function (component, event, helper) {
       var totalPrice = component.get("v.appTotalPrice") + component.get("v.brachyTotalPrice") +
                			component.get("v.brachyTax") + component.get("v.thirdPartyTax") + component.get("v.brachyShippingPrice"); 
        
        console.log('totalPrice ->' + totalPrice);
        if(component.get("v.selectedPaymentType") !='PO' && totalPrice > 999999)
            this.showToast (component, event, helper, 'Cart Amount Exceeded the Limit, Please choose PO method to Order !', 'Error', 'Error');
        else 
            this.createOrder (component, event, helper);
    },
    
    createOrder: function(component, event, helper){
        component.set("v.processing", true);
        var error = component.find('errorMsg');
        var isLegalValue = component.get("v.agreementValue");
        //alert('prodWrapper--',JSON.stringify(component.get("v.prodWrapper")));
        if(isLegalValue=='True') {
            component.set("v.paymentScreen", true);
            $A.util.addClass(error, 'slds-hide');
            var action = component.get("c.createNewOrder");
            var thirdPartyApps = component.get("v.appWrapper");
            var brachyProds = component.get("v.prodWrapper");
            var totalPrice = component.get("v.appTotalPrice") + component.get("v.brachyTotalPrice") +
                			component.get("v.brachyTax") + component.get("v.thirdPartyTax") + component.get("v.brachyShippingPrice");
            var termsandCondtions = component.get("v.TermsConds.MasterLabel");
            console.log('termsandCondtions label-> ' +termsandCondtions);
            
            var wrapper = { 
                thirdParty : [] ,
                brachy : []
            };
            
            /*PO is applicable only for Brachy Products*/
            if(component.get("v.selectedPaymentType") !='PO') {
                for(var i=0; i< thirdPartyApps.length; i++) {
                    var tpJsonData = {};
                    tpJsonData['appId'] = thirdPartyApps[i].resp.vMTPApp.Id;
                    tpJsonData['unitPrice'] = thirdPartyApps[i].resp.vMTPApp.Price__c;
                    tpJsonData['qty'] = 1;
                    tpJsonData['rId'] = 'Third Party App';
                    tpJsonData['appSubPrice'] = thirdPartyApps[i].resp.appSubPrice;
                    tpJsonData['appSubTerm'] = thirdPartyApps[i].resp.appSubTerm;
                    wrapper.thirdParty.push(tpJsonData);
                }
            }
            console.log('thirdParty ' + JSON.stringify(wrapper.thirdParty));
            for(var i=0; i< brachyProds.length; i++) {
                var brachyJsonData = {};
                brachyJsonData['prodId'] = brachyProds[i].resp.itemline.Brachy_Product__c;
                brachyJsonData['unitPrice'] = brachyProds[i].resp.itemline.Brachy_Product__r.NA_Target_Price__c;
                brachyJsonData['qty'] = brachyProds[i].resp.quantity;
                brachyJsonData['prodCode'] = brachyProds[i].resp.itemline.Brachy_Product__r.ProductCode;
                brachyJsonData['rId'] = 'Brachy Product';
                brachyJsonData['discountedPrice'] =  brachyProds[i].resp.prodDiscount;
                wrapper.brachy.push(brachyJsonData);
            }
            component.get("v.fieldValues.destination.label");
            console.log('fieldValues---'+JSON.stringify(component.get("v.fieldValues")));
            
            var shipToAddress = ''; var billToAddress = '';
            if( component.get("v.fieldValues.destination") ){
                shipToAddress += component.get("v.fieldValues.destination.Partner_Street__c");
                if( component.get("v.fieldValues.destination.Partner_Street_line_2__c") !== '' && (typeof (component.get("v.fieldValues.destination.Partner_Street_line_2__c")) !== 'undefined')){
                    shipToAddress += ', ' + component.get("v.fieldValues.destination.Partner_Street_line_2__c");
                }
                shipToAddress += ', ' + component.get("v.fieldValues.destination.Partner_City__c");
                shipToAddress += ', ' + component.get("v.fieldValues.destination.Partner_State__c");
                shipToAddress += ', ' + component.get("v.fieldValues.destination.Partner_Zipcode_postal_code__c");
                shipToAddress += ', ' + component.get("v.fieldValues.destination.Partner_Country__c");
            }
            console.log('shipToAddress'+shipToAddress);
            if( component.get("v.fieldValues.billingAddress") ){
                billToAddress += component.get("v.fieldValues.billingAddress.Partner_Street__c");
                if( component.get("v.fieldValues.billingAddress.Partner_Street_line_2__c") !== '' && (typeof (component.get("v.fieldValues.destination.Partner_Street_line_2__c")) !== 'undefined')){
                    billToAddress += ', ' + component.get("v.fieldValues.billingAddress.Partner_Street_line_2__c");
                }
                billToAddress += ', ' + component.get("v.fieldValues.billingAddress.Partner_City__c");
                billToAddress += ', ' + component.get("v.fieldValues.billingAddress.Partner_State__c");
                billToAddress += ', ' + component.get("v.fieldValues.billingAddress.Partner_Zipcode_postal_code__c");
                billToAddress += ', ' + component.get("v.fieldValues.billingAddress.Partner_Country__c");
            }
            console.log('billingAddress'+billToAddress);
            var shipTo = component.get("v.fieldValues.destination.Id");
            var billTo = component.get("v.fieldValues.billingAddress.Id");
            var shippingInfo = component.get("v.fieldValues");
            delete shippingInfo.billingAddress;
            delete shippingInfo.destination;
			var shippingInfoObject = [];
            shippingInfoObject.push(shippingInfo);
            
            action.setParams({
                thirdPartyJSON: JSON.stringify(wrapper.thirdParty),
                brachyJSON : JSON.stringify(wrapper.brachy),
                tPtax : component.get("v.thirdPartyTax"),
                brachytax : component.get("v.brachyTax"),
                brachyShippingCost : component.get("v.brachyShippingPrice"),
                paymentMethod : component.get("v.selectedPaymentType"),
                isLegal:isLegalValue,
                accountId:component.get("v.userAccount"),
                shipToId : shipTo,
                billToId : billTo,
                shipToAddress: shipToAddress,
                billToAddress: billToAddress,
                userFieldValues : JSON.stringify(shippingInfoObject),
                isInternalUserFlag : component.get("v.isInternalUser"),
                termsandCondtions : termsandCondtions,
                totalPrice : totalPrice
            })
            action.setCallback(this, function(response) {
                var state = response.getState();
                console.log('Resp'+state);
                if (response.getState() === "SUCCESS") {
                    /*Third party order */
                    var resp = response.getReturnValue();
                    if(component.get("v.selectedPaymentType")=='PO' || totalPrice == 0) {
                        var urlEvent = $A.get("e.force:navigateToURL");
                        if(totalPrice == 0) {
                            urlEvent.setParams({
                                "url": '/varianMarketPlace/s/vmc-order-confirmation?appOrderId='+resp+'&baOrderId=NA',
                            });
                        }
                        if(component.get("v.selectedPaymentType")=='PO') {
                            urlEvent.setParams({
                                "url": '/varianMarketPlace/s/vmc-order-confirmation?appOrderId=NA&baOrderId='+resp,
                            });
                        }
                        urlEvent.fire();  
                    }
                    else {
                        /*Subscription order and Brachy order */
                        var compEvent =component.getEvent("compEvent");
                        compEvent.fire();
                    }
                    helper.closeModel (component, event, helper);
                }
                else if(response.getState() === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        helper.showToast (component, event, helper, 'Failed to Create Order, Please try Again.', 'Error', 'Error');
                    }
                }
                component.set("v.processing", false);
            });
            $A.enqueueAction(action);
        }
        else if(isLegalValue=='False'){
            $A.util.addClass(error, 'slds-hide');
            component.set("v.processing", false);
            helper.closeModel (component, event, helper);
        } else {
            component.set("v.processing", false);
            $A.util.removeClass(error, 'slds-hide');
        }
    },
})