({
    doInit: function(component, event, helper) {
        console.log('doInit');
         helper.fetchTermsConds(component, event, helper);
        var fieldValues = component.get("v.fieldValues");
        console.log(fieldValues);
       
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        helper.closeModel (component, event, helper);
    },
    createOrder: function(component, event, helper){
        helper.validateTotal (component, event, helper);
    },
    
    
})