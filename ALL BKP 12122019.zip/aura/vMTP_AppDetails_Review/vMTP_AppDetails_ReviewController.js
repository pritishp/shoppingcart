({
	getComments : function(component, event, helper) {
        component.set("v.loaded", true);
        var pageNumber = component.get("v.PageNumber");  
		helper.getComments(component, pageNumber);
        helper.getCommentedUserInfo (component, event, helper);
        helper.getIfUserVerified (component, event, helper);
	},
    
    handleNext: function(component, event, helper) {
        var pageNumber = component.get("v.PageNumber");  
        pageNumber++;
        helper.getComments(component, pageNumber);
    },
     
    handlePrev: function(component, event, helper) {
        var pageNumber = component.get("v.PageNumber");  
        pageNumber--;
        helper.getComments(component, pageNumber);
    },
    
    openReviewModal : function (component, event, helper) {
        var reviewModal = component.find('reviewModal');
        $A.util.removeClass(reviewModal, 'slds-hide');
    },
    
    closeModal : function (component, event, helper) {
        var reviewModal = component.find('reviewModal');
        $A.util.addClass(reviewModal, 'slds-hide');
    },
    
    closeSubmitModal : function (component, event, helper) {
        var pageNumber = component.get("v.PageNumber");  
        var reviewModal = component.find('reviewModal');
        $A.util.addClass(reviewModal, 'slds-hide');
        component.find('selectFilter').set('v.value', 'All');
        component.set("v.filterRating", 'All');
        debugger;
        $A.get('e.force:refreshView').fire();
        helper.getComments(component, pageNumber);
    },
    
    onRatingChange : function(component) {
		component.set("v.filterRating", component.find('selectFilter').get('v.value'));
	},
})