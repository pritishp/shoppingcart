({
	getComments : function(component, pageNumber) {
		var action = component.get("c.getUserCommentsOnApp");
        action.setParams({
            selectedRating : component.get("v.filterRating"),
            pageNumber: pageNumber,
            appId : component.get("v.appId")
        });
        
		action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resultData =  response.getReturnValue();
                component.set("v.listOfComments", resultData.comments);
                component.set("v.PageNumber", resultData.pageNumber);
                component.set("v.TotalRecords", resultData.totalRecords);
                component.set("v.RecordStart", resultData.recordStart);
                component.set("v.RecordEnd", resultData.recordEnd);
                component.set("v.TotalPages", Math.ceil(resultData.totalRecords / 5));
            }
            component.set("v.loaded", false);
        });
        
        $A.enqueueAction(action);
	},
    
    getCommentedUserInfo : function(component, event, helper) {
		var action = component.get("c.getIsUserCommented");
        
        action.setParams({
            appId : component.get("v.appId")
        });
        
		action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.IsUserCommented", response.getReturnValue());
            }
        });
        
        $A.enqueueAction(action);
	},
    
    getIfUserVerified : function(component, event, helper) {
		var action = component.get("c.getIsVerifiedUser");
        action.setParams({
            appId : component.get("v.appId")
        });
        
		action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.IsVerifiedUser", response.getReturnValue());
            }
        });
        
        $A.enqueueAction(action);
	},
  
})