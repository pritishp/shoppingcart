({
	getOrders : function(component) {
        var tpOrder;var baOrder;
        if(component.get("v.appOrder")){
            tpOrder=component.get("v.appOrder");
        }
        if(component.get("v.baOrder")){
            baOrder=component.get("v.baOrder");
        }
        var action = component.get("c.getOrderDetails"); 
         action.setParams ({
            appOrderId:  tpOrder,
             baOrderId: baOrder
        });
         action.setCallback(this, function(response) {
          var state = response.getState();
         if (state === "SUCCESS") {
             var result = response.getReturnValue();
             console.log('result ---->' + JSON.stringify(result));
             component.set("v.OrderList",result);
             for(var i=0; i< result.length;i++) {
                 component.set("v.paymentMethod", result[i].vMC_Payment_Method__c);
             }
             console.log('result ---->' + JSON.stringify(component.get("v.OrderList")));
            this.setBreadCrumbs(component);
            //  component.set("v.loaded", false);
         }  
           //  component.set("v.loaded", false);
      });
      $A.enqueueAction(action);
	},
    
    getSubscriptionOrder : function (component) {
        var action = component.get("c.getSubsOrderDetails"); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                console.log('result ---->' + JSON.stringify(result));
                var orderId =[];
                component.set("v.OrderList",result);
                for(var i=0; i< result.length;i++) {
                    component.set("v.paymentMethod", result[i].vMC_Payment_Method__c);
                    orderId.add(result[i].Id);
                }
                console.log('result ---->' + JSON.stringify(component.get("v.OrderList")));
                this.setBreadCrumbs(component);
               // component.set("v.loaded", false);
            }  
           // component.set("v.loaded", false);
        });
        $A.enqueueAction(action);
    },
    
    getURLParameters : function (component, helper) {
        console.log('Inside');
        // the function that reads the url parameters
        var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;
            
            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');
                
                if (sParameterName[0] === sParam) {
                    return sParameterName[1] === undefined ? true : sParameterName[1];
                }
            }
        };
        
        component.set("v.appOrder", getUrlParameter('appOrderId'));
        component.set("v.baOrder", getUrlParameter('baOrderId'));
        var subsOrder = getUrlParameter('subsOrderId');
        if(subsOrder) {
            helper.getSubscriptionOrder(component);
        }
        else {
            helper.getOrders(component);
            helper.getERPOrders(component);
        }
        
    },
    setBreadCrumbs : function (component) {
        var breadcrumbCollection = [
            {label: 'Home', name: 'brachy products' },
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },
    getERPOrders : function(component) {
		var baOrder = '';
        var tpOrder = '';
        if(component.get("v.baOrder")){
            baOrder=component.get("v.baOrder");
        }
        if(component.get("v.appOrder")){
            tpOrder = component.get("v.appOrder");
        }
        console.log('baOrder -> ' +baOrder);    
        if(baOrder != '' || tpOrder != ''){
            var action = component.get("c.createERPOrder"); 
             action.setParams ({
                baOrderId: baOrder,
            	thirdPartyOrderId : tpOrder
            });
             action.setCallback(this, function(response) {
              var state = response.getState();
             if (state === "SUCCESS") {
                 var result = response.getReturnValue();
                 console.log('result ---->' + JSON.stringify(result));
             }  
          });
          $A.enqueueAction(action);
            }
	},
})