({
	doInit : function(component, event, helper) {
       // component.set("v.loaded", true);
        helper.getURLParameters(component, helper);
	}
    
})