({ 
    loadJquery : function(component, event, helper) {
        jQuery(document).ready(function() {
        });
    },
    doInit: function(component, event, helper) {
        helper.getListEnvironmentHelper(component, event);
    },
    removeRow : function(component, event, helper){
        if (confirm("Are you sure to delete current environment ?")) {
            component.set("v.isDeleteSandbox",true);
            helper.getremoveEnvSelectedHelper(component, event);
            //component.getEvent("DeleteRowEvt").fire();
        }
    },
    CreateEnv : function(component, event, helper){
        component.set("v.isEnvironment",true); 
        component.set("v.isCommandCenter",false); 
    },
    
    hideAllEnv: function(component, event, helper) {
        $(".hide-all").click(function (e) {
            $('.hide-all').hide(); $('.view-all-env').show();
        });
    },
    
    toggles : function(component, event, helper) { 
        alert('error in data');
        var changeElement = component.find("view-all");
        $A.util.removeClass(changeElement, 'slds-hide');
    },
    powerOffEnvPopUp : function(component, event, helper) {
        if (confirm("Are you sure to turn off current environment ?")) {
            component.set("v.isPowerOff",true);
            helper.powerOffEnvHelper(component, event);
        }
    },
    powerOffAllEnv : function(component, event, helper) {
        if (confirm("Are you sure to turn off all environment ?")) {
            component.set("v.isPowerOff",false);
            helper.powerOffEnvAllUserHelper(component, event);
            var toggleText = component.find("textType1");
            $A.util.toggleClass(toggleText, "slds-show");
        }
    },
    
    doSubmitPowerOff : function(component, event, helper) { 
        
        // component.set("v.isPowerOff",true);     
        helper.powerOffEnvHelper(component, event);
    },
    
    doCancel: function(component, event, helper) {
        component.set("v.isPowerOff", false);      
    },
    
    doConnect : function(component, event, helper){
        //alert("connect to vm"); commented by ujjwal
    },
    turnOffEnv: function(component, event, helper){
        helper.powerOffEnvHelper(component, event);
    },
    dodeleted : function(component, event, helper) {
        component.set("v.isDeleteSandbox", false);      
    },
    inlineEditName : function(component,event,helper){   
        // show the name edit field popup 
        var selectedItem = event.currentTarget;
        
        var currentVMId = selectedItem.dataset.value;
        console.log("currentVMId",currentVMId);
        
        component.set("v.currentVMId",currentVMId);
        //component.set("v.vmEditMode", true); 
        
        var index = event.target.value;
        var hideClassName = "hideEdit-"+index;
        var showClassName = "showEdit-"+index;
        var hideClassName1 = "hideEditb-"+index;
        var showClassName1 = "showEditb-"+index;
        var hideClassElem = component.find(hideClassName);
        var showClassElem = component.find(showClassName);
        var hideClassElem1 = component.find(hideClassName1);
        var showClassElem1 = component.find(showClassName1);
        $A.util.addClass(hideClassElem, "slds-hide");
        $A.util.removeClass(showClassElem, "slds-hide");
        $A.util.addClass(hideClassElem1, "slds-hide");
        $A.util.removeClass(showClassElem1, "slds-hide");
        
        console.log("edit clicked");
        // after the 100 millisecond set focus to input field   
        setTimeout(function(){ 
            component.find("inputId").focus();
        }, 100);
    },    
    
    closeNameBox : function (component, event, helper) {
        // on focus out, close the input section by setting the 'nameEditMode' att. as false   
        component.set("v.vmEditMode", false); 
        // check if change/update Name field is blank, then add error class to column -
        // by setting the 'showErrorClass' att. as True , else remove error class by setting it False   
        if(event.getSource().get("v.value").trim() == ''){
            component.set("v.showErrorClass",true);
        }else{
            component.set("v.showErrorClass",false);
        }
        
        var index = event.target.value;
        var hideClassName = "hideEdit-"+index;
        var showClassName = "showEdit-"+index;
        var hideClassName1 = "hideEditb-"+index;
        var showClassName1 = "showEditb-"+index;
        var hideClassElem = component.find(hideClassName);
        var showClassElem = component.find(showClassName);
        var hideClassElem1 = component.find(hideClassName1);
        var showClassElem1 = component.find(showClassName1);
        $A.util.removeClass(hideClassElem, "slds-hide");
        $A.util.addClass(showClassElem, "slds-hide");
        $A.util.removeClass(hideClassElem1, "slds-hide");
        $A.util.addClass(showClassElem1, "slds-hide");
    },     
    onNameChange : function(component,event,helper){ 
        // if edit field value changed and field not equal to blank,
        // then show save and cancel button by set attribute to true
        var currentId=component.get("v.currentVMId");
        console.log("onname change",currentId);
        if(event.getSource().get("v.value").trim() != ''){ 
            console.log("onname change",event.getSource().get("v.value").trim());
            var updatedVMName=event.getSource().get("v.value").trim();
            var action = component.get("c.UpdateVMName"); 
            action.setParams({ 
                "updatedVMName": updatedVMName,
                "currentId":currentId
            }); 
            action.setCallback(this, function(response) {
                var state = response.getState();
                var rtnValue = response.getReturnValue();
                
                $A.get('e.force:refreshView').fire();
                if(state === "SUCCESS") {
                    component.set("v.VICOrderInstance",rtnValue); 
                } else {
                    alert('Something went wrong !');
                }
            });
            $A.enqueueAction(action); 
        }
    },
})