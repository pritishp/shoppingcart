({
    getListEnvironmentHelper: function(component, event) {
        //var arrVmStatus[];
		var cmpTarget = component.find('loadingIcon');
        $A.util.removeClass(cmpTarget, 'hideEl');

        var action = component.get("c.getEnnviroList"); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            var rtnValue = response.getReturnValue();
            console.log("return list env",rtnValue);
			$A.util.addClass(cmpTarget, 'hideEl');
            if(state === "SUCCESS") {
                component.set("v.VICOrderInstance", rtnValue);
            }
        });
        $A.enqueueAction(action);  
    },
    getCountOfEnvtHelper: function(component, event) {
        var action1 = component.get("c.getLimitEnvList"); 
        action1.setCallback(this, function(response) {
            var state = response.getState();
            var rtnValue = response.getReturnValue();
            if(state === "SUCCESS") {
                console.log("trial env",rtnValue);
                component.set("v.EnvSize",rtnValue.length);    
            }
        });
        $A.enqueueAction(action1);  
    },
    //below code is for delete dynamic box
    getremoveEnvSelectedHelper: function(component, event) {
        var selectedItem = event.currentTarget;
        var deleteid = selectedItem.dataset.record;
        console.log("delected",deleteid);
        var action = component.get("c.removeEnnviroVICOrder"); 
        action.setParams({ 
            "VICOrderId": deleteid
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            var rtnValue = response.getReturnValue();
            
            $A.get('e.force:refreshView').fire();
            if(state === "SUCCESS") {
                component.set("v.VICOrderInstance",rtnValue); 
            } 
        });
        $A.enqueueAction(action); 
    },
    //above code is for delete dynamic box
    getsowResultHelper: function(component, event) {
        var showless = component.get("c.getLimitEnvList");
        showless.setCallback(this, function(response) {
            var state = response.getState();
            var returnValue = response.getReturnValue();
            if(state === "SUCCESS") {
                component.set("v.EnvSize",returnValue.length);
                component.set("v.VICOrderInstance",returnValue);
            }
        });
        $A.enqueueAction(showless);  
    },
    powerOffEnvHelper : function(component, event) {
        var selectedItem = event.currentTarget;
        var powerId = selectedItem.dataset.record;
        console.log('data Name = '+ powerId);
        
        //var powerId= event.currentTarget.getAttribute("data-record");
        //var powerId=event.getSource().get("v.value");
        console.log("powerId",powerId);
        var action = component.get("c.PowerOffEnvironVICOrder"); 
        action.setParams({ 
            "VICOrderId": powerId
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            var rtnValue = response.getReturnValue();
            $A.get('e.force:refreshView').fire();
            if(state === "SUCCESS") {
                component.set("v.VICOrderInstance",rtnValue);
            }
        });
        $A.enqueueAction(action);
    },
    createObjectData: function(component, event) {
        // get the orderList from component and add(push) New Object to List  
        var RowItemList = component.get("v.orderList");
        RowItemList.push({
            'sobjectType': 'VIC_Order__c',
            'Name': '',
            'VM_Power_Off__c': '',
            'VM_Connect_Status__c': '',
            'Contact__c':''
        });
        // set the updated list to attribute (orderList) again    
        component.set("v.orderList", RowItemList);
    },
    // helper function for check if first Name is not null/blank on save  
    validateRequired: function(component, event) {
        var isValid = true;
        var allOrderRows = component.get("v.orderList");
        for (var indexVar = 0; indexVar < allOrderRows.length; indexVar++) {
            if (allOrderRows[indexVar].Contact__c == '') {
                isValid = false;
                //alert('Must Have a Contact Attached ' + (indexVar + 1)); commented by ujjwal
            }
        }
        return isValid;
    },
    powerOffEnvAllUserHelper : function(component, event) {
        
        var action = component.get("c.PowerOffAllUserEnvironVICOrder"); 
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            var rtnValue = response.getReturnValue();
            console.log("state",state);
            if(state === "SUCCESS") {
                // alert("Environment has PowerOff All Environment Sucessfully");
                $A.get('e.force:refreshView').fire();
            }else{
                console.log("state",state);  
            }
            
        });
        $A.enqueueAction(action);
    }
})