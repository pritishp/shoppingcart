({
    setPaymentOptions: function (component) {
        var paymentOptions;
        if(component.get("v.appTotalQty")!=0 && component.get("v.brachyTotalQty")==0) {
            paymentOptions = [
            {'label': 'Credit Card', 'value': 'Credit Card'},
            ];
        }
        else {
            paymentOptions = [
            {'label': 'Credit Card', 'value': 'Credit Card'},
            {'label': 'PO', 'value': 'PO'}
            ];
        }
        component.set('v.paymentOptions', paymentOptions);
        
    },
    
    getCartItems : function(component, event, helper) {
        component.set("v.processing", true);
        var action = component.get("c.getCartItemLineList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                var appTotalPrice=0; var brachyTotalPrice=0;
                var appTotalQty=0; var brachyTotalQty=0;
                
                if(resp && resp.length) {
                    var appList =[];
                    var prodList =[];
                    for(var i=0 ; i < resp.length; i++) {
                        if(resp[i].vMTPApp) {
                            appList.push({
                                resp: resp[i],
                                 subsPrice :resp[i].appSubPrice,
                                appSubTerm :resp[i].appSubTerm
                            });
                           appTotalPrice = appTotalPrice + resp[i].vMTPApp.Price__c + resp[i].appSubPrice;
                            appTotalQty = appTotalQty + resp[i].quantity;
                            if(resp[i].vMTPApp.subscription__c)
                            {
                                console.log('Subscription Item');
                                component.set("v.isSubscription", true);                                
                            }
                        }
                        if(resp[i].itemline) {
                                prodList.push({
                                    resp: resp[i],
                                    total : resp[i].prodDiscount * resp[i].quantity,
                                });
                                brachyTotalPrice = brachyTotalPrice + (resp[i].prodDiscount * resp[i].quantity);
                            
                            brachyTotalQty = brachyTotalQty + resp[i].quantity;
                        }
                        
                    }
                    component.set("v.appTotalPrice",  appTotalPrice);
                    component.set("v.brachyTotalPrice",   brachyTotalPrice);
                    component.set("v.appTotalQty",  appTotalQty);
                    component.set("v.brachyTotalQty",   brachyTotalQty);            
                    
                }
                //component.set("v.brachyTax", 0);
                console.log('prodList--'+prodList);
                component.set("v.appWrapper", appList);
                component.set("v.prodWrapper", prodList);
                if(component.get("v.selectedPaymentType")=='PO' && component.get("v.appTotalQty")!=0 && component.get("v.brachyTotalQty")==0) {
                    helper.navigateToLandingPage (component, event, helper);
                }else {
                    var inventoryEvent = $A.get("e.c:vMC_CheckInventory");
                    inventoryEvent.fire();
                }
            }
            this.setPaymentOptions(component);
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    removeProduct : function (component, event, helper, sfId, index, productType) {
        
        var action = component.get("c.deleteFromDB");
        var brachyWrapperCurrent = component.get("v.prodWrapper");
        var thirdPartyWrapperCurrent = component.get("v.appWrapper");
        action.setParams({ 
            itemId : sfId,
            itemType : productType
        });
        action.setCallback(this,function(response){
            if (response.getState() === "SUCCESS"){
                var resp =  response.getReturnValue();
                if(resp == true) {
                    helper.navigateToLandingPage (component, event, helper);
                }
                
                else {
                    helper.getCartItems(component, event, helper);
                    var appEvent = $A.get("e.c:vMTP_reloadHeader");
                    appEvent.fire();
                }
                
            }
        });
        $A.enqueueAction(action);
    },
    
   calculatePrice : function (component, event, helper, index, sfId) {
        var ifValidNo = true;
        var invalidNo = component.find('invalidNo');
        var productWrapperLength = component.get("v.prodWrapper").length;
        var subTotal = 0; var totalqty = 0;
        if(productWrapperLength > 1) {
            /*Multiple Product in Brachy Product List */
            var qty = component.find('qty')[index].get('v.value');
            if(qty > 0) {
                var discountedPrice = component.find('prodDiscount')[index].get("v.value");
                var totalPrice ;
                var totalPrice = qty * discountedPrice;
                
                component.find('total')[index].set("v.value", totalPrice);
                $A.util.addClass(invalidNo[index], 'slds-hide');
            } else {
                ifValidNo = false;
                //component.find('qty')[index].set("v.value","0");
                $A.util.removeClass(invalidNo[index], 'slds-hide');
            }
            
        } else {
            /*Single Product in Brachy Product List */
            var prodWrapper = component.get("v.prodWrapper")[0];
            var prodWrapperTemp = [];
            var qty = prodWrapper.resp.quantity;
            if(qty > 0) {
                var unitPrice = prodWrapper.resp.itemline.Brachy_Product__r.NA_Target_Price__c;
                var discountedPrice = prodWrapper.resp.prodDiscount;
                prodWrapper.total = qty * discountedPrice;
                prodWrapperTemp.push(prodWrapper);
                component.set("v.prodWrapper", prodWrapperTemp);
                $A.util.addClass(invalidNo, 'slds-hide');
            }
            else {
                ifValidNo = false;
                //component.find('qty').set("v.value","0");
                $A.util.removeClass(invalidNo, 'slds-hide');
            }
        }
        if(ifValidNo) {
           var brachyProducts = component.get("v.prodWrapper");
            if(brachyProducts.length) {
                for(var i=0 ; i< brachyProducts.length ; i++) {
                    subTotal = subTotal + brachyProducts[i].resp.quantity * brachyProducts[i].resp.prodDiscount;
                    totalqty = totalqty + parseInt(brachyProducts[i].resp.quantity);
                }
            } else {
                subTotal = brachyProducts.resp.quantity * brachyProducts.resp.prodDiscount;
                totalqty = parseInt(brachyProducts.resp.quantity);
            }
            
            component.set("v.brachyTotalPrice", subTotal);
            component.set("v.brachyTotalQty", totalqty);
            
            this.updateCartLineItemsQty(component, event, helper)
        }       
    },
    
    
     updateCartLineItemsQty : function (component, event, helper) {
         console.log('Update quantiy');
        var mapBrachyIdQty = new Object();
        var brachyWrapper = component.get("v.prodWrapper");
        for(var i=0 ; i< brachyWrapper.length; i++) {
            mapBrachyIdQty[brachyWrapper[i].resp.itemline.Brachy_Product__c] = brachyWrapper[i].resp.quantity; 
            if(brachyWrapper[i].error) {
                delete brachyWrapper[i]['error'];
            } 
        }
        var action = component.get("c.updateCartLineItem");
        action.setParams({ 
            mapBrachyIdWithQuantity : mapBrachyIdQty,
            selectedPaymentMethod : null
        });
        action.setCallback(this,function(response){
            if (response.getState() === "SUCCESS"){
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
            }
            //component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    navigateToLandingPage : function (component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({ "url": '/'});
        urlEvent.fire();
    },
     /*handlePaymentMethodEvent : function (component, event, helper) {
        var paymentEvent = component.getEvent("paymentMethodCheckEvent");
        paymentEvent.setParams({  "isPaymentMethodSelected" : true  });
        paymentEvent.fire();        
    },*/
    
})