({
	downloadAppSource : function(component, event, helper) {
		var docId = event.getSource().get("v.value");
        console.log(docId);
        window.open(window.location.origin+'/sfc/servlet.shepherd/version/download/'+docId,'_blank');
	}
})