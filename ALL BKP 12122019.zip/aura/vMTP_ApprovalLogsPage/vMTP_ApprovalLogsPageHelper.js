({
	fetchLogHistory : function(component, event) {
        
      /*  var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),               
                sURLVariables = sPageURL.split('&'),
                sParameterName,                
                i;  
          
            for (i = 0; i < sURLVariables.length; i++) {               
                sParameterName = sURLVariables[i].split('=');               
                if (sParameterName[0] === sParam) {                    
                    return sParameterName[1] === undefined ? true : sParameterName[1];                    
                } 
            }
            
        }; 
         component.set("v.appId", getUrlParameter('appId'));
             console.log("appId" +component.get("v.appId")); */
        // component.find("appRecordLoader").reloadRecord();
        //Calling Server Side controller for fetching the App Approval Logs Details
        var action = component.get("c.approvalLogs");
        action.setParams({
            appId: String(component.get("v.appId")),            
        });  
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
              //  console.log('response ' +JSON.stringify(response));
                component.set("v.approvalLogList", response);
            }
        });
        $A.enqueueAction(action);   
    }
})