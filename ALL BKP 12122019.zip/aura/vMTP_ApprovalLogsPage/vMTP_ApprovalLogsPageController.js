({
	doInit : function(component, event, helper) {
		helper.fetchLogHistory(component, event, helper);
       //var userId = $A.get("$SObjectType.CurrentUser.Id");
		        
         component.set("v.userId", $A.get("$SObjectType.CurrentUser.Id"));
             console.log("userId" +component.get("v.userId"));
         component.find("userRecordLoader").reloadRecord();
    }  ,
    
    openAppDetails: function(component, event, helper) {
    	var appId = component.get("v.appId");
       console.log('navigateToRecord ' +appId);
      window.open('/'+appId); 
        //window.open('/varianMarketPlace/s/detail/'+appId); 
    },
    
     openModal: function(component, event, helper) { 
           var appInfo = event.currentTarget.getAttribute("data-appInfo");
       //  var appInfo = event.currentTarget.getAttribute("alternativeText");
               component.set("v.appInfo", appInfo);
        component.set("v.isOpen", true);
    },
    
     closeModal: function(component, event, helper) { 
        component.set("v.isOpen", false);
    },
    
    
})