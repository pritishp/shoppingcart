({
    doInit : function (component, event, helper) {
        helper.showSpinner(component, event, helper);
        var recordId = component.get("v.recordId");
        var caseType = component.get("v.caseType");
        var createArticle = component.get("v.createArticle");
        component.find('cstypeid').set('v.value', caseType);
        setTimeout(function(){helper.hideSpinner(component, event, helper); }, 1000);
    },
    closeModel: function(component, event, helper) {
        component.set("v.showPopup", false);
        //$A.get('e.force:refreshView').fire();
    },
    saveData : function(component, event, helper) {
        component.set("v.showPopup", false);
        //$A.get('e.force:refreshView').fire();
    },
    
    onPicklistLoad : function(component, event, helper) {
        var value = event.getSource().get("v.value");                        
        component.set("v.refreshFlag",true);
    },
    
    onChangeCaseType : function(component, event, helper) {
        var value = event.getSource().get("v.value");
        var createArticle = component.get("v.createArticle");
        // alert(createArticle);
        var caseObject = component.get("v.caseObject");
        caseObject.Case_Type__c = value;
        component.set("v.caseObject",caseObject);
    },
    onChangeCL1 : function(component, event, helper) {
        var value = event.getSource().get("v.value");
        var caseObject = component.get("v.caseObject");
        caseObject.Classification_1__c = value;
        component.set("v.caseObject",caseObject);
    },
    onChangeCL2 : function(component, event, helper) {
        var value = event.getSource().get("v.value");
        var caseObject = component.get("v.caseObject");
        caseObject.Classification_2__c = value;
        component.set("v.caseObject",caseObject);
    },
    onChangeCL3 : function(component, event, helper) {
        var value = event.getSource().get("v.value");
        var caseObject = component.get("v.caseObject");
        caseObject.Classification_3__c = value;
        component.set("v.caseObject",caseObject);
    },
    onChangeCloseCaseReason : function(component, event, helper) {
        var value = event.getSource().get("v.value");
        var caseObject = component.get("v.caseObject");
        caseObject.Closed_Case_Reason__c = value;
        component.set("v.caseObject",caseObject);
    },
    onChangeCaseActivity : function(component, event, helper) {
        var value = event.getSource().get("v.value");
        var caseObject = component.get("v.caseObject");
        caseObject.Local_Case_Activity__c = value;
        component.set("v.caseObject",caseObject);
    },
    saveCaseData : function(component, event, helper) {
        console.log('===saveCaseData===');
        var sObjectEvent = $A.get("e.force:navigateToSObject");
        sObjectEvent.setParams({
            "recordId": component.get("v.recordId"),
        });
        var caseObject = component.get("v.caseObject");
        var message = '';
        var caseRec1;
        
        if(!caseObject.hasOwnProperty('Classification_1__c')) {
            caseObject.Classification_1__c = component.find("classificationId1").get("v.value");
        }
        if(!caseObject.hasOwnProperty('Classification_2__c')) {
            caseObject.Classification_2__c = component.find("classificationId2").get("v.value");
        }
        if(!caseObject.hasOwnProperty('Classification_3__c')) {
            caseObject.Classification_3__c = component.find("classificationId3").get("v.value");
        }
        if(!caseObject.hasOwnProperty('Closed_Case_Reason__c')) {
            caseObject.Closed_Case_Reason__c = component.find("closedCaseReasonId").get("v.value");
        }
        
        
        caseObject.Local_Case_Activity__c = component.find("recId").get("v.value");
        console.log('==caseObject.Local_Case_Activity__c=='+ caseObject.Local_Case_Activity__c);
        caseObject.Case_Type__c = component.find("cstypeid").get("v.value");
        if(caseObject.Case_Type__c === '' || caseObject.Case_Type__c === 'undefined' || 
           caseObject.Case_Type__c === undefined || caseObject.Case_Type__c === null) {
            message += 'Please select case type.<br/>';
        }
        
        if(caseObject.Classification_1__c === undefined || caseObject.Classification_1__c === 'undefined' || 
           caseObject.Classification_1__c === null || caseObject.Classification_1__c === '') {
            message += 'Please select Classification 1.<br/>';
        }
        if(caseObject.Classification_2__c  === '' || caseObject.Classification_2__c  === 'undefined' || 
           caseObject.Classification_2__c  === undefined || caseObject.Classification_2__c  === null) {
            message += 'Please select Classification 2.<br/>';
        }
        if(caseObject.Closed_Case_Reason__c  === '' || caseObject.Closed_Case_Reason__c  === 'undefined' || 
           caseObject.Closed_Case_Reason__c  === undefined || caseObject.Closed_Case_Reason__c  === null) {
            message += 'Closed Case Reason: You must enter a value.<br/>';
        }
        
        var formRec = caseObject.Local_Case_Activity__c;
        if(formRec != null && formRec != '' && formRec != undefined){
            formRec = formRec.replace(/<[^>]*>?/gm, '');
            formRec = formRec.replace(/\s+/g, '');
        }
        console.log('new recommendation: '+formRec);
        if(formRec == '' || formRec === 'undefined' || formRec === undefined || formRec === null || formRec == null || formRec === '' ||
           formRec.length < 2){
            message += 'Please enter a Recommendation. <br/>';
        }
        
        if(message !== '') {
            component.set("v.message",message);
            var cmpTarget = component.find('headerNotify');
            $A.util.removeClass(cmpTarget, 'slds-theme_success');
            $A.util.removeClass(cmpTarget, 'slds-theme_error');
            $A.util.addClass(cmpTarget, 'slds-theme_error');
            helper.toggleClass(component,true,"SubmitPopup");
        }
        
        if(message === '') {
            component.set("v.message","");
            helper.toggleClass(component,false,"SubmitPopup");
            helper.showSpinner(component, event, helper);
            var createArticle = component.get("v.createArticle");
            var recordId = component.get("v.recordId");
            var fetchCase = component.get("c.getCase");
            fetchCase.setParams({
                "caseId" :  recordId
            });
            
            fetchCase.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    caseRec1 = response.getReturnValue();
                    component.set("v.caseRecord",caseRec1);
                    var caseInfo = component.get("c.updateCloseCase");
                    caseInfo.setParams({
                        "caseId" :  recordId,
                        "caseObject" : caseObject
                    });
                    
                    caseInfo.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            if(response.getReturnValue().includes("Failure")) {
                                message = response.getReturnValue();
                                message = message.replace("Failure :","");
                                component.set("v.message",message);
                                var cmpTarget = component.find('headerNotify');
                                $A.util.removeClass(cmpTarget, 'slds-theme_success');
                                $A.util.removeClass(cmpTarget, 'slds-theme_error');
                                $A.util.addClass(cmpTarget, 'slds-theme_error');
                                helper.toggleClass(component,true,"SubmitPopup");
                                helper.hideSpinner(component, event, helper); 
                            } else {
                                if (createArticle == true) {
                                    component.set("v.message","");
                                    helper.toggleClass(component,false,"SubmitPopup");
                                    helper.hideSpinner(component, event, helper);
                                    
                                    var recid = component.get("v.recordId");
                                    var url1 = "/flow/Create_Draft_Article_from_Case?recordId="+recid+"&retURL=/apex/kaflowredirect?id="+recid;
                                    var workspaceAPI = component.find("workspace");
                                    workspaceAPI.isConsoleNavigation().then(function(response) {
                                        workspaceAPI.getFocusedTabInfo().then(function(response) {
                                            var focusedTabId = response.tabId;
                                            workspaceAPI.closeTab({tabId: focusedTabId});
                                        });
                                        
                                        if(response) {
                                            workspaceAPI.openTab({
                                                url: url1,
                                                focus:true
                                            });
                                        } else {
                                            var urlEvent = $A.get("e.force:navigateToURL");
                                            urlEvent.setParams({
                                                "url": url1
                                            });
                                            urlEvent.fire();
                                        }
                                    });
                                    
                                    /*var action = component.get("c.getRecordTypeId");
                                    action.setParams({ 
                                        "recTypeName" : component.find("levels").get("v.value") 
                                    });
                                    
                                    action.setCallback(this, function(response)  {
                                        var state = response.getState();
                                        var workspaceAPI = component.find("workspace");
                                        if (state === "SUCCESS") {
                                            var recid = response.getReturnValue();
                                            var caseObject = component.get("v.caseRecord");
                                            var articleRecTypeName = component.find("levels").get("v.value");
                                            if (articleRecTypeName === 'Q&A') {    
                                                var createRecordEvent = $A.get("e.force:createRecord");
                                                createRecordEvent.setParams({
                                                    "entityApiName": "Service_Article__kav",
                                                    "recordTypeId" : recid,
                                                    "navigationLocation":"LOOKUP",
                                                    "defaultFieldValues": {
                                                        'Answer__c' : caseObject.Local_Case_Activity__c,
                                                        'Title' : caseObject.Subject,
                                                        'Manager_Name__c' : caseObject.Applies_To__c,
                                                        'Properties__c' : caseObject.ECF_Investigation_Notes__c,
                                                        'Solution__c' : caseObject.Local_Case_Activity__c,
                                                        'Symptoms__c' : caseObject.Symptoms__c,
                                                        'SourceId': caseObject.Id
                                                    },
                                                    "panelOnDestroyCallback": function(event) {
                                                        workspaceAPI.isConsoleNavigation().then(function(response) {
                                                            if(response) {
                                                                workspaceAPI.getFocusedTabInfo().then(function(response) {
                                                                    var focusedTabId = response.tabId;
                                                                    workspaceAPI.closeTab({tabId: focusedTabId}).then(function(response) {
                                                                        window.setTimeout(function() {
                                                                            $A.get('e.force:refreshView').fire();
                                                                        }, 3000);
                                                                        sObjectEvent.fire();
                                                                    });
                                                                });
                                                                
                                                            } else {
                                                                window.setTimeout(function() {
                                                                    $A.get('e.force:refreshView').fire();
                                                                }, 3000);
                                                                sObjectEvent.fire();
                                                            }
                                                        });
                                                    }
                                                });
                                                
                                                createRecordEvent.fire();
                                            } else if (articleRecTypeName === 'How To') {    
                                                var createRecordEvent = $A.get("e.force:createRecord");
                                                createRecordEvent.setParams({
                                                    "entityApiName": "Service_Article__kav",
                                                    "recordTypeId" : recid,
                                                    "navigationLocation":"LOOKUP",
                                                    "defaultFieldValues": {
                                                        'Process__c' : caseObject.Local_Case_Activity__c,
                                                        'Title' : caseObject.Subject,
                                                        'Manager_Name__c' : caseObject.Applies_To__c,
                                                        'Properties__c' : caseObject.ECF_Investigation_Notes__c,
                                                        'Solution__c' : caseObject.Local_Case_Activity__c,
                                                        'Symptoms__c' : caseObject.Symptoms__c,
                                                        'SourceId': caseObject.Id
                                                    },
                                                    "panelOnDestroyCallback": function(event) {
                                                        workspaceAPI.isConsoleNavigation().then(function(response) {
                                                            if(response) {
                                                                workspaceAPI.getFocusedTabInfo().then(function(response) {
                                                                    var focusedTabId = response.tabId;
                                                                    workspaceAPI.closeTab({tabId: focusedTabId}).then(function(response) {
                                                                        window.setTimeout(function() {
                                                                            $A.get('e.force:refreshView').fire();
                                                                        }, 3000);
                                                                        sObjectEvent.fire();
                                                                    });
                                                                });
                                                                
                                                            } else {
                                                                window.setTimeout(function() {
                                                                    $A.get('e.force:refreshView').fire();
                                                                }, 3000);
                                                                sObjectEvent.fire();
                                                            }
                                                        });
                                                    }
                                                });
                                                
                                                createRecordEvent.fire();
                                            } else {
                                                var createRecordEvent = $A.get("e.force:createRecord");
                                                createRecordEvent.setParams({
                                                    "entityApiName": "Service_Article__kav",
                                                    "recordTypeId" : recid,
                                                    "navigationLocation":"LOOKUP",
                                                    "defaultFieldValues": {
                                                        'Title' : caseObject.Subject,
                                                        'Manager_Name__c' : caseObject.Applies_To__c,
                                                        'Properties__c' : caseObject.ECF_Investigation_Notes__c,
                                                        'Solution__c' : caseObject.Local_Case_Activity__c,
                                                        'Symptoms__c' : caseObject.Symptoms__c,
                                                        'SourceId': caseObject.Id
                                                    },
                                                    "panelOnDestroyCallback": function(event) {
                                                        workspaceAPI.isConsoleNavigation().then(function(response) {
                                                            if(response) {
                                                                workspaceAPI.getFocusedTabInfo().then(function(response) {
                                                                    var focusedTabId = response.tabId;
                                                                    workspaceAPI.closeTab({tabId: focusedTabId}).then(function(response) {
                                                                        window.setTimeout(function() {
                                                                            $A.get('e.force:refreshView').fire();
                                                                        }, 3000);
                                                                        sObjectEvent.fire();
                                                                    });
                                                                });
                                                                
                                                            } else {
                                                                window.setTimeout(function() {
                                                                    $A.get('e.force:refreshView').fire();
                                                                }, 3000);
                                                                sObjectEvent.fire();
                                                            }
                                                        });
                                                    }
                                                });
                                                
                                                createRecordEvent.fire();
                                            }
                                        }
                                    });
                                    $A.enqueueAction(action);*/
                                } else {
                                    var workspaceAPI1 = component.find("workspace");
                                    workspaceAPI1.isConsoleNavigation().then(function(response) {
                                        if(response) {
                                            workspaceAPI1.getFocusedTabInfo().then(function(response) {
                                                var focusedTabId = response.tabId;
                                                workspaceAPI1.closeTab({tabId: focusedTabId}).then(function(response){ 
                                                    sObjectEvent.fire(); 
                                                    $A.get('e.force:refreshView').fire();
                                                });
                                            }).catch(function(error) {
                                                console.log(error);
                                            });
                                        } else {
                                            sObjectEvent.fire(); 
                                            $A.get('e.force:refreshView').fire();
                                        }
                                    });
                                }   
                            }
                        }
                    });
                    $A.enqueueAction(caseInfo);
                }
            });
            $A.enqueueAction(fetchCase);   
        }
    },
    hideAlertModal : function(component,event,helper){
        helper.toggleClass(component,false,"SubmitPopup");
    },
    backToCase: function(component,event,helper){
        var sObjectEvent = $A.get("e.force:navigateToSObject");
        sObjectEvent.setParams({
            "recordId": component.get("v.recordId"),
        })
        sObjectEvent.fire();
    },
    setPagref : function(component, event) {
        var navLink = component.find("navLink");
        var pageRef = {
            type: 'standard__objectPage',
            attributes: {
                actionName: 'list',
                objectApiName: 'case',                
            },
            state: {
                filterName: "MyCases"
            }
        };
        
        navLink.generateUrl(pageRef).then($A.getCallback(function(a) {
            component.set("v.url", a ? a : "#");
        }), $A.getCallback(function(error) {
            component.set("v.url", "#");
        }));
    }
})