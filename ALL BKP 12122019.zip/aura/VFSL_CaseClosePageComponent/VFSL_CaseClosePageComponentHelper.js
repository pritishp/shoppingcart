({
    showSpinner : function(component, event, helper) {
        $A.util.removeClass(component.find('spinner'), "slds-hide");
    },
    hideSpinner : function(component, event, helper) {
        $A.util.addClass(component.find('spinner'), "slds-hide");  
    },
    toggleClass: function(component,showModal, modalName) {
        // console.log('---in toggle class');
        var modalComponent = component.find(modalName);
        
        if(showModal) {
            $A.util.removeClass(modalComponent,'LockOff');
            $A.util.addClass(modalComponent,'LockOn');
        } else {
            $A.util.removeClass(modalComponent,'LockOn');
            $A.util.addClass(modalComponent,'LockOff');
        }
    },
    setPagref : function(component, event) {
        var navLink = component.find("navLink");
        var pageRef = {
            type: 'standard__objectPage',
            attributes: {
                actionName: 'list',
                objectApiName: 'case',                
            },
            state: {
                filterName: "MyCases"
            }
        };

        navLink.generateUrl(pageRef).then($A.getCallback(function(a) {
            component.set("v.url", a ? a : "#");
        }), $A.getCallback(function(error) {
            component.set("v.url", "#");
        }));
    },
    redirectRecordPage : function(component, event, recordId) {
        var navLink = component.find("navLink");
        var pageRef = {
            type: 'standard__recordPage',
            attributes: {
                actionName: 'view',
                objectApiName: 'case',
                recordId : recordId
            },
        };
        navLink.navigate(pageRef, true);
    }
})