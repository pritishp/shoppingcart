({
    loadInitData: function(component, event, helper) { 
        
        var action = component.get('c.initMethod');
        
        action.setCallback(this, function(response) {
            
            var state = response.getState();
             console.log('wrapper state----'+JSON.stringify(state));
            if (state === "SUCCESS") {    
                var wrList = response.getReturnValue();    
                console.log('wrapper object----'+JSON.stringify(wrList));
                component.set('v.wrapperList', wrList);
                component.set("v.authenticated", wrList.checkAuthenticatedUser);
                component.set("v.developer", wrList.checkDev);
                component.set("v.developerPending", wrList.checkDevRequest);
                component.set("v.cartItemCount", wrList.checkCartItemCount);
                component.set("v.stripeConnectURL", wrList.checkDevStripe);
                
                //fetch User Info
                var storeUserInfo = wrList.getUserInfo;                
                if(storeUserInfo.ContactId != null) {
                    component.set("v.isInternalUser", false);
                } else {
                    component.set("v.isInternalUser", true);
                    //helper.getUserProfileName(component,event,helper);
                    if( !(wrList.checkUserProfile === 'VMS VMarket Admin' || wrList.checkUserProfile === 'VMS System Admin' || wrList.checkUserProfile === 'System Administrator') ){
                        component.set("v.showThirdParty", false);
            	}
                }
                component.set("v.userInfo", storeUserInfo);
                
                
            
        
                
                
                /*
                //currency Dropdown
                component.set("v.lstCurrencies", wrList.getCurrencyType);
                var CurrencyType = wrList.getCurrencyType;
                console.log('CurrencyType----'+JSON.stringify(wrList.checkCurrency));
                var userCartCurr =  wrList.checkCartCurrency;    
                // alert('currencyTypeee>>>>>>'+UserCartCurr);  
                 console.log('currencyTypeee----'+userCartCurr);
                for(var i in CurrencyType){                    
                    var curr = CurrencyType[i].IsoCode;   
                    console.log('curr---'+curr);
                    if(curr == userCartCurr){
                        debugger;
                        component.find("currencySelect").set("v.value", i + '-' + CurrencyType[i].ConversionRate) ;
                        helper.handleUserSelecedCurrency(component, CurrencyType[i].IsoCode,CurrencyType[i].ConversionRate, i);
                        break;
                    }
                }
                */
            }
            else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("loadInitData Error message: " + errors[0].message);
                    }
                } else {
                    console.log("loadInitData Unknown error");
                }
                component.set("v.authenticated", false);
                component.set("v.developer", false);
                component.set("v.developerPending", false);
                component.set("v.lstCurrencies", null);
            }
        });
        $A.enqueueAction(action);
    },
    
    
    isAuthenticated: function(component,event) {
        var action = component.get("c.isAuthenticatedUser");
        console.log('---isAuthenticated---');   
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            console.log('---state'+state);
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('authenticated==>'+response);
                // set searchResult list with return value from server.
                component.set("v.authenticated", response);
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
                component.set("v.authenticated", false);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    
        isDeveloper: function(component,event) {
        var action = component.get("c.isDev");
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('isDeveloper==>'+response);
                // set searchResult list with return value from server.
                component.set("v.developer", response);
            } else {
                component.set("v.developer", false);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    isDeveloperPending: function(component,event) {        
        var action = component.get("c.isDevRequestPending");        
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();            
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('isDeveloperPending==>'+response);
                // set searchResult list with return value from server.
                component.set("v.developerPending", response);
            } else {
                component.set("v.developerPending", false);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    cartItemCount: function(component,event) {        
        var action = component.get("c.getCartItemCount");        
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();            
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                console.log('cartItemCount==>'+response);
                // set searchResult list with return value from server.
                component.set("v.cartItemCount", response);
            } 
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    getUserInfo: function(component,event,helper){
        var action = component.get("c.fetchUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                // set current user information on userInfo attribute
                if(storeResponse.ContactId != null) {
                    component.set("v.isInternalUser", false);
                } else {
                    component.set("v.isInternalUser", true);
                    helper.getUserProfileName(component,event,helper);
                }
                component.set("v.userInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    showSpinner: function(component, event) {
        alert(111);
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    hideSpinner : function(component,event){
        alert(222);
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    },
    
    authorizeDeveloperAccount : function(component){
        //alert('inauthorize DeveloperAccount' );
        var stripeKey = this.getUrlParameter('code');
        var scopeValue = this.getUrlParameter('scope');
        //alert('stripeKey--'+stripeKey );
        console.log('---stripeKey--'+stripeKey);
        console.log('---scopeValue--'+scopeValue);
        if(stripeKey != '' && scopeValue != ''){
            console.log('---in authorize--');
            var action = component.get("c.authorizeCustomerAccount");
            action.setParams({
                "customerStripeAccId": stripeKey,
                "scope": scopeValue
            });
            component.set("v.vMarketSpinner", true);
            action.setCallback(this, function(response) {
                var state = response.getState();
                console.log('---AUTHORIZE STRIPE--'+state);
                if (state === "SUCCESS") {
                    component.set("v.vMarketSpinner", false);
                }else{
                    console.log('----ERROR--authorize--'+response.getError());
                }
            });
            $A.enqueueAction(action);
        }
    },
    
    getUrlParameter : function(sParam) {
        //alert('sParam---'+sParam );
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
        var sURLVariables = sPageURL.split('&');
        //alert('sURLVariables---'+sURLVariables )
        var sParameterName = [];
        var i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? '' : sParameterName[1];
            }
        }
        return '';
    },
    
    getPageName : function(){
        var pageName = decodeURIComponent(window.location);
        var pageNameArray = pageName.split('/');
        var pageNameArrayLength = pageNameArray.length;
        return pageNameArray[pageNameArrayLength-1];
    },
    getUserProfileName : function(component,event,helper) {
        var action = component.get("c.getUserProfile"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();         
            console.log('getUserProfile=='+result); 
            if( !(result === 'VMS VMarket Admin' || result === 'VMS System Admin' || result === 'System Administrator') ){
                component.set("v.showThirdParty", false);
            }
        });
        $A.enqueueAction(action);
    },
    
    navigateToCommunityPage : function(component, pageName){
        console.log('-----navigateToAppAssetPage----');
        var appId = component.get('v.vMTPAppId');
        console.log('---appId--'+appId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": '/'+pageName
        });
        urlEvent.fire();
    },
    handleLogout : function(component,event,helper) {
        console.log('-----HandleLogout----');
        var logoutUser = component.get("c.logoutUser");
        logoutUser.setCallback(this, function(response) {              
            var state = response.getState();
            if (state === "SUCCESS") {
                var logoutUrl = response.getReturnValue();
                //window.location.replace('/varianMarketPlace/s/login/');
                window.location.replace('/apex/vMarketPlaceLogoutPage');
            }else{
                console.log('----ERROR--authorize--'+response.getError());
            }
        });
        $A.enqueueAction(logoutUser);
    },
    getStripeConnectURL: function(component,event,helper) {
        var action = component.get("c.isDevStripeNotConnected");
        action.setCallback(this, function(response) {              
            var state = response.getState();
            console.log('getStripeConnectURL state',state);
            if (state === "SUCCESS") {
                var stripeUrl =  response.getReturnValue();  
                component.set("v.stripeConnectURL", stripeUrl);
                console.log('getStripeConnectURL returnValue',stripeUrl);
            }else{
                component.set("v.stripeConnectURL", '');	
            }
        });
        $A.enqueueAction(action);
    },
    
    getCurrencyType:function(component,event,helper){
        var action = component.get("c.getCurrency");
        action.setCallback(this,function(response){
            var state = response.getState();
            console.log('getCurrencyType state----'+state);            
            if(state==="SUCCESS"){ 
                var currType =  response.getReturnValue();  
                //component.set("v.lstCurrencies", currType);                 
                helper.getUserCartCurrency(component, event, helper, currType);
            }else{
                component.set("v.currencies", '');
            }
        });    
        $A.enqueueAction(action);
    },
    
    getUserCartCurrency:function(component,event,helper, cartCurr){
        console.log('cartCurr>>'+JSON.stringify(cartCurr)) ;
        component.set("v.lstCurrencies", cartCurr);
        var action = component.get("c.getUserCartCurrency");
        action.setCallback(this,function(response){
            var state = response.getState();
            console.log('getUserSelecedCurrency state----'+state);               
            if(state==="SUCCESS"){            
                var userCartCurr =  response.getReturnValue();    
               // alert('currencyTypeee>>>>>>'+UserCartCurr);  
                for(var i in cartCurr){
                     console.log('i---'+i);
                    var curr = cartCurr[i].IsoCode;
                  // debugger; //
                    if(curr == userCartCurr){
                       	component.set("v.showlstCurrencies", true); 
                        component.set("v.cartCurrency",userCartCurr);
                        component.find("currencySelect").set("v.value", i + '-' + cartCurr[i].ConversionRate) ;
                        helper.handleUserSelecedCurrency(component, cartCurr[i].IsoCode,cartCurr[i].ConversionRate);
                    	
                        break;
                    }
                    
                }
            }else{	
                console.log('----ERROR--getUserCartCurrency--'+response.getError());
            }
        });    
        $A.enqueueAction(action);
    },
    
    handleUserSelecedCurrency:function(component,currencyISOCode,ConvRate){
        //debugger; //
      //  if(component.get("v.cartCurrency") != currencyISOCode){
            var action = component.get("c.updateUserCartCurrency");
            action.setParams ({
                "currencyCode":currencyISOCode
            });
            console.log('handleUserSelecedCurrency state----'+currencyISOCode); 
            action.setCallback(this,function(response){
                var state = response.getState();
                console.log('handleUserSelecedCurrency state----'+state);                 
                if(state==="SUCCESS"){            
                    console.log('handleUserSelecedCurrency success--');    
                    var appEvent = $A.get("e.c:vMC_CurrencyTypeEvent"); 
                     console.log('Event fired');
                    appEvent.setParams({
                        "selectedCurrency" :currencyISOCode,
                        "conversionRate":ConvRate
                    });       
                    appEvent.fire(); 
                  // $A.get('e.force:refreshView').fire();      
                }else{	
                    console.log('----ERROR--handleUserSelecedCurrency--'+response.getError());
                    
                }
            });    
            $A.enqueueAction(action);
       /* }else{
            var appEvent = $A.get("e.c:vMC_CurrencyTypeEvent"); 
                     console.log('Event fired');
                    appEvent.setParams({
                        "selectedCurrency" :currencyISOCode,
                        "conversionRate":ConvRate
                    });       
                    appEvent.fire(); 
        }  */
    },
    
   getCartItems : function(component, event, helper) {
     
        var action = component.get("c.getCartItemLineList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
               
                
                if(resp && resp.length) {
                    var appList =[];
                    var prodList =[];
                    for(var i=0 ; i < resp.length; i++) {
                        if(resp[i].vMTPApp) {
                            appList.push({
                                resp: resp[i]
                            });   
                        }
                        if(resp[i].itemline) {
                                prodList.push({
                                    resp: resp[i]
                                });
                        }
                        
                    }
                }                
                console.log('prodList--'+prodList);                
                console.log('appWrapper--'+appList);
                component.set("v.appWrapper", appList);
                component.set("v.prodWrapper", prodList);
                
            }
            
           
        });
        $A.enqueueAction(action);
    },

    

})