({
    doInit : function(component, event, helper) {   
        helper.loadInitData(component,event,helper);
        helper.getCartItems(component,event,helper);
        //helper.isAuthenticated(component,event);
        //helper.getUserInfo(component,event,helper);
        //helper.isDeveloper(component,event);
        
        //helper.isDeveloperPending(component,event);
        //helper.cartItemCount(component,event);
        
        helper.authorizeDeveloperAccount(component);
        //helper.getStripeConnectURL(component, event, helper);
        helper.getCurrencyType(component,event,helper);
        component.set("v.pageName", helper.getPageName());
    },
    
    openCartMessageModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.cartMessageModalOpen", true);
    }, 
    closeCartMessageModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.cartMessageModalOpen", false);
    },
    reloadCartCount : function(component, event, helper) {
        helper.cartItemCount(component,event);
    },
    handleSelectedMenu : function (component, event, helper) {
        var selectedMenuItemValue = event.getParam("value");
        if(selectedMenuItemValue == 'myOrders') {
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-all-orders"
            });
            urlEvent.fire();
        }
        if(selectedMenuItemValue == 'mySubscriptions') {
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-all-subscriptions"
            });
            urlEvent.fire();
        }
        if(selectedMenuItemValue == 'myDashboard') {
            window.location.href = '/varianMarketPlace/s/vmtp-landing-dev';
        }
        if(selectedMenuItemValue == 'connectWithStripe') {    
            var stripeURL = component.get('v.stripeConnectURL');                        
            window.open(
                stripeURL,
                '_blank' 
            );            
        }
        if(selectedMenuItemValue == 'myProfile') {
            var myProfileUrlEvent = $A.get("e.force:navigateToURL");
            myProfileUrlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-myprofile"
            });
            myProfileUrlEvent.fire();
        }
        if(selectedMenuItemValue == 'logout') {
            helper.handleLogout(component,event,helper);
        }
    },
    openACHModal : function (component, event, helper) {
        component.set("v.isACHModalOpen", true);
    },
    openAppUploadPopup : function(component, event, helper){
        var popupComponent = component.find("uploadAppPopup");
        $A.util.addClass(popupComponent, 'slds-show');
        $A.util.removeClass(popupComponent, 'slds-hide');
    },
    
    executeAppUploadActions : function(component, event, helper){
        var clickedActionName = event.getSource().getLocalId();
        console.log("--clickedActionName--"+clickedActionName);
        if(clickedActionName == 'openAppUploadPopup'){
            var popupComponent = component.find("uploadAppPopup");
            $A.util.addClass(popupComponent, 'slds-show');
            $A.util.removeClass(popupComponent, 'slds-hide');
        }else if(clickedActionName == 'newAppUpload'){
            helper.navigateToCommunityPage(component, "vmtp-appupload");
        }else if(clickedActionName == 'bugFix'){
            helper.navigateToCommunityPage(component, "vmtp-appbugfix");
        }else if(clickedActionName == "closeAppUploadPopup"){
            var popupComponent = component.find("uploadAppPopup");
            $A.util.addClass(popupComponent, 'slds-hide');
            $A.util.removeClass(popupComponent, 'slds-show');
        }
    },
    
    openCartPrev : function(component, event, helper) {
        //var cmpTarget = component.find('modalDiv');
        //$A.util.addClass(cmpTarget, 'slds-show');
        //$A.util.removeClass(cmpTarget, 'slds-hide');
        var items = component.find("appShortDescPopover");
        //if(!items.length) items = [items];
        $A.util.removeClass(items,'slds-hide');
    },
    
    closeCartPrev : function(component, event, helper) {
        
        //var cmpTarget = component.find('modalDiv');
        //$A.util.addClass(cmpTarget, 'slds-hide');
        //$A.util.removeClass(cmpTarget, 'slds-show');
        var items = component.find("appShortDescPopover");
        //if(!items.length) items = [items];
        $A.util.addClass(items,'slds-hide');
        
    },
    
    handleCurrencyMenu: function(component, event, helper) { 
        var index = component.find("currencySelect").get("v.value").split('-')[0];
        var currencyIsoCode = component.get("v.lstCurrencies")[index].IsoCode;  
        var ConversionRate = component.get("v.lstCurrencies")[index].ConversionRate;
        helper.handleUserSelecedCurrency(component,currencyIsoCode,ConversionRate);
      
    },
})