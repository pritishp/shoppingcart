({
    doInit : function(component,event,helper) {
        var action = component.get("c.onInit");
        action.setParams ({
            ifReviewScreen: component.get("v.ifReviewScreen"),
        });
        action.setCallback(this, function(resp) {
            var result = resp.getReturnValue(); 
            if(result) {
                component.set("v.isInternalUser",result.isInternalUser);
                component.set("v.accountInfo", result.getCartAccount); 
                component.set("v.loggedInUserAccount", result.getLoggedInUserAccountId);
                component.set("v.salesOrgList", result.getSalesOrg);
                component.set("v.catalogModelList", result.getCatalogModel);
                component.set("v.shippingFieldsByCountry", result.getShippingFieldsByCountry);
            }
            if(result && result.getContact)
                component.set("v.contactInfo" , result.getContact);
            if(result && !component.get("v.ifReviewScreen")) {
                helper.setCartItems(component, helper, result.getCartItemLineList);
                component.set("v.blankScreen", false);
            }
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    toggleNextContentHelper : function(component, oldtab, oldcontent, newtab, newcontent) {
        $A.util.removeClass(oldtab, 'slds-is-current');
        $A.util.addClass(oldtab, 'slds-is-complete');
        $A.util.addClass(oldcontent, 'slds-hide');
        $A.util.removeClass(newtab, 'slds-is-incomplete');
        $A.util.addClass(newtab, 'slds-is-current');
        $A.util.removeClass(newcontent, 'slds-hide');
    },
    
    togglePreviousContentHelper : function(component, oldtab, oldcontent, newtab, newcontent) {
        $A.util.removeClass(oldtab, 'slds-is-current');
        $A.util.addClass(oldtab, 'slds-is-incomplete');
        $A.util.addClass(oldcontent, 'slds-hide');
        $A.util.removeClass(newtab, 'slds-is-complete');
        $A.util.addClass(newtab, 'slds-is-current');
        $A.util.removeClass(newcontent, 'slds-hide');
    },
    
    
    
    checkInventory: function (component, event, helper, oldtab, oldcontent, newtab, newcontent) {
        var action = component.get("c.checkInventory");
        var paymentMethod =component.get("v.cart.Payment_Method__c");
        var marketPlaceProductArray = component.get("v.marketPlaceProductArray");
        var catalogList = component.get("v.catalogModelList");
        
        var prodModelWithInventory=[];
        for(var index in catalogList) {
            if(catalogList[index].Inventory_Check_Required__c == true) {
                if(prodModelWithInventory.indexOf(catalogList[index].Product_Model__c) == -1)
                	prodModelWithInventory.push(catalogList[index].Product_Model__c);
            }
        }
        
         var productIds = []; var isValidate = true;
        for(var prodIndex in marketPlaceProductArray) {
            if(prodModelWithInventory.indexOf(marketPlaceProductArray[prodIndex].model) > -1) {
                for(var i=0 ; i< marketPlaceProductArray[prodIndex].response.length; i++) {
                    productIds.push(marketPlaceProductArray[prodIndex].response[i].itemline.Product__r.ProductCode);
                    delete marketPlaceProductArray[prodIndex].response[i]['errorDescription'];
                    if(isNaN(parseInt(marketPlaceProductArray[prodIndex].response[i].quantity))) {
                        marketPlaceProductArray[prodIndex].response[i].error = 'Please enter a valid number.';
                        isValidate = false;
                    }
                    else if(parseInt(marketPlaceProductArray[prodIndex].response[i].quantity) < 1) {
                        marketPlaceProductArray[prodIndex].response[i].error = 'Qunatity cannot be less than 1.';
                        isValidate = false;
                    } 
                        else if(parseInt(marketPlaceProductArray[prodIndex].response[i].quantity) > 999 && paymentMethod=='PO') {
                            marketPlaceProductArray[prodIndex].response[i].error = 'For PO, Maximum quantity accepted is 999.';
                            isValidate = false;
                        }
                            else if(paymentMethod=='Credit Card' && marketPlaceProductArray[prodIndex].response[i].maxQuantity && parseInt(marketPlaceProductArray[prodIndex].response[i].quantity) > parseInt(marketPlaceProductArray[prodIndex].response[i].maxQuantity)) {
                                marketPlaceProductArray[prodIndex].response[i].error = 'Maximum Quantity Allowed: '+  marketPlaceProductArray[prodIndex].response[i].maxQuantity;
                                isValidate = false;
                            }
                                else {
                                    delete marketPlaceProductArray[prodIndex].response[i]['error'];
                                }
                    if(!isValidate)
                        component.set("v.marketPlaceProductArray",marketPlaceProductArray);
                }
            }
        }
        
        action.setParams ({
            prodIds: productIds
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var isNext = true; var isPONext = true;
                var inventory = response.getReturnValue();
                var inventoryCodeList=[];
                console.log('inventory'+JSON.stringify(inventory));
                component.set('v.inventoryMap', inventory);
                for (var key in inventory) {
                        inventoryCodeList.push(key);
                }
                
                for(var i=0 ; i< marketPlaceProductArray.length ; i++) {
                    if(prodModelWithInventory.indexOf(marketPlaceProductArray[i].model) > -1) {
                        for(var j=0 ; j< marketPlaceProductArray[i].response.length; j++) {
                            
                            
                            for(var indx=0 ; indx< inventoryCodeList.length; indx++) {
                                if (marketPlaceProductArray[i].response[j].itemline.Product__r.ProductCode == inventoryCodeList[indx]) {
                                    var totalQuantityPerProduct=0; marketPlaceProductArray[i].response[j].errorDescription = '';
                                    
                                    for(var k=0; k<inventory[inventoryCodeList[indx]].length; k++) {
                                        totalQuantityPerProduct= totalQuantityPerProduct + parseInt(inventory[inventoryCodeList[indx]][k].Unrestricted_Quantity__c) ;
                                        if(k == inventory[inventoryCodeList[indx]].length - 1)
                                            marketPlaceProductArray[i].response[j].errorDescription = marketPlaceProductArray[i].response[j].errorDescription + ' and ';
                                        else if(k!=0 && k < inventory[inventoryCodeList[indx]].length - 1)
                                            marketPlaceProductArray[i].response[j].errorDescription = marketPlaceProductArray[i].response[j].errorDescription + ' , ';
                                        marketPlaceProductArray[i].response[j].errorDescription = marketPlaceProductArray[i].response[j].errorDescription + parseInt(inventory[inventoryCodeList[indx]][k].Unrestricted_Quantity__c) + ' in ' +inventory[inventoryCodeList[indx]][k].Plant_Description__c;
                                    }
                                    
                                    if(parseInt(marketPlaceProductArray[i].response[j].quantity) >  totalQuantityPerProduct && paymentMethod!='PO') {
                                        if(totalQuantityPerProduct==0) {
                                            marketPlaceProductArray[i].response[j].error = 'Not in stock. Please remove this product from shopping cart.'
                                        } else {
                                            marketPlaceProductArray[i].response[j].error = 'Only '+totalQuantityPerProduct +' in stock. Please revise the Qty to <='+totalQuantityPerProduct +'.';
                                        }
                                        isNext = false; isPONext= false;
                                    }
                                    else if(parseInt(marketPlaceProductArray[i].response[j].quantity) >  totalQuantityPerProduct && paymentMethod=='PO') {
                                        marketPlaceProductArray[i].response[j].error ='There is currently not enough stock in inventory to fulfill this order. The operations team will advise you of a lead time once the order has been placed, or you can reach out to ' + component.get("v.shippingFieldsByCountry")[0].vMC_Support_Email__c +' to confirm lead times before placing this order.'
                                        isNext = false;
                                    }
                                        else if(marketPlaceProductArray[i].response[j].error) {
                                            delete marketPlaceProductArray[i].response[j]['error'];
                                        } 
                                }
                            } 
                            if(inventoryCodeList.indexOf(marketPlaceProductArray[i].response[j].itemline.Product__r.ProductCode)<0) {
                                marketPlaceProductArray[i].response[j].error = 'No inventory info for this product. Please remove from the shopping cart.';
                                isNext = false;
                            }
                        }
                    }
                }
                
                if( oldtab !== '' && oldcontent !== '' && newtab !== '' && newcontent !== '' ){
                    if(isNext && isPONext) {
                        helper.toggleNextContentHelper(component, oldtab, oldcontent, newtab, newcontent);
                        helper.updateCartLineItems (component, event, helper);
                    }
                    if(isPONext && !isNext && paymentMethod=='PO') {
                        component.find('shoppingQtySelection').disableQtyFld();
                        component.find('selectQTyNext').set("v.label", 'Confirm');
                        component.find('selectQTyNext').set("v.name", 'Confirmbtn2');
                        $A.util.removeClass(component.find('updateQtyDiv'),'slds-hide');
                        $A.util.addClass(component.find('updateQtyDiv'),'slds-show');
                    }
                }
            }
            component.set("v.marketPlaceProductArray",marketPlaceProductArray);
            setTimeout(function(){ component.set("v.processing", false) }, 1500);
        });
        if(isValidate)
            $A.enqueueAction(action);
        else
            component.set("v.processing", false);
    },
    
    updateCartLineItems : function (component, event, helper) {
        var mapProdIdQty = new Object();
        var marketPlaceProductArray = component.get("v.marketPlaceProductArray");
        for(var i=0 ; i< marketPlaceProductArray.length; i++) {
            if(marketPlaceProductArray[i].model !='Third Party') {
                for(var j=0; j< marketPlaceProductArray[i].response.length; j++) {
                    mapProdIdQty[marketPlaceProductArray[i].response[j].itemline.Product__c] = marketPlaceProductArray[i].response[j].quantity; 
                    if(marketPlaceProductArray[i].response[j].error)
                        delete marketPlaceProductArray[i].response[j]['error'];
                }
            }
        }
        var action = component.get("c.updateCartLineItem");
        action.setParams({ 
            mapBrachyIdWithQuantity : mapProdIdQty,
            selectedPaymentMethod : component.get("v.cart.Payment_Method__c")
        });
        action.setCallback(this,function(response){
            if (response.getState() === "SUCCESS"){
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
            }
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    getCartItems : function(component, event, helper, isInternalUser, loggedInUserAccount) {        
        component.set("v.processing", true);
        var action = component.get("c.getCartItemLineList");
        action.setParams({
            ifInternalUser : isInternalUser,
            accId : loggedInUserAccount
        })        
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                 helper.setCartItems(component, helper, response.getReturnValue());
            }
            component.set("v.blankScreen", false);
        });
        $A.enqueueAction(action);
    },
    
    setCartItems : function (component, helper, resp) {
        console.log('getCartItems Response='+resp);
        var appTotalPrice=0; var brachyTotalPrice=0;
        var appTotalQty=0; var brachyTotalQty=0;
        if(resp && resp.length) {
            component.set("v.isInternalUser", resp[0].isInternalUser);
            component.set("v.userAccount", resp[0].userAccountId);
            component.set("v.cart", resp[0].cartItem);
            component.set("v.OrderPlacedBy",resp[0].cartItem.CreatedBy.Name);
            component.set("v.shipToErp", resp[0].shipToErp);
            component.set("v.billToErp", resp[0].billToErp);
            component.set("v.orderContact", resp[0].cartOrderContact);
            
            var fullArray = [];
            var modelResponse = [];
            var setOfModels = [];
            var shippingCost = 0;
            var ifCartHasThirdPartyApps = false;
            
            var tempQty = 0; var tempTotalPrice = 0; var tempResponse = [];
            
            for(var i=0 ; i < resp.length; i++) {
                if(fullArray[resp[i].productModel]  && fullArray[resp[i].productModel].model== resp[i].productModel){
                    tempQty = fullArray[resp[i].productModel]['qty'];
                    tempTotalPrice = fullArray[resp[i].productModel]['totalPrice'];
                    tempResponse = fullArray[resp[i].productModel]['response'];
                } else {
                    tempQty = 0;
                    tempTotalPrice = 0;
                    tempResponse = [];
                }
                
                fullArray[resp[i].productModel]  = {
                    'model': resp[i].productModel,
                    'qty': tempQty + resp[i].quantity,
                    'shippingPrice' : shippingCost,
                }
                
                if(resp[i].productModel != 'Third Party') {
                    if(resp[i].itemline.Discounted_Price__c && resp[i].itemline.Discounted_Price__c!=0) 
                        fullArray[resp[i].productModel]['totalPrice'] = tempTotalPrice + (resp[i].itemline.Discounted_Price__c * resp[i].quantity);
                    else
                        fullArray[resp[i].productModel]['totalPrice'] = tempTotalPrice + (resp[i].itemline.Unit_Price__c * resp[i].quantity);
                    fullArray[resp[i].productModel]['response'] = tempResponse;
                    fullArray[resp[i].productModel]['response'].push(resp[i]);
                    if(!fullArray[resp[i].productModel]['shippingPrice']) {
                        for(var index in fullArray[resp[i].productModel].response) {
                            shippingCost = shippingCost + fullArray[resp[i].productModel].response[index].itemline.Shipping_Cost__c;
                        }
                    }
                    
                }
                else  {
                    ifCartHasThirdPartyApps = true;
                    fullArray[resp[i].productModel]['totalPrice'] = tempTotalPrice + resp[i].itemline.Unit_Price__c + resp[i].appSubPrice;
                    fullArray[resp[i].productModel]['response'] = tempResponse;
                    fullArray[resp[i].productModel]['response'].push(resp[i]);
                }
                
                if(setOfModels.indexOf(resp[i].productModel)==-1) 
                    setOfModels.push(resp[i].productModel);
            }
            
            for(var key in fullArray) {
                modelResponse.push(fullArray[key]);
            }
        }
        component.set("v.marketPlaceProductArray",modelResponse);
        component.set("v.ifCartHasThirdPartyApps", ifCartHasThirdPartyApps);
        component.set("v.setOfModels", setOfModels);
        component.set("v.processing", false);
        helper.setBreadCrumbs (component, event, helper);
    },
    
    callWebservice : function (component, oldtab, oldcontent, newtab, newcontent,shipToNumber,helper) {
        component.set("v.processing", true);
        console.log('selected shipping---'+component.get("v.selectedShippingMethod"));
        var setOfModels = component.get("v.setOfModels");
        var action = component.get("c.getShippingDataFromSAP");
        var appWrapper =[];
        var prodWrapper = [];
        var productArrays = component.get("v.marketPlaceProductArray");
        var salesOrgList = component.get("v.salesOrgList");
        for(var i=0; i <productArrays.length ; i++) {
            if(productArrays[i].model == 'Third Party') {
                appWrapper.push(productArrays[i].response);
            } else {
                prodWrapper.push(productArrays[i].response);
            }
        } 
        
        var baProdCodePriceMap=[]; var tpAppPriceList=[];
        var finalPrice=0;
        
        console.log('finalPrice--'+finalPrice);
        for(var i=0 ; i< prodWrapper.length; i++) {
            for(var j=0 ; j< prodWrapper[i].length; j++) {
                for(var salesOrgIndex in salesOrgList) {
                    if(prodWrapper[i][j].productModel == salesOrgList[salesOrgIndex].Product_Model__c) {
                        prodWrapper[i].defaultPlant = salesOrgList[salesOrgIndex].Default_Plant__c;
                        prodWrapper[i].productModel = salesOrgList[salesOrgIndex].Product_Model__c; 
                        prodWrapper[i].salesOrg = salesOrgList[salesOrgIndex].Sales_Org__c;
                        if(salesOrgList[salesOrgIndex].Document_Type__c)
                            prodWrapper[i].docType = salesOrgList[salesOrgIndex].Document_Type__c;
                        if(salesOrgList[salesOrgIndex].Distribution_Channel__c)
                            prodWrapper[i].distributionChannel = salesOrgList[salesOrgIndex].Distribution_Channel__c;
                        if(salesOrgList[salesOrgIndex].Division__c)
                            prodWrapper[i].division = salesOrgList[salesOrgIndex].Division__c;
                    }
                    
                }
                if(!!prodWrapper[i][j].itemline.Discounted_Price__c){
                    finalPrice=prodWrapper[i][j].itemline.Discounted_Price__c;
                }
                else{
                    finalPrice=prodWrapper[i][j].itemline.Unit_Price__c; 
                }
                baProdCodePriceMap.push({
                    pCode: prodWrapper[i][j].itemline.Product__r.ProductCode,
                    pQty: prodWrapper[i][j].quantity,
                    price :finalPrice,
                    shippingMethod : prodWrapper[i][j].itemline.Shipping_Method__c,
                    defaultPlant : prodWrapper[i].defaultPlant,
                    salesOrg : prodWrapper[i].salesOrg,
                    productModel : prodWrapper[i].productModel,
                    docType : prodWrapper[i].docType,
                    distributionChannel : prodWrapper[i].distributionChannel,
                    division : prodWrapper[i].division,
                });
            }
        }
        
        for(var k=0 ; k< appWrapper.length; k++) {
            for(var l=0 ; l< appWrapper[k].length; l++) {
                if(appWrapper[k][l].appSubPrice > 0)
                    tpAppPriceList.push(appWrapper[k][l].appSubPrice);
                else
                    tpAppPriceList.push(appWrapper[k][l].vMTPApp.Price__c);
            }
        }
        
        console.log('tpAppPriceList ' + JSON.stringify(tpAppPriceList));
        action.setParams ({
            shipToNumber:shipToNumber,
            accountId:component.get("v.userAccount"),
            baProdCodePriceMap: JSON.stringify(baProdCodePriceMap),
            tpAppPriceList : tpAppPriceList,
            country : component.get("v.accountInfo").ISO_Country__c,
            currencyCode : component.get("v.currencyISOCode"),
        }); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var isValid = true;
                if(result && result.IT_ITEMS_PRICE_OUT && result.IT_ITEMS_PRICE_OUT.length) {
                    var taxArray = {};
                    for(var index in setOfModels) {
                        var taxPrice = 0;
                        for(var i=0 ; i < result.IT_ITEMS_PRICE_OUT.length; i++) {
                            if(setOfModels[index] == result.IT_ITEMS_PRICE_OUT[i].PRODUCT_MODEL) {
                                if(taxArray[setOfModels[index]] || taxArray[setOfModels[index]] ==0) {
                                    taxArray[setOfModels[index]] = taxPrice + parseFloat(result.IT_ITEMS_PRICE_OUT[i].TAX);
                                    taxPrice = taxPrice + parseFloat(result.IT_ITEMS_PRICE_OUT[i].TAX);
                                }
                                else {
                                    taxArray[setOfModels[index]] = parseFloat(result.IT_ITEMS_PRICE_OUT[i].TAX);
                                    taxPrice = parseFloat(result.IT_ITEMS_PRICE_OUT[i].TAX);
                                }
                            }
                        }
                    }
                    
                    for(var j=0; j<productArrays.length;j++) { 
                        if(taxArray[productArrays[j].model] || taxArray[productArrays[j].model] ==0)
                            productArrays[j].tax =  taxArray[productArrays[j].model];
                    }
                    component.set("v.marketPlaceProductArray", productArrays);
                    helper.updateCart (component, event, helper);
                } 
                else {
                    component.set("v.processing", false);
                    isValid = false;
                    if(result.IT_RETURN && result.IT_RETURN[0]) 
                        helper.showToast(component, result.IT_RETURN[0].MESSAGE, 'Error', 'Error');
                    else 
                        helper.showToast(component, 'Error in getting Shipping and Tax Response', 'Error', 'Error'); 
                }
                if(result.IT_RETURN && result.IT_RETURN.length > 1) {
                    isValid = false;
                    component.set("v.processing", false);
                    for(var i=0 ; i < result.IT_ITEMS_PRICE_OUT.length; i++) {
                        helper.showToast(component, result.IT_RETURN[i].MESSAGE, 'Error', 'Error');
                    }
                } else if(result.IT_RETURN && result.IT_RETURN.length == 1) {
                    isValid = false;
                    component.set("v.processing", false);
                    helper.showToast(component, result.IT_RETURN[0].MESSAGE, 'Error', 'Error');
                }
            }
            if(isValid)
                component.find('confirmOrder').set("v.disabled", false);
        });
        $A.enqueueAction(action);
    },
    
    updateCart : function (component, event, helper) {
        
        var action = component.get("c.updateCart");
        var products = component.get("v.marketPlaceProductArray");
        var isCustomerCarrier = component.get("v.cart.Customer_Carrier__c");
        
        var wrapper = { 
            thirdParty : [] ,
            brachy : [],
        };
        
        for(var prodModel in products) {
            if(products[prodModel].model == 'Third Party') {
                for(var modelIndex in products[prodModel].response) {
                    var tpJsonData = {};
                    tpJsonData['appId'] = products[prodModel].response[modelIndex].vMTPApp.Id;
                    tpJsonData['unitPrice'] = products[prodModel].response[modelIndex].vMTPApp.Price__c;
                    tpJsonData['qty'] = 1;
                    tpJsonData['rId'] = 'Third Party App';
                    tpJsonData['model'] = products[prodModel].model;
                    tpJsonData['tax'] =  products[prodModel].tax;
                    wrapper.thirdParty.push(tpJsonData);
                }
            } else {
                for(var modelIndex in products[prodModel].response) {
                    if(!isNaN(modelIndex)) {
                        var brachyJsonData = {};
                        brachyJsonData['prodId'] = products[prodModel].response[modelIndex].itemline.Product__c;
                        brachyJsonData['unitPrice'] = products[prodModel].response[modelIndex].itemline.Unit_Price__c;
                        brachyJsonData['qty'] = products[prodModel].response[modelIndex].quantity;
                        brachyJsonData['prodCode'] = products[prodModel].response[modelIndex].itemline.Product__r.ProductCode;
                        brachyJsonData['rId'] = 'Varian Product';
                        brachyJsonData['model'] = products[prodModel].model;
                        brachyJsonData['discountedPrice'] =  products[prodModel].response[modelIndex].itemline.Discounted_Price__c;
                        brachyJsonData['tax'] = products[prodModel].tax;
                        brachyJsonData['shippingCost'] =  products[prodModel].shippingPrice;
                        if(isCustomerCarrier) {
                            brachyJsonData['cc_ShippingMethod'] =  products[prodModel].response[0].itemline.Customer_Carrier_Shipping_Method__c;
                            brachyJsonData['cc_reqDeliveryDate'] =  products[prodModel].response[0].itemline.Customer_Carrier_Requested_Delivery_Date__c;
                        } else {
                            brachyJsonData['shippingMethod'] =  products[prodModel].response[0].itemline.Shipping_Method__c;
                            brachyJsonData['reqDeliveryDate'] =  products[prodModel].response[0].itemline.Requested_Delivery_Date__c;
                        }
                        wrapper.brachy.push(brachyJsonData);
                    }
                    if(modelIndex =='salesOrg')
                        brachyJsonData['salesOrg'] = products[prodModel].response[modelIndex];
                    if(modelIndex =='docType')
                        brachyJsonData['docType'] = products[prodModel].response[modelIndex];
                    if(modelIndex =='defaultPlant')
                        brachyJsonData['defaultPlant'] = products[prodModel].response[modelIndex];
                    if(modelIndex =='distributionChannel')
                        brachyJsonData['distributionChannel'] = products[prodModel].response[modelIndex];
                    if(modelIndex =='division')
                        brachyJsonData['division'] = products[prodModel].response[modelIndex];
                }
            }
            
        }
        
        component.get("v.fv.destination.label");
        var shipToAddress = ''; var billToAddress = '';
        if( component.get("v.fv.destination") ){
            shipToAddress += component.get("v.fv.destination.Partner_Street__c");
            if( component.get("v.fv.destination.Partner_Street_line_2__c") !== '' && (typeof (component.get("v.fv.destination.Partner_Street_line_2__c")) !== 'undefined')){
                shipToAddress += ', ' + component.get("v.fv.destination.Partner_Street_line_2__c");
            }
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_City__c");
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_State__c");
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_Zipcode_postal_code__c");
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_Country__c");
        }
        console.log('shipToAddress'+shipToAddress);
        if( component.get("v.fv.billingAddress") ){
            billToAddress += component.get("v.fv.billingAddress.Partner_Street__c");
            if( component.get("v.fv.billingAddress.Partner_Street_line_2__c") !== '' && (typeof (component.get("v.fv.destination.Partner_Street_line_2__c")) !== 'undefined')){
                billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_Street_line_2__c");
            }
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_City__c");
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_State__c");
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_Zipcode_postal_code__c");
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_Country__c");
        }
        console.log('billingAddress'+billToAddress);
        var shipTo = component.get("v.fv")[0].destination.Id;
        var billTo = component.get("v.fv")[0].billingAddress.Id;
        var shippingInfo = component.get("v.fv")[0];
        console.log('shippingInfo 1--->'+JSON.stringify(shippingInfo.destination));
        delete shippingInfo.billingAddress;
        delete shippingInfo.destination;
        console.log('shippingInfo-2-->'+JSON.stringify(shippingInfo));
        var shippingInfoObject =[];
        shippingInfoObject.push(shippingInfo);
        console.log('shippingInfoObject--->'+JSON.stringify(shippingInfoObject));
        action.setParams({
            thirdPartyJSON: JSON.stringify(wrapper.thirdParty),
            brachyJSON : JSON.stringify(wrapper.brachy),
            brachyShippingCost : component.get("v.brachyShippingPrice"),
            accountId:component.get("v.userAccount"),
            shipToId : shipTo,
            billToId : billTo,
            shipToAddress: shipToAddress,
            billToAddress: billToAddress,
            userFieldValues : JSON.stringify(shippingInfoObject),
            isInternalUserFlag : component.get("v.isInternalUser"),
            selectedPaymentMethod: component.get("v.cart.Payment_Method__c"),
        })
        action.setCallback(this, function(a) {
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    showToast : function(component, errorMessage, errorType, errorTitle) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": errorTitle,
            "message": errorMessage,
            "type" : errorType,
            "mode" : 'sticky',
        });
        toastEvent.fire(); 
    },
    
    changeShippingFields : function (component, event, helper) {
        
    },
    
	setBreadCrumbs : function (component, event, helper) {       
        var breadcrumbCollection = [
        	{label: 'Home', name: 'all products'},    
        ];              
        var productModels = component.get("v.setOfModels"); 
            if(productModels) {
            productModels.forEach(function(element) {
            if(element == 'Third Party' && !component.get('v.isInternalUser')){
            	breadcrumbCollection.push({label: 'Third Party Apps', name: 'thirdParty products'});
            }else{
            	breadcrumbCollection.push({ label: element, name: element });
            }        	
        });  
            }
        
        component.set('v.breadcrumbCollection', breadcrumbCollection);        
    } 
})