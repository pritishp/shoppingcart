({
    doInit : function(component, event, helper) {
        //Get Work Order defaults
        var WorkOrderInfo = component.get("c.getWOWrapper");
        
        WorkOrderInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response){
            var woCheck = response.getReturnValue();
            if(woCheck) {
                component.set("v.workOrder",woCheck.wo); 
                component.set("v.case", woCheck.woCase);
                component.set("v.workOrderDetails", woCheck);
                //console.log('woCheck: '+ JSON.stringify(woCheck));
                if((woCheck.wo.Status == 'Reviewed') && (woCheck.wo.Interface_Status__c == 'Processed' || (woCheck.wo.Interface_Status__c == 'Do Not Process' && 
                                                                                                           woCheck.wo.SAP_Status__c == 'Not Applicable')))
                {   
                    component.set("v.Qualify",false);
                }
            }            
        });
        
        $A.enqueueAction(WorkOrderInfo);
        helper.getData(component);   
                        
        component.set('v.mycolumn', [
            
            {label: 'Title', fieldName: 'attachmentURL', type: 'url', typeAttributes: {label: { fieldName: 'Title' }, target: '_blank'}},
            {label: 'Created By', fieldName: 'CreatedByid'},  
            {label: 'Last Modified', fieldName: 'LastModifiedDate',type: 'date', typeAttributes:{month: "2-digit", day: "2-digit", year: "2-digit"}}
        ]);
            helper.getData1(component);   
            
            component.set('v.micolumns', [
            
            {label: 'Paid Service Overhead JO#', fieldName: 'Paid_Service_JO'},
            {label: 'Helpdesk Overhead JO#', fieldName: 'HelpDesk_JO'},
            {label: 'Contract Overhead JO#', fieldName: 'Contract_JO'},   
        ]);
        helper.getData2(component); 
        helper.getUser(component);
     
        var today = $A.localizationService.formatDate(new Date(), "YYYY-MM-DD");
        component.set('v.today', today);  
    },
    
    toggleSection : function(component, event, helper) {
        var sectionAuraId = event.target.getAttribute("data-auraId");
        var sectionDiv = component.find(sectionAuraId).getElement();
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    },
   
    savecontacts: function(component, event, helper) {
        var newcon = component.get("v.workOrder");
        var action = component.get("c.saveRecord");
        
        action.setParams({ 
            "WorkOrder": newcon
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") 
                
            {
                component.set("v.workOrder", response.getReturnValue());
                alert("Record is successfully saved");
            }
            else if (state === "ERROR")
            {
                alert("Failed");
            }
        });
        $A.enqueueAction(action);
    },
  
 	Approve : function(component, event, helper) {
        var lineItems = component.get("v.mydata");       
         
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].ERP_Billable && (!lineItems[i].Billing_Review || !lineItems[i].Review_Type)) {
                alert('Billing Review and Review Type is required when line is Billable: ' + lineItems[i].LineItemNumber);
            	return;
        	
            } else if(!lineItems[i].Service_Contract && lineItems[i].Review_Type === 'Contract') {
                alert('Line Item category cannot be "Contract" if line has no contract: ' + lineItems[i].LineItemNumber);
                return;
            }
        }    
        	
    	component.set("v.woApproved",true);    
    },
                
 	handleRowAction : function(component, event, helper){
        var selRows = event.getParam('selectedRows');
        // alert (selRows[0].Id);
        //console.log(selRows[0].id);
        component.set("v.delIds",selRows[0].Id);
    },
    
    FOA : function(component, event, helper) {
        var recordId = component.get("v.recordId");
        var url = '/apex/Vfsl_FOAreviewpage?id=' + recordId;   
        var urlEvent = $A.get("e.force:navigateToURL"); 
        urlEvent.setParams({ 
            "url": url
            
        });
        urlEvent.fire();
    },
    
	 Waive : function(component, event, helper) {
         var lineItems = component.get("v.mydata");
         var wo = component.get("v.workOrder");
         var st = component.get("v.midata");
         
         //var fieldsMap = component.get("v.depnedentFieldMap");
         var updatedLineItems = [];
         
         for(var i = 0; i < lineItems.length; i++) {
             if(lineItems[i].selected === true) {
                 //lineItems[i].action = 'Waive';
                 //lineItems[i].category = fieldsMap['Waive'];
                 lineItems[i].Billing_Review = 'Waive';
                 if(lineItems[i].Service_Contract) {
                     lineItems[i].Review_Type = 'Contract';
                     //Adding Billing Type setting for N Waived.
                     lineItems[i].Billing_Type = 'N – Waived';
                 } else {
                     lineItems[i].Review_Type = 'Overhead';
                 }
                 
                 if(st && !lineItems[i].Service_Contract) {
                     if(wo.RecordType.Name === 'Field Service') {
                         lineItems[i].SAP_Service = st[0].Paid_Service_JO;
                     } else if(wo.RecordType.Name === 'HelpDesk') {
                         lineItems[i].SAP_Service = st[0].HelpDesk_JO;
                     }
                 }
                 
             }
             
             updatedLineItems.push(lineItems[i]);
         }
         console.log(JSON.stringify(updatedLineItems));
         component.set("v.mydata",updatedLineItems); 
         //component.set("v.isWaived",true);
        /*var delIdList = component.get("v.delIds");
        var action = component.get("c.Waivechanges");
        
        action.setParams({
            wlid : delIdList
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS"){
                var d = response.getReturnValue();
                component.set("v.workOrder", d);
                alert("Record is saved Sucessfully");
                $A.get('e.force:refreshView').fire();
                
            }
            else if  (state === "ERROR"){
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.error("Error message: " + 
                                      errors[0].message);
                    }
                } 
                else {
                    console.error("Unknown Error");
                }
            }
        })  ;       $A.enqueueAction(action);*/
        
    },
        
    Bill : function(component, event, helper) {
        var lineItems = component.get("v.mydata");
         //var fieldsMap = component.get("v.depnedentFieldMap");
         var updatedLineItems = [];
         
         for(var i = 0; i < lineItems.length; i++) {
             if(lineItems[i].selected === true) {
                 //lineItems[i].action = 'Bill';
                 //lineItems[i].category = fieldsMap['Bill'];
                 lineItems[i].Billing_Review = 'Bill';
                 lineItems[i].Review_Type = 'Standard';
                 lineItems[i].Billing_Type = 'P – Paid Service';
                 //lineItems[i].Billing_Type = lineItems[i].origBillingType;
             }
             
             updatedLineItems.push(lineItems[i]);
         }
         
        //component.find('reviewtype').set('v.value','Standard');
         component.set("v.mydata",updatedLineItems); 
        /*var delIdList = component.get("v.delIds");
        var action = component.get("c.billWL");
        
        action.setParams({
            wlidb : delIdList
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS"){
                var d = response.getReturnValue();
                component.set("v.workOrder", d);
                alert("Record is saved Sucessfully");
                $A.get('e.force:refreshView').fire();
                
            }
            else if  (state === "ERROR"){
                alert("failed"); 
                
            }
        })  ;       $A.enqueueAction(action);*/
        
    },
    
    isRefreshed: function(component, event, helper) {
        location.reload();
    },
    
    isnavigated: function(component, event, helper) {
        
        var recordId = component.get("v.recordId");      
        location.href= '/apex/Vfsl_FOAreviewpage?id=' + recordId;
    },
    
    waiveTravel: function(component, event, helper) {
        var lineItems = component.get("v.mydata");
        //var fieldsMap = component.get("v.depnedentFieldMap");
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Type === 'Travel' && lineItems[i].ERP_Billable && lineItems[i].Billing_Type === 'C – Contract') {
                //lineItems[i].category = fieldsMap['Waive'];
                lineItems[i].Billing_Type = 'N – Waived';
                lineItems[i].Billing_Review = 'Waive';
                lineItems[i].Review_Type = 'Contract';
            } else if(lineItems[i].Type === 'Travel' && lineItems[i].ERP_Billable && lineItems[i].Billing_Type === 'P – Paid Service') {
                //lineItems[i].category = fieldsMap['Waive'];
                lineItems[i].Billing_Type = 'O - Other';
                lineItems[i].Billing_Review = 'Waive';
                lineItems[i].Review_Type = 'Overhead';
                lineItems[i].SAP_Service = lineItems[i].HelpDeskJO;     
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        
        component.set("v.mydata",updatedLineItems); 
    },
    
    /*onControllerFieldChange: function(component, event, helper) {  
        var billing = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        var fieldsMap = component.get("v.depnedentFieldMap");
        var updatedLineItems = [];
        //console.log('fieldsMap: ' + JSON.stringify(fieldsMap));
        
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].Review_Type = '';
                lineItems[i].category = fieldsMap[billing];
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        
        component.set("v.mydata",updatedLineItems);*/ 
        
        /*var controllerValueKey = event.getSource().get("v.value"); // get selected controller field value
        var depnedentFieldMap = component.get("v.depnedentFieldMap");
        
        if (controllerValueKey != '--- None ---') {
            var ListOfDependentFields = depnedentFieldMap[controllerValueKey];
            
            if(ListOfDependentFields.length > 0){
                component.set("v.bDisabledDependentFld" , false);  
                helper.fetchDepValues(component, ListOfDependentFields);    
            }else{
                component.set("v.bDisabledDependentFld" , true); 
                component.set("v.listDependingValues", ['--- None ---']);
            }  
            
        } else {
            component.set("v.listDependingValues", ['--- None ---']);
            component.set("v.bDisabledDependentFld" , true);
        }*/
    /*},
    
    onCategoryChange: function(component, event, helper) {  
        var category = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].Review_Type = category;
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        console.log('updatedLineItems: ' + JSON.stringify(updatedLineItems));
        component.set("v.mydata",updatedLineItems); 
    },*/   
    
    onWOLISelectChange: function(component, event, helper) {  
        var selected = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].selected = selected;
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        console.log(JSON.stringify(updatedLineItems));
        component.set("v.mydata",updatedLineItems); 
        component.set("v.selectAll",false); 
    },
    
    selectAllCheckbox: function(component, event, helper) {  
        var selectAll = event.getSource().get('v.value');
        var lineItems = component.get("v.mydata");
        var isTrue = false;
        if(selectAll === true) {
            isTrue = true;
        }
        for(var i = 0; i < lineItems.length; i++) {
            lineItems[i].selected = isTrue;
        }
        component.set("v.mydata",lineItems); 
    }, 
    
    onSSOChange: function(component, event, helper) {  
        var sso = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        
        console.log('sso: ' + sso);
        console.log('woliid: ' + woliid);
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].SAP_Service = sso;
                if(lineItems[i].SAP_Service) {
                    lineItems[i].Billing_Type = 'O - Other';
                } else {
                    lineItems[i].Billing_Type = lineItems[i].origBillingType;
                }
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        console.log(JSON.stringify(updatedLineItems));
        component.set("v.mydata",updatedLineItems); 
    },
        
    onDescriptionChange: function(component, event, helper) {  
        var description = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].Description = description;
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        component.set("v.mydata",updatedLineItems); 
    },
        
    onReasonChange: function(component, event, helper) {  
        var reason = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].Reason_for_Billing_Review = reason;
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        component.set("v.mydata",updatedLineItems); 
    },
    
    onbrchange: function(component, event, helper) {  
        var billingreview = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        var st = component.get("v.midata");
        var wo = component.get("v.workOrder");
        console.log('billingreview: ' + billingreview);
        console.log('woliid: ' + woliid);
        
        var updatedLineItems = [];
        
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].Billing_Review = billingreview;
                
                if(lineItems[i].Billing_Review === 'Waive') {
                    if(lineItems[i].SAP_Service) {
                        lineItems[i].Review_Type = 'SWO/JO';
                    } else {
                        if(lineItems[i].Service_Contract) {
                            lineItems[i].Review_Type = 'Contract';
                            //Adding Billing Type setting for N Waived.
                            lineItems[i].Billing_Type = 'N – Waived';
                        } else {
                            lineItems[i].Review_Type = 'Overhead';
                        }
                    }
                    
                } else {
                    lineItems[i].Billing_Type = lineItems[i].origBillingType;
                }
                
                if(lineItems[i].Review_Type === 'Overhead' && st) {
                    if(wo.RecordType.Name === 'Field Service') {
                        lineItems[i].SAP_Service = st[0].Paid_Service_JO;
                    } else if(wo.RecordType.Name === 'HelpDesk') {
                        lineItems[i].SAP_Service = st[0].HelpDesk_JO;
                    }
                } 

                if(lineItems[i].SAP_Service) {
                    lineItems[i].Billing_Type = 'O – Other';
                }
                if(lineItems[i].Review_type === 'Contract') {
                    lineItems[i].Billing_Type = 'N – Waived';
                }
                             
                if(lineItems[i].Billing_Review === 'Bill') {
                    lineItems[i].Billing_Type = 'P – Paid Service';
                }
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        component.set("v.mydata",updatedLineItems); 
    },
    
    onrtchange: function(component, event, helper) {  
        var reviewtype = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        var st = component.get("v.midata");
        var wo = component.get("v.workOrder");
        console.log('woliid: ' + woliid);
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].Review_Type = reviewtype;
                
                if(lineItems[i].Review_Type === 'Overhead' && st) {
                    if(wo.RecordType.Name === 'Field Service') {
                        lineItems[i].SAP_Service = st[0].Paid_Service_JO;
                    } else if(wo.RecordType.Name === 'HelpDesk') {
                        lineItems[i].SAP_Service = st[0].HelpDesk_JO;
                    }
                } /* shouldn't clear SAP_Service_Order__c ever.
               else {
                lineItems[i].SAP_Service = '';
            }*/
                
                if(lineItems[i].SAP_Service) {
                    lineItems[i].Billing_Type = 'O – Other';
                }
                if(reviewtype === 'Contract' &&!lineItems[i].SAP_Service)
                	lineItems[i].Billing_Type = 'N – Waived';
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        
        component.set("v.mydata",updatedLineItems); 
    },
    
    closeModal: function(component, event, helper) {  
        component.set("v.woApproved",false); 
    }, 
    
    approveWorkOrder: function(component, event, helper) {  
        component.set("v.woApproved",false); 
        var lineItems = component.get("v.mydata");
        
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].SAP_Service) {
                lineItems[i].Billing_Type = 'O – Other';
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        
        var action = component.get("c.Approves");
        action.setParams({
            woObj: JSON.stringify(component.get("v.workOrder")),
            woliList: JSON.stringify(updatedLineItems),
            isApprove: true
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            if (state == 'SUCCESS') {
                alert("Record is saved Sucessfully");
                $A.get('e.force:refreshView').fire();
            } else {
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(action); 
    },
        
    saveWO: function(component, event, helper) {  
        component.set("v.woApproved",false); 
        var lineItems = component.get("v.mydata");
        
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].SAP_Service) {
                lineItems[i].Billing_Type = 'O – Other';
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        
        var action = component.get("c.Approves");
        action.setParams({
            woObj: JSON.stringify(component.get("v.workOrder")),
            woliList: JSON.stringify(updatedLineItems),
            isApprove: false
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            if (state == 'SUCCESS') {
                alert("Record is saved Sucessfully");
                $A.get('e.force:refreshView').fire();
            } else {
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(action); 
    },    
        
    simulateWO: function(component, event, helper) {   
        
        var action = component.get("c.simulateBillingWO");
        action.setParams({
            wo: component.get("v.workOrder")
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            if (state == 'SUCCESS') {
                alert("Record is saved Sucessfully");
                $A.get('e.force:refreshView').fire();
            } else {
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(action); 
    }, 
    
    rejectWO: function(component, event, helper) {  
        var action = component.get("c.reject");
        action.setParams({
            woObj: JSON.stringify(component.get("v.workOrder"))
        });
        
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            if (!result) {
                alert("Record is saved Sucessfully");
                $A.get('e.force:refreshView').fire();
            } else {
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(action); 
    },
    
    viewWoli: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.Id,'_blank');
    },
    
    viewLocation: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.LocationId,'_blank');
    },
    
    viewCase: function(component, event, helper) {
        var caseRecord = component.get("v.case");
        window.open('/' + caseRecord.Id,'_blank');
    },
    
    viewWoAsset: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.Top_Level_Asset__c,'_blank');
    },
    
    viewWoliDetail: function(component, event, helper) {
        var objId = event.currentTarget.id;
        window.open('/' + objId,'_blank');
    }, 
 
    viewWoDM: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.District_Manager__c,'_blank');
    },
    
    viewWoSR: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.Service_Resource__c,'_blank');
    },
})