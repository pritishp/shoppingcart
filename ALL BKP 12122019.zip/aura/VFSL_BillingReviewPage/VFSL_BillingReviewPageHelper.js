({
    getData : function(component) {
        var action = component.get('c.getWOLI');
         action.setParams({
            "woid": component.get("v.recordId")
        });
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            var woli = response.getReturnValue();
            //var fieldsMap = response.getReturnValue().fieldsMap;
            //var fieldsSet = Object.keys(fieldsMap);
            //component.set('v.depnedentFieldMap', fieldsMap);
            //console.log('fieldsMap' + JSON.stringify(fieldsMap));
            if (state === "SUCCESS") {
                for(var i = 0; i < woli.length; i++) {
                    woli[i].origBillingType = woli[i].Billing_Type;
                    if(woli[i].ERP_Billable) {
                        woli[i].selected = true;
                    } else {
                        component.set('v.selectAll', false);
                    }
                    	
                    //woli[i].waiveCategory = fieldsMap['Waive'];
                    //woli[i].billCategory = fieldsMap['Bill'];
                    //woli[i].category = fieldsMap[woli[i].Billing_Review];
                    //woli[i].billing = fieldsSet;
                    //woli[i].action = '';
                }
                
                component.set('v.mydata', woli);
                console.log('my data: '+JSON.stringify(woli));
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);  
            }
        }));
        
        $A.enqueueAction(action);
    },
    
   getData1 : function(component) {
        var action = component.get('c.getRecordAttachment');
         action.setParams({
            "entityId": component.get("v.recordId")
       });
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.mydatas', response.getReturnValue());
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);  
            }
        }));
       $A.enqueueAction(action);
   },
    
    getUser : function(component) {
        var action = component.get('c.fetchUser');
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.userInfo', response.getReturnValue());
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);  
            }
        }));
        $A.enqueueAction(action);
    }, 
    
    getData2 : function(component) {
        var action = component.get('c.getServiceTerritory');
        action.setParams({"woid": component.get("v.recordId")});
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.midata', response.getReturnValue());
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);  
            }
        }));
        $A.enqueueAction(action);
    }
})