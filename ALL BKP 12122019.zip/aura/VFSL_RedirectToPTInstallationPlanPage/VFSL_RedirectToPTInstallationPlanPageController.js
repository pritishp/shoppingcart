({
    doInit : function(component, event, helper) {
        var getRecId = component.get("v.recordId");
        
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
        componentDef: "c:vFSL_PT_CreateInstallationPlan",
        componentAttributes: {
            "recordId" : getRecId
	     } 
    });
    evt.fire(); 
    }
})