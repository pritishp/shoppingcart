({
	getWrapperData : function(component, event, helper) {
        component.set("v.loaded", true);
        helper.getAccountDetails(component, event, helper);
        helper.getContactInfo(component, event, helper);
        helper.getURLParameters (component, event, helper);
        var action = component.get("c.incrementReadOnlyCount");
        var applicationId = component.get("v.appId");
        action.setParams ({
            appId: applicationId
        });
       action.setCallback(this, function(a) { 
       var result = a.getReturnValue();
       	if(result!== '' && result!==null){
            helper.getWrapperData (component, event, helper);
       	} 
      });
      $A.enqueueAction(action); 
	},
    carouselClick: function(component, event, helper) {
    	component.set("v.appVideoModalOpen", true);
	},
    openAppVideoModal: function(component, event, helper) {
        component.set("v.appVideoModalOpen", true);
    },
	closeAppVideoModal: function(component, event, helper) {
        component.set("v.appVideoModalOpen", false);
    }
})