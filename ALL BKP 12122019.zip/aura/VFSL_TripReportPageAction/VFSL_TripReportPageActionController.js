({
	doInit : function(component, event, helper) {
		var navEvt = $A.get("e.force:navigateToComponent");
        navEvt.setParams({
            componentDef: "c:vfsl_tripReportPage",
            componentAttributes :{"recordId":component.get('v.recordId')}
        });
        navEvt.fire();
	}
})