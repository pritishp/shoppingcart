({
	getAccountDetails : function(component,event,helper) {
        var acc= component.get("v.objAccount");
        console.log('getAccountDetails Landing  ' +acc);
        if(!acc){
             var action = component.get("c.getAccountDetails"); 
             action.setCallback(this, function(a) {
             var result = a.getReturnValue();
             console.log('result ---->' + JSON.stringify(result));
             console.log('result.length===='+Object.keys(result).length);
             var sizeObj = Object.keys(result).length;
             if(sizeObj > 0) {
                 component.set("v.isInternalUser",false);
                 component.set("v.objAccount", result);
                 component.set("v.selectedAccountRecord", result); 
                 if( typeof result.Id != 'undefined' ){
                     var accId = result.Id;
                     component.set("v.accountId" ,accId);
                     helper.getAccountAfterloader(component,event,helper,accId);
                 }
             } else {
                component.set("v.isInternalUser",true);
                 //check if Cart has account
                 helper.getAccountFromCart(component,event,helper);
             }         
             console.log('isInternalUser ---->' + component.get("v.isInternalUser"));         
          });
          $A.enqueueAction(action);
      }else{
             component.set("v.isInternalUser",false);
             component.set("v.selectedAccountRecord", component.get("v.objAccount"));
             console.log('accId ' +acc.Id);
             component.set("v.accountId" ,acc.Id);
             helper.getAccountAfterloader(component,event,helper,acc.Id);
        }
       ; 
       
	},
    getContactInfo : function(component) {
		 var action = component.get("c.getContactDetails"); 
         action.setCallback(this, function(a) {
         var result = a.getReturnValue();
         console.log('objContact=='+JSON.stringify(result));    
             if(result!== '' && result!==null){
                 component.set("v.objContact" , result);
             }
      });
      $A.enqueueAction(action);
      
	},
    getParentProductDetails : function(component) {
        this.getURLParameters (component);
         var catalogId = component.get("v.catlogId");
         console.log('==catalogId=='+catalogId);
		 var action = component.get("c.getBAParentProduct"); 
         action.setParams ({
            catalogId: catalogId,
            accountId: component.get("v.accountId")
        });
         action.setCallback(this, function(response) {
          var state = response.getState();
         if (state === "SUCCESS") {
             var result = response.getReturnValue();
             component.set("v.ifPermitted", result.isPermitted);
             console.log('getBAParentProduct result ---->' + JSON.stringify(result));
             component.set("v.objHeaderProduct",result);
            
            this.setBreadCrumbs(component);
         }  
         component.set("v.loaded", false);
      });
      $A.enqueueAction(action);
	},
  
     getURLParameters : function (component) {
         console.log('Inside');
         // the function that reads the url parameters
         var getUrlParameter = function getUrlParameter(sParam) {
             var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                 sURLVariables = sPageURL.split('&'),
                 sParameterName,
                 i;
             
             for (i = 0; i < sURLVariables.length; i++) {
                 sParameterName = sURLVariables[i].split('=');
                 
                 if (sParameterName[0] === sParam) {
                     return sParameterName[1] === undefined ? true : sParameterName[1];
                 }
             }
         };
         console.log('account---'+getUrlParameter('accId'));
         //set the src param value to my src attribute
         component.set("v.catlogId", getUrlParameter('catId'));
         component.set("v.selectedAfterLoader", getUrlParameter('afterLoader'));
         if(getUrlParameter('productType'))
             component.set("v.selectedTabId", getUrlParameter('productType')); 
         
         component.set("v.productNumber", getUrlParameter('productNumber'));
         component.set("v.prodGroup", getUrlParameter('productGroup')); 
     },
    setBreadCrumbs : function (component) {
        console.log('name==2='+component.get("v.objHeaderProduct.objProduct.Product__r.Name"));
        var breadcrumbCollection = [
            {label: 'Home', name: component.get("v.prodGroup") },			
			{label: component.get("v.prodGroup"), name: component.get("v.prodGroup") },
            {label: component.get("v.objHeaderProduct.objProduct.Product__r.Name"), name: ''}
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },
    addToCart : function (component, event, helper) {
        //var ctarget = event.currentTarget;
        var id_str = event.getSource().get("v.value");
        console.log('==prod=='+id_str);
        var prodDiscount = component.get("v.objHeaderProduct.prodDiscount");        
        var unitPrice = component.get("v.objHeaderProduct.objProduct.Product__r.NA_Target_Price__c");
        var conversionRate= component.get("v.conversionRate");
        console.log('proddiscount ' +prodDiscount);
        console.log('unitPrice ' +unitPrice);
        var action = component.get("c.addCartItem");
        var quantity=component.find('qty').get('v.value');
        if(component.get('v.selectedAccountRecord')){
            var accountId = component.get('v.selectedAccountRecord').Id;
        }         
        
        if(component.get('v.selectedContactRecord')){
            var contactId = component.get('v.selectedContactRecord').Id;              
        }
        
        if(typeof accountId === 'undefined'){
            helper.handleShowToast(component, event, helper, 'Account not selected. Please select Account from filter panel!','Info', 'Info');
            return false;
        }        
        
        action.setParams ({
            productId: id_str,
            quantity:quantity,
            prodDiscount : prodDiscount*conversionRate,
            unitPrice :unitPrice*conversionRate,
            accountId: accountId,
            contactId: contactId,
			productModel : component.get("v.prodGroup")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var msg = response.getReturnValue();
                var variant;
                if(msg.includes('Success')) {
                   variant = 'Success';
                    component.set("v.cartCount", 1);
                }else if(msg.includes('Subscription')){
                    console.log('Warning');
                 	variant = 'Warning';   
                }else if(msg.includes('Exception')){
                 	variant = 'Error';   
                } else {
                    variant = 'Info';
                }
                helper.handleShowToast(component, event, helper, msg,variant,variant);
                component.set('v.ifQtyAllowed',true);
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
                component.find('qty').set('v.value',0)
            }
            else {
                helper.handleShowToast(component, event, helper, 'Exception Occurred !','Error', 'Error');
            }
        });
        $A.enqueueAction(action);
    },
    handleShowToast : function(component, event, helper, msg, variant,title) {
        component.find('notifLib').showToast({
            "title": title,
            "message": msg,
            "variant" : variant
        });
    },
    
  /*  openSearchAccountModal: function(component, event, helper) { 
    	component.set("v.accountSearchModalOpen", true);        
    },
    closeSearchAccountModal: function(component, event, helper) { 
    	component.set("v.accountSearchModalOpen", false);
    },
    getAccounts: function(component, event, helper) { 
    	var action = component.get("c.fetchAccounts");
        var index = parseInt(component.get('v.indexAccountSearch'));
        var blockSize = parseInt(component.get('v.blockSizeAccountSearch'));
        action.setParams({
            'searchKeyWord': component.get('v.searchAccountInputValue'),
            'index': index,
            'blockSize': blockSize 
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();

                component.set('v.listOfAccountRecords',storeResponse);
            }
        });
        $A.enqueueAction(action);
        
        //Get Total Accounts Count
        var actionAccountCount = component.get("c.fetchTotalAccountCount");
        actionAccountCount.setParams({
            'searchKeyWord': component.get('v.searchAccountInputValue'),                      
        });
        actionAccountCount.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                component.set('v.totalAccountsCount', storeResponse);
                console.log(storeResponse);
                var totalAccountsCount = parseInt(storeResponse);
				var index = parseInt(component.get('v.indexAccountSearch'));
        		var blockSize = parseInt(component.get('v.blockSizeAccountSearch'));
                if((index + blockSize) >= totalAccountsCount){            		
                    document.getElementById("nextAccountSearchBtn").disabled = true;
                }else{
                    document.getElementById("nextAccountSearchBtn").disabled = false;
                }

				var prevIndex = index - blockSize;
                if (prevIndex < 0){                    
                    document.getElementById("prevAccountSearchBtn").disabled = true;
                }else{
                    document.getElementById("prevAccountSearchBtn").disabled = false;
                }			
	                
            }
        });
        $A.enqueueAction(actionAccountCount);
    },*/
    deleteCartItem: function(component,event,helper) {        
       var accountId = component.get('v.newAccountRecord.Id');
		console.log('deleteCartItem----'+accountId);        
        var action = component.get("c.deleteCart");
        action.setParams({
            'accountId': accountId,                      
        });
        action.setCallback(this, function(response) {            
            var state = response.getState();
            if (state === "SUCCESS") {
            	var appEvent = $A.get("e.c:vMTP_reloadHeader");
            	appEvent.fire(); 
                component.set("v.cartCount", 0);
            }    
        }); 
		$A.enqueueAction(action);              
    },
    getAccountFromCart: function(component,event,helper) {
        var action = component.get("c.getAccountFromCart"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            console.log(JSON.stringify(result));
            var accObj = JSON.parse(result[0]);
            var cartCount = parseInt(result[1]);
            console.log('accObj=='+JSON.stringify(accObj));
            console.log('cartCount=='+cartCount);            
            var sizeObj = Object.keys(accObj).length;
            if(sizeObj > 0) {
                component.set("v.objAccount", accObj);
         	 	component.set("v.selectedAccountRecord", accObj); 
                var accId = accObj.Id;
                helper.getAccountAfterloader(component,event,helper,accId);
            } else {
                helper.getParentProductDetails(component); 
            }
            component.set("v.cartCount", cartCount);
        }); 
		$A.enqueueAction(action);        
    },
    getAccountAfterloader: function(component,event,helper,accId) {    
        var action = component.get("c.fetchAccountAfterloader"); 
        action.setParams({
            'accountId': accId,                      
        });
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();			        
            var afterLoaderStr = '';
            if (result.indexOf("H64") > -1) {
    			afterLoaderStr += ' / ' + 'GammaMed';
			}
			if (result.indexOf("H60") > -1) {
    			afterLoaderStr += ' / ' + 'VariSource';
			}
			if (result.indexOf("H65") > -1) {
    			afterLoaderStr += ' / ' + 'Bravos';
			}
            //if (result.indexOf("HID") > -1) {
    		//	afterLoaderStr += ' / ' + 'Identify';
			//}
            if (result.indexOf("HCL") > -1) {
    			afterLoaderStr += ' / ' + 'Calypso';
			}
            afterLoaderStr = afterLoaderStr.slice(3);			
            component.set('v.accountAfterLoader', afterLoaderStr);
            component.set("v.accountId" ,accId);
            helper.getParentProductDetails(component); 
        }); 
        $A.enqueueAction(action); 
    },
    addAccountToCart: function(component, event, helper,accId) {  
        var accountId = component.get("v.selectedAccountRecord.Id");
        console.log('addAccountToCart----'+accountId);
        if( typeof accountId !== 'undefined' && accountId !== ''){
            var action = component.get("c.addAccountToCart");
            action.setParams({
                'accountId': accId,                      
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log('addAccountToCart success');                  
                }
            });
            $A.enqueueAction(action);
        }
    },
    getAllowedProdQty: function(component, event, helper,proCode,quantity,maxQuantity) {     
            var action = component.get("c.fetchCartProductQty");
            action.setParams({
                'prodCode': proCode,                      
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var result=response.getReturnValue(); 
                    console.log('result---'+result+'maxQuantity--'+maxQuantity);
                    var allowedCartQty=parseInt(maxQuantity)-parseInt(result);
                    console.log('allowedCartQty---'+allowedCartQty);
                    if(parseInt(quantity)>allowedCartQty ){
                        component.set('v.ifQtyAllowed',false);
                    }
                    else{
                        helper.addToCart(component, event, helper);
                    }
                }
            });
            $A.enqueueAction(action);
    },
    
})