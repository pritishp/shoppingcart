({
	doInit : function(component, event, helper) {
        component.set("v.loaded", true);
        helper.getAccountDetails(component,event,helper);
        helper.getContactInfo(component, event, helper);
  	},
    
    clearErrorMessage : function (component, evnt, helper) {
        component.set('v.ifQtyAllowed',true);
    },
    
    AddToCart : function(component, event, helper) {
        var quantity=component.find('qty').get('v.value');
        var maxQuantity=component.get('v.objHeaderProduct.maxQty');
        var proCode=component.get('v.objHeaderProduct.objProduct.Product_Number__c');
        console.log('quantity--'+quantity+'---max---'+maxQuantity+'--proCode--'+proCode);
        if(quantity==0){
           helper.handleShowToast(component, event, helper, 'Please add quantity of product','Error', 'Error'); 
        }
        else{
            if((maxQuantity && quantity>maxQuantity)){
                component.set('v.ifQtyAllowed',false);
            }
            else{
                 helper.getAllowedProdQty(component, event, helper,proCode,quantity,maxQuantity);
            }
        }
  	},
    openCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", true);
    },
	closeCartDeleteModal: function(component, event, helper) {
        component.set("v.cartDeleteModalOpen", false);
    },
    removeCart: function(component, event, helper) {
        helper.deleteCartItem(component, event,helper);
        var newSelectedRecord = component.get("v.newAccountRecord");
        component.set("v.selectedAccountRecord" , newSelectedRecord);
        component.set("v.cartDeleteModalOpen", false);
    },
    imageClick : function (component, event, helper){
        component.set("v.appImageModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
      component.set("v.appImageModalOpen", false);
   },
    getAccountVal: function (component, event){
        console.log("App Event Value");
        var accInfo = event.getParam("recordId");
       
        component.set("v.objAccount", accInfo);
         console.log('AccountId ' +accInfo);
	},
    
    fetchCurrencyValue : function (component, event) {
      console.log("currency existing " +component.get("v.currencyISOCode"));
      component.set("v.conversionRate", event.getParam("conversionRate")); 
      component.set("v.currencyISOCode", event.getParam("selectedCurrency"));  
    },
    
    callAction: function(cmp, event) {
		component.set("v.flagCheck", true);
    }
})