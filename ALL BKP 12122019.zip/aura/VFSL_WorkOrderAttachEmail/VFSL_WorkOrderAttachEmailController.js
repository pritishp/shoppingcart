({
	doInit : function(component, event, helper) {
        
        console.log('Record Id is--'+component.get("{!v.recordId}"));
        
        component.set('v.attachmentcolumns', [
            {label: 'Title/Name', fieldName: 'attachmentName', type: 'text'},
            {label: 'Last Modified Date', fieldName: 'attachmentLastModified', type: 'text'}
        ]);
		helper.getAttachments(component);
        
        
        component.set('v.contactcolumns', [
            {label: 'Name', fieldName: 'contactName', type: 'text'},
            {label: 'Role', fieldName: 'contactRole', type: 'text'},
            {label: 'Email', fieldName: 'contactEmail', type: 'text'}
        ]);
        
        var action = component.get("c.getWOAccount");
        action.setParams(
            {
                woId : component.get("{!v.recordId}")
            }
        );
        // Method to get the Work Order Details
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
			console.log('Account Is--'+response.getReturnValue());
                var woobj = response.getReturnValue();              
        		//console.log('casenum'+woobj.Case.CaseNumber+woobj.WorkOrderNumber+woobj.AccountId);
	        	component.set("{!v.woNumber}",woobj.WorkOrderNumber);
                if(woobj.Case) component.set("{!v.wocasenumber}",woobj.Case.CaseNumber);
                if(woobj.Contact) component.set("{!v.wocontactname}",woobj.Contact.Name);
                if(woobj.Location) component.set("{!v.wolocationcity}",woobj.Location.City__c);
                if(woobj.Location) component.set("{!v.wolocationname}",woobj.Location.Name);
				if(woobj.Account) component.set("{!v.woaccountname}",woobj.Account.Name);
                             
                component.set("{!v.wocontactemail}",woobj.Contact_Email__c);
        
                component.set("{!v.subject}",'Documents: Case '+component.get("v.wocasenumber")+','+component.get("v.woNumber")+','+component.get("{!v.wolocationname}")+','+component.get("{!v.wolocationcity}"));
                
			helper.getContacts(component,woobj.AccountId);        
        	helper.getContactRoles(component,woobj.AccountId);                
            }
         });

        $A.enqueueAction(action);        		        
        
	},
    send : function(component, event, helper) {
		helper.sendEmail(component);
	},
    
    cancel : function(component, event, helper) {
		var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
		dismissActionPanel.fire(); 
        
        var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
            		"slideDevName": "detail"
        		});
        backtoRecord.fire();
	},
    
    handleClick : function(component, event, helper) {
        component.set("{!v.errorMessage}","");
        var selAttachs = '';
        var selAttachmentsList = component.find('attachtable').getSelectedRows();//component.get("{!v.selectedAttachments}");
        if(selAttachmentsList.length==0)
        {
            component.set("{!v.errorMessage}","Please Select an Attachment");
            return false;
        }
        
        for(var i=0;i<selAttachmentsList.length;i++)
        {
            selAttachs += selAttachmentsList[i].attachmentId+',';
        }
        
    	var action = component.get("c.getDownloadablePDF");
        action.setParams(
            {
                selectedDocs : selAttachs
            }
        );
        //window.open("data:application/pdf;base64,TESTING"); 
        action.setCallback(this, function(response) {
            console.log('Response is'+response.getReturnValue());
           let state = response.getState();
           if (state === "SUCCESS") {
            let downloadLink = document.createElement("a");
               var pdfstring = "testing";
           //downloadLink.href = "data:application/pdf;base64,"+encodeURI(pdfstring);
           downloadLink.target = '_self';
           downloadLink.download = "filename_wo.pdf";
                var blob = new Blob([response.getReturnValue()], { type: 'application/pdf' });

                  // create an object URL from the Blob
                  var URL = window.URL;
                  var downloadUrl = URL.createObjectURL(blob);
                
                  // set object URL as the anchor's href
                  downloadLink.href = downloadUrl;
                
                  // append the anchor to document body
                  document.body.appendChild(downloadLink);
                                  
           downloadLink.click();
           } else {
                console.log("Failed with state: " + state);
           }
    })

    $A.enqueueAction(action);
    }
    
})