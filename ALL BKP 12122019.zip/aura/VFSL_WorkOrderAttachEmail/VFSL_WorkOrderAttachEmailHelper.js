({
	sendEmail : function(component) {
        console.log('In Here'+component.get("{!v.subject}"));
        component.set("{!v.errorMessage}","");
        var selAttachmentsList = component.find('attachtable').getSelectedRows();//component.get("{!v.selectedAttachments}");
        var selContactsList = component.find('contactable').getSelectedRows();//component.get("{!v.selectedContacts}");
        var selContactRolesList = component.find('contactrolestable').getSelectedRows();//component.get("{!v.selectedContactRoles}");
        console.log(selAttachmentsList.length);
        console.log(selContactsList.length);
        console.log(selContactRolesList.length);
        
        var selEmails = '';
        var selAttachs = '';
        
        if(selAttachmentsList.length==0)
        {
            component.set("{!v.errorMessage}","Please Select an Attachment");
            return false;
        }
            
        if(selContactsList.length==0 && selContactRolesList.length==0)
        {
            if(component.get("v.additionalrecipients")==null)
            {
        		component.set("{!v.errorMessage}","Please Select atleast a contact or a contact role");
            	return false;
            }
        }
        
        if(component.get("v.additionalrecipients"))
        {
        	var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;  
            var addEmails = component.get("v.additionalrecipients").split(';');
            for(var i=0;i<addEmails.length;i++)
            if(!addEmails[i].match(regExpEmailformat))
            {
            	{
             		component.set("{!v.errorMessage}","Please Enter valid Email Address in Additoinal Email Fields");
            		return false;   
            	}
        	}
        }
        
        if(component.get("v.subject") == null)
        {
        	component.set("{!v.errorMessage}","Please Enter Subject");
            return false;
        }
        
        if(component.get("v.emailbody") == null)
        {
        	component.set("{!v.errorMessage}","Please Enter Body");
            return false;
        }
        
        
        for(var i=0;i<selAttachmentsList.length;i++)
        {
            console.log('Attache'+selAttachmentsList[i].attachmentId);
            selAttachs += selAttachmentsList[i].attachmentId+',';
        }
        
        for(var i=0;i<selContactsList.length;i++)
        {
            selEmails += selContactsList[i].contactEmail+',';
        }
        
        for(var i=0;i<selContactRolesList.length;i++)
        {
            selEmails += selContactRolesList[i].contactEmail+',';
        }
        
        console.log('Emails'+component.get("v.mergePdfs"));
        
         	var action;        	
        // Check if Merge PDFs is Checked
        if(component.get("v.mergePdfs").toString() == 'true') action = component.get("c.sendEmailMerge");
        else action = component.get("c.sendEmail");
		// Call Send Email Apex Method
        action.setParams(
            {
                subject : component.get("v.subject"),
                emailbody : component.get("v.emailbody"),
                additonalemails : component.get("v.additionalrecipients"),
                emails : selEmails,
                emailCC : component.get("v.carbonchecked").toString(),
                selectedDocs : selAttachs
            }
        );
       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
			if(response.getReturnValue())
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Email Sent Successfully!",
                    "type" : "success",
                    "message": "Please wait while we refresh the page"
                });
                toastEvent.fire();
                setTimeout(function() {location.reload();}, 3000);
            }
            else 
            {
				var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error occurred while sending email",
                    "type" : "error",
                    "message": "Please try again after sometime"
                });
                toastEvent.fire();  
                setTimeout(function() {location.reload();}, 3000);
            }
            }
         });

        $A.enqueueAction(action);
	},
    getAttachments : function(component,accountId) {
        
         var action = component.get("c.getFiles");
        
        action.setParams(
            {
                woId : component.get("{!v.recordId}")
            }
        );
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
			console.log(response.getReturnValue());
                component.set("{!v.attachmentsdata}",response.getReturnValue());
            }
         });

        $A.enqueueAction(action);
    },
    getContacts : function(component,accountId) {
        console.log('In Contact'+accountId);
         var action = component.get("c.getContacts");
        
        action.setParams(
            {
                accountId : accountId
            }
        );
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
			console.log(response.getReturnValue());
                component.set("{!v.contactsdata}",response.getReturnValue());
            }
         });

        $A.enqueueAction(action);
    }, 
	getContactRoles : function(component,accountId) {
         console.log('In Contact Roles'+accountId);
         var action = component.get("c.getContactRoles");
        
        action.setParams(
            {
                accountId : accountId
            }
        );
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
			console.log(response.getReturnValue());
                component.set("{!v.contactRolesdata}",response.getReturnValue());
            }
         });

        $A.enqueueAction(action);
    }    
})