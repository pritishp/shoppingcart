({
	
  doInit : function(component,event,helper){
    console.log("doInit is called.-----");
       var iframeURL =  $A.get('$Resource.vMarket_TermsOfUse');
      console.log("iframeURL.-----"+iframeURL);
       component.set("v.iframeUrl", iframeURL);
  },
    
    
    agreeTermsClick : function(component,event,helper){       
    helper.agreeTermsClick(component, event, helper);
  },
    
    disAgreeTermsClick1 : function(component,event,helper){
        console.log('disAgreeTermsClick js Controller--');
        //alert('disAgreeTermsClick js Controller--');
    helper.disAgreeTermsClick(component, event, helper);
  },
    

})