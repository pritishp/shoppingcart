({
    agreeTermsClick : function(component,event,helper) {
        var action = component.get("c.agreeTerms"); 
        // action.setParams({ terms : 'agree'
        //                  });
        action.setCallback(this, function(a) {             
            var result = a.getReturnValue();  
            console.log('agreeTerms before if=='+result); 
            if(result == true){                 
                component.set("v.termsOfUseChecked",true);
                console.log('agreeTerms=='+result);    
                document.querySelector(".headerWrapper").style.display = 'block';
            }
            else{
                //component.set("v.isTermsOfUseChecked",false); 
                //console.log('agreeTermsClick=='+result);                                    
            }                 
        });
        $A.enqueueAction(action);
    },
    
    disAgreeTermsClick : function(component,event,helper) {  
        console.log('disAgreeTermsClick helper--');
        var logoutUser = component.get("c.disAgreeTerms");
        logoutUser.setCallback(this, function(response) {              
              var state = response.getState();
	            if (state === "SUCCESS") {
	               var logoutUrl = response.getReturnValue();
                    //window.location.replace('/varianMarketPlace/s/login/');
                    window.location.replace('/apex/vMarketPlaceLogoutPage');
	            }else{
	            	console.log('----ERROR--authorize--'+response.getError());
	            }
        });
        $A.enqueueAction(logoutUser);
	},  
    })