({
	getACHAccount : function(component, event, helper) {
		var action = component.get("c.getExistingCustomer");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue(); 
                console.log('-ach----'+JSON.stringify(resp));
                component.set("v.listOfACHAccount", resp);
            }
            component.set("v.loaded", false);
        });
        $A.enqueueAction(action);
	},
    getVerifiedACHAccount : function(component, event, helper) {
		var action = component.get("c.getVerifiedExistingCustomer");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue(); 
                console.log('-ach----'+JSON.stringify(resp));
                component.set("v.listOfACHAccount", resp);
            }
            component.set("v.loaded", false);
        });
        $A.enqueueAction(action);
	},
    removeAccount : function(component, event, helper, sfId) {
		var action = component.get("c.deleteACH");
        action.setParams ({
            achId: sfId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue(); 
                if(resp == true) {
                 	helper.getACHAccount(component, event, helper);
                }
                
            }
        });
        $A.enqueueAction(action);
	},
})