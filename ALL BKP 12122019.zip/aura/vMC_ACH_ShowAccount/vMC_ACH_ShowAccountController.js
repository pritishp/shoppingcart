({
	doInit : function(component, event, helper) {
        component.set("v.loaded", true);
        var flag=component.get("v.isVarifiedACH");
        if(flag){
            helper.getVerifiedACHAccount(component, event, helper);
        }
        else{
             helper.getACHAccount(component, event, helper);
        }
       
	},
    removeAccount : function(component, event, helper) {
        var sfId = event.getSource().get("v.name");
        helper.removeAccount(component, event, helper,sfId);
	},
    openVerificationModal: function(component, event, helper) {
        var ach = event.getSource();
        var achId = ach.get("v.value");
        component.set("v.achAccId", achId);
		component.set("v.verificationModalOpen", true);
	},
    selectACHAccount : function(component, event, helper) {
        debugger;
        var achCustomerNumber = event.currentTarget.dataset.value;
        component.set("v.loadACHBtnIframe", true);
        var totalAmt=component.get("v.totalPayableAmt");
         var achMessage = totalAmt + '#' + achCustomerNumber;
       //  var vfOrigin = "https://" + component.get("v.vfACHHost");
       var vfOrigin = 'https://sfdev1-varian.cs62.force.com';
         setTimeout(function(){ var vfWindow = component.find("achFrame").getElement().contentWindow;
                                  vfWindow.postMessage(achMessage, vfOrigin); }, 1000);
    }
})