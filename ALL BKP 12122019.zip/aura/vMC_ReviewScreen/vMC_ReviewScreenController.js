({
	doInit : function (component, event, helper) {       
        var selectedShipToRecord = component.get('v.selectedShipToRecord');
        console.log('selectedShipToRecord==='+selectedShipToRecord);
    },
    onRender: function(component, event, helper) {
        console.log('accountInfo---'+JSON.stringify(component.get('v.accountInfo')));
        console.log('contactInfo---'+JSON.stringify(component.get('v.contactInfo')));
    }
})