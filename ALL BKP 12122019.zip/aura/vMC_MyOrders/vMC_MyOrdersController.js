({
    doInit : function (component, event, helper) {
        helper.getURLParameters (component, event, helper);
        component.set('v.processing',true);
        /*if(component.get('v.isInternal') && (component.get('v.orderList.Status__c')=='Pending PO review')){
             component.set('v.isAvailableForApproval',true);
        }*/
    },
	uploadPO : function(component, event, helper) {
		component.set("v.isModalOpen", true);        
	},
        
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "False"  
        component.set("v.isModalOpen", false);
        if(component.get("v.uploadedFiles").length>0)
        	helper.savePO(component,helper);
   },
    
    closeRejectionModal : function (component, event, helper) {
        component.set("v.rejectionModal", false);
    },
    
    downloadPO : function (component, event, helper) {
        component.set("v.isPOModalOpen", true);
    },
    
    downloadOrderPdf : function (component, event, helper) {
        var orderId = component.get("v.orderId");
        /*
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": $A.get("$Label.c.vMC_Print_Quote") +'/Quote?orderId=' + orderId,
            "isredirect": "true"
        });
        urlEvent.fire();
        */
        var url = window.location.origin + '/apex/Quote?orderId=' + orderId;
        window.open( url, '_blank');
    },
    
    downloadTPOrderPdf : function (component, event, helper) {
        var orderId = component.get("v.orderId");
        /*
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": $A.get("$Label.c.vMC_Print_Quote") +'/vMTP_Quote?orderId=' + orderId,
            "isredirect": "true"
        });
        urlEvent.fire();
        */
        var url = window.location.origin + '/apex/vMTP_Quote?orderId=' + orderId;
        window.open( url, '_blank');
    },
    
    approve : function (component, event, helper) {
        helper.updateOrderApproval (component, helper, true);
    },
    reject : function (component, event, helper) {
        component.set("v.rejectionModal", true);
    },
    submitRejection : function (component, event, helper) {
        if(component.get("v.reason")) {
            component.set("v.validity", true);
            helper.updateOrderApproval (component, helper, false);
            component.set("v.rejectionModal", false);
        } else {
             component.set("v.validity", false);
        }
        
    },
	addBackOrder : function(component, event, helper) {
		component.set("v.isBackOrderModalOpen", true);
	},
    closeBackOrderModal : function(component, event, helper) {
		component.set("v.isBackOrderModalOpen", false);
	},
    updateBackOrder : function(component, event, helper) {
        var backOrder = component.find("backOrder");
        if(component.get("v.backOrderComment")) {
            component.set("v.backOrderValidity", true);
            helper.updateBackOrder(component);
            component.set("v.isBackOrderModalOpen", false);
        } else {
            backOrder.reportValidity();
            component.set("v.backOrderValidity", false);
        }
	},
    onReSubmitOrder : function(component, event, helper) {
        console.log('hello');
        component.set('v.processing',true);
        helper.callResubmitOrder(component);
	},
    editNetTerm : function (component, event, helper) {
        var editNetTerm = component.find("editNetTerm");
        var saveNetTerm = component.find("saveNetTerm");
        var netTermOutput = component.find("netTermOutput");
        var netTermInput = component.find("netTermInput");
        $A.util.toggleClass(saveNetTerm, 'slds-hide');
        $A.util.toggleClass(editNetTerm, 'slds-hide');
        $A.util.toggleClass(netTermOutput, 'slds-hide');
        $A.util.toggleClass(netTermInput, 'slds-hide');
    },
    saveNetTerm : function (component, event, helper) {
		var editNetTerm = component.find("editNetTerm");
        var saveNetTerm = component.find("saveNetTerm");
        var netTermOutput = component.find("netTermOutput");
        var netTermInput = component.find("netTermInput");
        $A.util.toggleClass(saveNetTerm, 'slds-hide');
        $A.util.toggleClass(editNetTerm, 'slds-hide');
        $A.util.toggleClass(netTermOutput, 'slds-hide');
        $A.util.toggleClass(netTermInput, 'slds-hide');
        helper.updateNetTerm (component, event, helper);
    }, 
    
    deliveryAccordian : function(component,event,helper) {
       var a = event.target.dataset.index;
      	console.log('--aa--'+a);
      var acc = component.find(a);
        for(var cmp in acc) {
        	$A.util.toggleClass(acc[cmp], 'slds-show');  
        	$A.util.toggleClass(acc[cmp], 'slds-hide');  
       }
	},
    deliveryAccordianOpen: function(component, event, helper) {
        var a = event.target.dataset.index;
      	console.log('--aa--'+a);
        var items = component.find("delLineInfo");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');
        var items_accOpen = component.find("accOpen");
        if(!items_accOpen.length) items_accOpen = [items_accOpen];
		$A.util.addClass(items_accOpen[parseInt(event.target.dataset.index)],'slds-hide');
        $A.util.removeClass(items_accOpen[parseInt(event.target.dataset.index)],'slds-show');        
        
        var items_accClose = component.find("accClose");
        if(!items_accClose.length) items_accClose = [items_accClose];
		$A.util.addClass(items_accClose[parseInt(event.target.dataset.index)],'slds-show');
        $A.util.removeClass(items_accClose[parseInt(event.target.dataset.index)],'slds-hide');
		        
    },
    deliveryAccordianClose: function(component, event, helper) {
        console.log('test out=='+component.find("delLineInfo"));
        var items = component.find("delLineInfo");
        if(!items.length) items = [items];
         console.log('items--'+items);
        console.log('event--'+event.target.dataset.index);
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');
        //$A.util.removeClass(component.find("accOpen"),'slds-hide');
        //$A.util.removeClass(component.find("accClose"),'slds-show');
        var items_accOpen = component.find("accOpen");
        if(!items_accOpen.length) items_accOpen = [items_accOpen];
		$A.util.addClass(items_accOpen[parseInt(event.target.dataset.index)],'slds-show');
        $A.util.removeClass(items_accOpen[parseInt(event.target.dataset.index)],'slds-hide');        
        
        var items_accClose = component.find("accClose");
        if(!items_accClose.length) items_accClose = [items_accClose];
		$A.util.addClass(items_accClose[parseInt(event.target.dataset.index)],'slds-hide');
        $A.util.removeClass(items_accClose[parseInt(event.target.dataset.index)],'slds-show');
    },
    
})