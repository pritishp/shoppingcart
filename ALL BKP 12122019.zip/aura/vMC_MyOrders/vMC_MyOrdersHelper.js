({
    setBreadCrumbs : function (component, event, helper) {
        var breadcrumbCollection = [
            {label: 'Home', name: 'brachy products' },
            {label: 'All Orders', name: 'All Orders' },
            {label: 'Order Detail', name: ''}
            //{label: 'Order Detail', name: 'orderDetailPage' , orderId: component.get("v.orderId")}
        ];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },
    
    
    getOrders : function (component, event, helper) {
        console.log('---'+component.get("v.orderId"));
        var action = component.get("c.getOrders");
        action.setParams({
            oId : component.get("v.orderId"),
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                console.log(resp);
                component.set("v.orderList", resp.order);
                component.set("v.isInternal", resp.ifInternalUser);
                component.set("v.isSubscribed", resp.order.IsSubscribed__c);
                console.log('orderLineItems ' +JSON.stringify(resp.orderLineItems));
                this.getOrderLineItems(component ,resp.orderLineItems, helper);
            } else {
                component.set('v.processing',false);
            }
            helper.getDeliveryItems (component, event, helper);           
        });
        $A.enqueueAction(action);
    },
    
    getOrderLineItems : function (component ,resp, helper) {
        var appList =[]; var prodList =[];
        var appTotalPrice=0; var appTotalQty=0;
        var brachyTotalPrice=0; var brachyTotalQty=0;
        if(resp && resp.length) {
            for(var i=0 ; i < resp.length; i++) {
                if(resp[i].vMTP_App__c) {
                    appList.push({
                        resp: resp[i],
                    });
                    appTotalPrice = appTotalPrice + resp[i].vMTP_App__r.Price__c;
                    appTotalQty = appTotalQty + resp[i].vMC_Quantity__c;
                }
                if(resp[i].Brachy_Product__c) {
                    prodList.push({
                        resp: resp[i],
                        total : resp[i].Brachy_Product__r.Price__c * resp[i].vMC_Quantity__c,
                    });
                    brachyTotalPrice = brachyTotalPrice + (resp[i].Brachy_Product__c.Price__c * resp[i].vMC_Quantity__c);
                    brachyTotalQty = brachyTotalQty + resp[i].vMC_Quantity__c;
                }
                
            }
            component.set("v.appTotalPrice",  appTotalPrice);
            component.set("v.brachyTotalPrice",   brachyTotalPrice);
            component.set("v.appTotalQty",  appTotalQty);
            component.set("v.brachyTotalQty",   brachyTotalQty);
        }
        component.set("v.appWrapper", appList);
        component.set("v.prodWrapper", prodList);
        component.set('v.processing',false);
        console.log('appList length:'+appList.length);
        console.log('prodWrapper length:'+prodList.length);
        if( parseInt(appList.length) > 0 ){
            //get app source for third party apps
            helper.getThirdPartyAppSource(component, event, helper,appList);
        }
    },
    
    callResubmitOrder : function (component) { 
        console.log('---'+component.get("v.orderId"));
        var action = component.get("c.reSubmitOrder");
        action.setParams({
            baOrderId : component.get("v.orderId"),
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                component.set('v.processing',false);
            }
        });
        $A.enqueueAction(action);
    },
    
     getURLParameters : function (component, event, helper) {
			console.log('Inside');
            // the function that reads the url parameters
            var getUrlParameter = function getUrlParameter(sParam) {
                var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                    sURLVariables = sPageURL.split('&'),
                    sParameterName,
                    i;

                for (i = 0; i < sURLVariables.length; i++) {
                    sParameterName = sURLVariables[i].split('=');

                    if (sParameterName[0] === sParam) {
                        return sParameterName[1] === undefined ? true : sParameterName[1];
                    }
                }
            };
            component.set("v.orderId", getUrlParameter('orderId'));
         	helper.getOrders (component, event, helper);
         	//helper.getDeliveryItems (component, event, helper);
         	helper.setBreadCrumbs (component, event, helper);
        },
    
    savePO : function(component, helper) {
       var action = component.get("c.savePO_Order");
        action.setParams({
            orderId : component.get("v.orderId"),
            poNumber : component.get("v.orderList.PO_Number__c"),
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                component.set("v.orderList", resp);
                //alert('Success');
                this.getPOAttachments(component);
                this.handleShowToast(component);
            }  
            
        });
        
        $A.enqueueAction(action);
	},
    
    updateOrderApproval : function (component, helper, isApproved) {
        var prodWrapper = component.get("v.prodWrapper");
        var rejectionReason = component.get("v.reason");
        var prodCode = [];
        for(var i=0; i <prodWrapper.length; i++) {
            prodCode.push(prodWrapper[i].resp.Brachy_Product__r.ProductCode);
        }
        
        var action = component.get("c.updateOrderApproval");
        action.setParams({
            orderId : component.get("v.orderId"),
            ifApproved : isApproved,
            productJSON : JSON.stringify(prodWrapper),
            productCode : prodCode,
            rejectReason : rejectionReason,
        })
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                component.set("v.orderList", resp);
            }
        });
        $A.enqueueAction(action);
    },
    
    updateNetTerm : function (component, event, helper) {
        var action = component.get("c.updateOrderNetTerm");
        var inputNetTerm = component.find('netTermInput').get("v.value");
        action.setParams({
            orderId : component.get("v.orderId"),
            netTerm : inputNetTerm,
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.find('netTermOutput').set('v.value',inputNetTerm);
            }
        });
        $A.enqueueAction(action);
    },
    getDeliveryItems: function (component, event, helper) {       
        var action = component.get("c.fetchDeliveryItems");
        //var deliveries = [];var deliveyItems = [];
        action.setParams({
            orderId : component.get("v.orderId"),
        });
        action.setCallback(this, function(response) {
            var state = response.getState();             
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                 console.log('--resp--'+JSON.stringify(resp));               
                if(resp.length ===0){
                    component.set("v.noDeliveryItemsMsg",true);
                }else{
                    /*for(var i=0 ; i< resp.length; i++) {
                        deliveries.push(resp[i].delItem);
                    }*/
                    component.set("v.deliveryItemsList",resp); 
               		console.log('--n--'+JSON.stringify(component.get("v.deliveryItemsList")));
                    component.set("v.noDeliveryItemsMsg",false);
                	                   
                }
            }       
        });
        $A.enqueueAction(action);
    },
    
    updateBackOrder: function (component) {       
        var action = component.get("c.updateBackOrderInfo");
        var inputBackOrder = component.find('backOrder').get("v.value");
        action.setParams({
            orderId : component.get("v.orderId"),
            backOrderInfo : inputBackOrder,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();             
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                console.log(resp);                
            }       
        });
        $A.enqueueAction(action);
    },
	handleShowToast : function(component) {
        console.log('TOAST');
        component.find('notifLib').showToast({
            "title": "PO is successfully updated!",
            "message": "Pending review by the internal team."
        });
    },
    
    getPOAttachments : function (component) {
        var action = component.get("c.getAttachedFiles");
        action.setParams({
            oId : component.get("v.orderId"),
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                component.set("v.attachments", resp);
            }
            
        });
        $A.enqueueAction(action);
    },
    getThirdPartyAppSource: function (component, event, helper, appList) {
        console.log(appList);
        var appIdList = []; var appId = '';
        for(var i=0; i < appList.length; i++){ 
            appId = appList[i].resp.vMTP_App__r.Id;
            appIdList.push( appId );
        }
        console.log('appIdList'+appIdList);
        var getAppPackages = component.get("c.getAppSources");
        getAppPackages.setParams({
            "appId" : appIdList
        });
        getAppPackages.setCallback(this, function(response){
            var state = response.getState();
            console.log(state);
            var tableData = response.getReturnValue();
            console.log(tableData);
            console.log(typeof tableData);
            
            var appSourceData = {};
            var resultJsonData = JSON.parse(tableData);
            for(i in resultJsonData) {
                var sData = resultJsonData[i];
                var appId = sData.appId;
                console.log(appId);
                var appName = sData.appName;
                var keyList = Object.keys(appSourceData);
                var appSourceVersions = sData.appSourceVersions;
                var appSourceVersionsNames = [];
                console.log('appSourceVersions=='+appSourceVersions);
                for (var j=0; j<appSourceVersions.length;j++ ){                    
                    appSourceVersionsNames.push(appSourceVersions[j].Name);
                }
                console.log('appSourceVersionsNames=='+appSourceVersionsNames);
                var appSourceVersionsNamesStr = appSourceVersionsNames.join(', ');
                var appSourceRow = {};
                var appSourceRecordData = {};
                appSourceRow = {'docName': sData.docName, 'appCategoryVersion': sData.appCategoryVersion, 'contentVersionId': sData.contentVersionId, 'appSourceVersion': appSourceVersionsNamesStr};
                console.log(appSourceRow);
            
                if(keyList.includes(appId)) {
                    appSourceRecordData = appSourceData[appId];
                    var appSourceList = appSourceRecordData['appSource'];
                    console.log(appSourceRecordData);
                    console.log(appSourceList);
                    appSourceList.push(appSourceRow);
                    appSourceData[appId] = {'appName': appName, 'appSource':appSourceList};
                } else {
                    appSourceData[appId] = {'appName': appName, 'appSource':[appSourceRow]};
                }
            }
            console.log(appSourceData);
            var resultData = Array();
            for(i in appSourceData) {
               var row = appSourceData[i];
               row['appId'] = i;
               resultData.push(row);
            }
            console.log('resultData',resultData);
            component.set('v.appSourceData', resultData);
        });
        $A.enqueueAction(getAppPackages);
    }
})