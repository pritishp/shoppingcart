({
	doInit : function(component, event, helper) {
		var navEvt = $A.get("e.force:navigateToComponent");
        navEvt.setParams({
            componentDef: "c:VFSL_WorkDetailInLineEditSupport",
            componentAttributes :{"recordId":component.get('v.recordId')}
        });
        navEvt.fire();
	}
})