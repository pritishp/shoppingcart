({
	 /*navigates to home page of vMarket App*/
	navigateToHome : function(component, event, helper) {
		helper.navigateToHome(component, event, helper);
	},
 
})