({
	/*navigates to home page of vMarket App*/
	navigateToHome : function(component, event, helper) {
	}
})