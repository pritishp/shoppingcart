({
    confirmRoutingNo : function(component, event, helper) {
        var routingNo = component.find('routingNo').get("v.value");
        var reReoutingNo = component.find('reReoutingNo').get("v.value");
        var routingError = component.find('routingNoError');
        if(routingNo != '' && routingNo != reReoutingNo) {
            $A.util.removeClass(routingError, 'slds-hide');
        }  else {
            $A.util.addClass(routingError, 'slds-hide');
            component.set("v.routingNo", routingNo);
        }
    },
    
    confirmAccountNo : function(component, event, helper) {
        var accountNo = component.find('accountNo').get("v.value");
        var accountName = component.find('accountName').get("v.value");
        var reAccountNo = component.find('reAccountNo').get("v.value");
        var routingError = component.find('accountNoError');
        if(accountNo != '' && accountNo != reAccountNo) {
            $A.util.removeClass(routingError, 'slds-hide');
        }  else {
            $A.util.addClass(routingError, 'slds-hide');
            component.set("v.accountNo", accountNo);
            component.set("v.accountName", accountName);
        }
    },
    
    validateFields: function (component, event, helper) {
        var accountNo; var reAccountNo; var accountName;
        var routingNo; var reReoutingNo;
        if(component.find('accountNo'))
            accountNo = component.find('accountNo').get("v.value");
        else accountNo = '';
        if(component.find('reAccountNo'))
            reAccountNo = component.find('reAccountNo').get("v.value");
        else reAccountNo = '';
        if(component.find('accountName')) 
            accountName = component.find('accountName').get("v.value");
        else accountName = '';
        if(component.find('routingNo'))
            routingNo = component.find('routingNo').get("v.value");
        else routingNo = '';
        if(component.find('reReoutingNo')) 
            reReoutingNo = component.find('reReoutingNo').get("v.value");
        else reReoutingNo = '';
        
        var ifValid = true;
        
        if( accountNo == '' ||  reAccountNo == '' || accountName == '' || routingNo == '' || reReoutingNo == '') {
            ifValid = false;
        }
        component.set("v.ifValid", ifValid);
        
    }
})