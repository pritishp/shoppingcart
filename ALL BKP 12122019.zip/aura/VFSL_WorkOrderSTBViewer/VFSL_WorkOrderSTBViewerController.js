({
	doInit : function(component, event, helper) {
        component.set('v.columns', [
            {label: 'Asset', fieldName: 'Asset_Name__c', type: 'text', sortable: 'true', cellAttributes:{class:{fieldName:'Warning'}}},
            {label: 'STB Number', fieldName: 'STB_Number__c', type: 'text', sortable: 'true', cellAttributes:{class:{fieldName:'Warning'}}},
            {label: 'Type', fieldName: 'Type__c', type: 'text', sortable: 'true', cellAttributes:{class:{fieldName:'Warning'}}},
            {label: 'Due Date', fieldName: 'Date_Due__c', type: 'date', sortable: 'true', cellAttributes:{class:{fieldName:'Warning'}}},
            /*{label: 'Warning', fieldName: 'Warning', type: 'text', sortable: 'true', cellAttributes:{class:{fieldName:'Warning'}}},*/
            {label: 'JO#', fieldName: 'STB_Org_JO__c', type: 'text', sortable: 'true', cellAttributes:{class:{fieldName:'Warning'}}}
        ]);
        
        //Get STB Details for this Work Order
        var STBInfo = component.get("c.getSTBStatus");

        STBInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        STBInfo.setCallback(this, function(response){
            var stbList = response.getReturnValue();
            var dueType;
            var lineDate;
            var currentDate = new Date();
            for(var i=0;i<stbList.length;i++){
            	lineDate = new Date(stbList[i].Date_Due__c);
                dueType = Math.floor((lineDate - currentDate)/1000)/86400;
                if(dueType > 0 && dueType < 30){
                    stbList[i].Warning = 'soon';
                }else if(dueType < 0){
                    stbList[i].Warning = 'past';
                }else{
                    stbList[i].Warning = 'future';
                }
            }
            component.set("v.stbList",response.getReturnValue());
            console.log('stbList: '+JSON.stringify(stbList));
            if(stbList.length > 0){
            	component.set("v.showModal",true);
                component.set("v.noSTB",false);
        	}

        });

        $A.enqueueAction(STBInfo);

	},
    
    clickHide : function(component, event, helper) {
        console.log('enter clickHide');
		component.set("v.showHide",true); 
        component.set("v.showModal",false);
	},
        
    clickShow : function(component, event, helper) {
        console.log('enter clickShow');
		component.set("v.showHide",false); 
        component.set("v.showModal",true);
	},
    
    updateColumnSorting: function (component, event, helper) {
        var fieldName = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        // assign the latest attribute with the sorted column fieldName and sorted direction
        component.set("v.sortedBy", fieldName);
        component.set("v.sortedDirection", sortDirection);
        helper.sortData(component, fieldName, sortDirection);
    }
})