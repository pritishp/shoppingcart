({
    callServer:function(component,method,params,callback) {
        var action = component.get(method);
        if (params) {
            action.setParams(params);
        }
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                // pass returned value to callback function
                callback.call(this,response.getReturnValue());   
            } 
        });
        $A.enqueueAction(action);
    },
    getCountryList : function(component, event) {
        var params={};
        this.callServer(component,"c.getCountry",params,function(response){
            if(!$A.util.isEmpty(response)){
                var opts = [{
                    label: "Please select a Country",
                    value: ""
                }];
                for (var i=0; i<response.length; i++) {
                    opts.push({
                        label : response[i],
                        value: response[i]
                    });
                }
                component.find("fcountry").set("v.options",opts);
            }
        });
    },
    getFunctionalRole : function(component, event) {
        var params={};
        this.callServer(component,"c.getFunctionalRoles",params,function(response){
            if(!$A.util.isEmpty(response)){
                var opts = [{
                    label: "Please select a role",
                    value: ""
                }];
                for (var i=0; i<response.length; i++) {
                    opts.push({
                        label : response[i],
                        value: response[i]
                    });
                }
                component.find("frole").set("v.options",opts);
            }
        });
    },
    getPreferedLanguage : function(component, event) {
        var params={};
        this.callServer(component,"c.getPreferedLanguage",params,function(response){
            if(!$A.util.isEmpty(response)){
                var opts = [{
                    label: "Please select a Language",
                    value: ""
                }];
                for (var i=0; i<response.length; i++) {
                    opts.push({
                        label : response[i],
                        value: response[i]
                    });
                }
                component.find("flang").set("v.options",opts);
            }
        });
    },
    
    MAX_FILE_SIZE: 4500000, //Max file size 4.5 MB 
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    
    uploadHelper: function(component, event) {
        var fileInput = component.find("fileId").get("v.files");
        // get the first file using array index[0]  
        var file = fileInput[0];
        var self = this;
        // create a FileReader object 
        var objFileReader = new FileReader();
        // set onload function of FileReader object   
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            // call the uploadProcess method 
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents) {
        // set a default size or startpostiton as 0 
        var startPosition = 0;
        // calculate the end size or endPostion using Math.min() function which will return the min. value   
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        
        // start with the initial chunk, and set the attachId(last parameter)is null at the beginning
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        // call the apex method 'saveChunk'
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        var prntId=component.get("v.record.Id");
        action.setParams({
            parentId: prntId,
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                // check if the start postion is still less than end postion 
                // then call again 'uploadInChunk' method , 
                // else, diaply alert msg and hide the loading spinner
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    component.set("v.picture",response.getReturnValue());
                    var imgUrl=component.get("v.prefixURL");
                    var contVersnId=component.get("v.picture");
                    component.set("v.prefixURLs",imgUrl+contVersnId);
                    component.set("v.record.ProfilePicture__c",imgUrl+contVersnId);    
                }
                // handel the response errors        
            } else if (state === "INCOMPLETE") {
                console.log("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        // enqueue the action
        $A.enqueueAction(action);
    },
    
  /*  showSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
    
    hideSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    },*/
    
    //Function to fetch the image of the active user Starts below by ujjwal singh.
    getUserImage : function(component, event, helper) {
        var action = component.get("c.fetchUserImage");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var res = response.getReturnValue();
                component.set('v.ImgUser', res);
            }
            else if (state === "INCOMPLETE") {
            }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + 
                                        errors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
        });
        $A.enqueueAction(action);	
    }, 
    
})