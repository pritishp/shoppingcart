({
	doInit : function(component, event, helper) {
        //Get Work Order defaults
        var WorkOrderInfo = component.get("c.getWorkOrderSimulate");

        WorkOrderInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response){
            var woCheck = response.getReturnValue();
            component.set("v.WorkOrder",response.getReturnValue());
            console.log('woCheck: '+woCheck);
            if(woCheck.SAP_Status__c == null || woCheck.Interface_Status__c == 'Do Not Process' ||
               	(woCheck.Status != 'Submitted' && woCheck.Status != 'Reviewed' && woCheck.Status != 'Error' && woCheck.Status != 'Approved')){
            		component.set("v.Qualify",false);
        			}
            if(woCheck.Status == 'Approved' && woCheck.SAP_Status__c != 'Simulation Failure'){
                component.set("v.Qualify",false);
            }
        });

        $A.enqueueAction(WorkOrderInfo);

	}, 
    
    YesClick : function(component, event, helper) {
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var save = component.get("c.saveSimulateWO");
        save.setParams({
            "WorkOrder": component.get("v.WorkOrder")
        });
        $A.enqueueAction(save);
        
        save.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                /*var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
				dismissActionPanel.fire(); 
        
                var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
            		"slideDevName": "detail"
        		});
        		backtoRecord.fire();*/
                
                component.find("overlayLib").notifyClose();
        		var refreshPage = $A.get("e.force:refreshView");
        		refreshPage.fire();
            }else{
                $A.util.addClass(
      			component.find('spinner'), 
      			"slds-hide"
				);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "message":  "There was problem simulating Work Order.  Please log a ticket",
                    "type": "ERROR"
                });
                toastEvent.fire();
            }
        })
        }, 
    
    /*NoClick : function(component, event, helper) {
		var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
		dismissActionPanel.fire(); 
        
        var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
           		"slideDevName": "detail"
        		});
        backtoRecord.fire();
	}, */
    
    NoClick : function(component, event, helper) {
        component.find("overlayLib").notifyClose();
	}
})