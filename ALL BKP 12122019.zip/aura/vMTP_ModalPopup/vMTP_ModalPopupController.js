({
	presentationRatingChange : function(component, event, helper) {
        component.set("v.rating", event.getParam("rating"));
	},
    
    onSubmit : function (component, event, helper) {
        var Title = component.find('Title').get("v.value");
        var Description = component.find('Description').get("v.value");
        var rating = component.get("v.rating");
        var titleError = component.find('titleError');
        var descError = component.find('descError');
        var ratingError = component.find('ratingError');
        if(!Title) {
            $A.util.removeClass(titleError, 'slds-hide');
        } else {
            $A.util.addClass(titleError, ' slds-hide');
        }
        if(!Description) {
            $A.util.removeClass(descError, 'slds-hide')
        } else {
            $A.util.addClass(descError, ' slds-hide');
        }
        if(!rating) {
            $A.util.removeClass(ratingError, 'slds-hide')
        } else {
            $A.util.addClass(ratingError, ' slds-hide');
        }
        if(Title && Description && rating) {
            helper.submitReview (component, event, helper, Title, Description, rating);
        }
    }
})