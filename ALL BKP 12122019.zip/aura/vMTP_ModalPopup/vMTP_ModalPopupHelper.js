({
	submitReview : function(component, event, helper, Title, Description, rating) {
		var action = component.get('c.insertReview');
        action.setParams({
            applicationId : component.get("v.appId"),
            userTitle :Title,
            userDesc : Description,
            userRating: rating
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var compEvents = component.getEvent("reloadComments");
				compEvents.fire();
            }
        });
        $A.enqueueAction(action);
        helper.closeModal (component, event, helper);
	},
    
    closeModal : function(component, event, helper) {
        var modalWindow = component.find('modalWindow');
        var backdrop = component.find('backdrop');
        var container=component.find('modalContainer');
        $A.util.removeClass(modalWindow, 'slds-fade-in-open');
        $A.util.removeClass(backdrop, 'slds-backdrop slds-backdrop_open');
        $A.util.addClass(container, 'slds-hide');
        
	},
})