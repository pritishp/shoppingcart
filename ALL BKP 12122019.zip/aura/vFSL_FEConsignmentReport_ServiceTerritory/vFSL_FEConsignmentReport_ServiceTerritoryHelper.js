({
    
    fetchFEDetails : function(component, event, helper) {
        
        component.set('v.respcolumns', [
            {label: 'FE', fieldName: 'customer', type: 'text', sortable: 'true'},
            {label: 'Name', fieldName: 'name', type: 'text', sortable: 'true'},
            {label: 'Plant', fieldName: 'plant', type: 'text', sortable: 'true'},
            {label: 'Location', fieldName: 'location', type: 'text'},
            {label: 'Material', fieldName: 'material', type: 'text', sortable: 'true'},
            {label: 'Material Description', fieldName: 'description', type: 'text'},
            {label: 'Quantity', fieldName: 'quantity', type: 'text', sortable: 'true'},
            {label: 'Batch', fieldName: 'batch', type: 'text'}
        ]);
        
        var action = component.get("c.callFEConsignWebserviceST");
        action.setParams({
            "stId" : component.get('v.recordId') 
        });
        //Populate the lightning Database table with the data received from SAP
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('*****response----**'+response.getReturnValue()); 
            if (state === "SUCCESS") {
                var data = [];
                var result = response.getReturnValue();  
                console.log('---result--'+JSON.stringify(result));
                
                var consignmentTableData = result.fe_consignment;
                console.log('---consignmentTableData--'+JSON.stringify(consignmentTableData));
                
                if(consignmentTableData == ''){
                    component.set("v.available",false);
                }
                
                for(var counter in consignmentTableData){
                    var consignmentRow = new Object();
                    consignmentRow.customer =  consignmentTableData[counter].customer;
                    consignmentRow.name =  consignmentTableData[counter].name;
                    consignmentRow.plant = consignmentTableData[counter].plant;
                    consignmentRow.location = consignmentTableData[counter].location;
                    consignmentRow.material = consignmentTableData[counter].material;
                    consignmentRow.description = consignmentTableData[counter].material_desc;
                    consignmentRow.quantity = consignmentTableData[counter].quantity;
                    consignmentRow.batch = consignmentTableData[counter].batch;
                    data.push(consignmentRow);
                }
                console.log('---data--'+JSON.stringify(data));
                component.set("v.responseList", data);
            }
            else if(state == "ERROR"){
                var errors = response.getError(); 
                component.set("v.showErrors",true);
                component.set("v.errorMessage",errors[0].message);
            }
            
        });
        $A.enqueueAction(action);
    },
    
    sortData: function (cmp, fieldName, sortDirection) {
        var data = cmp.get("v.responseList");
        var reverse = sortDirection !== 'asc';
        //sorts the rows based on the column header that's clicked
        data.sort(this.sortBy(fieldName, reverse))
        cmp.set("v.responseList", data);
    },
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        //checks if the two rows should switch places
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    }
})