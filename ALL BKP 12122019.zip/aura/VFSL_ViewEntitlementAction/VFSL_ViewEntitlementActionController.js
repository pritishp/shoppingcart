({
	doInit : function(component, event, helper) {
		var navEvt = $A.get("e.force:navigateToComponent");
        navEvt.setParams({
            componentDef: "c:vfsl_ViewEntitlement",
            componentAttributes :{"recordId":component.get('v.recordId')}
        });
        navEvt.fire();
	}
})