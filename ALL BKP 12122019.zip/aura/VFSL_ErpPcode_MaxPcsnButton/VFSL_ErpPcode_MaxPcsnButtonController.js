({
	doInit: function(component, event, helper) {
        debugger;
        helper.getCurrentMaxPCSNValue(component, event);
       
        //helper.setMaxPCSNSerialNumber(component, event);
        
    },
    
    cancel: function(component, event, helper)
    {
        helper.closeWindow(component, event);
    },
    
    
    recalculate: function(component, event, helper)
    {
        helper.setMaxPCSNSerialNumber(component, event);
    }
})