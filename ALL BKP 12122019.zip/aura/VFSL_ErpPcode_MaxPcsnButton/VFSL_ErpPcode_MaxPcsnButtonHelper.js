({
	setMaxPCSNSerialNumber : function(component, event) {
        debugger;
		var action = component.get("c.setMaxPCSNSerialNumber");
        action.setParams({
            "ERPPcodeId": component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();
            }
            else {
                $A.log("callback error", response.getError());
            }
        });
        // Send action off to be executed
        $A.enqueueAction(action);
       //var wasDismissed = 

	},
    
    closeWindow : function(component, event){
        $A.get("e.force:closeQuickAction").fire();
        //$A.get('e.force:refreshView').fire();
    },
    
    getCurrentMaxPCSNValue : function(component, event){
       
        debugger;
       var action = component.get("c.getCurrentMaxPCSNValue");
        action.setParams({
            "erpId": component.get("v.recordId")
        });
          action.setCallback(this, function(response) {
              
               //$.noConflict();
              console.log("getCurrentMaxPCSNValue function called");
            var state = response.getState();
            if (state === "SUCCESS") {
    			console.log("inside success");
                var maxExist =  response.getReturnValue();
                if(maxExist == false)
                {
                    console.log("inside false");
                    
                    //document.getElementById("calculating").style.display = 'block';
                    //document.getElementById("recalculate").style.display = 'none';
                    $A.util.addClass(component.find("recalculate"), "slds-hide")
                    $A.util.addClass(component.find("calculating"), "slds-show");
                    this.setMaxPCSNSerialNumber(component, event);
                    //closeWindow();
                    
                    //$A.util.addClass(component.find("calculating"), "slds-show");
                }
                else
                {
                    console.log("inside true");
                    document.getElementById("calculating").style.display = 'none';
                    document.getElementById("recalculate").style.display = 'block';
                    
                   // $A.util.addClass(component.find("calculating"), "slds-hide");
                }
            }
            else {
                console.log("no success");
                $A.log("callback error", response.getError());
            }
        });
        $A.enqueueAction(action);
    }
    
})