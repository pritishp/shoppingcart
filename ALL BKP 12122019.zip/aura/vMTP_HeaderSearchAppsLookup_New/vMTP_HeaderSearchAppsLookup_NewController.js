({
	doInit : function(component, event, helper) {		
	//	helper.getAccountDetails(component, event, helper);       
	},
    handleOptionSelected : function(component, event, helper) {
        console.log('Option Selected',event.getParam("value"));
    },
    appSearchInputKeypress : function(component, event, helper) {
        var searchKeyword = component.get("v.searchKeyword");
		var productModel = component.find("productModelSelect").get("v.value");		
        if( searchKeyword.length > 0 && event.getParams().keyCode == 13 ){
            console.log('searchKeyword=='+searchKeyword);
            console.log('productModel=='+productModel);
            searchKeyword = searchKeyword.trim();
            productModel = productModel.trim();
            window.open("/varianMarketPlace/s/vmc-product-search?searchKeyword="+searchKeyword+"&productModel="+productModel, "_self");                      
        }
    },
    onSearchIconClick : function(component, event, helper) {
        var searchKeyword = component.get("v.searchKeyword");
		var productModel = component.find("productModelSelect").get("v.value");		
        if( searchKeyword.length > 0 ){
            console.log('searchKeyword=='+searchKeyword);
            console.log('productModel=='+productModel);
            searchKeyword = searchKeyword.trim();
            productModel = productModel.trim();
            window.open("/varianMarketPlace/s/vmc-product-search?searchKeyword="+searchKeyword+"&productModel="+productModel, "_self");            
        }
    }
})