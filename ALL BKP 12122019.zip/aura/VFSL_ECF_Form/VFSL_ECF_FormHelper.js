({
    initialize: function(component) {
        var action = component.get("c.validateAndPopulateFields");
        console.log('case record id: ' + component.get("v.recordId"));
        action.setParams({
            "recordId" : component.get("v.recordId")
        });
        
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            if (result !== null && result[0] !== "true") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "type": "error",
                    "mode" : "sticky",
                    "message": result[1]
                });
                toastEvent.fire();
                component.find('TopSaveButton').set('v.disabled',true);
                component.find('BottomSaveButton').set('v.disabled',true);
                $A.get("e.force:closeQuickAction").fire();
            } else {
                console.log(result);
                var sObj = JSON.parse(result[2]);
                var ecfObj = sObj.ecfObj;
                component.set('v.ecfObj', ecfObj);
                
                
                if(ecfObj.Case__c !== null && ecfObj.Case__c !== undefined) {
                    component.set('v.caseLookupRecordId', ecfObj.Case__c);
                    component.set('v.caseLookupName', sObj.caseNumber);
                    component.set('v.caseReadOnly', true);
                }
                if(ecfObj.WorkOrder__c !== null && ecfObj.WorkOrder__c !== undefined) {
                    component.set('v.woLookupRecordId', ecfObj.WorkOrder__c);
                    component.set('v.woLookupName', sObj.woNumber);
                    component.set('v.woReadOnly', true);
                }
                if(ecfObj.Asset_Location__c !== null && ecfObj.Asset_Location__c !== undefined) {
                    component.set('v.locLookupRecordId', ecfObj.Asset_Location__c);
                    component.set('v.locLookupName', sObj.locationName);
                    component.set('v.locReadOnly', true);
                }
                if(ecfObj.District_Manager__c !== null && ecfObj.District_Manager__c !== undefined) {
                    component.set('v.dmLookupRecordId', ecfObj.District_Manager__c);
                    component.set('v.dmLookupName', sObj.distManName);
                    component.set('v.dmReadOnly', true);
                }
                if(ecfObj.Varian_Employee__c !== null && ecfObj.Varian_Employee__c !== undefined) {
                    component.set('v.vmLookupRecordId', ecfObj.Varian_Employee__c);
                    component.set('v.vmLookupName', sObj.varEmpName);
                    component.set('v.vmReadOnly', true);
                }
                if(ecfObj.Asset_Top_Level__c !== null && ecfObj.Asset_Top_Level__c !== undefined) {
                    component.set('v.prodLookupRecordId', ecfObj.Asset_Top_Level__c);
                    component.set('v.prodLookupName', sObj.productName);
                    component.set('v.prodReadOnly', true);
                }
            }
        });
        $A.enqueueAction(action);
    },
    toggleFields: function(component) {
        var PatientStatusId = component.find("PatientStatusId");
        var deathCmp = component.find("deathid");
        var wasInjuredCmp = component.find("wasInjuredId");

        if( (deathCmp.get("v.value") !== undefined && deathCmp.get("v.value") !== null && deathCmp.get("v.value") === 'Yes') || 
          	(wasInjuredCmp.get("v.value") !== undefined && wasInjuredCmp.get("v.value") !== null && wasInjuredCmp.get("v.value") === 'Yes') 
          ) {
            //$A.util.removeClass(PatientStatusId, 'slds-hide');
            $A.util.removeClass(PatientStatusId, 'disabledDiv');
        } else {
            //$A.util.addClass(PatientStatusId, 'slds-hide');
            $A.util.addClass(PatientStatusId, 'disabledDiv');
        }
        component.find('injPatValue').set('v.value', '');
        component.find('injPatIdValue').set('v.value', '');
        component.find('agKnownValue').set('v.value', '');
        component.find('agValueEntered').set('v.value', '');
        component.find('sxKnownValue').set('v.value', '');
        component.find('sxValueEntered').set('v.value', '');
    },
    validateRadiationEvent : function(component) {
        var radiationEventValue = component.find("radiationId").get("v.value");;
        if(radiationEventValue == 'Yes') {
            var requiredRadEventFieldList = ["modId", "treatDelWrongId", "treatDelPlanId", "affAnatomyId", "treatModId", "singleFractionId",
                                             "radioTherepyTreatmentId", "errorPlannedDoseId", "totalPlannedId",
                                             "adjustedPlanId",  "prescriptionId", 
                                             "plannedTreatmentId", "actualTreatmentId", "treatmentRegionId", 
                                             "recordPlannedId", "closestNormalStructureId"];
            
            for(var i=0; i < requiredRadEventFieldList.length; i++) {
                var fieldValue = component.find(requiredRadEventFieldList[i]).get('v.value');
                if(fieldValue !== undefined && fieldValue !== null) {
                    fieldValue = fieldValue.trim();
                }
                
                if(fieldValue === '--None--' || fieldValue === '' || fieldValue === undefined || fieldValue === null) {
                    console.log('Radiation required field---'+requiredRadEventFieldList[i]);
                    console.log('Radiation required field value---'+fieldValue);
                    return 'Please, fill the required radiation event fields.';
                }
            }
        }
        return null;
    },
    validateBrachyEvent : function(component) {
        var brachyEventValue = component.get('v.ecfObj.Did_a_Brachy_Event_Occur__c', 'v.value');
        if(brachyEventValue == 'Yes') {
            var requiredBrachyFieldList = ["unintendedDosev100Id", "criticalStructureId", "unintendedDosev150Id", "unintendedDosev200Id", 
                                           "plannedv100Id", "actualv100Id", "plannedBachyTreatmentId", "deliveredTreatmentId"];
            
            for(var i=0; i < requiredBrachyFieldList.length; i++) {
                var fieldValue = component.find(requiredBrachyFieldList[i]).get('v.value');
                if(fieldValue !== undefined && fieldValue !== null) {
                    fieldValue = fieldValue.trim();
                }
                
                if(fieldValue === '--None--' || fieldValue === '' || fieldValue === undefined || fieldValue === null) {
                    console.log('Brachy required field---'+requiredBrachyFieldList[i]);
                    console.log('Brachy required field value---'+fieldValue);
                    return 'Please, fill the required brachytheray event fields.';
                }
            }
        }
        
        return null;
    },
    validateMoEvent : function(component) {
        var moEventValue = component.get('v.ecfObj.Did_a_MO_Event_Occur__c', 'v.value');
        if(moEventValue == 'Yes') {
            var requiredMoFieldList = ["treatmentDeliveredWrongPatientId", "treatmentRegimenId", 
                                       "prescribedDoseId", "prescribedRegimenId"];
            
            for(var i=0; i < requiredMoFieldList.length; i++) {
                var fieldValue = component.find(requiredMoFieldList[i]).get('v.value');
                if(fieldValue !== undefined && fieldValue !== null) {
                    fieldValue = fieldValue.trim();
                }
                
                if(fieldValue === '--None--' || fieldValue === '' || fieldValue === undefined || fieldValue === null) {
                    console.log('Medical Oncology required field---'+requiredMoFieldList[i]);
                    console.log('Medical Oncology required field value---'+fieldValue);
                    return 'Please, fill the required medical oncology event fields.';
                }
            }
        }
        return null;
    },    
    saveRecord: function(component) {
        this.resetAllMsgs(component);
        var result = this.validate(component);
        var radResult = this.validateRadiationEvent(component);
        var brachyResult = this.validateBrachyEvent(component);
        var moResult = this.validateMoEvent(component);
        
        var isExecute = true;
        var errorMessage = '';
        var errorToastMessage = '';
        if(result !== null) {
            isExecute = false;
            errorMessage += result;
            var toastHtmlMsg = result.replace(/<br\/>/g, '\n');
            toastHtmlMsg = toastHtmlMsg.replace('<p>', '').replace('<ul>', '').replace('<li>', '').replace('</p>', '').replace('</ul>', '').replace('</li>', '');
            errorToastMessage += (toastHtmlMsg + ' \n ');
        }

        if(radResult !== null) {
            isExecute = false;
            errorMessage += (radResult + '<br/>');
            errorToastMessage += (radResult + ' \n ');
        }
        
        if(brachyResult !== null) {
            isExecute = false;
            errorMessage += (brachyResult + '<br/>');
            errorToastMessage += (brachyResult + ' \n ');
        }
        
        if(moResult !== null) {
            isExecute = false;
            errorMessage += (moResult + '<br/>');
            errorToastMessage += (moResult + ' \n ');
        }
        
        if(!isExecute) {
            this.setMsg(component, 'errMsg', errorMessage, true);
            /*var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "type": "error",
                "message": errorToastMessage
            });
            toastEvent.fire();*/
            window.scrollTo(0, 0);
            this.toggleSpinner(component, false);
        }
        
        if(isExecute) {
            var ecfObj = component.get('v.ecfObj');
            var action = component.get("c.saveECFRecord");
            
            if(component.get('v.caseLookupRecordId') !== undefined)
                ecfObj.Case__c = component.get('v.caseLookupRecordId');
            
            if(component.get('v.woLookupRecordId') !== undefined)
                ecfObj.WorkOrder__c = component.get('v.woLookupRecordId');
            
            
            if(component.get('v.locLookupRecordId') !== undefined)
                ecfObj.Asset_Location__c = component.get('v.locLookupRecordId');
            
            if(component.get('v.dmLookupRecordId') !== undefined)
                ecfObj.District_Manager__c = component.get('v.dmLookupRecordId');
            
            if(component.get('v.vmLookupRecordId') !== undefined)
                ecfObj.Varian_Employee__c = component.get('v.vmLookupRecordId');
            
            if(component.get('v.prodLookupRecordId') !== undefined)
                ecfObj.Asset_Top_Level__c = component.get('v.prodLookupRecordId');
            
            if(component.get('v.addProdLookupRecordId') !== undefined)
                ecfObj.Asset__c = component.get('v.addProdLookupRecordId');
            
            ecfObj.Is_Submitted__c = 'Not Yet';
            ecfObj.Is_Submit__c = false;
            ecfObj.Send_Email_from_WO_for_Close_Case__c = false;
            ecfObj.ECF_Activity_Created__c = false;
            
            var injValue = component.find("injuryOccurId").get("v.value");
            ecfObj.Did_a_Physical_Injury_occur__c = injValue;
            
            var radiationValue = component.find("radiationId").get("v.value");
            ecfObj.Did_a_Radiation_Event_occur__c = radiationValue;
            
            var modValue = component.find("modId").get("v.value");
            ecfObj.Was_the_wrong_treatment_modality_used__c = modValue;
            
            var treatDelWrongValue = component.find("treatDelWrongId").get("v.value");
            ecfObj.Was_treatment_delivered_to_wrong_patient__c = treatDelWrongValue;
            
            var treatDelPlanValue = component.find("treatDelPlanId").get("v.value");
            ecfObj.Was_treatment_delivered_outside_of_the_p__c = treatDelPlanValue;
            
            var affAnatomyValue = component.find("affAnatomyId").get("v.value");
            ecfObj.Were_any_critical_structures_exposed_to__c = affAnatomyValue;
            
            ecfObj.Modality__c = component.find("treatModId").get("v.value");
            ecfObj.Single_Fraction_or_Multiple_Fractions__c = component.find("singleFractionId").get("v.value");
            ecfObj.critical_structure_exposed__c = component.find("criticalStructureId").get("v.value");
            
            ecfObj.error_exceed_15_of_the_weekly_planned__c = component.find("errorPlannedDoseId").get("v.value");
            ecfObj.error_exceed_10_of_total_planned_dose__c = component.find("totalPlannedId").get("v.value");
            
            ecfObj.Was_treatment_delivered_to_wrongpatient1__c = component.find("treatmentDeliveredWrongPatientId").get("v.value");
            ecfObj.Was_the_wrong_treatment_Regimen_used__c = component.find("treatmentRegimenId").get("v.value");
            ecfObj.Treatment_delivered_outside_pres__c = component.find("prescribedRegimenId").get("v.value");
            ecfObj.Error_exceed_10_of_total_planned_dose_MO__c = component.find("prescribedDoseId").get("v.value");
            
            //alert('=== ecfObj.Percentage_of_Total_Dose_Error__c=='+ ecfObj.Percentage_of_Total_Dose_Error__c);
            //alert('=== ecfObj.Error_exceed_10_of_total_planned_dose_MO__c=='+ ecfObj.Error_exceed_10_of_total_planned_dose_MO__c);
            //var ecfList = Array();
            //ecfList.push(ecfObj);
            //delete ecfObj['attributes']
            //ecfObj.sobjectType = 'L2848__c';
            //var jsonECFStr = JSON.stringify(ecfObj);
            
            delete ecfObj['Case__r'];
            delete ecfObj['Varian_Employee__r'];
            delete ecfObj['District_Manager__r'];
            delete ecfObj['Asset_Location__r'];
            delete ecfObj['Asset_Top_Level__r'];
            delete ecfObj['WorkOrder__r'];
            
            this.toggleSpinner(component, true);
            component.find('TopSaveButton').set('v.disabled',true);
            component.find('BottomSaveButton').set('v.disabled',true);
            action.setParams({
                ecfJSONRecord : JSON.stringify(ecfObj)
            });
            var self = this;
            action.setCallback(this, function(response) {
                //var state = a.getState();
                var result = response.getReturnValue();
                if(result !== null && result.startsWith('a41')) {
                    
                    var workspaceAPI = component.find("workspace");
                    workspaceAPI.isConsoleNavigation().then(function(response) {
                        console.log('==response=='+response);
                        if(response === true){ 
                            var tabId = component.get('v.workspaceTabId');
                            //alert('==tabId=='+tabId);
                            workspaceAPI.closeTab({tabId: tabId});
                            setTimeout(function(){   $A.get('e.force:refreshView').fire(); }, 1000);  
                            
                            workspaceAPI.getFocusedTabInfo().then(function(response) {
                                console.log('==FocusedTadIdresponse==='+response);
                                var focusedTabId = response.tabId;
                                workspaceAPI.closeTab({tabId: focusedTabId});
                                
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    "title": "SUCCESS!",
                                    "type": "success",
                                    "message": 'ECF record has been created.'
                                });
                                toastEvent.fire();
                                
								setTimeout(function() {
                                    var sObectEvent = $A.get("e.force:navigateToSObject");
                                    sObectEvent .setParams({
                                        "recordId": result, //component.get("v.recordId"),
                                        "slideDevName": "detail"
                                    });
                                    sObectEvent.fire();
                                }, 4000);

                                setTimeout(function(){   $A.get('e.force:refreshView').fire(); }, 1000);
                            })
                            .catch(function(error) {
                                console.log(error);
                            });
                        } else {
                            var sObectEvent = $A.get("e.force:navigateToSObject");
                            sObectEvent .setParams({
                                "recordId": result, //component.get("v.recordId"),
                                "slideDevName": "detail"
                            });
                            sObectEvent.fire();
                            
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "SUCCESS!",
                                "type": "success",
                                "message": 'ECF record has been created.'
                            });
                            toastEvent.fire();
                            
                            setTimeout(function(){   $A.get('e.force:refreshView').fire(); }, 2000);   
                        }
                    });
                }  else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "type": "error",
                        "duration" : "15000",
                        "message": result
                    });
                    toastEvent.fire();
                }
                this.toggleSpinner(component, false);
                component.find('TopSaveButton').set('v.disabled',false);
                component.find('BottomSaveButton').set('v.disabled',false);
                //component.cancelECF(component, event, this)
            });
            $A.enqueueAction(action);
        }
    },
    
    toggleSpinner: function(component, flag) {
        component.set('v.spinner', flag);
    },
    getInjOptions: function(component) {
        var action = component.get("c.getInjuredOptions");
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            component.set('v.injuredOptions', result);
        });
        $A.enqueueAction(action);
    },
    getRadOptions: function(component) {
        var action = component.get("c.getRadiationOptions");
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            component.set('v.radiationOptions', result);
        });
        $A.enqueueAction(action);
    },
    getTreatmentModOptions: function(component) {
        var action = component.get("c.getTreatmentModalityOptions");
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            component.set('v.treatModalityOptions', result);
        });
        $A.enqueueAction(action);
    },
    getFractionOptions: function(component) {
        var action = component.get("c.getFractionValuesOptions");
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            component.set('v.fractionalOptions', result);
        });
        $A.enqueueAction(action);
    },
    getCritStructOptions: function(component) {
        var action = component.get("c.getCriticalStructureOptions");
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            component.set('v.criticalOptions', result);
        });
        $A.enqueueAction(action);
    },
    setMsg: function(component, strText, msg, isHtml) {
        var elem = component.find(strText).getElement();
        $A.util.removeClass(elem, 'slds-hide');
        if(isHtml)
            elem.innerHTML = msg;
        else
            elem.innerText = msg;
    },
    resetAllMsgs: function(component) {
        var errElem = component.find('errMsg').getElement();
        var infoElem = component.find('infoMsg').getElement();
        
        $A.util.addClass(errElem, 'slds-hide');
        $A.util.addClass(infoElem, 'slds-hide');
        
        infoElem.innerHtml = '';
        errElem.innerHtml = '';
    },
    validate: function(component) {
        this.toggleSpinner(component, true);
        var smartConnectUsed = component.get('v.ecfObj.SmartConnect_available__c');
        component.set('v.ecfObj.Did_a_Radiation_Event_occur__c', component.find('radiationId').get('v.value'));

        var errorDisplayKeywordDict = {"v.ecfObj.Initial_Reporter_Type__c": "Initial Reporter Type", 
                                         "v.ecfObj.City__c": "City",
                                         "v.ecfObj.Country__c" : "Country",
                                         "v.ecfObj.Name_of_Customer_Contact__c":"Name of Customer Contact",
                                         "v.ecfObj.Title_Role__c":"Title/Role",
                                         "v.ecfObj.Phone_Number__c": "Phone Number", 
                                         "v.ecfObj.Date_of_Event__c": "Date of Event", 
                                         "v.ecfObj.Date_only_Reported_to_Varian__c": "Date Reported to Varian", 
                                         "v.ecfObj.Employee_Phone__c": "Employee Phone", 
                                         "v.ecfObj.Device_or_Application_Name__c": "Device or Application Name", 
                                         "v.ecfObj.Version_Model__c": "Version/Model", 
                                         "v.ecfObj.Corrective_action_or_work_around_perfor__c": "Immediate Correction Performed?", 
                                         "v.ecfObj.SmartConnect_available__c": "SmartConnect Used?", 
                                         "v.ecfObj.Patient_on_the_table_at_time_of_event__c": "Patient on the table at time of event?", 
                                         "v.ecfObj.Was_anyone_injured__c": "Was anyone injured?", 
                                         "v.ecfObj.Did_a_Radiation_Event_occur__c": "Did a Radiation Event occur?", 
                                         "v.ecfObj.Did_a_Brachy_Event_Occur__c": "Did a Brachy Event Occur", 
                                         "v.ecfObj.Did_a_MO_Event_Occur__c": "Did a MO Event Occur"};
        
        
        var requiredFields = ["v.ecfObj.Initial_Reporter_Type__c", "v.ecfObj.City__c", "v.ecfObj.Country__c", "v.ecfObj.Name_of_Customer_Contact__c", "v.ecfObj.Title_Role__c",
                              "v.ecfObj.Phone_Number__c", "v.ecfObj.Date_of_Event__c", "v.ecfObj.Date_only_Reported_to_Varian__c", "v.ecfObj.Employee_Phone__c", "v.ecfObj.Device_or_Application_Name__c", 
                              "v.ecfObj.Version_Model__c", "v.ecfObj.Corrective_action_or_work_around_perfor__c", "v.ecfObj.SmartConnect_available__c", 
                              "v.ecfObj.Patient_on_the_table_at_time_of_event__c", "v.ecfObj.Was_anyone_injured__c", "v.ecfObj.Did_a_Radiation_Event_occur__c", "v.ecfObj.Did_a_Brachy_Event_Occur__c", "v.ecfObj.Did_a_MO_Event_Occur__c"];
        var correctionsPerformed = component.get('v.ecfObj.Immediate_correction_performed__c');
        var documentGateway = component.get('v.ecfObj.If_Yes_document_Gateway_info__c');
        var elem = component.find('gatewayDivId').getElement();
        
        $A.util.removeClass(elem, 'gatewayClass');
        
        // Check the required fields
        if(correctionsPerformed  === null || correctionsPerformed === '' || correctionsPerformed === undefined){
            return 'Please fill the required field <br/><ul><li>What corrections were performed?.</li></ul>';
        }
        if(smartConnectUsed === 'Yes' && (documentGateway === null || documentGateway === '' || documentGateway === undefined)) {
            $A.util.addClass(elem, 'gatewayClass');
            console.log('==Is smartConnectUsed required==');
            return 'Describe Gateway Info is Mandatory if Smartconnect is available.';
        } else {
            var errorMessage = '';
            for(var i=0; i < requiredFields.length; i++) {
                var fieldValue = component.get(requiredFields[i]);
                if(fieldValue !== undefined  && fieldValue !== null) {
                    fieldValue = fieldValue.trim();
                }

                if(fieldValue == '--None--' || fieldValue === '' || fieldValue === null || fieldValue === undefined || fieldValue === 'None') {
                    console.log('requiredFields=='+requiredFields[i]);
                    console.log('fieldValue=='+fieldValue);
                    
                    if(requiredFields[i] in errorDisplayKeywordDict)
                    	errorMessage += ('<li>'+errorDisplayKeywordDict[requiredFields[i]] + '</li>');
                    //return 'Please, fill the required field.';
                }
            }
            if(errorMessage !== '') {
                return 'Please, fill the required fields <br/><ul>'+ errorMessage+'</ul>';
            }
        }
        return null;
    },
    makeMandatoryRadiationEventFields : function(component, isRequired) {
        var requiredRadEventFieldList = ["modId", "treatDelWrongId", "treatDelPlanId", "affAnatomyId", "treatModId", "singleFractionId", 
                                         "radioTherepyTreatmentId", "errorPlannedDoseId", "totalPlannedId",
                                         "adjustedPlanId",  "prescriptionId", 
                                         "plannedTreatmentId", "actualTreatmentId", "treatmentRegionId", 
                                         "recordPlannedId", "closestNormalStructureId"];
        
        for(var i=0; i < requiredRadEventFieldList.length; i++) {
            if(isRequired) {
                $A.util.addClass(component.find(requiredRadEventFieldList[i]), 'showError');
            } else {
                $A.util.removeClass(component.find(requiredRadEventFieldList[i]), 'showError');
            }
        }
    },
    toggleRadiationEventType : function(component, isDisabled) {
        var toggleRadEventFieldList = ["treatModId", "singleFractionId", "errorPlannedDoseId", "totalPlannedId", "treatmentModalityDescId",
                                       "radioTherepyTreatmentId", "patientId1", "patientId2", "tissueExposedId", "adjustedPlanId", 
                                       "anatomyExposedId", "prescriptionId", "plannedTreatmentId", "actualTreatmentId", "treatmentRegionId", 
                                       "multipleFractionCountId", "percentWeeklyErrorId", "percentTotalDoseId", "recordPlannedId", "closestNormalStructureId"];
        
        for(var i=0; i < toggleRadEventFieldList.length; i++) {
            component.find(toggleRadEventFieldList[i]).set("v.disabled", isDisabled);
            if(isDisabled) {
                component.find(toggleRadEventFieldList[i]).set("v.value", "");
            }
        }
    },
    makeMandatoryBrachyEventFields : function(component, isRequired) {
        var requiredBrachyFieldList = ["unintendedDosev100Id", "criticalStructureId", "unintendedDosev150Id", "unintendedDosev200Id", 
                                       "plannedv100Id", "actualv100Id", "plannedBachyTreatmentId", "deliveredTreatmentId"];
        
        for(var i=0; i < requiredBrachyFieldList.length; i++) {
            if(isRequired) {
                $A.util.addClass(component.find(requiredBrachyFieldList[i]), 'showError');
            } else {
                $A.util.removeClass(component.find(requiredBrachyFieldList[i]), 'showError');
            }
        }
    },
    toggleBrachyEventType : function(component, isDisabled) {
        var toggleBrachyFieldList = ["unintendedDosev100Id", "criticalStructureId", "unintendedDosev150Id", "unintendedDosev200Id", 
                                     "plannedv100Id", "actualv100Id", "plannedBachyTreatmentId", "deliveredTreatmentId"];
        
        for(var i=0; i < toggleBrachyFieldList.length; i++) {
            component.find(toggleBrachyFieldList[i]).set("v.disabled", isDisabled);
            
            if(isDisabled) {
                component.find(toggleBrachyFieldList[i]).set("v.value", "");
            }
        }
    },
    makeMandatoryMoEventFields : function(component, isRequired) {
        var requiredMoFieldList = ["treatmentDeliveredWrongPatientId", "treatmentRegimenId", 
                                   "prescribedDoseId", "prescribedRegimenId"];
        
        for(var i=0; i < requiredMoFieldList.length; i++) {
            if(isRequired) {
                $A.util.addClass(component.find(requiredMoFieldList[i]), 'showError');
            } else {
                $A.util.removeClass(component.find(requiredMoFieldList[i]), 'showError');
            }
        }
    },
    toggleMoEventType : function(component, isDisabled) {
        var requiredMoFieldList = ["treatmentDeliveredWrongPatientId", "moPatientId1", "moPatientId2", "treatmentRegimenId", 
                                   "treatmentRegimenDescId", "prescribedRegimenId", "prescribedRegimenDescId", "prescribedDoseId",
                                   "totalDoseId"];
        
        for(var i=0; i < requiredMoFieldList.length; i++) {
            component.find(requiredMoFieldList[i]).set("v.disabled", isDisabled);
            if(isDisabled) {
                component.find(requiredMoFieldList[i]).set("v.value", "");
            }
        }
    },
    togglePhysicalInjury : function(component) {
        var injuryValue = component.find('injuryOccurId').get('v.value');
        var appropriateInjuryDivCmp = component.find('appropriateInjureDiv');
        
        if(injuryValue === 'No') {
            component.find('siteReceivedInjureId').set('v.disabled', true);
            component.find('otherPhysicalInjuryId').set('v.disabled', true);
            //component.find('appropriateInjureId').set('v.disabled', true);
            $A.util.addClass(appropriateInjuryDivCmp, 'disabledDiv');
        } else {
            component.find('siteReceivedInjureId').set('v.disabled', false);
            component.find('otherPhysicalInjuryId').set('v.disabled', false);
            //component.find('appropriateInjureId').set('v.disabled', false);    
            $A.util.removeClass(appropriateInjuryDivCmp, 'disabledDiv');
        }
    }
})