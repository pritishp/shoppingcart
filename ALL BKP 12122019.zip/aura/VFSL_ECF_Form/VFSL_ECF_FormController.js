({
    doInit : function(component, event, helper) {
        helper.initialize(component);
        helper.toggleFields(component);
        helper.getInjOptions(component);
        helper.getRadOptions(component);
        helper.getTreatmentModOptions(component);
        helper.getFractionOptions(component);
        helper.getCritStructOptions(component);
        
        component.find("modId").set("v.disabled", true);
        component.find("treatDelWrongId").set("v.disabled", true);
        component.find("treatDelPlanId").set("v.disabled", true);
        component.find("affAnatomyId").set("v.disabled", true);
        helper.toggleRadiationEventType(component, true);
        helper.toggleBrachyEventType(component, true);
        helper.toggleMoEventType(component, true);
        
        var workspaceAPI = component.find("workspace");
        workspaceAPI.isConsoleNavigation().then(function(response)
        {
            if(response){
           			workspaceAPI.getFocusedTabInfo().then(function(response) {
                    var focusedTabId = response.tabId;
                    component.set('v.workspaceTabId', focusedTabId);
                    workspaceAPI.setTabLabel({
                        tabId: focusedTabId,
                        label: "Create ECF" //set label you want to set
                    });
                    workspaceAPI.setTabIcon({
                        tabId: focusedTabId,
                        icon: "utility:record_create", //set icon you want to set
                        iconAlt: "Create ECF" //set label tooltip you want to set
                    });
                 })
            }
        });  
    },
     reInit : function(component, event, helper) {
        $A.get('e.force:refreshView').fire();
    },
    changePhysicalInjury : function(component, event, helper) {
        helper.togglePhysicalInjury(component);
    },
    OnDeathValueChanged: function(component, event, helper) {
        helper.toggleFields(component);
    },
    OnInjuredValueChanged: function(component, event, helper) {
        if(event.getParam('value') === 'No') {
            var opts = ['No'];
            component.set('v.injuredOptions', opts);
            component.set('v.radiationOptions', opts);
            
            var ecfObj = component.get('v.ecfObj');
            ecfObj.Was_there_a_death__c = 'No';
            component.find('injuryOccurId').set('v.value', 'No');
            component.set('v.ecfObj', ecfObj);
        } else {
            helper.getInjOptions(component);
            helper.getRadOptions(component);
        }
		helper.togglePhysicalInjury(component);
        helper.toggleFields(component);
    },
    OnSmartConnectAvailable: function(component, event, helper) {
        var elem = component.find('gatewayDivId').getElement();
        if(event.getParam('value') === 'Yes') {
            $A.util.addClass(elem, 'gatewayClass');
        } else {
            $A.util.removeClass(elem, 'gatewayClass');
        }
    },
    onRadEventChanged: function(component, event, helper) {
        var selectedValue = component.find("radiationId").get("v.value");
        
        if(selectedValue === '' || selectedValue === undefined || selectedValue === null || selectedValue === 'None' || selectedValue === '--None--') {
            component.set('v.modalityOptions', []);
            component.set('v.treatDelWrongOptions', []);
            component.set('v.treatDelPlanOptions', []);
            component.set('v.affAnatomyOptions', []);
            
            component.find("modId").set("v.disabled", true);
            component.find("treatDelWrongId").set("v.disabled", true);
            component.find("treatDelPlanId").set("v.disabled", true);
            component.find("affAnatomyId").set("v.disabled", true);
            helper.toggleRadiationEventType(component, true);
            helper.makeMandatoryRadiationEventFields(component, false);
        } else if(selectedValue === 'Yes') {
            component.set('v.modalityOptions', ['Yes', 'No']);
            component.set('v.treatDelWrongOptions', ['Yes', 'No']);
            component.set('v.treatDelPlanOptions', ['Yes', 'No']);
            component.set('v.affAnatomyOptions', ['Yes', 'No']);
            
            component.find("modId").set("v.disabled", false);
            component.find("treatDelWrongId").set("v.disabled", false);
            component.find("treatDelPlanId").set("v.disabled", false);
            component.find("affAnatomyId").set("v.disabled", false);
            helper.toggleRadiationEventType(component, false);
            helper.makeMandatoryRadiationEventFields(component, true);
        } else if(selectedValue === 'No') {
            component.set('v.modalityOptions', []);
            component.set('v.treatDelWrongOptions', []);
            component.set('v.treatDelPlanOptions', []);
            component.set('v.affAnatomyOptions', ['No']);
            
            component.find("modId").set("v.disabled", true);
            component.find("treatDelWrongId").set("v.disabled", true);
            component.find("treatDelPlanId").set("v.disabled", true);
            component.find("affAnatomyId").set("v.disabled", true);
            helper.toggleRadiationEventType(component, true);
            helper.makeMandatoryRadiationEventFields(component, false);
        } else if(selectedValue === 'N/A') {
            component.set('v.modalityOptions', []);
            component.set('v.treatDelWrongOptions', []);
            component.set('v.treatDelPlanOptions', []);
            component.set('v.affAnatomyOptions', ['Yes', 'No']);
            
            component.find("modId").set("v.disabled", true);
            component.find("treatDelWrongId").set("v.disabled", true);
            component.find("treatDelPlanId").set("v.disabled", true);
            component.find("affAnatomyId").set("v.disabled", false);
            helper.toggleRadiationEventType(component, false);
            helper.makeMandatoryRadiationEventFields(component, false);
        } else if(selectedValue === 'Customer Declined To Provide Info') {
            component.set('v.modalityOptions', []);
            component.set('v.treatDelWrongOptions', []);
            component.set('v.treatDelPlanOptions', []);
            component.set('v.affAnatomyOptions', ['Yes', 'No']);
            
            component.find("modId").set("v.disabled", true);
            component.find("treatDelWrongId").set("v.disabled", true);
            component.find("treatDelPlanId").set("v.disabled", true);
            component.find("affAnatomyId").set("v.disabled", false);
            helper.toggleRadiationEventType(component, false);
            helper.makeMandatoryRadiationEventFields(component, false);
        }
    },
    OnBrachyEventChanged : function(component, event, helper) {
        var selectedValue = component.find("BrachyEventId").get("v.value");
        var selectedBrachyValue = component.find("moEventId").get("v.value");
        if(selectedValue === 'Yes' && selectedBrachyValue === 'Yes') {
            component.find("radiationId").set("v.value", '');
            component.changeRadEvent(event, helper);
        }

        if(selectedValue === '' || selectedValue === undefined || selectedValue === null || selectedValue === 'None' || selectedValue === '--None--') {
            helper.toggleBrachyEventType(component, true);
            helper.makeMandatoryBrachyEventFields(component, false);
        } else if(selectedValue === 'No') {
            helper.toggleBrachyEventType(component, true);
            helper.makeMandatoryBrachyEventFields(component, false);
        } else if(selectedValue === 'Yes') {
            helper.toggleBrachyEventType(component, false);
            helper.makeMandatoryBrachyEventFields(component, true);
        } else {
            helper.toggleBrachyEventType(component, false);
            helper.makeMandatoryBrachyEventFields(component, false);
        }
    },
    OnMoEventChanged : function(component, event, helper) {
        var selectedValue = component.find("moEventId").get("v.value");
        var selectedMoValue = component.find("BrachyEventId").get("v.value");
        if(selectedValue === 'Yes' && selectedMoValue === 'Yes') {
            component.find("radiationId").set("v.value", '');
            component.changeRadEvent(event, helper);
        }
        	
        if(selectedValue === '' || selectedValue === undefined || selectedValue === null || selectedValue === 'None' || selectedValue === '--None--') {
            helper.toggleMoEventType(component, true);
            helper.makeMandatoryMoEventFields(component, false);
         } else if(selectedValue === 'No') {
            helper.toggleMoEventType(component, true);
			helper.makeMandatoryMoEventFields(component, false);
		 } else if(selectedValue === 'Yes') {
            helper.toggleMoEventType(component, false);
            helper.makeMandatoryMoEventFields(component, true);
         } else {
            helper.toggleMoEventType(component, false);
            helper.makeMandatoryMoEventFields(component, false);
         }
    },
    cancelECF: function(component, event, helper) {
         var workspaceAPI = component.find("workspace");
         workspaceAPI.isConsoleNavigation().then(function(response)
         {
        	console.log('==response=='+response);
             workspaceAPI.getFocusedTabInfo().then(function(response) {
            var focusedTabId = response.tabId;
            workspaceAPI.closeTab({tabId: focusedTabId});
            })
            .catch(function(error) {
                console.log(error);
            });
        });
        
        
        var navEvent = $A.get("e.force:navigateToSObject");
        navEvent.setParams({
            recordId: component.get("v.recordId"),
            slideDevName: "detail"
        });
        navEvent.fire(); 
    },
    
    saveForm: function(component, event, helper) {
        helper.saveRecord(component);
    }
})