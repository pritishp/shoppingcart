({
    doInit : function(component, event, helper) {  
        var changeIWOButtonClass = component.find("CreateIWO");
        var changeIWO_PT_ButtonClass = component.find("CreateIWOPT");
        var changeCloseInstallationWOButtonClass = component.find("CloseInstallationWorkOrder");
        var ChangeCloseWorkOrder =  component.find("CloseWorkOrder");
        var ChangeButtonSendToDocuSign = component.find("SendToDocuSign");
        //Added by Shital
        var changeReOpenWorkOrderClass = component.find("ReOpenWorkOrder");
        //var showSTB = true;
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        //var userProfile = $A.get("$SObjectType.CurrentUser.Profile.Name");
        //console.log('user profile: '+userProfile);
        
        var workOrd = component.get('c.fetchWorkOrder'); 
        workOrd.setParams({
            "woId" : component.get('v.recordId') 
        });
        workOrd.setCallback(this, function(response){
            var state = response.getState(); // get the response state
            if(state == 'SUCCESS') {
                var obj = response.getReturnValue();
                if(!obj.Escalated_Complaint_Forms__r)
                	component.set("v.ecfButton", true);
                
                component.set("v.workOrderObj", obj);
                component.set("v.recordTypeName", obj.RecordType.Name);
                component.set("v.woStatus",obj.Status);
                
                if(obj.Notes_to_FE__c != null && obj.Notes_to_FE__c.length > 80){
                   component.set("v.feNotes",obj.Notes_to_FE__c.substring(0,80) + '...'); 
                }else{
                    component.set("v.feNotes",obj.Notes_to_FE__c);
                }
                
                // QuyGP 6/24/2019 Edit Start
                if(obj.RecordType.Name === 'Planning T&E') {
                    $A.util.addClass(changeIWOButtonClass, ".slds-show_inline-block");
                    $A.util.removeClass(changeIWOButtonClass, "slds-hide");
                    
                }
                // QuyGP 6/24/2019 Edit End
                else if(/*obj.RecordType.Name === 'Planning T&E' || */obj.RecordType.Name === 'Planning VIS'){
                    $A.util.addClass(changeIWOButtonClass, ".slds-show_inline-block");
                    $A.util.removeClass(changeIWOButtonClass, "slds-hide");
                    
                    $A.util.addClass(changeIWO_PT_ButtonClass, ".slds-show_inline-block");
                    $A.util.removeClass(changeIWO_PT_ButtonClass, "slds-hide");     
                }else if(obj.RecordType.Name === 'Installation'){
                    $A.util.addClass(changeCloseInstallationWOButtonClass, ".slds-show_inline-block");
                    $A.util.removeClass(changeCloseInstallationWOButtonClass, "slds-hide");
                
                }/*else{
                    $A.util.addClass(ChangeCloseWorkOrder, ".slds-show_inline-block");
                    $A.util.removeClass(ChangeCloseWorkOrder, "slds-hide");   
                }  */ 
                if((obj.RecordType.Name === 'Project Management' || obj.RecordType.Name === 'Planning VIS') && (obj.Status === 'Closed' || obj.Status === 'Canceled')){
                    $A.util.addClass(changeReOpenWorkOrderClass, ".slds-show_inline-block");
                    $A.util.removeClass(changeReOpenWorkOrderClass, "slds-hide");
                }
                
                if(!obj.Send_DocuSign_FSR__c && obj.Count_of_FSR__c){
                    $A.util.addClass(ChangeButtonSendToDocuSign, ".slds-show_inline-block");
                    $A.util.removeClass(ChangeButtonSendToDocuSign, "slds-hide");
                }
           }
        });
        $A.enqueueAction(workOrd);
    },
    
    navigateToReOpenWO : function(component, event, helper) { 
       
        var workOrd = component.get('c.changeWorkOrdStatus'); 
        workOrd.setParams({
            "woId" : component.get('v.recordId') 
        });
        workOrd.setCallback(this, function(response){
            
            var state = response.getState(); // get the response state
            if(state == 'SUCCESS') { 
                var message = response.getReturnValue();
                helper.refreshRecord(component, event, message);
           }
        });
        $A.enqueueAction(workOrd);
    },
    
    /*navigateToCancelWO : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderCancelButton",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToCancelWO : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderCancelButton",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
    
    /*navigateToModifyDate : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderDateChange",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToModifyDate : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderDateChange",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
    
    /*navigateToReassign : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderReassignButton",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToReassign : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderReassignButton",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
    
    navigateToReassignSA : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderReassignmentSA",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: false,
                                       showCloseButton: false,
                                       closeCallback: function() {;
                                       }
                                   })
                               }
                           })
    },
    
    navigateToParts : function(component, event, helper) {
        $A.createComponent("c:VFSL_ManageParts",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: false,
                                       showCloseButton: false,
                                       closeCallback: function() {;
                                       }
                                   })
                               }
                           })
    },
    
    navigateToServiceReport : function(component, event, helper) {
        $A.createComponent("c:VFSL_CreateServiceReport",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: false,
                                       showCloseButton: false,
                                       closeCallback: function() {;
                                       }
                                   })
                               }
                           })
    },
    
    /*navigateToAccept : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderAcceptButton",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToAccept : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderAcceptButton",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
    
    /*navigateToSimulate : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderSimulateButton",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToSimulate : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderSimulateButton",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
    
    navigateToSubmit : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        var recordTypeName = component.get("v.recordTypeName");
        if(recordTypeName === 'Installation' || recordTypeName === 'Planning VIS') {
            evt.setParams({
                componentDef : "c:VFSL_VIS_SubmitWorkOrder",
                componentAttributes: {
                    recordId : component.get("v.recordId")
                }
            });
            evt.fire();
        } else if(recordTypeName === 'Field Service'){
            var isValid = helper.validate(component);
            
            //=================================NEW IMP START=================================
            if(isValid) {
                helper.validateEmergency(component);
            }
            //=================================NEW IMP END==================================
            
            /*=================================OLD IMP START=================================
            if(isValid) {
                evt.setParams({
                    componentDef : "c:VFSL_FS_SubmitWorkOrder",
                    componentAttributes: {
                        recordId : component.get("v.recordId")
                    }});
                evt.fire();
            }
            =================================OLD IMP END==================================*/
        }   
    },
    
    submitFSWorkOrder : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_FS_SubmitWorkOrder",
                componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },
    
    navigateToUpdateInstallationPlan : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        var recordTypeName = component.get("v.recordTypeName");
        if(recordTypeName === 'Planning VIS') {
        	evt.setParams({
            	componentDef : "c:updateinstallationplan",
                	componentAttributes: {
                	recordId : component.get("v.recordId")
            	}
        	});
        	evt.fire();
        }
    },
    navigateToUpdatePTInstallationPlan : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        var recordTypeName = component.get("v.recordTypeName");
        if(recordTypeName === 'Planning VIS') {
        	evt.setParams({
            	componentDef : "c:updateptinstallationplan",
                	componentAttributes: {
                	recordId : component.get("v.recordId")
            	}
        	});
        	evt.fire();
        }
    },
    navigateToWorkOrderApproval : function(component, event, helper) {
        $A.createComponent("c:ApprovalWOComponent",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   console.log('Create Component Success'+JSON.stringify(content));
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
    
    /*navigateToReview : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderReviewButton",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToReview : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderReviewButton",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
   
    /*navigateToReviewWO : function(component, event, helper) {
        $A.createComponent("c:ReviewWorkOrderComponent",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },*/
    
    /*navigateToFOA : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:vfsl_FOAreviewPage",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToFOA : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToURL");
        evt.setParams({
            "url":"/apex/Vfsl_FOAreviewpage?id="+component.get("v.recordId")
        });
        evt.fire();
    },
    
    /*navigateToBilling : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:LaunchBillingpage",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    navigateToBilling : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToURL");
        evt.setParams({
            "url":"/apex/vfsl_billingvfpage?id="+component.get("v.recordId")
        });
        evt.fire();
    },
    
    navigateToEmail : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderAttachEmail",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },
    
    /*navigateToCloseSupport : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_WorkOrderCloseSupportButton",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },*/
    
    navigateToCloseSupport : function(component, event, helper) {
        $A.createComponent("c:VFSL_WorkOrderCloseSupportButton",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,
                                       showCloseButton: true,
                                       showCloseButton: true,
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    },
    
    navigateToCloseInstallationWO : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:VFSL_InstallationWOClosureComponent",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
        evt.fire();
    },
    
    navigateToCreateIWO_PT : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        var PTflag = true;
        evt.setParams({
            componentDef : "c:VFSL_RedirectToIWOPage",
            componentAttributes: {
                recordId : component.get("v.recordId"),
                isPTFlag : PTflag
            }
        });
        evt.fire();
    },
    
    checkCreateIWOCriterias : function(component, event, helper) {
		var checkWO = component.get('v.workOrderObj');
        if(checkWO.Top_Level_Asset__c == null && checkWO.RecordType__c == 'Planning_VIS'){
            component.set('v.assetWarning',true);
            return;
        }
        console.log('****Inside checkCreateIWOCriterias***');
        var workOrd = component.get('c.getWOLI'); 
        workOrd.setParams({
            "woId" : component.get('v.recordId') 
        });
        workOrd.setCallback(this, function(response){
            console.log('****Inside checkCreateIWOCriterias----1***');
            var state = response.getState(); // get the response state
            console.log('****Inside checkCreateIWOCriterias----state***'+state);
            if(state == 'SUCCESS') { 
                var message = response.getReturnValue();
                if(message === 'OK'){
                    helper.navigateToCreateIWO(component, event);
                }else{
                    helper.showErrorToastIWO(component, event, message);
                }  
           }
        });
        $A.enqueueAction(workOrd);
    },
    
    closeModal: function(component, event, helper) {
      // Set isModalOpen attribute to false  
      component.set("v.woWarning", false);
   },
    
    navigateToDocuSign: function(component, event, helper) {
        var isValid = helper.validateDocuSign(component);
        
        if(isValid) {
            var send = confirm('FSR will be Submitted to Docusign for E-Signature');
            if(send) {
                var wo = component.get('v.workOrderObj');
                wo.Send_DocuSign_FSR__c = true;

				delete wo['Escalated_Complaint_Forms__r'];                
                var workOrd = component.get('c.updateSendDocu');
                console.log(JSON.stringify(wo));
                workOrd.setParams({
                    "woObj" : JSON.stringify(wo)
                });
                workOrd.setCallback(this, function(response){
                    var state = response.getState(); // get the response state
                    if(state == 'SUCCESS') {
                        window.location.href = '/'+component.get("v.recordId");
                    } else {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title: 'Error!',
                            type: 'error',
                            message: response.getError()[0].message,
                            mode: 'sticky'
                        });
                        toastEvent.fire();
                    }
                });
                $A.enqueueAction(workOrd);
            }
        }
    },
    
    navigateToECF : function(component, event, helper) {
        var woObject = component.get("v.workOrderObj");
        var ecfBool = component.get("v.ecfButton");
        var urlEvent = $A.get("e.force:navigateToComponent");
        console.log('ecfBool: ' + ecfBool);
        
        if(woObject.ECF_Required__c == 'Yes from Work Order' && ecfBool) {
            urlEvent.setParams({
                componentDef  : "c:VFSL_ECF_Form",
                componentAttributes : {
                    recordId : woObject.Id
                }
            });
            urlEvent.fire();
        } else {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error Message',
                message:'You cannot create ECF form because Escalated Complaint Required is not set to Yes from Work Order, or where active ECF is already created.',
                duration:' 5000',
                key: 'info_alt',
                type: 'error',
                mode: 'pester'
            });
            toastEvent.fire();
        }
    },
    
    navigateToPHI : function(component, event, helper) {
        var woObject = component.get("v.workOrderObj");
        var urlEvent = $A.get("e.force:navigateToComponent");
        
        urlEvent.setParams({
            componentDef  : "c:VFSL_PHILog_Parent_Component",
            componentAttributes : {
                recordId : woObject.Id
            }
        });
        urlEvent.fire(); 
    },
    
    navigateToToR: function (component, event, helper) {
        var recordId = component.get("v.recordId");
        var url = '/apex/VFSL_TransferResponsibilityLaunch?id=' + recordId;
        window.open(url, '_blank');
    },
    
    navigateToEmailTripReport: function (component, event, helper) {
        var navEvt = $A.get("e.force:navigateToComponent");
        navEvt.setParams({
            componentDef: "c:vfsl_tripReportPage",
            componentAttributes :{"recordId":component.get('v.recordId')}
        });
        navEvt.fire();
    },
    
    navigateToCreateSA: function (component, event, helper) {        
        $A.createComponent("c:VFSL_TE_CreateSA",{recordId:component.getReference("v.recordId")},
                           function(content,status){
                               if (status === "SUCCESS") {
                                   component.find('cmp1').showCustomModal({
                                       body:content,                                      
                                       closeCallback: function() {
                                       }
                                   })
                               }
                           })
    }
})