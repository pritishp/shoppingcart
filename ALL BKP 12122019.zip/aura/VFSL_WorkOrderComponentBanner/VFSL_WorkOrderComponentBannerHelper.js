({
	validate: function(component) {
        var errorMsg = '';
        var isValid = true;
        var woRecord = component.get("v.workOrderObj");
        var hasEmergency = false;
        
        console.log('woRecord: ' + JSON.stringify(woRecord));
        if((woRecord.Non_Varian_Service__c || woRecord.Non_Varian_Parts__c) && !woRecord.Non_Varian_Comments__c)
            errorMsg = "Non-Varian Comments required when Non-Varian Service and/or Non-Varian Parts is checked.";
        
        if((!woRecord.Non_Varian_Service__c || !woRecord.Non_Varian_Parts__c) && woRecord.Non_Varian_Comments__c)
            errorMsg = "Non-Varian Service and/or Non-Varian Parts must be checked if Non-Varian Comments are entered.";
        
        if((woRecord.Injured__c === 'TBD' || woRecord.ECF_Required__c === 'TBD' || woRecord.Process_Workflow__c === 'TBD' || woRecord.Process_Code__c === 'TBD' ||
            !woRecord.Injured__c || !woRecord.ECF_Required__c || !woRecord.Process_Workflow__c|| !woRecord.Process_Code__c) && woRecord.Complaint__c === 'Yes')
            errorMsg = "Injury and/or Escalated Complaint Required and/or Process Workflow and/or Process Code is set to \"TBD\". These fields cannot remain as \"TBD\". Please ensure correct entry for both fields.";
        
        if ((woRecord.Status === "Assigned" &&
                      woRecord.ECF_Required__c !== "Yes from Work Order" &&
                      !woRecord.Count_of_FSR__c) || 
                    (woRecord.Status === "Assigned" && 
                     woRecord.ECF_Required__c === "Yes from Work Order" &&
                     (!woRecord.ECF_Form_Count__c  ||
                     !woRecord.Count_of_FSR__c))
           ) {
            	errorMsg = "FSR is not yet created, OR Work Order is Escalated Complaint Required from Work Order, but there is no ECF created for this Case/Work Order. Create FSR, and/or submit ECF prior to WO Submission";	
        }
        
        if((!woRecord.Count_of_Attachments__c || woRecord.Count_of_Attachments__c < 2) &&
           woRecord.SAP_Priority__c === "5 - PMI" &&  !errorMsg) {
            isValid = false;
            component.set("v.warningMessage", "Please attach PM Chceklist and supporting documentation to the Work Order if you have not already done so.");
            component.set("v.woWarning", true);
        }
            
        if(errorMsg) {
            isValid = false;
            this.setToastErrorMsg(errorMsg);
        }
        
        return isValid;	
    },
    
    validateEmergency: function(component) {
        var evt = $A.get("e.force:navigateToComponent");
        var emergencyWOLI = component.get('c.hasEmergencyWOLI'); 
        emergencyWOLI.setParams({
            "woId" : component.get('v.recordId') 
        });
        emergencyWOLI.setCallback(this, function(response){
            console.log('response: ' + JSON.stringify(response));
            var state = response.getState();
            if(state == 'SUCCESS') {
                var obj = response.getReturnValue();
                console.log('obj: ' + obj);
                if(obj) {
                    evt.setParams({
                        componentDef : "c:VFSL_FS_SubmitWorkOrder",
                        componentAttributes: {
                            recordId : component.get("v.recordId")
                        }});
                    evt.fire();
                } else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title: 'Error!',
                        type: 'error',
                        message: "Work Order is priority of 1 - Emergency, but at least one Activity Type on Service tab is not \"Emergency Service\". Verify the Activity Types, and adjust if necessary. If Priority is incorrect, please change the Purpose of Visit."
                    });
                    toastEvent.fire();
                }
            }
        });
        $A.enqueueAction(emergencyWOLI);
    },
    
    setToastErrorMsg: function(errorMsg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: 'Error!',
            type: 'error',
            message: errorMsg
        });
        toastEvent.fire();
    },
    
    navigateToCreateIWO : function(component, event) {
        var evt = $A.get("e.force:navigateToComponent");
        var PTflag = false;
        evt.setParams({
            componentDef : "c:VFSL_RedirectToIWOPage",
            componentAttributes: {
                recordId : component.get("v.recordId"),
                isPTFlag : PTflag
            }
        });
        evt.fire();
    },
    
    refreshRecord : function (component, event, message) {
        alert(message);
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
          "recordId": component.get("v.recordId"),
          "slideDevName": "detail"
        });
        navEvt.fire();
	},
    
    showErrorToastIWO : function(component, event, message) {
        
        var messageArray = message.split("***");
        var finalMessage = '';
        console.log('------messageArray----'+messageArray);
        messageArray.forEach(function(eachValue) {
            finalMessage = finalMessage + eachValue + '\n';
        });
        console.log('------finalMessage----'+finalMessage);
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            mode: 'sticky',
            type: 'error',
       		message: finalMessage
            //messageTemplate: '{0},{1},{2}',
            //messageTemplateData:messageArray
        });
        toastEvent.fire();
    },
    
    validateDocuSign: function(component, event, message) {
        var isValid = true;
        var woRecord = component.get("v.workOrderObj");
        if(!woRecord.Service_Resource_Email__c || !woRecord.Contact_Email__c) {
            this.setToastErrorMsg('Service Resource Email and Contact Email is required');
            isValid = false;
    	
        } else if(!woRecord.Account.Responsible_Engineer_Mgr_Email__c && woRecord.Country === 'Japan') {
            this.setToastErrorMsg('Responsible Engineer Mgr in Account is required when Country is Japan');
            isValid = false;
        }
        
    	return isValid;
	}
})