({
    doInit: function(component, event, helper) {
        helper.setUserTimezone(component);
        helper.populateWOFieldValues(component);
    },
    searchActivity: function(component, event, helper) {
        var data = component.get("v.activityList"),
            term = component.get("v.activityFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.LineItemNumber) || regex.test(row.Asset_Name__c) || regex.test(row.Activity_Type__c) || regex.test(row.Billing_Type__c));
        } catch (e) {}
        component.set("v.filteredActivityList", results);
    },
    searchPart: function(component, event, helper) {
        var data = component.get("v.partList"),
            term = component.get("v.partFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.LineItemNumber) || regex.test(row.Type__c) || regex.test(row.InstalledPartName) || regex.test(row.Asset_Name__c));
        } catch (e) {}
        component.set("v.filteredPartList", results);
    },
    searchRemainingPart: function(component, event, helper) {
        var data = component.get("v.remPartsList"),
            term = component.get("v.remainingPartFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.Part_Number__c) || regex.test(row.WOLineItemNumber) || regex.test(row.InstalledQty.toString()) || regex.test(row.Remaining_Qty__c.toString()));
        } catch (e) {}
        component.set("v.filteredRemPartsList", results);
    },
    searchRemovedPart: function(component, event, helper) {
        var data = component.get("v.removedPartsList"),
            term = component.get("v.removedPartFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.LineItemNumber) || regex.test(row.Type__c) || regex.test(row.InstalledPartName) || regex.test(row.Removed_Qty__c.toString()));
        } catch (e) {}
        component.set("v.filteredRemovedPartsList", results);
    },
    searchtools: function(component, event, helper) {
        var data = component.get("v.toolsList"),
            term = component.get("v.toolsFilter"),
            results = data,
            regex;
        try {
            regex = new RegExp(term, "i");
            results = data.filter(row => regex.test(row.LineItemNumber) || regex.test(row.toolName) || regex.test(row.toolType) || regex.test(row.serialNumber));
        } catch (e) {}
        component.set("v.filteredtoolsList", results);
    },
    submitWorkOrder: function(component, event, helper) {
        var isValid = helper.validate(component);
        if (isValid) {
            // Submit Inst WO Logic
            helper.submitWO(component);
        }
    },
    submitWorkOrderFromWarning: function(component, event, helper) {
        helper.submitWO(component);
    },
    cancelWorkOrder: function(component, event, helper) {
        // Cancel Submit Inst WO Logic
        helper.redirectWOPage(component);
    },
    closeModal: function(component, event, helper) {
      // Set isModalOpen attribute to false  
      component.set("v.toolWarning", false);
   },
    // common reusable function for toggle sections
    toggleSection: function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open');

        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if (sectionState == -1) {
            sectionDiv.setAttribute('class', 'slds-section slds-is-open');
        } else {
            sectionDiv.setAttribute('class', 'slds-section slds-is-close');
        }
    }
})