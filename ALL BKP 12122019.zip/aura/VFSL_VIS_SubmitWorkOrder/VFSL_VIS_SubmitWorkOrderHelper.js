({
    setUserTimezone:  function(component) {
        var action = component.get("c.getCurrentTimezoneKey");

        var self = this;
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            component.set("v.timeZoneKey", result);
            console.log("Timezone Key==============" + result);
        });
        $A.enqueueAction(action);
    },
    populateWOFieldValues: function(component) {
        var action = component.get("c.getWORecord");
        console.log("case record id: " + component.get("v.recordId"));
        action.setParams({
            recordId: component.get("v.recordId")
        });
        var self = this;
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            console.log("Result==============" + result);
            if (result.isMessage === false) {
                component.set("v.workOrderObj", result.workOrder);

                // Tools Tab - Display Exact Name instead of Id.
                for (var i = 0; i < result.toolsLineItems.length; i++) {
                    var row = result.toolsLineItems[i];
                    if (row.Service_Tool__c !== null && row.Service_Tool__c !== undefined) {
                        row.toolName = row.Service_Tool__r.Name;
                        row.toolType = row.Service_Tool__r.Tool_Type__c;
                        row.serialNumber = row.Service_Tool__r.Serial_Number__c;
                        row.outOfCalibration = row.Service_Tool__r.Calibration_Status__c;
                    }
                }
                component.set("v.toolsList", result.toolsLineItems);
                component.set("v.filteredtoolsList", result.toolsLineItems);

                // Activity Tab
                var timeZoneKey = component.get("v.timeZoneKey");
                for (var i = 0; i < result.activityLineItems.length; i++) {
                    var row = result.activityLineItems[i];
                    if (row.StartDate !== null && row.EndDate !== null) {
                        var stTime = new Date(row.StartDate).toLocaleString("en-US", {timeZone: timeZoneKey});
                        stTime = new Date(stTime);

                        var etTime = new Date(row.EndDate).toLocaleString("en-US", {timeZone: timeZoneKey});
                        etTime = new Date(etTime);                        

                        row.CustomStartDate = stTime.toLocaleString();
                        row.CustomEndDate = etTime.toLocaleString();
                    }
                }
                component.set("v.activityList", result.activityLineItems);
                component.set("v.filteredActivityList", result.activityLineItems);

                // InstalledParts Tab - Display Exact Name instead of Id.
                for (var i = 0; i < result.partsLineItems.length; i++) {
                    var row = result.partsLineItems[i];
                    if (row.Part__c !== null) row.InstalledPartName = row.Part__r.Name;
                    if (row.Part_Qty__c === null || row.Part_Qty__c === undefined)
                        row.Part_Qty__c = "0";
                }
                component.set("v.partList", result.partsLineItems);
                component.set("v.filteredPartList", result.partsLineItems);

                // RemainingQty Tab - Display Exact Name instead of Id.
                for (var i = 0; i < result.remainingPartsLineItems.length; i++) {
                    var row = result.remainingPartsLineItems[i];
                    if (row.WOLineItemNumber !== null)
                        row.WOLineItemNumber = row.WorkOrderLineItem.LineItemNumber;
                    if (row.InstalledQty !== null)
                        row.InstalledQty = row.WorkOrderLineItem.Part_Qty__c;
                    if (row.RemovedQty !== null)
                        row.RemovedQty = row.WorkOrderLineItem.Removed_Qty__c;
                    if (row.ProductStock !== null)
                        row.ProductStock = row.WorkOrderLineItem.Product_Item__c;
                }
                component.set("v.remPartsList", result.remainingPartsLineItems);
                component.set("v.filteredRemPartsList", result.remainingPartsLineItems);

                // RemovedPartsToBeReturned Tab - Display Name instead of Id.
                for (var i = 0; i < result.remainingProdLineItems.length; i++) {
                    var row = result.remainingProdLineItems[i];
                    if (row.Part__c !== null) row.InstalledPartName = row.Part__r.Name;
                }
                component.set(
                    "v.remainingProdLineItems",
                    result.remainingProdLineItems
                );
                component.set(
                    "v.filteredRemainingProdLineItems",
                    result.remainingProdLineItems
                );
                component.set(
                    "v.workOrderObj.Machine_Release__c",
                    new Date().toISOString()
                );

                /* Set Close to True, if WO Interface Status is Processed or Processing
                if (
                    result.workOrder.Interface_Status__c === "Processed" ||
                    result.workOrder.Interface_Status__c === "Processing"
                )
                    component.set("v.workOrderObj.Close__c", true);*/

                // Submit WO should not allow if ECF Required set to 'Yes from Work Order' and ECF Form Count is 0
                if (
                    result.workOrder.ECF_Required__c === "Yes from Work Order" ||
                    result.workOrder.ECF_Form_Count__c === 0
                ) {
                    self.setToastErrorMsg(
                        "Submit WO should not allow submission if ECF Required = Yes from Work Order, and no ECF has been created or submitted."
                    );
                    setTimeout(function() {
                        self.redirectWOPage(component);
                    }, 7000);
                }
            } else {
                component.find("SubmitButton").set("v.disabled", true);
                self.setToastErrorMsg(result.message);

                setTimeout(function() {
                    self.redirectWOPage(component);
                }, 7000);
                $A.get("e.force:closeQuickAction").fire();
            }
        });
        $A.enqueueAction(action);
    },
    setToastErrorMsg: function(errorMsg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: "Error!",
            type: "error",
            message: errorMsg
        });
        toastEvent.fire();
    },
    redirectWOPage: function(component) {
        //$A.get('e.force:refreshView').fire();
        var sObectEvent = $A.get("e.force:navigateToSObject");
        sObectEvent.setParams({
            recordId: component.get("v.recordId"),
            slideDevName: "detail"
        });
        sObectEvent.fire();
    },
    validate: function(component) {
        var errorMsg = "";
        var isValid = true;
        var woRecord = component.get("v.workOrderObj");

        // Machine Release is required, if priority 'Emergency'
        // Commented condition woRecord.Priority === 'Emergency'
        var machine_release_time = component.get(
            "v.workOrderObj.Machine_Release__c"
        );
        if (machine_release_time === null || machine_release_time === undefined)
            errorMsg = "Please fill in Machine Release Time.";

        var work_performed = component.get(
            "v.workOrderObj.Closure_Summary__c"
        );
        if (work_performed === null || work_performed === undefined)
            errorMsg = "Please fill in Work Performed.";

        // WO's Service Resource's Work Center required, if Service resource is assigned on WO
        if (woRecord.Service_Resource__c !== undefined && woRecord.Service_Resource__c !== null) {
            if(
                (woRecord.Service_Resource__r.Work_Center__c === null ||
                    woRecord.Service_Resource__r.Work_Center__c === undefined)
            )
                errorMsg += "Technician & Badge ID cannot be Null.";
    	}

        var activityList = component.get("v.activityList");
        var partList = component.get("v.partList");
        var remainingParts = component.get("v.remPartsList");
        var removedPartsList = component.get("v.removedPartsList");
        var toolsList = component.get("v.toolsList");
        
        var allWoliEntries = activityList.concat(partList,removedPartsList, toolsList);
        var isVisUsageEntry = false;
		for (var i = 0; i < allWoliEntries.length; i++) {
			var row = allWoliEntries[i];
            if(row !== null && row !== undefined && row.RecordType.Name === "VIS Usage") {
                isVisUsageEntry = true;
                break;
            }
        }  

        // Atleast, one Labor, Travel and Part WOLI required on WO
        if (!isVisUsageEntry)
            errorMsg +=
            "Work Order must be fully synchronized prior to Submission.  Each line in Activities and Parts tabs must have a Line Number.  Please Sync Data, and Re-Submit";

        var isClose = component.get("v.workOrderObj.Close__c");
        var remainingPartsCount = component.get(
            "v.workOrderObj.Remaining_Parts_Count__c"
        );
        if (remainingPartsCount !== null && remainingPartsCount !== undefined)
            remainingPartsCount = parseInt(remainingPartsCount);
        // Remaining Parts count > 0 and isClose true
        if (
            (parseInt(remainingPartsCount) > 0 /*||
               remainingPartsCount === undefined*/) &&
            isClose
        ){
           errorMsg +=
            "Exit to WO and disposition these parts appropriately prior to Submission.";  
        }
           

        var submittedLineCount = component.get("v.workOrderObj.Line_Count__c");
        if (submittedLineCount !== null && submittedLineCount !== undefined)
            submittedLineCount = parseInt(submittedLineCount);
        // Submitted Line Count is 0
        if (parseInt(submittedLineCount) === 0 || submittedLineCount === undefined)
            errorMsg +=
            "Submission is not allowed unless at least 1 labor or part is included.";

        // Not allowed, if close=true and product request line items's remaining qty > 0.. If any product request line items are there.
        if (isClose) {
            var isRemainingQty = false;
            if (remainingParts.length > 0) {
                for (var i = 0; i < remainingParts.length; i++) {
                    var row = remainingParts[i];
                    if (
                        row.Remaining_Qty__c !== null &&
                        row.Remaining_Qty__c !== undefined &&
                        parseInt(row.Remaining_Qty__c) > 0
                    ) {
                        isRemainingQty = true;
                        break;
                    }
                }
            }
            if (isRemainingQty) {
                errorMsg +=
                    "If Close = true, then Submit WO is not allowed until all Product Request Line Item have Remaining Qty. 0.";
            }
        }

        // Check whether entries on WOLI are overlapping
        //var newConcatList = activityList.concat(partList);
        var daterangeArray = [];
        var lineNumberList = [];
        for (var i = 0; i < activityList.length; i++) {
            var row = activityList[i];
            if(row.EndDate !== null && row.StartDate !== null) {
                lineNumberList.push(row.LineItemNumber);
            	daterangeArray.push(new Date(row.StartDate));
            	daterangeArray.push(new Date(row.EndDate));
            }
        }
        //var isOverlap = this.multipleDateRangeOverlaps(daterangeArray, lineNumberList);
        //if (isOverlap) {
        //    errorMsg += "Work Order Line Item Entries are overlapping. Please, correct startdate and enddate on work order line item to avoid overlapping.";
        //}
        var isOverlapMsg = this.multipleDateRangeOverlaps(daterangeArray, lineNumberList);
        if (isOverlapMsg !== null) {
            errorMsg += isOverlapMsg;
        }

        if (errorMsg !== "" && errorMsg !== null) {
            isValid = false;
            this.setToastErrorMsg(errorMsg);
        }

        var toolsList = component.get("v.toolsList");
        //var msg;
        if ((errorMsg === "" || errorMsg === null) && toolsList.length === 0) {
			component.set("v.warningMsg", "<li>No Test Equipment usage has been recorded on this Work Order. Select Save to confirm this is correct. Select Cancel to return to the Work Order and record Test Equipment usage.</li>");
            component.set("v.toolWarning", true);
            isValid = false;
        }

        if ((errorMsg === "" || errorMsg === null) && isClose) {
            //msg = component.get("v.warningMsg");
			component.set("v.warningMsg", "<li>If you plan to use the WO again, please ensure hte Close checkbox is not checked.</li>");
            component.set("v.toolWarning", true);
            isValid = false;
        }

        if ((errorMsg === "" || errorMsg === null) && !isClose) {
            //msg = component.get("v.warningMsg");
			component.set("v.warningMsg", "<li>If this is the last time you are going to use this WO, please go back and check the close box.</li>");
            component.set("v.toolWarning", true);
            isValid = false;
        }

        return isValid;
    },
    submitWO: function(component) {
        var action = component.get("c.saveWorkOrder");
        var activityList = component.get("v.activityList");
        var partList = component.get("v.partList");
        var toolsList = component.get("v.toolsList");
        var newActivityWoliList = activityList.concat(partList);
        var newConcatWoliList = newActivityWoliList.concat(toolsList);
        console.log("case record id: " + component.get("v.recordId"));

        // Convert to customer local time and set to 'customer malfunction end' field
		var machine_release_time = new Date(component.get("v.workOrderObj.Machine_Release__c"));
		var timeZoneKey = component.get("v.timeZoneKey");
		var customer_end_time = new Date(machine_release_time);
		customer_end_time = new Date(customer_end_time.toLocaleString("en-US", { timeZone: timeZoneKey }));
		customer_end_time.setTime(customer_end_time.getTime() - customer_end_time.getTimezoneOffset() * 60000);
        var woObj = component.get("v.workOrderObj");

        action.setParams({
            woObj: JSON.stringify(woObj),
            woliList: JSON.stringify(newConcatWoliList)
        });
        component.find("SubmitButton").set("v.disabled", true);
        var self = this;
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            var state = response.getState();
            console.log("Result==============" + result);
            if (state === "SUCCESS") {
                setTimeout(function() {
                	// Redirect to WO record
                	self.redirectWOPage(component);
				}, 3000);
            } else {
                self.setToastErrorMsg(result.message);
                //$A.get("e.force:closeQuickAction").fire();
            }
            component.find("SubmitButton").set("v.disabled", false);
        });
        $A.enqueueAction(action);
    },
    checkDateRangeOverlap: function(a_start, a_end, b_start, b_end) {
    	if(a_start <= b_start && b_start < a_end) return true;
    	if(a_start < b_end   && b_end <= a_end) return true;
    	if(b_start < a_start && a_end < b_end) return true;
    	return false;
	},
    multipleDateRangeOverlaps: function(dateRangeList, lineNumberList) {
    	var i, j;
    	if (dateRangeList.length % 2 !== 0)
        	return false;

    	for(i = 0; i < dateRangeList.length - 2; i += 2) {
        	for(j = i + 2; j < dateRangeList.length; j += 2) {
            	if(this.checkDateRangeOverlap(dateRangeList[i], dateRangeList[i+1],dateRangeList[j], dateRangeList[j+1])) 
                    return "Work Order Line Item Entries " + lineNumberList[i/2] + " and " + lineNumberList[j/2] + " are overlapping with each other. Please, correct startdate and enddate on work order line item to avoid overlapping.";
                    //return true;
        	}
    	}
        return null;
    	//return false;
	}
});