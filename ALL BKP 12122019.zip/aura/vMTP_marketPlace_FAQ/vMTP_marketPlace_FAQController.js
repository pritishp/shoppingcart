({
	doInit : function(component,event,helper){
     
    helper.getFAQ(component, event, helper);
  },
})