({
	getFAQ : function(component,event,helper) {
        var action = component.get("c.vMarketMenuPageController"); 
        // action.setParams({ terms : 'agree'
        //                  });
        action.setCallback(this, function(a) {    
            
            var result = a.getReturnValue();  
            var state = action.getState();         
            console.log('getFAQ before if=='+result); 
           if(state=="SUCCESS"){             
                //component.set("v.pageContent",result);
                //console.log('agreeTerms=='+result);        
               var html = result;
               var div = document.createElement("div");
               div.innerHTML = html;
               var text =  div.innerText ;  
               var doc = new DOMParser().parseFromString(result, 'text/html');
               component.set("v.pageContent",result);
            }
            else{
                                                  
            }                 
        });
        $A.enqueueAction(action);
    },
})