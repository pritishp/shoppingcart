({
	doInit : function(component, event, helper) {
		helper.getCartItems(component, event, helper);
	}
})