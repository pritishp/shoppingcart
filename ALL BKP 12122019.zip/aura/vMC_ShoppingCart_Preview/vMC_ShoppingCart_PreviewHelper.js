({
	    getCartItems : function(component, event, helper) {
        component.set("v.processing", true);
        var action = component.get("c.getCartItemLineList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                var appTotalPrice=0; var brachyTotalPrice=0;
                var appTotalQty=0; var brachyTotalQty=0;
                
                if(resp && resp.length) {
                    var appList =[];
                    var prodList =[];
                    for(var i=0 ; i < resp.length; i++) {
                        if(resp[i].vMTPApp) {
                            appList.push({
                                resp: resp[i],
                                 subsPrice :resp[i].appSubPrice,
                                appSubTerm :resp[i].appSubTerm
                            });
                           appTotalPrice = appTotalPrice + resp[i].vMTPApp.Price__c + resp[i].appSubPrice;
                            appTotalQty = appTotalQty + resp[i].quantity;
                            if(resp[i].vMTPApp.subscription__c)
                            {
                                console.log('Subscription Item');
                                component.set("v.isSubscription", true);                                
                            }
                        }
                        if(resp[i].itemline) {
                                prodList.push({
                                    resp: resp[i],
                                    total : resp[i].prodDiscount * resp[i].quantity,
                                });
                                brachyTotalPrice = brachyTotalPrice + (resp[i].prodDiscount * resp[i].quantity);
                            
                            brachyTotalQty = brachyTotalQty + resp[i].quantity;
                        }
                        
                    }
                    component.set("v.appTotalPrice",  appTotalPrice);
                    component.set("v.brachyTotalPrice",   brachyTotalPrice);
                    component.set("v.appTotalQty",  appTotalQty);
                    component.set("v.brachyTotalQty",   brachyTotalQty);            
                    
                }
                //component.set("v.brachyTax", 0);
                console.log('prodList--'+prodList);
                console.log('appWrapper--'+appList);
                component.set("v.appWrapper", appList);
                component.set("v.prodWrapper", prodList);
                /*
                if(component.get("v.selectedPaymentType")=='PO' && component.get("v.appTotalQty")!=0 && component.get("v.brachyTotalQty")==0) {
                    helper.navigateToLandingPage (component, event, helper);
                }else {
                    var inventoryEvent = $A.get("e.c:vMC_CheckInventory");
                    inventoryEvent.fire();
                }
                */
            }
            //this.setPaymentOptions(component);
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
})