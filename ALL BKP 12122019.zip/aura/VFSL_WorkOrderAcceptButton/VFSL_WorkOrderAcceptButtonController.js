({
	doInit : function(component, event, helper) {
        //Get Work Order defaults
        var WorkOrderInfo = component.get("c.getWorkOrderAccept");

        WorkOrderInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response){
            component.set("v.WorkOrder",response.getReturnValue());   
        });
        
        $A.enqueueAction(WorkOrderInfo);
        
	}, 
    
    YesClick : function(component, event, helper) {
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var saveWO = component.get("c.saveAcceptWO");
        saveWO.setParams({
            "WorkOrder": component.get("v.WorkOrder"),
        });
        
        saveWO.setCallback(this, function(response){
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {
                /*var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
				dismissActionPanel.fire(); 
        
                var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
            		"slideDevName": "detail"
        		});
        		backtoRecord.fire();*/
                
                component.find("overlayLib").notifyClose();
        		var refreshPage = $A.get("e.force:refreshView");
        		refreshPage.fire();
            }else if(state === "ERROR"){
                var errorMsg = response.getError()[0].message;
                console.log('error message: '+errorMsg);
                $A.util.addClass(
      			component.find('spinner'), 
      			"slds-hide"
				);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "message":errorMsg,
                    //"message":  "There was problem reassigning Work Order.  Please log a ticket",
                    "type": "ERROR"
                });
                toastEvent.fire();
            }
        })
        
        $A.enqueueAction(saveWO);
        }, 
    
    /*NoClick : function(component, event, helper) {
		var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
		dismissActionPanel.fire(); 
        
        var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
            		"slideDevName": "detail"
        		});
        backtoRecord.fire();
	}*/
    
    NoClick : function(component, event, helper) {
        component.find("overlayLib").notifyClose();
	}
})