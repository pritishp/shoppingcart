({
	doInit : function(component, event, helper) {
        //Get Work Order defaults
        var woId = component.get("v.recordId");
     //  alert('==woId=='+woId);
     console.log('woId:'+woId);
        var WorkOrderInfo = component.get("c.getWOWrapper");

        WorkOrderInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response){
            var woCheck = response.getReturnValue();
            console.log(woCheck);
            if(woCheck) {
                component.set("v.workOrder", woCheck.wo); 
                component.set("v.case", woCheck.woCase);
                component.set("v.workOrderDetails", woCheck);
                //console.log('woCheck: '+ JSON.stringify(woCheck));
                
                if((woCheck.wo.Status == 'Submitted' || woCheck.wo.Status == 'Error') && (woCheck.wo.Interface_Status__c == 'Processed' || (woCheck.wo.Interface_Status__c == 'Do Not Process' && 
                                                                                                                                            woCheck.wo.SAP_Status__c == 'Not Applicable')))
                    component.set("v.Qualify",false);
                
                if(woCheck.wo.Status == 'Reviewed' && (woCheck.wo.SAP_Status__c == 'Success' || woCheck.wo.SAP_Status__c == 'Not Applicable')) {
                    component.set("v.Billing",true);
                    console.log('BILLING');
                }  
            }
        });
        
        $A.enqueueAction(WorkOrderInfo);
        
        helper.getData(component);    
    
        component.set('v.mycolumn', [
            
            {label: 'Title', fieldName: 'attachmentURL', type: 'url', typeAttributes: {label: { fieldName: 'Title' }, target: '_blank'}},
            {label: 'Created By', fieldName: 'CreatedByid'},
            {label: 'Last Modified Date', fieldName: 'LastModifiedDate'}  
        ]);
         helper.getData1(component);        
    },
            
    // Collapsible Section Starts
    toggleSection : function(component, event, helper) {
        var sectionAuraId = event.target.getAttribute("data-auraId");
        var sectionDiv = component.find(sectionAuraId).getElement();
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    },
    
     Simulate1 : function(component, event, helper) {
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var save = component.get("c.saveSimulateWO");    
         save.setParams({
            "WorkOrder": component.get("v.workOrder")
        });
        
        save.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS"){
                var c = response.getReturnValue();
                component.set("v.workOrder", c);
                                alert("Record is saved Sucessfully");
                               $A.get('e.force:refreshView').fire();

            }else if  (state === "ERROR"){
               var errors = response.getError();
               alert(errors[0].message);

            }
        })  ;       $A.enqueueAction(save);
                  
        }, 
    
    reassign : function(component, event, helper) {
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var save = component.get("c.saveReassignWO");
     
         save.setParams({
            "WorkOrder": component.get("v.workOrder")
        });
        
        save.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS"){
                var c = response.getReturnValue();
            component.set("v.workOrder", c);
              alert("Record is saved Sucessfully");
                               $A.get('e.force:refreshView').fire();

            }
            else if  (state === "ERROR"){
               alert("failed");

            }
        })  ;       $A.enqueueAction(save);

        }, 
    
    ToReview1 : function(component, event, helper) {
        var SAPStatus = component.get("v.workOrder.SAP_Status__c");
        if(SAPStatus != 'Success' && SAPStatus != 'Not Applicable'){
            alert("Work Order cannot be marked Reviewed as Simulation failed.  Please correct and resimulate");
            return;
        }
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var save = component.get("c.saveReviewWO");
        save.setParams({
            "WorkOrder": component.get("v.recordId")
        });
        
        save.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS")  {
                var c = response.getReturnValue();
                component.set("v.workOrder", c);
                alert("Record is saved Sucessfully");
                                         $A.get('e.force:refreshView').fire();

            }else if  (state === "ERROR"){
               var errors = response.getError();
               alert(errors[0].message);

            }
        })  ;       $A.enqueueAction(save);
                      
        }, 
   
    savecoantact : function(component, event, helper) {
          $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        
        console.log(JSON.stringify(component.get("v.workOrder")));
        //var updatedRecords = JSON.stringify(component.find( "acctTable" ).get( "v.draftValues" ));
        //var woliRecords = JSON.stringify(component.get("v.mydata"));
        //console.log('woliRecords: ' + woliRecords);
        
        var action = component.get("c.saveRecord");
        action.setParams({"WorkOrder": component.get("v.workOrder"),
                          "woliJSONRecord": JSON.stringify(component.get("v.mydata"))});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state == "SUCCESS"){
                //var c = response.getReturnValue();
                //component.set("v.workOrder", c);
                alert("Record is saved Sucessfully");
              	/*helper.getData(component); 
              	setTimeout(function() {
                	helper.afterWOLIUpdate(component, event, helper);
                }, 500);*/
              
            } else {
            var errors = response.getError();
            alert(errors[0].message);
            }
        });
        $A.enqueueAction(action);

} ,

 onSave : function( component, event, helper ) {   
          
        var updatedRecords = JSON.stringify(component.find( "acctTable" ).get( "v.draftValues" )); 
              console.log('updatedRecords: ' + updatedRecords);
        var action = component.get("c.updateWOLI");  
        action.setParams({woliJSONRecord : updatedRecords});  
        action.setCallback( this, function( response ) {  
              
            var state = response.getState(); 
              console.log('state: ' + state);
            if ( state === "SUCCESS" ) {  
                alert("Work Order Line Item updated successfully");
              	helper.getData(component); 
              	setTimeout(function() {
                	helper.afterWOLIUpdate(component, event, helper);
                }, 500);
              
            } else { 
                var errors = response.getError();
                alert(errors[0].message);   
            } 
              
        });  
        $A.enqueueAction( action );    
          
    },
      
  Billing : function(component, event, helper) {
             var recordId = component.get("v.recordId");
          var url = '/apex/vfsl_billingvfpage?id=' + recordId;   
  var urlEvent = $A.get("e.force:navigateToURL"); 
    urlEvent.setParams({ 
        "url": url
       
    });
    urlEvent.fire();
},
    
isRefreshed: function(component, event, helper) {
                 var recordId = component.get("v.recordId");
        location.href= '/apex/vfsl_billingvfpage?id=' + recordId;
    },
 isnavigated: function(component, event, helper) {
        location.reload();
    },
              
    oncancel: function(component, event, helper) {
        console.log('cancelling');
        helper.getData(component);  
    },
    
    onSSOChange: function(component, event, helper) {  
        var sso = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        
        console.log('sso: ' + sso);
        console.log('woliid: ' + woliid);
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].SAP_Service = sso;
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        console.log(JSON.stringify(updatedLineItems));
        component.set("v.mydata",updatedLineItems); 
    },
        
    onDescriptionChange: function(component, event, helper) {  
        var description = event.getSource().get('v.value');
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.mydata");
        
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].Description = description;
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        component.set("v.mydata",updatedLineItems); 
    },
    
    closeModal: function(component, event, helper) {  
        component.set("v.woApproved",false); 
    },
    
    viewWoli: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.Id,'_blank');
    },
    
    viewLocation: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.LocationId,'_blank');
    },
    
    viewCase: function(component, event, helper) {
        var caseRecord = component.get("v.case");
        window.open('/' + caseRecord.Id,'_blank');
    },
    
    viewWoAsset: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.Top_Level_Asset__c,'_blank');
    },
    
    viewWoliDetail: function(component, event, helper) {
        var objId = event.currentTarget.id;
        window.open('/' + objId,'_blank');
    },
    
    viewWoliStb: function(component, event, helper) {
        var objId = event.currentTarget.id;
        window.open('/' + objId,'_blank');
    },
    
    viewWoSR: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.Service_Resource__c,'_blank');
    }, 
 
    viewWoDM: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.District_Manager__c,'_blank');
    }
})