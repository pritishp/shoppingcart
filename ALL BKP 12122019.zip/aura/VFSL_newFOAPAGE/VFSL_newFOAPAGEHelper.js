({
    getData : function(component) {
        var action = component.get('c.getWOLI');
         action.setParams({
            "woid": component.get("v.recordId")
        });
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();	
            if (state === "SUCCESS") {
                //console.log(JSON.stringify(response.getReturnValue()));
                component.set('v.mydata', response.getReturnValue());
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);  
            }
        }));
        $A.enqueueAction(action);
    },
    
   getData1 : function(component) {
        var action = component.get('c.getRecordAttachment');
         action.setParams({
            "entityId": component.get("v.recordId")
       });
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('docu: ' + JSON.stringify(response.getReturnValue()));
                component.set('v.mydatas', response.getReturnValue());
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);  
            }
        }));
        $A.enqueueAction(action);
    }, 
    
    afterWOLIUpdate: function(component, event, helper) { 
        component.find("acctTable").set("v.draftValues", null);      
    }
    
    
})