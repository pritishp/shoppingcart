({
	doInit : function(component, event, helper) {
       helper.doInitHelper(component,event);
	},
    saveCaseLine : function(component, event, helper) {
    	helper.doSaveCaseLineData(component,event);
    }
})