({
    doInitHelper : function(component, event) {
        //define action to get data from salesforce server
        component.set('v.error',null);
        var action = component.get('c.intialize');
        action.setParams({"recordId":component.get("v.recordId")});
        //Handle callback action once respose is ready
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var obj = response.getReturnValue();
                console.log('===data==='+JSON.stringify(obj, null, 2));
                component.set('v.classObj',obj);
                component.set('v.editMode',true);
            } else if (response.getState() == "ERROR") {
                $A.log("callback error", response.getError());
                console.log('===callback error==='+JSON.stringify(response.getError()));
            }
        });
        //invoke init action
        $A.enqueueAction(action);
    },
    
    doSaveCaseLineData : function(component, event) {
        
        var inObj = component.get('v.classObj');
        if(inObj.newcaseline.ERP_NWA__c != null){
            inObj.newcaseline.ERP_NWA__c = inObj.newcaseline.ERP_NWA__c.toString();
        }
        
        if(inObj.newcaseline.Case_Line_Owner__c != null){
            inObj.newcaseline.Case_Line_Owner__c = inObj.newcaseline.Case_Line_Owner__c.toString();
        }
        
        //Required Field Validation
        var validCaseLine = component.find('caseLineForm').reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        //check if installation and ERP NWA is blank
        if(inObj.newcaseline.Billing_Type__c.includes('Installation') && inObj.newcaseline.ERP_NWA__c == null){ 
            component.set('v.error','For billing type I – Installation, a Network Activity must be entered.');
            validCaseLine = false;
        }
        
        if(inObj.newcaseline.Billing_Review_Requested__c && inObj.newcaseline.Billing_Review_Reason__c == null){ 
            component.set('v.error','Reason for Billing Review is required.');
            validCaseLine = false;
        }
        
        if(inObj.newcaseline.Start_Date_Time__c < inObj.parentcase.Malfunction_Start__c){ 
            component.set('v.error','Start Date Time cannot be less than Malfunction Start Time.');
            validCaseLine = false;
        }
        
        // Field validation
        if(validCaseLine){
            var self = this;
            component.set('v.error','');
            $A.util.removeClass(component.find('mySpinner'),"slds-hide");
            event.getSource().set("v.disabled", true);
            var action = component.get('c.addCaseLine');
            if(inObj.hoursspent===undefined) inObj.hoursspent = "0";
            if(inObj.minutesspent===undefined) inObj.minutesspent = "0.00";
            console.log('Data-->'+JSON.stringify(inObj.newcaseline));
            action.setParams({"newcaseline":inObj.newcaseline,
                              "hoursspent":inObj.hoursspent,
                              "minutesspent":inObj.minutesspent});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    var obj = response.getReturnValue();
                    console.log('===data==='+JSON.stringify(obj, null, 2));
                    $A.util.addClass(component.find('mySpinner'),"slds-hide");
                    event.getSource().set("v.disabled", false);
                    self.resetForm(component);
                    $A.get('e.force:refreshView').fire();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: response.getReturnValue(),
                        duration:' 5000',
                        key: 'info_alt',
                        type: 'success',
                        mode: 'pester'
                    });
                    toastEvent.fire();
                } else if (response.getState() == "ERROR") {
                    var errors = response.getError();
                    if (!errors) {
                        errors = [{"message" : "Unknown Error Occured"}];
                    }
                    $A.util.addClass(component.find('mySpinner'),"slds-hide");
                    event.getSource().set("v.disabled", false);
                    component.set('v.error',errors[0].message);
                    console.log('error message'+JSON.stringify(errors));
                }
            });
            $A.enqueueAction(action);
        }
    },
    resetForm : function(component) {
		component.set('v.classObj.hoursspent', '0');
		component.set('v.classObj.minutesspent', '0.00');
    }
})