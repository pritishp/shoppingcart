({
	doInit : function(component, event, helper) {
        //Get Work Order defaults
        var WorkOrderInfo = component.get("c.getWorkOrderCancel");

        WorkOrderInfo.setParams({
            "WorkOrderId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response){
            var woCheck = response.getReturnValue();
            component.set("v.WorkOrder",response.getReturnValue());   
            if((woCheck.Status != 'New' && woCheck.Status != 'Assigned') 
               || woCheck.Remaining_Parts_Count__c >= 1 || woCheck.Line_Count__c >= 1 || woCheck.ECF_Form_Count__c >= 1 
               || (woCheck.Complaint__c == 'Yes' && (woCheck.Injured__c == 'TBD' || woCheck.ECF_Required__c == 'TBD' ||
                    woCheck.Process_Workflow__c == 'TBD' || woCheck.Process_Code__c == 'TBD'))){
            		component.set("v.Qualify",false);
        			}
        });
        
        $A.enqueueAction(WorkOrderInfo);
        
	}, 
    
    YesClick : function(component, event, helper) {
        //Catch lack of Cancellation Reason
        console.log('component: '+component.find("cancelReason").get("v.value"));
        if(component.find("cancelReason").get("v.value") == '' || component.find("cancelReason").get("v.value") == undefined){
            component.find('notifLib').showNotice({
		            "variant": "error",
		            "header": "Cancellation Reason is required."
           });
        }else{
        /*show spinner on button press*/
        $A.util.removeClass(
      		component.find('spinner'), 
      		"slds-hide"
		);
        var save = component.get("c.saveCancel");
        save.setParams({
            "WorkOrder": component.get("v.WorkOrder")
        });
        $A.enqueueAction(save);
        
        save.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                /*var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
				dismissActionPanel.fire(); 
                
                var backtoRecord = $A.get("e.force:navigateToSObject");
        		backtoRecord.setParams({
            		"recordId": component.get("v.recordId"),
            		"slideDevName": "detail"
        		});
        		backtoRecord.fire();*/
        
                component.find("overlayLib").notifyClose();
        		var refreshPage = $A.get("e.force:refreshView");
        		refreshPage.fire();
            }
            else if(state = "ERROR"){
                $A.util.addClass(
      			component.find('spinner'), 
      			"slds-hide"
				);
                var errorMsg = response.getError()[0];
                var displayMsg = '';
                if(errorMsg.message == 'WO Cancellation Failed.  Please open ticket'){
                    displayMsg = 'There was problem cancelling Work Order.  Please log a ticket'
                }else{
                    displayMsg = errorMsg.message;
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "message": displayMsg,
                    "type": "ERROR"
                });
                toastEvent.fire();                                          
            } //END- Added to dispaly Apex error Message
            else{
                $A.util.addClass(
      			component.find('spinner'), 
      			"slds-hide"
				);
                var errors = response.getError();
                /*if (errors) {
                if (errors[0] && errors[0].message) {
                    component.set(“v.message”,errors[0].message);
                 }	
                }
                else {
                component.set(“v.message”, ‘There was problem cancelling Work Order.  Please log a ticket’ );
                }*/
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "message":  "There was problem cancelling Work Order.  Please log a ticket",
                    "type": "ERROR"
                });
                toastEvent.fire();
            }
        })
        }
        }, 
    
    /*NoClick : function(component, event, helper) {
		var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
		dismissActionPanel.fire(); 
        var backtoRecord = $A.get("e.force:navigateToSObject");
        backtoRecord.setParams({
            "recordId": component.get("v.recordId"),
            "slideDevName": "detail"
        });
        backtoRecord.fire();
	}, */
    
    NoClick : function(component, event, helper) {
        component.find("overlayLib").notifyClose();
	}
})