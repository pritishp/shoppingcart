({
	helperMethod : function() {
	},

    validateEmail : function(component, event) {
    	var emailInput = component.find("userNameId").get("v.value");
    	//alert('emailInput = ' + emailInput);
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        /*
        if(emailInput == null || !emailInput.match(regExpEmailformat) 
        	|| $A.util.isEmpty(emailInput) ){ */

        if(!emailInput.match(regExpEmailformat)){ 
            return false;
        }else{
            return true;
        }    
    }, 	
})