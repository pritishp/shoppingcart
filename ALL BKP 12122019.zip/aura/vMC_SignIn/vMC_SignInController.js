({
	doInit : function(component, event, helper) {
        var url = $A.get('$Resource.vmarket_SignIn_BackGround');
        component.set('v.backgroundImageURL', url);	
        component.set("v.divHeight", 490);	
	},

    clearErrorMsg : function(component, event, helper) {
        $("#loginAlert").addClass("hide");
        $('.Rectangle-10').css('height','490px');
        $("#errorLoginMessage").text("").fadeOut();
        $("span[id*='mesgErrorGridID']").fadeOut();               
    },	

    handleLogin : function(component, event, helper) {

		component.set("v.errorFound", false);
		component.set("v.errorMessage", '');
		component.set("v.divHeight", 490);

    	var username = component.find("userNameId").get("v.value");
    	var pwd = component.find("passwordId").get("v.value");

    	if($A.util.isEmpty(username) && $A.util.isEmpty(pwd)) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Username and Password is required.");
    		component.set("v.divHeight", 500);
    		return;
    	}

    	if($A.util.isEmpty(username)) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Username is required.");
    		component.set("v.divHeight", 500);
    		return;
    	}

    	var validEmailRtrn = helper.validateEmail(component, event, username);
    	//alert('validEmailRtrn = ' + validEmailRtrn);

    	if(validEmailRtrn == false) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Email address is not valid");
    		component.set("v.divHeight", 500);
    		return;
    	}    	

    	if($A.util.isEmpty(pwd)) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Password is required.");
    		component.set("v.divHeight", 500);
    		return;
    	}

    	
    	//var b = component.get("c.validateform");
    	//$A.enqueueAction(b);
    	var username = component.find("userNameId").get("v.value");
    	var password = component.find("passwordId").get("v.value");

        var action = component.get("c.loginCommunity");
        // var startUrl = component.get("v.startUrl");        
        // startUrl = decodeURIComponent(startUrl);
        action.setParams({username:username, password:password});
        action.setCallback(this, function(a){
            var rtnValue = a.getReturnValue();
            //alert('rtnValue = ' + rtnValue);
            var urlEvent = $A.get("e.force:navigateToURL");
            window.open(a.getReturnValue(), '_self');
            if (rtnValue !== null) {
                component.set("v.errorMessage",rtnValue);
                component.set("v.showError",true);
            }
        });
        $A.enqueueAction(action);    	
    	
    },

    validateform : function(component, event, helper)
    {
		component.set("v.errorFound", false);
		component.set("v.errorMessage", '');
		component.set("v.divHeight", 490);

    	var username = component.find("userNameId").get("v.value");
    	var pwd = component.find("passwordId").get("v.value");

    	if($A.util.isEmpty(username) && $A.util.isEmpty(pwd)) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Username and Password is required.");
    		component.set("v.divHeight", 500);
    		return;
    	}

    	if($A.util.isEmpty(username)) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Username is required.");
    		component.set("v.divHeight", 500);
    		return;
    	}

    	if($A.util.isEmpty(pwd)) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Password is required.");
    		component.set("v.divHeight", 500);
    		return;
    	}

    	var validEmailRtrn = helper.validateEmail(component, event, username);
    	//alert('validEmailRtrn = ' + validEmailRtrn);

    	if(validEmailRtrn == false) {
    		component.set("v.errorFound", true);
    		component.set("v.errorMessage", "Email address is not valid");
    		component.set("v.divHeight", 500);
    		return;
    	}
    },

/*
    validateform : function(component, event, helper)
    {
	    //alert();
	    //$('#vMarketLoader').show();
	    var clrMsg = component.get('c.clearErrorMsg');
	    $A.enqueueAction(component.get(clrMsg));
	    //clearErrorMsg();

        var key = "vmappidlist";
         
        var usr = $('[id$=loginFormUsername]').val();//$(".form-username").val(); //document.getElementById('j_id0:j_id14:pageblock:j_id20:edit-name').value;
        //alert('here'+usr);
        usr = usr.trim();
        var psw = $('[id$=loginFormPassword]').val(); //document.getElementById('j_id0:j_id14:pageblock:j_id20:edit-pass').value;
        var cartIds = getCookie(key);

        if(! ValidateEmailAddress(usr))
            return false;
        
        if (usr === "" && psw==="") {
            $('.Rectangle-10').css('height','555px');
            $("#errorLoginMessage").text("Username and password are required.").fadeIn();
            $("#loginAlert").removeClass("hide");
            $("#errormsg").text("Username and password are required.").fadeIn();
        } else if (usr === "") {
            $('.Rectangle-10').css('height','555px');
            $("#errorLoginMessage").text("Username is required.").fadeIn();
            $("#loginAlert").removeClass("hide");
            $("#errormsg").text("Username is required.").fadeIn();
        } else if (psw === "") {
            $('.Rectangle-10').css('height','555px');
            $("#errorLoginMessage").text("Password is required.").fadeIn();
            $("#loginAlert").removeClass("hide");
            $("#errormsg").text("Password is required.").fadeIn();
        } else {
            $A.enqueueAction(component.get(clrMsg));                
            //// TODO chkLogin(usr, psw, cartIds);
        }
        
        return false;
     },
*/    
})