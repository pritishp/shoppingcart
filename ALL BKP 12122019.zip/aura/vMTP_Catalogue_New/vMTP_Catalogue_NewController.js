({
    doInit : function(component, event, helper) { 
        helper.loadInitData (component, event, helper);       
    },
    
    filterCategory: function (cmp, event, helper) {
        cmp.set("v.processing", true);
        var tab = event.getSource();
        var tabname = tab.get('v.id');        
        cmp.set('v.selectedAppCat', tabname);        
		cmp.set("v.index", 0);        
		cmp.set("v.startOffset", 1);        
        helper.getFilteredApps(cmp, event);        
    },
    filterApps: function (cmp, event, helper) {         
        helper.getFilteredApps(cmp, event);
    },
    appShortDescMouseOver: function(component, event, helper) {        
        var items = component.find("appShortDescPopover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },    
    appShortDescMouseOut: function(component, event, helper) {        
        var items = component.find("appShortDescPopover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    nextPage:function(component, event, helper) {     
        var totalRecs = parseInt(component.get('v.totalRecs'))
        var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));
        var nextIndex = index + blockSize;        
        
        if((index + blockSize) >= totalRecs){
            return false;
        }
        
        component.set("v.index", nextIndex); 
        var list = document.getElementsByClassName('paginationPageInput');
        for (var n = 0; n < list.length; ++n) {
            list[n].value='';
        }
        helper.getFilteredApps(component, event);
        
    },
    prevPage:function(component, event, helper) {        
		var blockSize = parseInt(component.get('v.blockSize'));
        var index = parseInt(component.get('v.index'));    
        var prevIndex = index - blockSize;
        if (prevIndex < 0){
            prevIndex = 0;
            return false;
    	}
        
    	component.set("v.index", prevIndex);  
        var list = document.getElementsByClassName('paginationPageInput');
        for (var n = 0; n < list.length; ++n) {
            list[n].value='';
        }        
        helper.getFilteredApps(component, event);       
	},
    keyPressPaginationInput: function(component, event, helper){
       // console.log(event.target.value);        
        var inputVal = parseInt(event.target.value);
        var totalPageCount = parseInt(component.get('v.paginationTotalPageCount'));
        var blockSize = parseInt(component.get('v.blockSize'));
        if( inputVal > 0 && inputVal <= totalPageCount){
            var index = (inputVal - 1 ) * blockSize;
            component.set('v.index', index);
            var list = document.getElementsByClassName('paginationPageInput');
            for (var n = 0; n < list.length; ++n) {
                list[n].value=inputVal;
            } 
            helper.getFilteredApps(component, event); 
        }        
    },
	handleApplicationEvent : function(component, event, helper) {
        var message = event.getParam("searchedName");
        //var category = event.getParam("recordCategory");
        component.set("v.appNameFromEvent", message);
        //component.find('categoryTab').set("v.selectedTabId", category);
		helper.getFilteredApps(component, event);
    },
	AddToCart : function (component, event, helper) {    		        
        helper.addToCart(component, event, helper);
    }    
})