({
	doInit : function(component, event, helper) {
		component.set('v.l_productpcsn',true);		
		component.set('v.l_reason',true);
		component.set('v.l_priority',true);
		component.set('v.l_assigntouser',true);
		component.set('v.l_assigntogroup',true);
		component.set('v.l_specialcareinstruction',true);
        
        helper.initHelper(component, event);
        helper.setIPdata(component, event);
        helper.getCaseRecordType(component, event);
        var value = helper.getParameterByName(component , event, 'inContextOfRef');
        if(value != undefined){
            var context = JSON.parse(window.atob(value));
            if(context.attributes.recordId!= undefined && context.attributes.recordId.startsWith("003")){
                helper.getContactHelper(component, event,context.attributes.recordId);
            }
            if(context.attributes.recordId!= undefined && context.attributes.recordId.startsWith("001")){
                helper.getAccountHelper(component, event,context.attributes.recordId); 
            }
        }

        var relatedToId = component.get('v.relatedToId');
        
        if(relatedToId != undefined && relatedToId.startsWith("003")){
            helper.getContactHelper(component, event,relatedToId);
        }
        if(relatedToId != undefined && relatedToId.startsWith("001")){
            helper.getAccountHelper(component, event,relatedToId); 
        }
        
        var workspaceAPI = component.find("workspace");
        workspaceAPI.isConsoleNavigation().then(function(response)
        {
            if(response){
           			workspaceAPI.getFocusedTabInfo().then(function(response) {
                    console.log('focused tab info: '+JSON.stringify(response));
                    var focusedTabId = response.tabId;
                    component.set('v.workspaceTabId', focusedTabId);
                    workspaceAPI.setTabLabel({
                        tabId: focusedTabId,
                        label: "Create Case" //set label you want to set
                    });
                    workspaceAPI.setTabIcon({
                        tabId: focusedTabId,
                        icon: "utility:record_create", //set icon you want to set
                        iconAlt: "Create Case" //set label tooltip you want to set
                    });
                      /*  workspaceAPI.focusTab({
                            tabId: focusedTabId
                        });*/
                 })
            }
        });   
	},
    /*navigateToCaseListView: function(component, event, helper) {
        window.location.href = '/500';
    },*/
    
     onRecordTypeChange : function(component, event, helper) {	
		
		component.set('v.l_productpcsn',false);
		component.set('v.l_reason',false);
		component.set('v.l_priority',false);
		component.set('v.l_assigntouser',false);
		component.set('v.l_assigntogroup',false);
		component.set('v.l_specialcareinstruction',false);
		
		var CRT = component.find('CaseRecordType').get('v.value');
        var selectedLabel;
        for(var i in event.getSource().get('v.options')) {
			var obj = event.getSource().get('v.options')[i];
            if(CRT === obj.value) {
                selectedLabel = obj.label;
                break;
            }
        }
		component.set("v.SelectedRecordType", selectedLabel);
		console.log('==CRT=='+CRT);
		if(selectedLabel === 'HD/DISP'){
			component.set('v.l_productpcsn',true);			
			component.set('v.l_reason',true);
			component.set('v.l_priority',true);
			component.set('v.l_assigntouser',true);
			component.set('v.l_assigntogroup',true);
			component.set('v.l_specialcareinstruction',true);
		}
		
	},
    resetAll : function(component, event, helper) {
        $A.get("e.force:refreshView").fire();
    },
    setSpecialInstruction: function(component, event, helper) {
        if(component.get('v.accountObj') !== null && component.get('v.accountObj') !== undefined) {
        	var accountId = component.get('v.accountObj').Id;
        	helper.getCasedataQuery(component, accountId);
        }
    },
    handleLookupChooseEventQuickCase : function(component, event, helper) {
        helper.handleLookupChooseEventQuickCaseHelper(component,event);
    },
    handleQuickCaseCreateContactEvent : function(component, event, helper) {
        helper.handleQuickCaseCreateContactEventHelper(component,event);
    },
    saveCaseRecord : function(component, event, helper) {
        var contactCheck = null;
        var ipCheck = null;
        if(component.find('contactObjId') !== undefined) {
			contactCheck = component.find('contactObjId').get('v.value');
        }
    	
        if(component.find('installedProduct') !== undefined) {
			ipCheck = component.find('installedProduct').get('v.value');
        }

        var selectedRecordType = component.get("v.SelectedRecordType");
        console.log('contactCheck: '+contactCheck+', ipCheck: '+ipCheck);
        //Check fields to make sure user hasn't cleared object values.
        if(contactCheck && (ipCheck || selectedRecordType !== 'HD/DISP')) {
            helper.caseCreateHelper(component, event, selectedRecordType);
        }else if(selectedRecordType === 'HD/DISP') {
            component.set('v.isError',true);
            component.set('v.errorMsg','Please select Contact and Product.');
        }else if(selectedRecordType !== 'HD/DISP') {
            component.set('v.isError',true);
            component.set('v.errorMsg','Please select Contact.');
        }
    },
    
    accountChanged : function(component, event, helper) {
        helper.getCasedata(component, event);
	},
    
    updateSelectedRows : function(component, event, helper) {
    	helper.updateSelectedRowsHelper(component, event);
    },
    
    updateContactSelectedRows : function(component, event, helper) {
    	helper.updateSelectedContactRowsHelper(component, event);
    },
    
    closeIPComp: function(component, event, helper) {
        var modal = component.find('iPComp');
        $A.util.addClass(modal,'slds-hide');
    },
    
    openIPComp: function(component, event, helper) {
        var modal = component.find('iPComp');
        $A.util.removeClass(modal,'slds-hide');
        helper.setIPdata(component,event);
    },
    
    searchIPComp: function(component, event, helper) {
        helper.setIPdata(component,event);
    },
    handleExpandClick: function(component, event, helper) {
    },
    handleCollapseClick: function(component, event, helper) {
    },
    
    closeContactComp: function(component, event, helper) {
        var modal = component.find('contactCmp');
        $A.util.addClass(modal,'slds-hide');
    },
    
    openContactComp: function(component, event, helper) {
        var modal = component.find('contactCmp');
        $A.util.removeClass(modal,'slds-hide');
        helper.setContactdata(component,event);
    },
    
    searchContactComp: function(component, event, helper) {
        helper.setContactdata(component,event);
    },
        
    closeCreateContact: function(component, event, helper) {
        var modal = component.find('createContact');
        $A.util.addClass(modal,'slds-hide');
    },   
    
    handleCreatedContactEvent: function(component, event, helper) {
        helper.handleCreatedContactEventHelper(component, event);
    },
    updateColumnSorting: function (cmp, event, helper) {
        var fieldName = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortData(cmp, fieldName, sortDirection);
    },
    updateContactColumnSorting: function (cmp, event, helper) {
        var fieldName = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        cmp.set("v.sortedBy", fieldName);
        cmp.set("v.sortedDirection", sortDirection);
        helper.sortContactData(cmp, fieldName, sortDirection);
    },
    createContact : function (component,event,helper) {
		var modal = component.find('contactCmp');
        $A.util.addClass(modal,'slds-hide');        
        var createContactEvent = component.getEvent("createContact");
        createContactEvent.setParams({
            "sObjectType" : "Contact",
            "actionType"  : "Create"
        });
        createContactEvent.fire();
        console.log('event fired');
    },
    
    editContact : function (component,event,helper) {
        var createContactEvent = component.getEvent("createContact");
        createContactEvent.setParams({
            "sObjectType" : "Contact",
            "actionType"  : "Edit"
        });
        createContactEvent.fire();
        console.log('event fired');
    }
})