({
    doInit : function(component, event, helper) {
        helper.getData(component, event, helper);
        helper.attachmentColumn(component);
        helper.serviceTerritoryColumn(component);
    },
    
    Back : function(component, event, helper) {
        window.location.href = '/'+component.get("v.recordId");
    },
    
    toggleSection : function(component, event, helper) {
        var sectionAuraId = event.target.getAttribute("data-auraId");
        var sectionDiv = component.find(sectionAuraId).getElement();
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    },
    
    SaveWO: function(component, event, helper) {
        var lineItems = component.get("v.woliList");
        
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].AssetId && lineItems[i].AssetId.length === 0)  
                lineItems[i].AssetId = null;
            if(lineItems[i].Service_Contract && lineItems[i].Service_Contract.length === 0)  
                lineItems[i].Service_Contract = null;
            if(lineItems[i].Sap_Nwa && lineItems[i].Sap_Nwa.length === 0)  
                lineItems[i].Sap_Nwa = null;
            if(lineItems[i].Part && lineItems[i].Part.length === 0) {
                lineItems[i].Part = null;
                lineItems[i].Part_Qty = null;
            }  
            if(!lineItems[i].Part && lineItems[i].Part_Qty)
                lineItems[i].Part_Qty = null;
        }
        console.log(JSON.stringify(lineItems));
        
        var action = component.get("c.updateWOLI");
        action.setParams({
            woliJSONRecord: JSON.stringify(lineItems)
        });
        component.find("saveButton").set("v.disabled", true);
        var self = this;
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            var state = response.getState();
            if (state !== 'ERROR') {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success',
                    type: 'success',
                    message: 'Line Item updated successfully'
                });
                toastEvent.fire();
                helper.getData(component, event, helper);
            } else {
                console.log("result.message: " + result);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error!',
                    type: 'error',
                    message: response.getError()[0].message
                });
                toastEvent.fire();
            }
            component.find("saveButton").set("v.disabled", false);
        });
        $A.enqueueAction(action);
    },
    
    viewWoli: function(component, event, helper) {
        var workOrder = component.get("v.workOrder");
        window.open('/' + workOrder.Id,'_blank');
    },
    
    viewWoliDetail: function(component, event, helper) {
        var objId = event.currentTarget.id;
        window.open('/' + objId,'_blank');
    },
    
    onSAPBillableChange: function(component, event, helper) {
        
        var isBillable = event.getSource().get('v.value');
        console.log(isBillable);
        var woliid = event.getSource().get('v.class');
        var lineItems = component.get("v.woliList");
        var updatedLineItems = [];
        for(var i = 0; i < lineItems.length; i++) {
            if(lineItems[i].Id === woliid) {
                lineItems[i].SAP_Billable = isBillable;
            }
            
            updatedLineItems.push(lineItems[i]);
        }
        
        component.set("v.woliList",updatedLineItems); 
    }
})