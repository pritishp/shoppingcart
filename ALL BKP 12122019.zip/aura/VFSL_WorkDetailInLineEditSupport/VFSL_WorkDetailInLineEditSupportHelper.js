({
    getData : function(component, event, helper) {
        var WorkOrderInfo = component.get("c.getWOrkOrderDetails");
        
        WorkOrderInfo.setParams({
            "woId": component.get("v.recordId")
        });
        
        WorkOrderInfo.setCallback(this, function(response) {
            var woDetails = response.getReturnValue();
            
            console.log('woDetails: ' + JSON.stringify(woDetails));
            component.set("v.workOrder", woDetails.wo);  
            component.set("v.woliList", woDetails.woli);
            component.set("v.attachmentList", woDetails.attachments);
            component.set("v.serviceTerritoryList", woDetails.serviceTerritory);
        });
        
        $A.enqueueAction(WorkOrderInfo);       
    },
  
    attachmentColumn : function(component) {
        component.set('v.attachmentColumn', [
            {label: 'Title', fieldName: 'AttachmentURL', type: 'url', typeAttributes: {label: { fieldName: 'Title' }, target: '_blank'}},
            {label: 'Created By', fieldName: 'CreatedByid'},  
            {label: 'Last Modified', fieldName: 'LastModifiedDate',type: 'date', typeAttributes:{month: "2-digit", day: "2-digit", year: "2-digit"}}
        ]);
    },
    
    serviceTerritoryColumn : function(component) {
        component.set('v.serviceTerritoryColumn', [
            {label: 'Paid Service Overhead JO#', fieldName: 'Paid_Service_JO'},
            {label: 'Helpdesk Overhead JO#', fieldName: 'HelpDesk_JO'},
            {label: 'Contract Overhead JO#', fieldName: 'Contract_JO'},   
        ]);
    }    
})