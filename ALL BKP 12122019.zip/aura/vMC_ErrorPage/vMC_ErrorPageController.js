({
	doInit : function(component, event, helper) {
        helper.getURLParameters(component);
	}
})