({
    getURLParameters : function (component) {
        console.log('Inside');
        // the function that reads the url parameters
        var getUrlParameter = function getUrlParameter(sParam) {
            var sPageURL = decodeURIComponent(window.location.search.substring(1)),
                sURLVariables = sPageURL.split('&'),
                sParameterName,
                i;
            
            for (i = 0; i < sURLVariables.length; i++) {
                sParameterName = sURLVariables[i].split('=');
                
                if (sParameterName[0] === sParam) {
                    return sParameterName[1] === undefined ? true : sParameterName[1];
                }
            }
        };
        
        component.set("v.logId", getUrlParameter('logId'));
        this.getOrders(component);
    },
    
    getOrders : function(component) {
        var action = component.get("c.getLogs"); 
        action.setParams ({
            logId:  component.get("v.logId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                component.set("v.errorMessage", result.Error_Message__c);
                this.setBreadCrumbs(component);
            }  
        });
        $A.enqueueAction(action);
    },
    
    setBreadCrumbs : function(component) {
        var breadcrumbCollection = [{label: 'Home', name: 'all products' }];
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },    
    
})