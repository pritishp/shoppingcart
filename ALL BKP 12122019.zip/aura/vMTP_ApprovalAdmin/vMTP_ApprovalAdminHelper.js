({
    setAdminFlag : function(component, event) {
        var action = component.get("c.getUserAdminInfo");
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.userAdminInfo", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);		
    },
    
    fetchCountriesList : function(component, event) {
        var action = component.get("c.getCountriesList");
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                var countryList = [];
                for(var key in response){
                    countryList.push({key:key,value:response[key]});
                }
                console.log('countryList' +countryList);
                //alert('entryList = ' + entryList);
                component.set("v.countriesList", countryList);   
                // if(component.get('v.selectedCountry') != undefined)
               	//	 this.fetchCountryAppsList(component, event);
            }
        });
        $A.enqueueAction(action);
    },
    sortBy: function(component, field) {
        console.log('Sorting');
        var sortAsc = component.get("v.sortAsc"),
            sortField = component.get("v.sortField"),
            records =  component.get("v.recordsToSort"),
            selectedTab =component.get("v.selTabId") ;
        console.log('Sorting elimentname ' +component.get("v.selTabId"));
     console.log('sortField ' +sortField);
        sortAsc = field == sortField? !sortAsc: true;
 		
         records.sort(this.sortByData(field, sortAsc));
        console.log('sortAsc ' +sortAsc);
       /* records.sort(function(a,b){
            var t1 = a[field] == b[field],
                t2 = a[field] > b[field];
            return t1? 0: (sortAsc?-1:1)*(t2?-1:1);
        });
        console.log('sortAsc ' +sortAsc +' ' +field);*/
        
        component.set("v.sortAsc", sortAsc);
        component.set("v.sortField", field);
       console.log('After Sorting' +JSON.stringify(records));
        switch (selectedTab) {
            case 'Published' :
                component.set("v.reviwedAppsList", records);
                break;
            case 'Under Review' :
                component.set("v.inProgressAppsList", records);
                break;
        }
    },
    
    sortByData: function (field, sortAsc, primer) {
        console.log('Data Sorting ');
        var key = primer ?
            function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        sortAsc = !sortAsc ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), sortAsc * ((a > b) - (b > a));
        }
    },
    
    fetchCountryAppsList : function(component, event) {
        console.log('In CountryApplist');
        var selectedCountry = component.get("v.selectedCountry");
        //var status = component.get("v.selTabId");
        console.log('selectedCountry ' +selectedCountry);
       // console.log('status ' +status);
       var action = component.get("c.vMTPCountryAppsList");
        action.setParams({
            status: 'Submitted',
            country : String(selectedCountry)
        });
        
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                console.log('result ->' +result);
                console.log('result length ->' +result.length);
              //  component.set("v.pendingAppsList", result.appCountryDetailList);
                if(result.length > 0){
                   var mapofAppList = JSON.parse(result[0]);
                    console.log(typeof JSON.parse(result[0]));
                    console.log('**mapofAppList** ' + result.length +'**' +Object.keys(mapofAppList));
                    
                    var mapofApps = new Map();
                    Object.keys(mapofAppList).forEach(key => {
                        console.log('key ' +key + ' *valur**' +JSON.stringify(mapofAppList[key]));
                        mapofApps.set(key, mapofAppList[key]);
                    });
                     console.log('mapofApps ->' + JSON.stringify(mapofApps.get('Submitted')));
                    component.set("v.appMapList",  mapofApps);   
                    //console.log('mapofAppList ->' + JSON.stringify(component.get("v.mapofAppList")));
                    
                    
                        if(typeof mapofApps.get('Submitted')!= "undefined" ){
                        	component.set("v.pendingAppsList", mapofApps.get('Submitted'));
                    	}else
                        	component.set("v.pendingAppsList",[]);
                        
                        if(typeof mapofApps.get('Under Review')!= "undefined" ){
                        	component.set("v.inProgressAppsList", mapofApps.get('Under Review'));
                    }else
                        	component.set("v.inProgressAppsList",[]);
                        
                        if(typeof mapofApps.get('Info Requested')!= "undefined" ){
                        	component.set("v.infoNeededAppsList", mapofApps.get('Info Requested'));                        
                    }else
                        	component.set("v.infoNeededAppsList",[]);
                        
                        if(typeof mapofApps.get('Published')!= "undefined" ){
                        	component.set("v.reviwedAppsList", mapofApps.get('Published'));
                    }else
                        	component.set("v.reviwedAppsList",[]);
                        
                        if(typeof mapofApps.get('Rejected')!= "undefined" ){
                        	component.set("v.rejectedAppsList", mapofApps.get('Rejected'));
                    }else
                        	component.set("v.rejectedAppsList",[]);
                        
                    }  

            }
        });
                        $A.enqueueAction(action);
        
       /* var actionPending = component.get("c.vMTPCountryAppsList");
        var actionInProgress = component.get("c.vMTPCountryAppsList");
        var actionInforNeeded = component.get("c.vMTPCountryAppsList");
        var actionReviewed = component.get("c.vMTPCountryAppsList");
        var actionRejected = component.get("c.vMTPCountryAppsList");
        actionPending.setParams({
            status: 'Submitted',
            country : String(selectedCountry)
        });
        
        actionInProgress.setParams({
            status: 'Under Review',
            country : String(selectedCountry)
        });
        actionInforNeeded.setParams({
            status: 'Info Requested',
            country : String(selectedCountry)
        });
        actionReviewed.setParams({
            status: 'Published',
            country : String(selectedCountry)
        });
        actionRejected.setParams({
            status: 'Rejected',
            country : String(selectedCountry)
        });
        
        actionPending.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();               
                component.set("v.pendingAppsList", result.appCountryDetailList);
            }
        });
        
        actionInProgress.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();               
                component.set("v.inProgressAppsList", result.appCountryDetailList);
            }
        });
        
        actionInforNeeded.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();               
                component.set("v.infoNeededAppsList", result.appCountryDetailList);
            }
        });
        actionReviewed.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();               
                component.set("v.reviwedAppsList", result.appCountryDetailList);
            }
        });
        actionRejected.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();               
                component.set("v.rejectedAppsList", result.appCountryDetailList);
            }
        });
        $A.enqueueAction(actionPending);
        $A.enqueueAction(actionInProgress);
        $A.enqueueAction(actionInforNeeded);
        $A.enqueueAction(actionReviewed);
        $A.enqueueAction(actionRejected);*/
    },
    
     initiateApprovalProcess: function (component, event, helper) {
         console.log('initiateApprovalProcess ' + component.get('v.selectedAppId'));
     //  var JSON.stringify(component.get("v.selectedReviewCountriesList"));
      //   JSON.stringify(component.get("v.selectedDepartmentCheckboxVal"));
        
         var action = component.get("c.startApproval");
          action.setParams({
            vMTPAppId : component.get('v.selectedAppId'),
            reviewType: JSON.stringify(component.get("v.selectedDepartmentCheckboxVal")),
            reviewCountries : JSON.stringify(component.get("v.selectedReviewCountriesList"))
        });
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            console.log('state ' +state);
            if (state === "SUCCESS") {
                this.fetchCountryAppsList(component, event);
                component.set("v.isModalOpen", false);
                 console.log('initiateApprovalProcess2 ');
            }
        });
        $A.enqueueAction(action);		
    },
})