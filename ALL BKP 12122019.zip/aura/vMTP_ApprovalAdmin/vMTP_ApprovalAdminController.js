({
	doInit : function(component, event, helper) {
       // helper.setBreadCrumbs (component, event, helper);		
        helper.setAdminFlag(component, event);
        component.set('v.selectedAppId', component.get("v.pageReference").state.c__appId);
         component.set('v.selectedCountry', component.get("v.pageReference").state.c__con);
             console.log('v.selectedCountry' +component.get('v.selectedCountry'));
        	 console.log('v.selectedAppId' +component.get('v.selectedAppId'));
        if( component.get('v.selectedAppId') != undefined){
            component.set("v.isAdminApproval", true);
        	component.set("v.isAdminLanding", false);
        	component.set("v.isReviewHistory", false);
        }        
        helper.fetchCountriesList(component, event);
	},
    openAppDetails: function(component, event, helper) {
    	var appId = event.currentTarget.getAttribute("data-appId");
		var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                      "recordId": appId,
                "slideDevName" :"detail"
                    }); 
            navEvt.fire();
    },
 
    openInitiateAction: function(component, event, helper) {
       // alert('Fired');
    	var appId = event.currentTarget.getAttribute("data-appId");
        var appCountryList = event.currentTarget.getAttribute("data-appCountries").split(';');
		console.log('Initiate Action -> '+appCountryList);
        var countryList = [];
                for(var key in appCountryList){
                    console.log('Key ' +appCountryList[key]);
                    countryList.push({key:key,value:appCountryList[key]});
                }
        component.set("v.reviewCountriesList", countryList);
        component.set("v.selectedAppId", appId);
        component.set("v.isModalOpen", true);
        console.log('reviewCountriesList ' + component.get('v.reviewCountriesList') + 'appId ->' +component.get('v.selectedAppId'));
    },
    closeModal: function(component, event, helper) { 
        component.set("v.isModalOpen", false);
    },
    	// this function will be invoked changing Country selection for App Reviewer Submission, it can be multiple as well
	onReviewCountryListChange : function(component, event, helper) 
	{
       var selectedValList = component.find("reviewCountryList").get('v.value');
        console.log('selectedValList -> '+selectedValList);
		var selectedVal = new Array();
		selectedVal.push(component.find("reviewCountryList").get('v.value'));
		var reviewCountryList = selectedVal[0].split(";");
		component.set('v.selectedReviewCountriesList', reviewCountryList);
        console.log('reviewCountryList ->' +reviewCountryList);
    },	
    handleDepartmentSelection :  function(component, event, helper) {
    	
          alert(component.get("v.selectedDepartmentCheckboxVal"));
        
    },
    handleReviewSubmission :  function(component, event, helper) {
        
        if(Object.keys(component.get("v.selectedReviewCountriesList")).length == 0){
              $A.util.removeClass(component.find('appReviewCountries'), "slds-hide");
             console.log("Empty Country List");
             if(Object.keys(component.get("v.selectedDepartmentCheckboxVal")).length == 0){
             	console.log("Empty Check box");            
            	$A.util.removeClass(component.find('reviewDepartmentError'), "slds-hide");
             }
        }else if(Object.keys(component.get("v.selectedDepartmentCheckboxVal")).length == 0){
             	console.log("Empty Check box");            
            $A.util.removeClass(component.find('reviewDepartmentError'), "slds-hide");
        }else{
            $A.util.addClass(component.find('appReviewCountries'), "slds-hide");
            $A.util.addClass(component.find('reviewDepartmentError'), "slds-hide");
          // alert('Start Approval Process');
            helper.initiateApprovalProcess(component, event, helper);
        }
        
    },
    setCountryValue : function(component, event, helper) {
         var selectedCountry;
        if(component.find("selectedCountryFilter") != undefined) {
            selectedCountry = component.find("selectedCountryFilter").get("v.value");
        }
        if(selectedCountry === undefined) {
            selectedCountry = '';
        }
        component.set("v.selectedCountry", selectedCountry);
        component.set("v.pendingAppsList",[]);
        component.set("v.inProgressAppsList",[]);
        component.set("v.infoNeededAppsList",[]);
        component.set("v.reviwedAppsList",[]);
        component.set("v.rejectedAppsList",[]);
        helper.fetchCountryAppsList(component, event);
        
    },
    
    handleAdminReview : function(component, event, helper) {
        var appId = event.currentTarget.getAttribute("data-appId");
        var selectedCountry  = event.currentTarget.getAttribute("data-appCountry");
        component.set("v.selectedAppId", appId);
        
        component.set("v.isAdminApproval", true);
        component.set("v.isAdminLanding", false);
        component.set("v.isReviewHistory", false);
    },
    
    handleReviewAppLogs : function(component, event, helper) {
        var appId = event.currentTarget.getAttribute("data-appId");
        component.set("v.selectedAppId", appId);
        
        component.set("v.isReviewHistory", true);
        component.set("v.isAdminLanding", false);
         component.set("v.isAdminApproval", false);
    },
    
    goBack :function(component, event, helper) {
        console.log('Go back');
        component.set("v.isAdminApproval", false);
         component.set("v.isAdminLanding", true);
         component.set("v.isReviewHistory", false);
        
         console.log('Go back 2');
         component.find("navigationService").navigate({
    		type: "standard__navItemPage",
            attributes: {
               "apiName": "vMTP_Admin" 
            }
		});
         console.log('Go back 3');
        var appId= component.get("v.pageReference").state.c__appId;
        console.log();
        if(appId){
            console.log('navigateToComponent');
         var evt = $A.get("e.force:navigateToComponent");
        console.log('evt'+evt);
        evt.setParams({
            componentDef: "c:vMTP_ApprovalAdmin"
            //componentAttributes :{ }
        });
        
            evt.fire();
        }
        
       // urlEvent.fire();
        
    },
    
    handleInfoClick :function(cmp, event, helper) {
     	var appId = event.getSource().get("v.name");      
       
        var divInfoTags = document.getElementsByTagName("div");
            for(var i = 0; i < divInfoTags.length; i++){
              if(divInfoTags[i].id === appId)
              	 divInfoTags[i].classList.toggle("slds-hide");
            }

       /*   var cmpTarget = cmp.find('feedbackInfoDiv');        
        for(var cmptar in cmpTarget) {
      	  $A.util.toggleClass(cmpTarget[cmptar], 'slds-hide');
    	}  */
     var iconName = event.getSource();
        console.log(iconName.get("v.iconName"));
        if(iconName.get("v.iconName").includes("add"))
       		iconName.set("v.iconName" ,"utility:dash");
        else{
            iconName.set("v.iconName" ,"utility:add");
        }	
   },
    
    handleInProcessClick : function (cmp,event) {
       
        var appId = event.getSource().get("v.name");      
       
        var divTags = document.getElementsByTagName("div");
            for(var i = 0; i < divTags.length; i++){
              if(divTags[i].id === appId)
              	 divTags[i].classList.toggle("slds-hide");
            }

       /*  var cmpTarget = cmp.find("feedbackDiv");        
       for(var cmptar in cmpTarget) {
             console.log("div1: ", cmpTarget[cmptar].getElement());
      	  $A.util.toggleClass(cmpTarget[cmptar], 'slds-hide');
    	}  */
     var iconName = event.getSource();
        console.log(iconName.get("v.iconName"));
        if(iconName.get("v.iconName").includes("add"))
       		iconName.set("v.iconName" ,"utility:dash");
        else{
            iconName.set("v.iconName" ,"utility:add");
        }
        // cmp.set('v.divInProcessClick', !cmp.get('v.divInProcessClick'));
    },
	sortByAppName: function(component, event, helper) {
          helper.sortBy(component, "App Name");
    },
	sortByDevName: function(component, event, helper) {
          helper.sortBy(component, "Developer Name");
    },
    sortByComment: function(component, event, helper) {
          helper.sortBy(component, "Comment");
    },
    sortByReviewer: function(component, event, helper) {
          helper.sortBy(component, "Review Initiated By");
    },
    sortByReviewDate: function(component, event, helper) {
          helper.sortBy(component, "Date of Review");
    },
     sortByNo: function(component, event, helper) {
          helper.sortBy(component, "No");
    },
    
    handleActive: function(component,event,helper) {
          var tab = event.getSource();
         console.log(tab.get('v.id'))      ;
        //debugger;
         /*switch (tab.get('v.id')) {
            case 'Published' :
               component.set("v.recordsToSort", component.get("v.reviwedAppsList"));
                component.set("v.selTabId", tab.get('v.id'));
                break;
            case 'Under Review' :
               component.set("v.recordsToSort", component.get("v.inProgressAppsList"));
				component.set("v.selTabId", tab.get('v.id'));               
                break;
        }*/
        
    }
})