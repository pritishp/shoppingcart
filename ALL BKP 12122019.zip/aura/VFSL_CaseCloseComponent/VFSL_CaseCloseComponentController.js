({
    doInit: function(component, event, helper) {
        helper.showSpinner(component, event, helper);
        //Get Work Order defaults
        
        var cmpTarget = component.find("headerNotify");
        $A.util.removeClass(cmpTarget, "slds-theme_success");
        $A.util.removeClass(cmpTarget, "slds-theme_error");
        $A.util.removeClass(cmpTarget, "slds-theme_warning");
        console.log("case Object:" + JSON.stringify(component.get("v.caseRecord")));
        
        var caseObject = component.get("v.caseRecord");
        var cstype = "";
        if (caseObject.Case_Group_Assignment__c != null) {
            if (caseObject.Case_Group_Assignment__c.startsWith("CHD")) {
                cstype = "Clinical";
            }
            if (caseObject.Case_Group_Assignment__c.startsWith("THD OIS")) {
                cstype = "Software";
            }
            if (caseObject.Case_Group_Assignment__c.startsWith("THD DEL")) {
                cstype = "Hardware";
            }
        }
        
        if(caseObject.Closed_Case_Reason__c == "Created in Error" || caseObject.Closed_Case_Reason__c == "Customer Cancelled" || caseObject.Closed_Case_Reason__c == "Closed by Work Order") {
            var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef: "c:VFSL_CaseClosePageComponent",
                componentAttributes: {
                    recordId: caseObject.Id,
                    caseType: cstype
                }
            });
            evt.fire();
            component.set("v.showPopup", false);
            helper.hideSpinner(component, event, helper);
        } else {
            var message = "testing";
            var theme = "Failure";
            if (caseObject.IsClosed == 1) {
                message = "Case is already Closed";
                $A.util.addClass(cmpTarget, "slds-theme_error");
                component.set("v.message", message);
                $A.util.removeClass(component.find("modaBox"), "slds-hide");
            } else {
                var caseInfo = component.get("c.checkECFCount");
                caseInfo.setParams({
                    caseObject: caseObject
                });
                
                caseInfo.setCallback(this, function(response) {
                    var ecfCount = response.getReturnValue();
                    var missingField = "";
                    
                    if (ecfCount == true) {
                        message =
                            "This case cannot be closed until the ECF is submitted  and ECF status has been updated to either Rejected by Regulatory or Accepted and Closed by Regulatory";
                        theme = "Failure";
                    } else if (
                        caseObject.Status != "Closed" &&
                        caseObject.Status != "Closed by Work Order" &&
                        (caseObject.Is_escalation_to_the_CLT_required__c == "Yes" ||
                         caseObject.Is_escalation_to_the_CLT_required__c ==
                         "Yes from Work Order") && caseObject.Case_ECF_Count__c == 0 
                    ) {
                        message =
                            "You cannot close this case because you have said there is an Escalated Complaint Required yet no ECF has been created. Please either change your escalation question to no or create the form";
                        theme = "Failure";
                        
                    }else if(caseObject.Is_This_a_Complaint__c == 'Yes' && caseObject.RecordType.DeveloperName == 'Helpdesk' && 
                                    (caseObject.Incident_Workflow_Location__c =='TBD' || caseObject.Incident_Workflow_Location__c == null 
                                           || caseObject.Error_Code__c =='TBD' || caseObject.Error_Code__c == null)){ 
                                message = 'Case cannot be closed if Process Workflow or Process Code is blank or TBD.  Please correct prior to closure'; 
                                theme == 'Failure';    
                        
                    } else if (
                        caseObject.Is_escalation_to_the_CLT_required__c == "Yes" &&
                        caseObject.EtQ_Complaint__c == null
                    ) {
                        message = "Please enter ETQ Complaint No.";
                        theme == "Warning";
                    } else if (
                        caseObject.Was_anyone_injured__c == "TBD" ||
                        caseObject.Is_escalation_to_the_CLT_required__c == "TBD"
                    ) {
                        message =
                            "Case cannot be closed if Injury or Escalated Complaint Required is equal to TBD. Please go back to the case and make the proper determination before closing your case.";
                        theme == "Warning";
                    } else if (
                        caseObject.Was_anyone_injured__c == null ||
                        caseObject.Is_escalation_to_the_CLT_required__c == null
                    ) {
                        message =
                            "Case cannot be closed if Injury or Escalated Complaint Required is blank. Please go back to the case and make the proper determination before closing your case.";
                        theme == "Warning";
                    } else if (
                        caseObject.AccountId == null ||
                        caseObject.ContactId == null ||
                        caseObject.AssetId == null ||
                        caseObject.Priority == null ||
                        caseObject.Status == null ||
                        caseObject.Reason == null ||
                        caseObject.Is_This_a_Complaint__c == null ||
                        caseObject.Local_Description__c == null ||
                        caseObject.OwnerId == null
                    ) {
                        if (caseObject.AccountId == null) {
                            missingField = "Account, ";
                        }
                        
                        if (caseObject.ContactId == null) {
                            missingField = missingField + "Contact, ";
                        }
                        
                        if (caseObject.AssetId == null) {
                            missingField = missingField + "Asset, ";
                        }
                        
                        if (caseObject.Priority == null) {
                            missingField = missingField + "Priority, ";
                        }
                        
                        if (caseObject.Status == null) {
                            missingField = missingField + "Status, ";
                        }
                        
                        if (caseObject.Reason == null) {
                            missingField = missingField + "Case Reason, ";
                        }
                        
                        if (caseObject.Local_Description__c == null) {
                            missingField = missingField + "Description, ";
                        }
                        
                        if (caseObject.Is_This_a_Complaint__c == null) {
                            missingField = missingField + "Complaint, ";
                        }
                        
                        if (caseObject.OwnerId == null) {
                            missingField = missingField + "OwnerId, ";
                        }
                        missingField = missingField.substring(0, missingField.length - 2);
                        message = "Please enter following fields: " + missingField;
                        theme == "Warning";
                    } else {
                        var evt = $A.get("e.force:navigateToComponent");
                        evt.setParams({
                            componentDef: "c:VFSL_CaseClosePageComponent",
                            componentAttributes: {
                                recordId: caseObject.Id,
                                caseType: cstype
                            }
                        });
                        evt.fire();
                        component.set("v.showPopup", false);
                        helper.hideSpinner(component, event, helper);
                    }
                    
                    if (theme == "Success") {
                        $A.util.addClass(cmpTarget, "slds-theme_success");
                    } else if (theme == "Failure") {
                        $A.util.addClass(cmpTarget, "slds-theme_error");
                    } else if (theme == "Warning") {
                        $A.util.addClass(cmpTarget, "slds-theme_warning");
                    }
                    component.set("v.message", message);
                    $A.util.removeClass(component.find("modaBox"), "slds-hide");
                    helper.hideSpinner(component, event, helper);
                });
                $A.enqueueAction(caseInfo);
            }
        }
    },
    closeModel: function(component, event, helper) {
        component.set("v.showPopup", false);
        $A.get("e.force:refreshView").fire();
    }
});