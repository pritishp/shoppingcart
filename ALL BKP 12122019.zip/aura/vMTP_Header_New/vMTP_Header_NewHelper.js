({
    loadInitData: function(component, event, helper) { 
        
        var action = component.get('c.initMethod');
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {    
                var wrList = response.getReturnValue();    
                component.set('v.wrapperList', wrList);
                component.set("v.authenticated", wrList.checkAuthenticatedUser);
                component.set("v.developer", wrList.checkDev);
                component.set("v.developerPending", wrList.checkDevRequest);
                component.set("v.cartItemCount", wrList.checkCartItemCount);
                component.set("v.stripeConnectURL", wrList.checkDevStripe);
                
                //fetch User Info
                var storeUserInfo = wrList.getUserInfo;                
                if(storeUserInfo.ContactId != null) {
                    component.set("v.isInternalUser", false);
                } else {
                    component.set("v.isInternalUser", true);
                    if( !(wrList.checkUserProfile === 'VMS VMarket Admin' || wrList.checkUserProfile === 'VMS System Admin' || wrList.checkUserProfile === 'System Administrator') ){
                        component.set("v.showThirdParty", false);
                    }
                }
                component.set("v.userInfo", storeUserInfo);
                component.set("v.loggedInUserCurrency", storeUserInfo.CurrencyIsoCode);                
            }
            else {
                component.set("v.authenticated", false);
                component.set("v.developer", false);
                component.set("v.developerPending", false);
                component.set("v.lstCurrencies", null);
            }
        });
        $A.enqueueAction(action);
    },
    
    
    isAuthenticated: function(component,event) {
        var action = component.get("c.isAuthenticatedUser");
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                // set searchResult list with return value from server.
                component.set("v.authenticated", response);
            } else {
                component.set("v.authenticated", false);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    
    isDeveloper: function(component,event) {
        var action = component.get("c.isDev");
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                // set searchResult list with return value from server.
                component.set("v.developer", response);
            } else {
                component.set("v.developer", false);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    isDeveloperPending: function(component,event) {        
        var action = component.get("c.isDevRequestPending");        
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();            
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                // set searchResult list with return value from server.
                component.set("v.developerPending", response);
            } else {
                component.set("v.developerPending", false);
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    cartItemCount: function(component,event) {        
        var action = component.get("c.getCartItemCount");        
        // set a callBack    
        action.setCallback(this, function(response) {          	
            var state = response.getState();            
            if (state === "SUCCESS") {
                var response = response.getReturnValue();
                // set searchResult list with return value from server.
                component.set("v.cartItemCount", response);
            } 
        });
        // enqueue the Action  
        $A.enqueueAction(action);
    },
    getUserInfo: function(component,event,helper){
        var action = component.get("c.fetchUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set current user information on userInfo attribute
                if(storeResponse.ContactId != null) {
                    component.set("v.isInternalUser", false);
                } else {
                    component.set("v.isInternalUser", true);
                    helper.getUserProfileName(component,event,helper);
                }
                component.set("v.userInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    authorizeDeveloperAccount : function(component){
        var stripeKey = this.getUrlParameter('code');
        var scopeValue = this.getUrlParameter('scope');
        if(stripeKey != '' && scopeValue != ''){
            var action = component.get("c.authorizeCustomerAccount");
            action.setParams({
                "customerStripeAccId": stripeKey,
                "scope": scopeValue
            });
            component.set("v.vMarketSpinner", true);
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.vMarketSpinner", false);
                }
            });
            $A.enqueueAction(action);
        }
    },
    
    getUrlParameter : function(sParam) {
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
        var sURLVariables = sPageURL.split('&');
        var sParameterName = [];
        var i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? '' : sParameterName[1];
            }
        }
        return '';
    },
    
    getPageName : function(){
        var pageName = decodeURIComponent(window.location);
        var pageNameArray = pageName.split('/');
        var pageNameArrayLength = pageNameArray.length;
        return pageNameArray[pageNameArrayLength-1];
    },
    getUserProfileName : function(component,event,helper) {
        var action = component.get("c.getUserProfile"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();         
            if( !(result === 'VMS VMarket Admin' || result === 'VMS System Admin' || result === 'System Administrator') ){
                component.set("v.showThirdParty", false);
            }
        });
        $A.enqueueAction(action);
    },
    
    navigateToCommunityPage : function(component, pageName){
        // console.log('-----navigateToAppAssetPage----');
        var appId = component.get('v.vMTPAppId');
        //console.log('---appId--'+appId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": '/'+pageName
        });
        urlEvent.fire();
    },
    handleLogout : function(component,event,helper) {
        var logoutUser = component.get("c.logoutUser");
        logoutUser.setCallback(this, function(response) {              
            var state = response.getState();
            if (state === "SUCCESS") {
                var logoutUrl = response.getReturnValue();
                window.location.replace('/apex/vMarketPlaceLogoutPage');
            }else{
            }
        });
        $A.enqueueAction(logoutUser);
    },
    getStripeConnectURL: function(component,event,helper) {
        var action = component.get("c.isDevStripeNotConnected");
        action.setCallback(this, function(response) {              
            var state = response.getState();
            if (state === "SUCCESS") {
                var stripeUrl =  response.getReturnValue();  
                component.set("v.stripeConnectURL", stripeUrl);
            }else{
                component.set("v.stripeConnectURL", '');	
            }
        });
        $A.enqueueAction(action);
    },
    
    getCurrencyType:function(component,event,helper,accountCurrency){
        var action = component.get("c.getCurrency");
        action.setParams({
            "accCurrency": accountCurrency                
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state==="SUCCESS"){ 
                var currType =  response.getReturnValue();  
                helper.getUserCartCurrency(component, event, helper, currType);
            }else{
                component.set("v.currencies", '');
            }
        });    
        $A.enqueueAction(action);
    },
    
    getUserCartCurrency:function(component,event,helper, cartCurr){
        component.set("v.lstCurrencies", cartCurr);
        var userdefaultCurr =  component.get("v.loggedInUserCurrency");        
        var action = component.get("c.getUserCartCurrency");
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state==="SUCCESS"){  
                var userCartCurr =  response.getReturnValue();    
                for(var i in cartCurr){
                    var curr = cartCurr[i].IsoCode;
                    if(curr == userCartCurr){
                        //alert(curr);
                        component.set("v.showlstCurrencies", true); 
                        component.set("v.cartCurrency",userCartCurr);
                        component.find("currencySelect").set("v.value", i + '-' + cartCurr[i].ConversionRate) ;
                        helper.handleUserSelecedCurrency(component, cartCurr[i].IsoCode,cartCurr[i].ConversionRate, 1);
                        component.set("v.oldConversionRate", cartCurr[i].ConversionRate);
                        break;
                    }                    
                }               
                
            }else{	
                //console.log('----ERROR--getUserCartCurrency--'+response.getError());
            }
        });    
        $A.enqueueAction(action);
    },    
    
    handleUserSelecedCurrency:function(component,currencyISOCode,ConvRate, oldConversionRate){
        var action = component.get("c.updateUserCartCurrency");
        action.setParams ({
            "currencyCode":currencyISOCode
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state==="SUCCESS"){            
                var appEvent = $A.get("e.c:vMC_CurrencyTypeEvent"); 
                appEvent.setParams({
                    "selectedCurrency" :currencyISOCode,
                    "conversionRate":ConvRate,
                    "oldConversionRate" : oldConversionRate,
                });       
                appEvent.fire(); 
            }
        });    
        $A.enqueueAction(action);
    },
    
    getAccountDetails : function(component,event,helper) {
        var acc= component.get("v.objAccount");
        if(!acc){
            var action = component.get("c.getAccountDetails"); 
            action.setCallback(this, function(a) {
                var result = a.getReturnValue();            
                var sizeObj = Object.keys(result).length;
                if(sizeObj > 0) {
                    component.set("v.isInternalUser",false);
                    component.set("v.objAccount", result);
                    var acc1= component.get("v.objAccount");
                    helper.getCurrencyType(component,event,helper,acc1.CurrencyIsoCode);
                } else {
                    component.set("v.isInternalUser",true);                    
                    helper.getCurrencyType(component,event,helper,'');
                }         
            });
            $A.enqueueAction(action);
        }
    },
    
})