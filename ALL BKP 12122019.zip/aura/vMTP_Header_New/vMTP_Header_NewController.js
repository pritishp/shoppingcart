({
    doInit : function(component, event, helper) {   
        helper.loadInitData(component,event,helper);
        helper.authorizeDeveloperAccount(component);
        helper.getAccountDetails(component, event, helper); 
        component.set("v.pageName", helper.getPageName());
    },
    
    openCartMessageModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.cartMessageModalOpen", true);
    }, 
    closeCartMessageModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.cartMessageModalOpen", false);
    },
    reloadCartCount : function(component, event, helper) {
        helper.cartItemCount(component,event);
    },
    handleSelectedMenu : function (component, event, helper) {
        var selectedMenuItemValue = event.getParam("value");
        if(selectedMenuItemValue == 'myOrders') {
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-all-orders"
            });
            urlEvent.fire();
        }
        if(selectedMenuItemValue == 'mySubscriptions') {
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-all-subscriptions"
            });
            urlEvent.fire();
        }
        if(selectedMenuItemValue == 'myDashboard') {
            window.location.href = '/varianMarketPlace/s/vmtp-landing-dev';
        }
        if(selectedMenuItemValue == 'connectWithStripe') {    
            var stripeURL = component.get('v.stripeConnectURL');                        
            window.open(
                stripeURL,
                '_blank' 
            );            
        }
        if(selectedMenuItemValue == 'myProfile') {
            var myProfileUrlEvent = $A.get("e.force:navigateToURL");
            myProfileUrlEvent.setParams({
                "url": "/varianMarketPlace/s/vmc-myprofile"
            });
            myProfileUrlEvent.fire();
        }
        if(selectedMenuItemValue == 'logout') {
            helper.handleLogout(component,event,helper);
        }
    },
    connectWithStripe : function (component, event, helper) {
        var stripeURL = component.get('v.stripeConnectURL');                        
        window.open(
            stripeURL,
            '_blank' 
        );     
    },
    userLogout: function (component, event, helper) {
    	helper.handleLogout(component,event,helper);       
    },
    openACHModal : function (component, event, helper) {
        component.set("v.isACHModalOpen", true);
    },
    openAppUploadPopup : function(component, event, helper){
        var popupComponent = component.find("uploadAppPopup");
        $A.util.addClass(popupComponent, 'slds-show');
        $A.util.removeClass(popupComponent, 'slds-hide');
    },
    
    executeAppUploadActions : function(component, event, helper){
        var clickedActionName = event.getSource().getLocalId();
        if(clickedActionName == 'openAppUploadPopup'){
            var popupComponent = component.find("uploadAppPopup");
            $A.util.addClass(popupComponent, 'slds-show');
            $A.util.removeClass(popupComponent, 'slds-hide');
        }else if(clickedActionName == 'newAppUpload'){
            helper.navigateToCommunityPage(component, "vmtp-appupload");
        }else if(clickedActionName == 'bugFix'){
            helper.navigateToCommunityPage(component, "vmtp-appbugfix");
        }else if(clickedActionName == "closeAppUploadPopup"){
            var popupComponent = component.find("uploadAppPopup");
            $A.util.addClass(popupComponent, 'slds-hide');
            $A.util.removeClass(popupComponent, 'slds-show');
        }
    },
    
    openCartPrev : function(component, event, helper) {
        var cmpTarget = component.find('modalDiv');
        $A.util.addClass(cmpTarget, 'slds-show');
        $A.util.removeClass(cmpTarget, 'slds-hide');
    },
    
    closeCartPrev : function(component, event, helper) {
        
        var cmpTarget = component.find('modalDiv');
        $A.util.addClass(cmpTarget, 'slds-hide');
        $A.util.removeClass(cmpTarget, 'slds-show');
        
    },
    
    handleCurrencyMenu: function(component, event, helper) { 
        var oldConversionRate = component.get("v.oldConversionRate");
        var index = component.find("currencySelect").get("v.value").split('-')[0];
        var currencyIsoCode = component.get("v.lstCurrencies")[index].IsoCode;  
        var ConversionRate = component.get("v.lstCurrencies")[index].ConversionRate;
        component.set("v.oldConversionRate", ConversionRate);
        helper.handleUserSelecedCurrency(component,currencyIsoCode,ConversionRate, oldConversionRate);
      
    },
    userDropdownToggle: function(component, event, helper) { 
    	document.getElementById("myDropdown").classList.toggle("show");
        
        // Close the dropdown menu if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    }     
})