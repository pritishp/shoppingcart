({
    getBAProducts : function(component) {
        var action = component.get("c.getBAProducts"); 
         action.setParams({
             "category" : component.get("v.appCategoryType")
        });
        action.setCallback(this, function(a) {
          var state = a.getState();            
            if(state=="SUCCESS"){
              var result = a.getReturnValue();
              console.log('rs ---->' + JSON.stringify(result)); 
              component.set("v.applicatorList", result);
              component.set("v.maxPage", Math.floor((result.length+9)/10));
              console.log('max ---->' +component.get("v.maxPage") ); 
              this.renderPage(component);
            } 
      });
      $A.enqueueAction(action);
	},
    
    renderPage: function(component) {
		var records = component.get("v.applicatorList"),
            pageNumber = component.get("v.pageNumber"),
            pageRecords = records.slice((pageNumber-1)*10, pageNumber*10);
            component.set("v.applicatorCurrentList", pageRecords);
        	console.log('pageRecords ---->' +pageRecords); 
	}
})