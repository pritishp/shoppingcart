({
	doInit : function(component, event, helper) {
       helper.getBAProducts(component);  
	},
    
    renderPage: function(component, event, helper) {
        helper.renderPage(component);
    },
    
    appDetailMouseOver: function(component, event, helper) {
        console.log('test=='+component.find("hover"));
        var items = component.find("hover");
        if(!items.length) items = [items];
        $A.util.removeClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    },
    
    appDetailMouseOut: function(component, event, helper) {
        console.log('test out=='+component.find("hover"));
        var items = component.find("hover");
        if(!items.length) items = [items];
        $A.util.addClass(items[parseInt(event.target.dataset.index)],'slds-hide');
    }
})