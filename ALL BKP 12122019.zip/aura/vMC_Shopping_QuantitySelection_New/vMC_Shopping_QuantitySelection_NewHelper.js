({
    setPaymentOptions: function (component) {
        var paymentOptions;
        if(component.get("v.ifCartHasThirdPartyApps")) {
            paymentOptions = [
            {'label': 'Credit Card', 'value': 'Credit Card'},
        ];
        } else {
            paymentOptions = [
            {'label': 'Credit Card', 'value': 'Credit Card'},
            {'label': 'PO', 'value': 'PO'}
        ];
        }
            
        
        component.set("v.paymentOptions", paymentOptions);        
    },
    
    removeProduct : function (component, event, helper, sfId, index, productType) {
        
        var action = component.get("c.deleteFromDB");
        action.setParams({ 
            itemId : sfId,
            itemType : productType
        });
        action.setCallback(this,function(response){
            if (response.getState() === "SUCCESS"){
                var resp =  response.getReturnValue();
                if(resp == true) {
                    helper.navigateToLandingPage (component, event, helper);
                }
                
                else {
                    var reloadCartEvent = $A.get("e.c:vMC_reloadCart");
                    reloadCartEvent.fire();
                    
                    var appEvent = $A.get("e.c:vMTP_reloadHeader");
                    appEvent.fire();
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    calculatePrice : function (component, event, helper, index, sfId, model) {
        var validity;
        if(component.find('qty')[index]) {
            validity = component.find('qty')[index].get("v.validity");
        } else {
            validity = component.find('qty').get("v.validity");
        }
        
        if(validity.valid)
            this.updateCartLineItemsQty(component, event, helper, sfId, model, index)
            },
    
    updateCartLineItemsQty : function (component, event, helper, sfId, model, index) {
        console.log('Update quantiy');
        var mapBrachyIdQty = new Object();
        var prodWrapper = component.get("v.marketPlaceProductArray");
        var prodWrapTemp = []; var prodResponseTemp = [];
        for(var i=0 ; i< prodWrapper.length; i++) {
            var total = 0; var totalQty = 0;
            
            if(prodWrapper[i].model == model) {
                for(var j=0; j< prodWrapper[i].response.length; j++) {
                    if(prodWrapper[i].response[j].itemline.Product__c == sfId) {
                        mapBrachyIdQty[prodWrapper[i].response[j].itemline.Product__c] = prodWrapper[i].response[j].quantity; 
                    }
                    totalQty = totalQty + parseInt(prodWrapper[i].response[j].quantity);
                    prodWrapper[i].qty = totalQty;
                    if(prodWrapper[i].response[j].itemline.Discounted_Price__c && prodWrapper[i].response[j].itemline.Discounted_Price__c!=0) {
                        total = total + (prodWrapper[i].response[j].quantity * prodWrapper[i].response[j].itemline.Discounted_Price__c);
                        prodWrapper[i].totalPrice = total;
                    }
                    else {
                        total = total + (prodWrapper[i].response[j].quantity * prodWrapper[i].response[j].itemline.Unit_Price__c);
                        prodWrapper[i].totalPrice = total;
                    }
                } 
            }
        }
        component.set("v.marketPlaceProductArray", prodWrapper);
        var action = component.get("c.updateCartLineItem");
        action.setParams({ 
            mapBrachyIdWithQuantity : mapBrachyIdQty,
            selectedPaymentMethod : null
        });
        action.setCallback(this,function(response){
            if (response.getState() === "SUCCESS"){
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
            }
            
            //component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    navigateToLandingPage : function (component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({ "url": '/'});
        urlEvent.fire();
    },
    
    getShippingMethodPicklist: function(component, event, helper){
        var action = component.get("c.fetchShippingMethod");
        var opts=[];
        action.setCallback(this, function(response) {
            var resp=response.getReturnValue();
            console.log('--rsp--'+JSON.stringify(resp));
            opts.push({"class": "optionClass", label: 'Customer Carrier', value:'Customer Carrier'});
            var shpCost;
            for(var i=0;i< resp.length;i++){
                shpCost = (resp[i].Shipping_Cost__c * component.get("v.conversionRate")).toFixed(2);
                opts.push({"class": "optionClass", label:resp[i].Shipping_Material_Label__c+' - '+component.get("v.currencyISOCode")+' '+shpCost, value: resp[i].Shipping_Material_Label__c});
            }
            
            component.set('v.shippingTypeLst',opts);
            var customerOpts=[];   
            for(var i=0;i< resp.length;i++){
                customerOpts.push({"class": "optionClass", label:resp[i].Shipping_Material_Label__c, value: resp[i].Shipping_Material_Label__c});
            }
            component.set('v.customShippingTypeLst',customerOpts);
            console.log('customShippingTypeLst ' +JSON.stringify(component.get('v.customShippingTypeLst')));
            console.log('shippingTypeLst ' +JSON.stringify(component.get('v.shippingTypeLst')));
        });
        
        $A.enqueueAction(action);
        
    },
    /*handlePaymentMethodEvent : function (component, event, helper) {
        var paymentEvent = component.getEvent("paymentMethodCheckEvent");
        paymentEvent.setParams({  "isPaymentMethodSelected" : true  });
        paymentEvent.fire();        
    },*/
    
})