({
    doInit : function (component, event, helper) {
        var vatCountries = component.get("v.VATCountries");
        var splitVatCountries = vatCountries.split(';')
        
        if (splitVatCountries.indexOf(component.get("v.accountInfo.ISO_Country__c")) > -1 )
            component.set('v.isVat',true);

        helper.setPaymentOptions (component);
        //alert('Quantity Selection ')
        window.scrollTo(0,0);
        /*var ReviewScreen = component.get("v.ifReviewScreen");       
        var totalPrice = component.get("v.cartTotalPrice");
        if(!ReviewScreen){
        if (totalPrice == 0)        
        helper.handlePaymentMethodEvent(component, event, helper);
        if (totalPrice >0) 
        {
            var radioGrpValue = component.find("paymentType").get("v.value");
            if (typeof radioGrpValue !== 'undefined' && (radioGrpValue === 'Credit Card'|| radioGrpValue === 'PO'))
                               	helper.handlePaymentMethodEvent(component, event, helper); 
                
        }
        }
        var totalPrice = component.get("v.cartTotalPrice");
        if (totalPrice > 0)
        {
            //set default payment type
            var paymentType = component.get('v.cart.Payment_Method__c');
            if( typeof paymentType === 'undefined' || paymentType === null || paymentType === '' ){
                component.set('v.cart.Payment_Method__c', 'Credit Card');
            }
        }*/
    },
    
    getSelectedPayment : function (component, event, helper) {
        var selectedOption = component.find("paymentType").get("v.value");
        component.set("v.cart.Payment_Method__c",selectedOption );
        //helper.handlePaymentMethodEvent(component, event, helper);
    },
    
    validatePaymentType : function (component, event, helper) {
        var formValidated = [component.find('paymentType')].reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields            
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        }, true);
        
        if(!formValidated){             
            component.set("v.processing", false);
            return false;
        }else{            
            
        }
    },
    removeProduct : function (component, event, helper) {
        var sfId = event.getSource().get("v.name");
        var index = event.getSource().get("v.class");
        var productType= event.getSource().get("v.iconClass");
        helper.removeProduct (component, event, helper, sfId, index, productType);
    },
    
    handleNext : function (component, event, helper) {
        helper.handleNext (component, event, helper);
    },
    
    calculatePrice : function (component, event, helper) {
        var index = event.getSource().get("v.name");
        var sfId = event.getSource().get("v.variant");
        var model = event.getSource().get("v.accesskey");
        helper.calculatePrice (component, event, helper, index, sfId, model);
    },
    
    disableQtyField : function (component, event, helper) {
        var qty = component.find('qty');
        if(qty.length) {
            for(var i=0; i< qty.length; i++) {
                component.find('qty')[i].set("v.disabled", true);
            }
        } else {
            component.find('qty').set("v.disabled", true);
        }
    },
    
    enableQtyField : function (component, event, helper) {
        var qty = component.find('qty');
        if(qty.length) {
            for(var i=0; i< qty.length; i++) {
                component.find('qty')[i].set("v.disabled", false);
            }
        } else {
            component.find('qty').set("v.disabled", false);
        }
    },
    
})