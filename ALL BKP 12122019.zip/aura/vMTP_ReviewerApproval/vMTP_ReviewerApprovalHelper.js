({
	     getUrlParameter : function (component, event) {
              /*component.set("v.teamName","Regulatory");
        component.set("v.appId","aD35C00000003IUSAY");
        component.set("v.country","US");*/
             console.log('pageref ' +JSON.stringify(component.get("v.pageReference").state));
             component.set('v.appId', component.get("v.pageReference").state.c__appId);
             component.set('v.countryCode', component.get("v.pageReference").state.c__con);
             component.set('v.typeName', component.get("v.pageReference").state.c__type);
             
             console.log('v.country' +component.get('v.countryCode') +' type -> ' +component.get("v.typeName"));
             if(component.get('v.appId')!= undefined && component.get('v.typeName')!= undefined && component.get('v.countryCode')!= undefined){
                 console.log('App paramenters set ');
                 this.getCheckAppDetails(component, event);
             }
        },
    
    getCheckAppDetails : function(component, event){
        console.log('getCheckAppDetails');
      	 var action = component.get("c.checkAppIdExist");
         action.setParams({
            appId : component.get("v.appId"),
            type  : component.get("v.typeName"),
            countryCode : component.get("v.countryCode")
         });
         action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS") {
                console.log('response -> ' +response.getReturnValue());
                component.set("v.appInfo", response.getReturnValue());
                var attachmentData = response.getReturnValue().appAttachementDetails;
                var countryAppattachmentData = response.getReturnValue().countryAppAttachementDetails;
                console.log(JSON.stringify(response.getReturnValue().reviewers));
                this.extractAttachments(component, attachmentData);
                if(countryAppattachmentData && countryAppattachmentData.length >0 )
                {
                    var attachmentObject = component.get('v.attachmentInfo');
                    for(var attachmentCounter in countryAppattachmentData){
                    var attachmentJSONObject = countryAppattachmentData[attachmentCounter];
                        if(attachmentJSONObject && attachmentJSONObject.docName){
                            if(attachmentJSONObject.docName.startsWith('510')){
                                attachmentObject["Form510k"] = attachmentJSONObject;
                            }
                            if(attachmentJSONObject.docName.startsWith('CE')){
                                attachmentObject["CEMark"] = attachmentJSONObject;
                            }
                            if(attachmentJSONObject.docName.startsWith('Declaration')){
                                attachmentObject["Conformity"] = attachmentJSONObject;
                            }
                        }
                   }
                      component.set("v.attachmentInfo", attachmentObject);
                }
                
            }else {
                $A.log("callback error", response.getError());
            }      
        });
        $A.enqueueAction(action);
    },
    
     extractAttachments : function(component, attachments){
        console.log('--extractAttachments--1-'+attachments);
        var appPackages = [];
        var attachmentObject = component.get('v.attachmentInfo');
           console.log('attachments -> ' + JSON.stringify(attachments));
        var screenShotName = '';
        for(var attachmentCounter in attachments){
            var attachmentJSONObject = attachments[attachmentCounter];
            if(attachmentJSONObject && attachmentJSONObject.docName){
                if(attachmentJSONObject.docName.startsWith('AppSource')){
                    console.log('Appsource -> ' + JSON.stringify(attachmentJSONObject));
                	appPackages.push(attachmentJSONObject);
                      attachmentObject["AppSource"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('AppBanner')){
                    attachmentObject["AppBanner"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('UserGuide')){
                    attachmentObject["AppGuide"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('AppGuide')){
                    attachmentObject["AppGuide"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('AppLogo')){
                    attachmentObject["AppLogo"] = attachmentJSONObject;
                }else if(attachmentJSONObject.docName.startsWith('Screenshot1')){
                    attachmentObject['Screenshot1'] = attachmentJSONObject;
                    screenShotName = 'Screenshot1';
                }else if(attachmentJSONObject.docName.startsWith('Screenshot2')){
                    attachmentObject['Screenshot2'] = attachmentJSONObject;
                    screenShotName = 'Screenshot2';
                }else if(attachmentJSONObject.docName.startsWith('Screenshot3')){
                    attachmentObject['Screenshot3'] = attachmentJSONObject;
                    screenShotName = 'Screenshot3';
                }else if(attachmentJSONObject.docName.startsWith('Screenshot4')){
                    attachmentObject['Screenshot4'] = attachmentJSONObject;
                    screenShotName = 'Screenshot4';
                }else if(attachmentJSONObject.docName.startsWith('CCATS')){
                    attachmentObject['CCATS'] = attachmentJSONObject;
                 }else if(attachmentJSONObject.docName.startsWith('techSpec')){
                    attachmentObject['techSpec'] = attachmentJSONObject;
                }
            	
            
            }    
        }
      /*  if(attachmentObject[screenShotName]){
            console.log('----attachmentObject[screenShotName]--'+JSON.stringify(attachmentObject[screenShotName]));
            component.set("v.vmcAppAssetId", attachmentObject[screenShotName].parentRecordId);
            component.find("vMAppAssetCreator").reloadRecord();
        }else{
			this.getNewRecordInstance(component, "vMTP_App_Asset__c","newVMAppAsset", "newVMAppAssetError", "vMAppAssetCreator", "vMAppAsset");            
        }*/
        component.set("v.data", appPackages);
         
        component.set("v.attachmentInfo", attachmentObject);
        console.log('---attachmentObject--'+JSON.stringify(attachmentObject));
         console.log('attachment data' +JSON.stringify(component.get("v.data")));
          console.log('attachmentObject ' +JSON.stringify(attachmentObject.CCATS).length);
        return appPackages;
    },
    
    setReAssignUser : function(component, event){
        console.log('setReAssignUser');
        var action = component.get("c.reAssignUser");
         action.setParams({
            appId : component.get("v.appId"),
            countryCode : component.get("v.countryCode"),
             reviewType : component.get("v.typeName"),
            changeComment : component.find("changeReviewerComments").get('v.value'),
            userId :  component.get("v.selectedReviewer")
         });
         action.setCallback(this, function(response) {
             console.log('Inside action ' +component.get("v.typeName"));
            var state = response.getState();
            if(state === "SUCCESS") {
                console.log('response -> ' +response.getReturnValue());
                 var result = response.getReturnValue(); 
                if(result == true){
                   //  $A.get('e.force:refreshView').fire();
                   this.getCheckAppDetails(component, event);
                }
                component.set("v.isReAssignApprovalModal", false);
            }
             else{
                 console.log('Inside else');
             }
         }); 
         $A.enqueueAction(action);
    },
    
     reviwerActionSubmission : function(component, event, helper) { 
        var status;
        console.log('In reviwerAction Submission');
        if(component.get("v.isApproved") )
            status = 'No Objection';
        else if(component.get("v.isReject") )
        	status ='Rejected';
        else if(component.get("v.isInfoNeeded") )
            status ='Info Requested';
        
        console.log('status Action ' +status);
        
        var action = component.get("c.reviwerAction");
        action.setParams({
            appId : component.get("v.appId"),
            countryCode : component.get("v.countryCode"),
            reviewType  : component.get("v.typeName"),
            comment : component.find("comments").get('v.value'),
            reviwerActionStatus : status
         });
        
        action.setCallback(this, function(response) {          	
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();               
               console.log('result ->' +result);
                if(result == 'NotInProgress'){
                    // $A.get('e.force:refreshView').fire();
                    console.log('App status not in Progress');
                }
                else if (result == 'success'){
                    console.log('Success');
                   var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                      "recordId": component.get("v.appId"),
                      "slideDevName": "related"
                    });
                    navEvt.fire();
                    
                }else
                    console.log('Exception');
            }
        });
        $A.enqueueAction(action);        
    },    
   
})