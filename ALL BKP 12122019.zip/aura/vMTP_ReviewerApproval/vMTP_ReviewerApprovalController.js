({
	
    doInit : function (component, event, helper) {
        helper.getUrlParameter(component, event);
    },
    download: function(component, event, helper){
        console.log("---download-1-");
        var attachId = event.target.name;
        window.open(window.location.protocol+'//'+window.location.hostname+'/sfc/servlet.shepherd/version/download/'+attachId);
    },
    
     handleChangeReviewer: function(component, event, helper){
        console.log("---handleChangeReviewer-");
		component.set("v.isReAssignApprovalModal", true);({
	
    doInit : function (component, event, helper) {
        helper.getUrlParameter(component, event);
    },
    download: function(component, event, helper){
        console.log("---download-1-");
        var attachId = event.target.name;
        window.open(window.location.protocol+'//'+window.location.hostname+'/sfc/servlet.shepherd/version/download/'+attachId);
    },
    
     handleChangeReviewer: function(component, event, helper){
        console.log("---handleChangeReviewer-");
		component.set("v.isReAssignApprovalModal", true);
     },
    
    closeModal: function(component, event, helper) { 
        component.set("v.isModalOpen", false);
       
    },
     closeReAssignModal: function(component, event, helper) { 
        component.set("v.isReAssignApprovalModal", false);
    },
    
    onChangeReviewer: function(component, event, helper){
        console.log("---onChangeReviewer-");
		  var selectedReviewer;
        if(component.find("reviewerList") != undefined) {
            selectedReviewer = component.find("reviewerList").get("v.value");
        }
        if(selectedReviewer === undefined) {
            selectedReviewer = '';
        }
       component.set("v.selectedReviewer", selectedReviewer);
        console.log('selectedReviewer ' +selectedReviewer);
     },
	
    handleReAssignUser :function(component, event, helper) { 
        component.set("v.isModalOpen", false);
       
        
      //  alert(component.find('reviewerList').get("v.label"));
         var validComments= [component.find('changeReviewerComments')].reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields            
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        	}, true); 
        //component.set("v.isReAssignApprovalModal", false);
        //
        if(validComments){
           // alert(component.get("v.selectedReviewer"));
            helper.setReAssignUser(component, event); 
        }
    },
    
     handleReviewerAction: function(component, event, helper) {
       //var validComments = component.validateComments(component, event, helper);
      var validComments= [component.find('comments')].reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields            
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        	}, true); 
        
       // console.log('isValid ' +validComments)
        if(validComments){
         	var clickedBtn = event.getSource().getLocalId();
        	console.log(clickedBtn);
          //  debugger;
            if(clickedBtn == "noObj") {
                console.log(clickedBtn );
                // $A.util.removeClass(component.find("appPubLishText"), "slds-hide");
                component.set("v.isApproved", true);              
                component.set("v.isReject", false);     
                component.set("v.isInfoNeeded", false); 
                component.set("v.isModalOpen", true);
            }
            else if(clickedBtn == "reject") {
                console.log(clickedBtn);
               component.set("v.isApproved", false);              
                component.set("v.isReject", true);     
                component.set("v.isInfoNeeded", false);
                component.set("v.isModalOpen", true);
            }
            else if(clickedBtn == "moreInfo") {
                 //$A.util.removeClass(component.find('appInfoReqText'), "slds-hide");
                component.set("v.isApproved", false);              
                component.set("v.isReject", false);
				component.set("v.isInfoNeeded", true);                
                helper.reviwerActionSubmission(component, event, helper);
            }  
            
     }
    },
    
      handleReviewSubmission: function(component, event, helper) { 
         console.log('in handleReviewSubmission Action ');
         helper.reviwerActionSubmission(component, event, helper);
        component.set("v.isModalOpen", false);
    },
    
     handleRowAction: function (cmp, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        console.log('Showing Details: ' + JSON.stringify(row));
        switch (action.name) {
            case 'download':
                window.open(window.location.protocol+'//'+window.location.hostname+'/sfc/servlet.shepherd/version/download/'+row.contentVersionId);
                //helper.downloadFile(row.contentVersionId);
                break;
           /* case 'delete':
                helper.deleteFiles(cmp, row.contentVersionId, 'AppSource' ,row.parentRecordId, helper);
                break;*/
        }
    }, 
   
})
     },
    
    closeModal: function(component, event, helper) { 
        component.set("v.isModalOpen", false);
       
    },
     closeReAssignModal: function(component, event, helper) { 
        component.set("v.isReAssignApprovalModal", false);
    },
    
    onChangeReviewer: function(component, event, helper){
        console.log("---onChangeReviewer-");
		  var selectedReviewer;
        if(component.find("reviewerList") != undefined) {
            selectedReviewer = component.find("reviewerList").get("v.value");
        }
        if(selectedReviewer === undefined) {
            selectedReviewer = '';
        }
       component.set("v.selectedReviewer", selectedReviewer);
        console.log('selectedReviewer ' +selectedReviewer);
     },
	
    handleReAssignUser :function(component, event, helper) { 
        component.set("v.isModalOpen", false);
       
        
      //  alert(component.find('reviewerList').get("v.label"));
         var validComments= [component.find('changeReviewerComments')].reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields            
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        	}, true); 
        //component.set("v.isReAssignApprovalModal", false);
        //
        if(validComments){
           // alert(component.get("v.selectedReviewer"));
            helper.setReAssignUser(component, event); 
        }
    },
    
     handleReviewerAction: function(component, event, helper) {
       //var validComments = component.validateComments(component, event, helper);
      var validComments= [component.find('comments')].reduce(function (validSoFar, inputCmp) {
            // Displays error messages for invalid fields            
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && inputCmp.get('v.validity').valid;
        	}, true); 
        
       // console.log('isValid ' +validComments)
        if(validComments){
         	var clickedBtn = event.getSource().getLocalId();
        	console.log(clickedBtn);
          //  debugger;
            if(clickedBtn == "noObj") {
                console.log(clickedBtn );
                // $A.util.removeClass(component.find("appPubLishText"), "slds-hide");
                component.set("v.isApproved", true);              
                component.set("v.isReject", false);     
                component.set("v.isInfoNeeded", false); 
                component.set("v.isModalOpen", true);
            }
            else if(clickedBtn == "reject") {
                console.log(clickedBtn);
               component.set("v.isApproved", false);              
                component.set("v.isReject", true);     
                component.set("v.isInfoNeeded", false);
                component.set("v.isModalOpen", true);
            }
            else if(clickedBtn == "moreInfo") {
                 //$A.util.removeClass(component.find('appInfoReqText'), "slds-hide");
                component.set("v.isApproved", false);              
                component.set("v.isReject", false);
				component.set("v.isInfoNeeded", true);                
                helper.reviwerActionSubmission(component, event, helper);
            }  
            
     }
    },
    
      handleReviewSubmission: function(component, event, helper) { 
         console.log('in handleReviewSubmission Action ');
         helper.reviwerActionSubmission(component, event, helper);
        component.set("v.isModalOpen", false);
    },
    
     handleRowAction: function (cmp, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        console.log('Showing Details: ' + JSON.stringify(row));
        switch (action.name) {
            case 'download':
                window.open(window.location.protocol+'//'+window.location.hostname+'/sfc/servlet.shepherd/version/download/'+row.contentVersionId);
                //helper.downloadFile(row.contentVersionId);
                break;
           /* case 'delete':
                helper.deleteFiles(cmp, row.contentVersionId, 'AppSource' ,row.parentRecordId, helper);
                break;*/
        }
    }, 
   
})