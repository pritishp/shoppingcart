({
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        helper.closeModel (component, event, helper);
    },
    
    addAccount : function(component, event, helper) {
        component.set("v.addACHAccount", true);
        component.set("v.achHomeScreen", false);
        component.set("v.allAccount", false);
        component.set('v.loadIframe', false);
        component.set("V.verificationModalOpen", false);
    },
    
    showAllAccounts : function (component, event, helper) {
        component.set("v.addACHAccount", false);
        component.set("v.achHomeScreen", false);
        component.set("v.allAccount", true);
        component.set('v.loadIframe', false);
        component.set("V.verificationModalOpen", false);
    },
    
    achHomeScreen : function(component, event, helper) {
        component.set("v.addACHAccount", false);
        component.set("v.achHomeScreen", true);
        component.set("v.allAccount", false);
        component.set('v.loadIframe', false);
        component.set("V.verificationModalOpen", false);
    },
    
    verifyAccountScreen : function (component, event, helper) {
        if(component.get("v.verificationModalOpen")) {
            component.set("v.addACHAccount", false);
            component.set("v.achHomeScreen", false);
            component.set("v.allAccount", false);
            component.set('v.loadIframe', false);
            component.set("V.verificationModalOpen", true);
        }   
    },
    
    onSubmit : function(component, event, helper) {
        var childCmp = component.find('addAccountAch');
        childCmp.validateFields();
        if(component.get("v.ifValid")) {
            component.set("v.addACHAccount", false);
            component.set('v.loadIframe', true);
            var routingNo = component.get("v.routingNo");
            var accountNo = component.get("v.accountNo");
            var accountName = component.get("v.accountName");
            var achMessage = routingNo + '#' + accountNo + '#' + accountName;
            var vfOrigin = "https://" + component.get("v.vfHost");
            setTimeout(function(){ var vfWindow = component.find("vfFrame").getElement().contentWindow;
                                  vfWindow.postMessage(achMessage, vfOrigin); }, 1000);
            
        }
    },
    
    verifyAccount : function(component, event, helper) {
        helper.verifyAccount(component, event, helper);
	},
})