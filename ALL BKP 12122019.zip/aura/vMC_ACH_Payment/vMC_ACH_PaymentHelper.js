({
	closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isACHModalOpen", false);
    },
    
    verifyAccount : function(component, event, helper) {
        var deposit1=component.find('deposit1').get("v.value");
        var deposit2=component.find('deposit2').get("v.value");
        var action = component.get("c.submitverification");
        action.setParams ({
            achId: component.get("v.achAccId"),
            deposit1 : deposit1,
            deposit2 : deposit2
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue(); 
                if(resp == true) {
                    component.set("v.verificationModalOpen", false);
                    component.set("v.allAccount", true);
                    helper.getACHAccount(component, event, helper);
                }
                
            }
        });
        $A.enqueueAction(action);
	},
})