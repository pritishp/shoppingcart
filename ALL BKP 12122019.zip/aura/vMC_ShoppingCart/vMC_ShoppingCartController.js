({
    doInit : function (component, event, helper) {
        helper.getAccountDetails(component, event, helper);
        helper.getContactInfo(component);
        component.set("v.processing", true);
        if(!component.get("v.ifReviewScreen")) {
            helper.getCartItems(component, event, helper);
        }
       // component.set("v.isSelected",true);
       /*if(!component.get("v.cart.Payment_Method__c"))
        {
			component.set("v.isSelected",true);
        }*/
        /* START:: Commenting ACH functionality
        helper.checkValidACHExists(component, event);
        END:: Commenting ACH functionality */
        window.scrollTo(0,0);
    },
    
    changeAccount : function (component) {
        var accModalBackdrop = component.find('accModalBackdrop');
        var accModal = component.find('accModal');
        $A.util.removeClass(accModalBackdrop, 'slds-hide');
        $A.util.removeClass(accModal, 'slds-hide');
    },
    
    showContent : function (component, event, helper) {
        var sourceTab = event.getSource().get('v.name');
        //alert('sourceTab----'+sourceTab);
        if(sourceTab=='btn2') {
            component.set("v.processing", true);
            //    var paymentType = component.find('paymentType').get('v.value');
            
            /* START:: Commenting ACH functionality
                if(paymentType == "ACH"){
                   var validACH = component.get("v.noValidAccs");
                   console.log(component.get("v.noValidAccs"));
                    if(validACH == true){
                         console.log(" validACH " +validACH);
                        component.set("v.showError",true);
                        return false;
                    }
                }
            END:: Commenting ACH functionality */
            
            var oldtab = component.find('tab2');
            var oldcontent = component.find('content2');
            var newtab = component.find('tab3');
            var newcontent = component.find('content3');     
            var paymentType = component.get('v.cart.Payment_Method__c');            
            if(paymentType) {
                helper.checkInventory(component, event, helper, oldtab, oldcontent, newtab, newcontent);
                component.set("v.isStep2", true);
            } else if(component.get("v.prodWrapper.length")>0){
                component.find('shoppingQtySelection').validatePayment();
                component.set("v.processing", false);
            } else {
                component.set("v.isStep2", true);
                helper.toggleNextContentHelper(component, oldtab, oldcontent, newtab, newcontent);
                component.set("v.processing", false);
            }
        }
        
        else if(sourceTab == 'Confirmbtn2') {
            component.set("v.processing", true);
            var oldtab = component.find('tab2');
            var oldcontent = component.find('content2');
            var newtab = component.find('tab3');
            var newcontent = component.find('content3');  
            component.find('shoppingQtySelection').enableQtyFld();
            component.find('selectQTyNext').set("v.label", 'Checkout');
            component.find('selectQTyNext').set("v.name", 'btn2');
            $A.util.addClass(component.find('updateQtyDiv'),'slds-hide');
            helper.toggleNextContentHelper(component, oldtab, oldcontent, newtab, newcontent);
            helper.updateCartLineItems (component, event, helper);
        }
        
        else if(sourceTab=='btn3') { 
            var oldtab = component.find('tab3');
            var oldcontent = component.find('content3');
            var newtab = component.find('tab4');
            var newcontent = component.find('content4');
            
            var childCmp = component.find("orderInfo");
            var auraMethodResult = childCmp.userFields();
            console.log(childCmp.get("v.fieldValues")[0].shippingMethod);
            
            //validate Order Info
            childCmp.validateOrderInfo();
            var stepThreeValid = childCmp.get("v.stepThreeValid");
            console.log('shopping cart - stepThreeValid=='+stepThreeValid);
            if(!stepThreeValid){                	
                return false;
            }
            console.log('destination ' +component.get("v.shipToErp.ERP_Partner_Number__c"));
            if(childCmp.get("v.fieldValues") && childCmp.get("v.fieldValues")[0].destination) {
                var shipToNumber = childCmp.get("v.fieldValues")[0].destination.ERP_Partner_Number__c;
            } else {
                var shipToNumber = component.get("v.shipToErp.ERP_Partner_Number__c");
            }
            helper.callWebservice (component, oldtab, oldcontent, newtab, newcontent,shipToNumber,helper);
            component.set("v.loadReviewScreen", true);
            helper.toggleNextContentHelper(component, oldtab, oldcontent, newtab, newcontent);
                
        }
        window.scrollTo(0,0);
        
    },
    
    showPreviousContent : function (component, event, helper) {
        var sourceTab = event.getSource().get('v.name');
        if(sourceTab=='backbtn2') {
            var oldtab = component.find('tab2');
            var oldcontent = component.find('content2');
            var newtab = component.find('tab1');
            var newcontent = component.find('content1');
            component.find('selectQTyNext').set("v.label", 'Checkout');
            component.find('selectQTyNext').set("v.name", 'btn2');
            helper.togglePreviousContentHelper(component, oldtab, oldcontent, newtab, newcontent);
        }
        
        if(sourceTab=='updateQty') {
            $A.util.addClass(component.find('updateQtyDiv'),'slds-hide');
            component.find('selectQTyNext').set("v.label", 'Checkout');
            component.find('selectQTyNext').set("v.name", 'btn2');
            component.find('shoppingQtySelection').enableQtyFld();
        }
        
        else if(sourceTab=='backbtn3') {
            var oldtab = component.find('tab3');
            var oldcontent = component.find('content3');
            var newtab = component.find('tab2');
            var newcontent = component.find('content2');
            component.set("v.loadReviewScreen", false);
            component.set("v.isStep2", false);
            helper.togglePreviousContentHelper(component, oldtab, oldcontent, newtab, newcontent);
        }
        
            else if(sourceTab=='backbtn4') {
                var oldtab = component.find('tab4');
                var oldcontent = component.find('content4');
                var newtab = component.find('tab3');
                var newcontent = component.find('content3');
                helper.togglePreviousContentHelper(component, oldtab, oldcontent, newtab, newcontent);
            }
        window.scrollTo(0,0);
    },
    
    placeOrder : function (component, event, helper) {
        component.set("v.isModalOpen", true);
    },
    
    proceedToPayment : function (component, event, helper) {
        var oldtab = component.find('tab4');
        var oldcontent = component.find('content4');
        var newtab = component.find('tab5');
        var newcontent = component.find('content5');
        helper.toggleNextContentHelper(component, oldtab, oldcontent, newtab, newcontent);
    },
    
   /* enableCheckOutButton: function (component, event, helper) { 
        //alert('js');
        helper.enableCheckOut(component, event, helper);
    },  
    */
    
    checkInventoryValidation: function (component, event, helper) {        
        helper.checkInventory(component, event, helper, '', '', '', '');
    }
    
})