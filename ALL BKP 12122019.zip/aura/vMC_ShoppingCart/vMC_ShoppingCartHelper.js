({
    toggleNextContentHelper : function(component, oldtab, oldcontent, newtab, newcontent) {
        $A.util.removeClass(oldtab, 'slds-is-current');
        $A.util.addClass(oldtab, 'slds-is-complete');
        $A.util.addClass(oldcontent, 'slds-hide');
        $A.util.removeClass(newtab, 'slds-is-incomplete');
        $A.util.addClass(newtab, 'slds-is-current');
        $A.util.removeClass(newcontent, 'slds-hide');
    },
    
    togglePreviousContentHelper : function(component, oldtab, oldcontent, newtab, newcontent) {
        $A.util.removeClass(oldtab, 'slds-is-current');
        $A.util.addClass(oldtab, 'slds-is-incomplete');
        $A.util.addClass(oldcontent, 'slds-hide');
        $A.util.removeClass(newtab, 'slds-is-complete');
        $A.util.addClass(newtab, 'slds-is-current');
        $A.util.removeClass(newcontent, 'slds-hide');
    },
    
    setBreadCrumbs : function (component, event, helper) {
        if(component.get('v.isInternalUser')) {
            var breadcrumbCollection = [
                {label: 'Home', name: 'all products' },
                {label: 'Brachy', name: 'brachy products'}
                //{label: 'Order Detail', name: 'orderDetailPage' , orderId: component.get("v.orderId")}
            ];
        } else {
            var breadcrumbCollection = [
                {label: 'Home', name: 'all products' },
                {label: 'Third Party Apps', name: 'thirdParty products'},
                {label: 'Brachy', name: 'brachy products'},
                //{label: 'Order Detail', name: 'orderDetailPage' , orderId: component.get("v.orderId")}
            ];
        }
        
        component.set('v.breadcrumbCollection', breadcrumbCollection);
    },
    
    checkInventory: function (component, event, helper, oldtab, oldcontent, newtab, newcontent) {
               
        var action = component.get("c.checkInventory");
        var paymentMethod =component.get("v.cart.Payment_Method__c");
        var brachyWrapper = component.get("v.prodWrapper");
        var productIds = []; var isValidate = true;
        for(var i=0 ; i< brachyWrapper.length; i++) {
            productIds.push(brachyWrapper[i].resp.itemline.Brachy_Product__r.ProductCode);
            delete brachyWrapper[i]['errorDescription'];
            if(isNaN(parseInt(brachyWrapper[i].resp.quantity))) {
                brachyWrapper[i].error = 'Please enter a valid number.';
                isValidate = false;
            }
            else if(parseInt(brachyWrapper[i].resp.quantity) < 1) {
                brachyWrapper[i].error = 'Qunatity cannot be less than 1.';
                isValidate = false;
            } 
                else if(parseInt(brachyWrapper[i].resp.quantity) > 999 && paymentMethod=='PO') {
                    brachyWrapper[i].error = 'For PO, Maximum quantity accepted is 999.';
                    isValidate = false;
                }
            else if(paymentMethod=='Credit Card' && brachyWrapper[i].resp.maxQuantity && parseInt(brachyWrapper[i].resp.quantity) > parseInt(brachyWrapper[i].resp.maxQuantity)) {
                brachyWrapper[i].error = 'Maximum Quantity Allowed: '+  brachyWrapper[i].resp.maxQuantity;
                    isValidate = false;
                }
                    else {
                        delete brachyWrapper[i]['error'];
                    }
            if(!isValidate)
                component.set("v.prodWrapper",brachyWrapper);
        }
        action.setParams ({
            prodIds: productIds
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
              
            if (state === "SUCCESS") {
                var isNext = true; var isPONext = true;
                var inventory = response.getReturnValue();
                var inventoryCodeList=[];
                console.log('inventory'+JSON.stringify(inventory));
                component.set('v.inventoryMap', inventory);
                for(var i=0 ; i< brachyWrapper.length; i++) {
                    for (var key in inventory) {
                        if(i==0)
                            inventoryCodeList.push(key);
                        if (brachyWrapper[i].resp.itemline.Brachy_Product__r.ProductCode == key) {
                            var Unrestricted_Quantity1=0; var Unrestricted_Quantity2=0;
                            if(inventory[key][0]) {
                                Unrestricted_Quantity1= parseInt(inventory[key][0].Unrestricted_Quantity__c) ;
                            }
                            if(inventory[key][1]) { 
                                Unrestricted_Quantity2= parseInt(inventory[key][1].Unrestricted_Quantity__c)  ;
                            }
                            
                            var totalQuantityPerProduct = Unrestricted_Quantity1+ Unrestricted_Quantity2;
                            
                            if(totalQuantityPerProduct!=0) {
                                brachyWrapper[i].errorDescription = '';
                                if(inventory[key][0]) {
                                    brachyWrapper[i].errorDescription = brachyWrapper[i].errorDescription + parseInt(inventory[key][0].Unrestricted_Quantity__c) + ' in ' +inventory[key][0].Plant_Description__c;
                                }
                                if(inventory[key][0] && inventory[key][1])  {
                                    brachyWrapper[i].errorDescription = brachyWrapper[i].errorDescription + ' and ';
                                }
                                if(inventory[key][1]) {
                                    brachyWrapper[i].errorDescription = brachyWrapper[i].errorDescription + parseInt(inventory[key][1].Unrestricted_Quantity__c) + ' in ' +inventory[key][1].Plant_Description__c;
                                }
                            }
                            
                            if(parseInt(brachyWrapper[i].resp.quantity) >  totalQuantityPerProduct && paymentMethod!='PO') {
                                if(totalQuantityPerProduct==0) {
                                    brachyWrapper[i].error = 'Not in stock. Please remove this product the shopping cart.'
                                } else {
                                    brachyWrapper[i].error = 'Only '+totalQuantityPerProduct +' in stock. Please revise the Qty to <='+totalQuantityPerProduct +'.';
                                }
                                isNext = false; isPONext= false;
                            }
                            else if(parseInt(brachyWrapper[i].resp.quantity) >  totalQuantityPerProduct && paymentMethod=='PO') {
                                brachyWrapper[i].error ="Not enough in inventory. Some order items will be in back order and expect the lead time up to two weeks, or you'll receive the further notice."
                                isNext = false;
                            }
                                else if(brachyWrapper[i].error) {
                                    delete brachyWrapper[i]['error'];
                                } 
                            
                        } 
                    }
                    if(inventoryCodeList.indexOf(brachyWrapper[i].resp.itemline.Brachy_Product__r.ProductCode)<0) {
                        brachyWrapper[i].error = 'No inventory info for this product. Please remove from the shopping cart.';
                        isNext = false;
                    }
                }
                
                if( oldtab !== '' && oldcontent !== '' && newtab !== '' && newcontent !== '' ){
                    if(isNext && isPONext) {
                    	helper.toggleNextContentHelper(component, oldtab, oldcontent, newtab, newcontent);
                    	helper.updateCartLineItems (component, event, helper);
                    }
                    if(isPONext && !isNext && paymentMethod=='PO') {
                        component.find('shoppingQtySelection').disableQtyFld();
                        component.find('selectQTyNext').set("v.label", 'Confirm');
                        component.find('selectQTyNext').set("v.name", 'Confirmbtn2');
                        $A.util.removeClass(component.find('updateQtyDiv'),'slds-hide');
                        $A.util.addClass(component.find('updateQtyDiv'),'slds-show');
                    }
                }
            }
            component.set("v.prodWrapper",brachyWrapper);
            setTimeout(function(){ component.set("v.processing", false) }, 1500);
        });
        if(isValidate)
            $A.enqueueAction(action);
        else
            component.set("v.processing", false);
    },
    
    updateCartLineItems : function (component, event, helper) {
        var mapBrachyIdQty = new Object();
        var brachyWrapper = component.get("v.prodWrapper");
        for(var i=0 ; i< brachyWrapper.length; i++) {
            mapBrachyIdQty[brachyWrapper[i].resp.itemline.Brachy_Product__c] = brachyWrapper[i].resp.quantity; 
            if(brachyWrapper[i].error) {
                delete brachyWrapper[i]['error'];
            } 
        }
        var action = component.get("c.updateCartLineItem");
        action.setParams({ 
            mapBrachyIdWithQuantity : mapBrachyIdQty,
            selectedPaymentMethod : component.get("v.cart.Payment_Method__c")
        });
        action.setCallback(this,function(response){
            if (response.getState() === "SUCCESS"){
                var appEvent = $A.get("e.c:vMTP_reloadHeader");
                appEvent.fire();
            }
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
    
    getCartItems : function(component, event, helper) {        
        component.set("v.processing", true);
        var action = component.get("c.getCartItemLineList");        
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                var resp =  response.getReturnValue();
                console.log('getCartItems Response='+resp);
                var appTotalPrice=0; var brachyTotalPrice=0;
                var appTotalQty=0; var brachyTotalQty=0;
                if(resp && resp.length) {
                    component.set("v.isInternalUser", resp[0].isInternalUser);
                    component.set("v.userAccount", resp[0].userAccountId);
                    component.set("v.cart", resp[0].cartItem);
                    console.log('order placed by---'+resp[0].cartItem.CreatedBy.Name);
                   	component.set("v.OrderPlacedBy",resp[0].cartItem.CreatedBy.Name);
                    component.set("v.shipToErp", resp[0].shipToErp);
                    component.set("v.billToErp", resp[0].billToErp);
                    component.set("v.orderContact", resp[0].cartOrderContact);
                    console.log('accountId in getCartItems==='+JSON.stringify(resp[0].cartItem));
                    var appList =[];
                    var prodList =[];
                    for(var i=0 ; i < resp.length; i++) {
                        if(resp[i].vMTPApp) {
                            appList.push({
                                resp: resp[i],
                                subsPrice :resp[i].appSubPrice,
                                appSubTerm :resp[i].appSubTerm
                            });
                            
                            appTotalPrice = appTotalPrice + resp[i].vMTPApp.Price__c + resp[i].appSubPrice;
                            appTotalQty = appTotalQty + resp[i].quantity;
                            if(resp[i].vMTPApp.subscription__c)
                            {
                                console.log('Subscription Item');
                                component.set("v.isSubscription", true);
                            }
                        }
                        if(resp[i].itemline) {
                            prodList.push({
                                resp: resp[i],
                                total : resp[i].prodDiscount * resp[i].quantity,
                            });
                            brachyTotalPrice = brachyTotalPrice + (resp[i].prodDiscount * resp[i].quantity);
                            
                            brachyTotalQty = brachyTotalQty + resp[i].quantity;
                        }
                    }
                }
                component.set("v.appTotalPrice",  appTotalPrice);
                component.set("v.brachyTotalPrice",   brachyTotalPrice);
                component.set("v.appTotalQty",  appTotalQty);
                component.set("v.brachyTotalQty",   brachyTotalQty);
                component.set("v.appWrapper", appList);
                component.set("v.prodWrapper", prodList);
                component.set("v.processing", false); 
            }
            component.set("v.blankScreen", false);
        });
        $A.enqueueAction(action);
    },
    
    callWebservice : function (component, oldtab, oldcontent, newtab, newcontent,shipToNumber,helper) {
        component.set("v.processing", true);
        /*var shipToNumber='';
         if(component.get("v.selectedShipToRecord").ERP_Partner_Number__c){
              shipToNumber=component.get("v.selectedShipToRecord").ERP_Partner_Number__c;
         }*/
        console.log('selected shipping---'+component.get("v.selectedShippingMethod"));
         var action = component.get("c.getShippingDataFromSAP");
         var brachyWrapper = component.get("v.prodWrapper");
         console.log('brachyWrapper--->>'+JSON.stringify(brachyWrapper));
         var appWrapper = component.get("v.appWrapper");
         var baProdCodePriceMap=[];var tpAppPriceList=[];
         var finalPrice=0;
        
        console.log('finalPrice--'+finalPrice);
         for(var i=0 ; i< brachyWrapper.length; i++) {
             if(!!brachyWrapper[i].resp.prodDiscount){
                 finalPrice=brachyWrapper[i].resp.prodDiscount;
             }
             else{
                 finalPrice=brachyWrapper[i].resp.itemline.Brachy_Product__r.NA_Target_Price__c; 
             }
             baProdCodePriceMap.push({
                 pCode: brachyWrapper[i].resp.itemline.Brachy_Product__r.ProductCode,
                 pQty: brachyWrapper[i].resp.quantity,
                 price :finalPrice,
             });
         }
         
         for(var j=0 ; j< appWrapper.length; j++) {
             if(appWrapper[j].subsPrice > 0)
                  tpAppPriceList.push(appWrapper[j].subsPrice);
             else
             	tpAppPriceList.push(appWrapper[j].resp.vMTPApp.Price__c);
         }
         console.log('tpAppPriceList ' + JSON.stringify(tpAppPriceList));
         action.setParams ({
             shipToNumber:shipToNumber,
             accountId:component.get("v.userAccount"),
             baProdCodePriceMap: JSON.stringify(baProdCodePriceMap),
             tpAppPriceList : tpAppPriceList,
             selShippingMethod :component.get("v.selectedShippingMethod")
         }); 
         action.setCallback(this, function(response) {
             var state = response.getState();
             if (state === "SUCCESS") {
                 var result = response.getReturnValue();
                 console.log('resp='+JSON.stringify(result));
                 // component.set("v.CalloutResponseWrapper", resp);
                 var shippingPrice=0; var brachyTax=0 ; var thirdPartyTax=0;                 
                 var appTotalPrice=0; var brachyTotalPrice=0;
                 var appTotalQty=0; var brachyTotalQty=0;
                 // var shippingPrice=0; var brachyTax=0 ; var thirdPartyTax=0;
                 if(result && result.IT_ITEMS_PRICE_OUT && result.IT_ITEMS_PRICE_OUT.length) {
                     for(var i=0 ; i < result.IT_ITEMS_PRICE_OUT.length; i++) {
                         if(result.IT_ITEMS_PRICE_OUT[i].MATERIAL==='TAX_MARKETPLACE_AP') {
                             for(var item in appWrapper) {
                                 var appPrice;
                                 var appSubPrice = appWrapper[item].resp.appSubPrice;
                                 if(appSubPrice != 0 && appWrapper[item].resp.appSubPrice.toString().indexOf('.') !== -1)
                                     appPrice = appWrapper[item].resp.appSubPrice.toString().split(".")[0];
                                 else if(appSubPrice != 0 && appWrapper[item].resp.appSubPrice.toString().indexOf('.') == -1)
                                     appPrice = appWrapper[item].resp.appSubPrice;
                                 else if(appSubPrice == 0 && appWrapper[item].resp.vMTPApp.Price__c.toString().indexOf('.') !== -1)
                                 	appPrice = appWrapper[item].resp.vMTPApp.Price__c.toString().split(".")[0];
                                 else if(appSubPrice == 0 && appWrapper[item].resp.vMTPApp.Price__c.toString().indexOf('.') == -1)
                                 	appPrice = appWrapper[item].resp.vMTPApp.Price__c;
                                  
                                 if(appPrice == result.IT_ITEMS_PRICE_OUT[i].PRICE.toString().split(".")[0]) {
                                     appWrapper[item].tax = result.IT_ITEMS_PRICE_OUT[i].TAX;
                                 } 
                             }
                             thirdPartyTax=thirdPartyTax+parseFloat(result.IT_ITEMS_PRICE_OUT[i].TAX);  
                         }
                         else if(result.IT_ITEMS_PRICE_OUT[i].MATERIAL_DESCR.includes("Freight")){
                             shippingPrice=shippingPrice+parseFloat(result.IT_ITEMS_PRICE_OUT[i].PRICE);
                         }
                         else{
                            for(var j=0 ; j < brachyWrapper.length; j++) {
                                 if(result.IT_ITEMS_PRICE_OUT[i].MATERIAL===brachyWrapper[j].resp.itemline.Brachy_Product__r.ProductCode) {
                                     brachyTax=brachyTax+parseFloat(result.IT_ITEMS_PRICE_OUT[i].TAX);
                                 } 
                                 brachyTotalPrice = brachyTotalPrice + (parseFloat(result.IT_ITEMS_PRICE_OUT[i].PRICE) * brachyWrapper[j].resp.quantity);
                                 brachyTotalQty = brachyTotalQty + brachyWrapper[j].resp.quantity;
                            }
                         }
                     }
                     component.set("v.appWrapper", appWrapper);
                     component.set("v.brachyShippingPrice", shippingPrice);
                     component.set("v.brachyTax", brachyTax);
                     component.set("v.thirdPartyTax", thirdPartyTax);
                     helper.updateCart (component, event, helper);
                 } else {
                     component.set("v.processing", false);
                     if(result.IT_RETURN && result.IT_RETURN[0]) 
                         helper.showToast(component, result.IT_RETURN[0].MESSAGE, 'Error', 'Error');
                     else 
                         helper.showToast(component, 'Error in getting Shipping and Tax Response', 'Error', 'Error'); 
                     	
                 }
                 /*  if(childCmp.get("v.fieldValues")[0].shippingMethod=='Customer Carrier') {
                    shippingPrice=0;
                }*/
                
                //component.set("v.loadReviewScreen", true);
                
                //component.set("v.processing", false);
                //setTimeout(function(){ component.set("v.processing", false) }, 2000);
            }
             
        });
         $A.enqueueAction(action);
         
     },
    
    getAccountDetails : function(component,event,helper) {
        var action = component.get("c.getAccountDetails"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();         
            var sizeObj = Object.keys(result).length;
            if(sizeObj > 0) {
                component.set("v.isInternalUser",false);
                component.set("v.accountInfo", result);
            } else {
                component.set("v.isInternalUser",true);
                //check if Cart has account
                helper.getAccountFromCart(component,event,helper);
            }
            helper.setBreadCrumbs (component, event, helper);
            
        });
        $A.enqueueAction(action);
    },
    getAccountFromCart: function(component,event,helper) {
        var action = component.get("c.getAccountFromCart"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            console.log(JSON.stringify(result));
            var accObj = JSON.parse(result[0]);
            var cartCount = parseInt(result[1]);
            console.log('accObj=='+JSON.stringify(accObj));
            console.log('cartCount=='+cartCount);            
            var sizeObj = Object.keys(accObj).length;
            if(sizeObj > 0) {
                component.set("v.accountInfo", accObj); 
            }            
        }); 
        $A.enqueueAction(action);        
    },
    getContactInfo : function(component) {
        var action = component.get("c.getContactDetails"); 
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            if(result!== '' && result!==null){
                component.set("v.contactInfo" , result);
            }
        });
        $A.enqueueAction(action);
    },
    updateCart : function (component, event, helper) {
       
        var action = component.get("c.updateCart");
        var thirdPartyApps = component.get("v.appWrapper");
        var brachyProds = component.get("v.prodWrapper");
        var totalPrice = component.get("v.appTotalPrice") + component.get("v.brachyTotalPrice") +
            component.get("v.brachyTax") + component.get("v.thirdPartyTax") + component.get("v.brachyShippingPrice");
        
        var wrapper = { 
            thirdParty : [] ,
            brachy : []
        };
        
        if(component.get("v.selectedPaymentType") !='PO') {
            for(var i=0; i< thirdPartyApps.length; i++) {
                var tpJsonData = {};
                tpJsonData['appId'] = thirdPartyApps[i].resp.vMTPApp.Id;
                tpJsonData['unitPrice'] = thirdPartyApps[i].resp.vMTPApp.Price__c;
                tpJsonData['qty'] = 1;
                tpJsonData['rId'] = 'Third Party App';
                tpJsonData['tax'] =  thirdPartyApps[i].tax;
                wrapper.thirdParty.push(tpJsonData);
            }
        }
        
        for(var i=0; i< brachyProds.length; i++) {
            var brachyJsonData = {};
            brachyJsonData['prodId'] = brachyProds[i].resp.itemline.Brachy_Product__c;
            brachyJsonData['unitPrice'] = brachyProds[i].resp.itemline.Brachy_Product__r.NA_Target_Price__c;
            brachyJsonData['qty'] = brachyProds[i].resp.quantity;
            brachyJsonData['prodCode'] = brachyProds[i].resp.itemline.Brachy_Product__r.ProductCode;
            brachyJsonData['rId'] = 'Brachy Product';
            brachyJsonData['discountedPrice'] =  brachyProds[i].resp.prodDiscount;
            wrapper.brachy.push(brachyJsonData);
        }
        component.get("v.fv.destination.label");
        var shipToAddress = ''; var billToAddress = '';
        if( component.get("v.fv.destination") ){
            shipToAddress += component.get("v.fv.destination.Partner_Street__c");
            if( component.get("v.fv.destination.Partner_Street_line_2__c") !== '' && (typeof (component.get("v.fv.destination.Partner_Street_line_2__c")) !== 'undefined')){
                shipToAddress += ', ' + component.get("v.fv.destination.Partner_Street_line_2__c");
            }
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_City__c");
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_State__c");
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_Zipcode_postal_code__c");
            shipToAddress += ', ' + component.get("v.fv.destination.Partner_Country__c");
        }
        console.log('shipToAddress'+shipToAddress);
        if( component.get("v.fv.billingAddress") ){
            billToAddress += component.get("v.fv.billingAddress.Partner_Street__c");
            if( component.get("v.fv.billingAddress.Partner_Street_line_2__c") !== '' && (typeof (component.get("v.fv.destination.Partner_Street_line_2__c")) !== 'undefined')){
                billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_Street_line_2__c");
            }
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_City__c");
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_State__c");
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_Zipcode_postal_code__c");
            billToAddress += ', ' + component.get("v.fv.billingAddress.Partner_Country__c");
        }
        console.log('billingAddress'+billToAddress);
        var shipTo = component.get("v.fv")[0].destination.Id;
        var billTo = component.get("v.fv")[0].billingAddress.Id;
        var shippingInfo = component.get("v.fv")[0];
        console.log('shippingInfo 1--->'+JSON.stringify(shippingInfo.destination));
        delete shippingInfo.billingAddress;
        delete shippingInfo.destination;
        console.log('shippingInfo-2-->'+JSON.stringify(shippingInfo));
        var shippingInfoObject =[];
        shippingInfoObject.push(shippingInfo);
        console.log('shippingInfoObject--->'+JSON.stringify(shippingInfoObject));
        console.log('Estimated date--->'+component.get("v.ExpectedDeliveryDate"));
        action.setParams({
            thirdPartyJSON: JSON.stringify(wrapper.thirdParty),
            brachyJSON : JSON.stringify(wrapper.brachy),
            tPtax : component.get("v.thirdPartyTax"),
            brachytax : component.get("v.brachyTax"),
            brachyShippingCost : component.get("v.brachyShippingPrice"),
           // paymentMethod : component.get("v.selectedPaymentType"),
            paymentMethod : component.get("v.cart.Payment_Method__c"),
            accountId:component.get("v.userAccount"),
            shipToId : shipTo,
            billToId : billTo,
            shipToAddress: shipToAddress,
            billToAddress: billToAddress,
            userFieldValues : JSON.stringify(shippingInfoObject),
            isInternalUserFlag : component.get("v.isInternalUser"),
            estimatedDelDate:component.get("v.ExpectedDeliveryDate"),
        })
        action.setCallback(this, function(a) {
            component.find('confirmOrder').set("v.disabled", false);
            component.set("v.processing", false);
        });
        $A.enqueueAction(action);
    },
        
        showToast : function(component, errorMessage, errorType, errorTitle) {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": errorTitle,
                "message": errorMessage,
                "type" : errorType,
                "mode" : 'sticky',
            });
            toastEvent.fire(); 
        },            
        /*enableCheckOut: function(component,event,helper) {            
        var pMethod = event.getParam("isPaymentMethodSelected"); 
            console.log('pMethod----'+pMethod);
            //alert('pMethod----'+pMethod);
            if(pMethod)
        	component.set("v.checkOutButtonDisabled", false); 
            else            
            component.set("v.checkOutButtonDisabled", true);            
    },     */    
    /* START:: Commenting ACH functionality
    checkValidACHExists : function(component,event) {
        var action = component.get("c.getVerifiedACHCustomer");
        console.log("checkValidACHExists");
        action.setCallback(this, function(response) {
            var result = response.getReturnValue();
            if(result!== '' && result!==null){
                console.log('Result for ACH ' +result);
                if(result == false){
                    component.set("v.noValidAccs",true);
                    console.log(result);
                }
            }
        });
        $A.enqueueAction(action);
    }
    END:: Commenting ACH functionality */
})